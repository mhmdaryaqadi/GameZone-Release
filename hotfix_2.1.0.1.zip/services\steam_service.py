import os
import winreg
import subprocess
import time
import threading
import re

def get_steam_path():
    """Detect local Steam path from Windows registry with standard fallback."""
    try:
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, r"Software\Valve\Steam") as key:
            steam_path = winreg.QueryValueEx(key, "SteamPath")[0]
            return os.path.normpath(steam_path)
    except Exception:
        return r"C:\Program Files (x86)\Steam"

def get_all_steamapps_paths():
    """
    Detect ALL Steam library folders (multi-drive support).
    Parses libraryfolders.vdf to find steamapps on C:, D:, E:, etc.
    Returns a list of absolute paths to steamapps directories.
    """
    steam_path = get_steam_path()
    if not steam_path:
        return []
    
    libraries = [steam_path]
    vdf_path = os.path.join(steam_path, "steamapps", "libraryfolders.vdf")
    if os.path.exists(vdf_path):
        try:
            with open(vdf_path, "r", encoding="utf-8") as f:
                content = f.read()
                paths = re.findall(r'"path"\s+"([^"]+)"', content)
                for p in paths:
                    libraries.append(p.replace("\\\\", "\\"))
        except Exception:
            pass
    
    # Deduplicate (case-insensitive on Windows)
    unique_libs = []
    seen = set()
    for lib in libraries:
        norm = os.path.normpath(lib).lower()
        if norm not in seen:
            seen.add(norm)
            unique_libs.append(lib)
    
    # Return only existing steamapps paths
    result = []
    for lib in unique_libs:
        apps_path = os.path.join(lib, "steamapps")
        if os.path.exists(apps_path):
            result.append(apps_path)
    
    return result

def is_steam_running():
    """Check if any Steam process (steam.exe, steamwebhelper.exe) is currently active."""
    try:
        out = subprocess.check_output('tasklist /FI "IMAGENAME eq steam*"', shell=True).decode('utf-8', errors='ignore')
        out_lower = out.lower()
        return "steam.exe" in out_lower or "steamwebhelper.exe" in out_lower
    except Exception:
        return False

def force_stop_steam():
    """Forcefully terminate all Steam processes only when explicitly required."""
    processes = ["steam.exe", "steamwebhelper.exe", "steamservice.exe", "GameOverlayUI.exe"]
    for proc in processes:
        try:
            subprocess.run(f'taskkill /F /T /IM {proc}', shell=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        except Exception:
            pass

def restart_steam(status_callback=None, force=False, appids_to_patch=None, depot_manifests_map=None, buildids_map=None):
    """
    Cleanly and gracefully restart Steam (CloudRedirect methodology).
    Asks Steam to shut down gracefully via 'steam.exe -shutdown', polls until
    Steam releases file locks & flushes config to disk, then relaunches cleanly.
    This prevents 'Purchase' errors caused by abrupt process termination (taskkill).
    """
    steam_base = get_steam_path()
    steam_exe = os.path.join(steam_base, "steam.exe")
    if not os.path.exists(steam_exe):
        steam_exe = r"C:\Program Files (x86)\Steam\steam.exe"

    if status_callback:
        status_callback("Menutup Steam...")

    # 1. Instantly terminate Steam process silently without popup dialog window
    if is_steam_running():
        force_stop_steam()
        time.sleep(1.0)

    # 2. Short pause for OS file lock release
    time.sleep(1.0)

    # 4b. Patch appmanifest files while Steam is completely closed
    if appids_to_patch:
        if isinstance(appids_to_patch, (int, str)):
            appids_to_patch = [appids_to_patch]
        for aid in appids_to_patch:
            try:
                aid_str = str(aid)
                d_map = None
                b_id = None
                if depot_manifests_map:
                    d_map = depot_manifests_map.get(aid_str) or depot_manifests_map.get(int(aid_str) if str(aid_str).isdigit() else aid_str)
                if buildids_map:
                    b_id = buildids_map.get(aid_str) or buildids_map.get(int(aid_str) if str(aid_str).isdigit() else aid_str)

                if status_callback:
                    status_callback(f"Memperbarui status manifest game ({aid})...")
                patch_appmanifest_state(aid, latest_buildid=b_id, depot_manifests=d_map, force_installed_state=False)
            except Exception:
                pass

    # 5. ALWAYS clear appinfo.vdf & packageinfo.vdf before relaunching Steam.
    #    These cache files store "not owned" license status. If they exist on next
    #    launch, Steam reads the cached "not owned" faster than SteamTools can hook,
    #    causing the Purchase button. Deleting them forces Steam to do a fresh API
    #    check which SteamTools properly intercepts to show Play.
    if status_callback:
        status_callback("Membersihkan cache lisensi Steam...")
    appcache_dir = os.path.join(steam_base, "appcache")
    for cache_file in ("appinfo.vdf", "packageinfo.vdf"):
        cache_path = os.path.join(appcache_dir, cache_file)
        try:
            if os.path.exists(cache_path):
                os.remove(cache_path)
        except Exception:
            pass

    # 6. Relaunch Steam
    if status_callback:
        status_callback("Memuat ulang Steam...")
    try:
        subprocess.Popen([steam_exe])
        if status_callback:
            status_callback("Steam berhasil dimuat ulang!")
    except Exception as e:
        if status_callback:
            status_callback(f"Gagal membuka Steam: {e}")

def restart_steam_async(status_callback=None, on_error_cb=None, force=False, appids_to_patch=None, depot_manifests_map=None, buildids_map=None):
    """Restart Steam asynchronously in a background thread."""
    def _worker():
        try:
            restart_steam(
                status_callback=status_callback,
                force=force,
                appids_to_patch=appids_to_patch,
                depot_manifests_map=depot_manifests_map,
                buildids_map=buildids_map
            )
        except Exception as e:
            if on_error_cb:
                on_error_cb(str(e))
    threading.Thread(target=_worker, daemon=True).start()

def is_game_installed_or_updating(appid):
    """
    Smart detection:
    Returns True if the game is already installed or was in the middle of updating/downloading.
    Returns False if it's a brand new game / fresh download.
    """
    all_steamapps = get_all_steamapps_paths()
    if not all_steamapps:
        return False
        
    for sa_path in all_steamapps:
        for sub in ("downloading", "temp"):
            if os.path.exists(os.path.join(sa_path, sub, str(appid))):
                return True
                
        candidate = os.path.join(sa_path, f"appmanifest_{appid}.acf")
        if os.path.exists(candidate):
            try:
                with open(candidate, "r", encoding="utf-8", errors="ignore") as f:
                    content = f.read()
                    m = re.search(r'"StateFlags"\s+"(\d+)"', content)
                    if m:
                        sf = int(m.group(1))
                        if sf not in (0, 1026):
                            return True
                    b_down = re.search(r'"BytesDownloaded"\s+"([1-9]\d*)"', content)
                    if b_down:
                        return True
            except Exception:
                return True
    return False

def is_game_update(appid):
    """
    Returns True if the game is an EXISTING installation undergoing an UPDATE.
    Returns False if it's a fresh new download.
    """
    all_steamapps = get_all_steamapps_paths()
    if not all_steamapps:
        return False
        
    for sa_path in all_steamapps:
        candidate = os.path.join(sa_path, f"appmanifest_{appid}.acf")
        if os.path.exists(candidate):
            try:
                with open(candidate, "r", encoding="utf-8", errors="ignore") as f:
                    content = f.read()
                    
                # Check SizeOnDisk > 0 (game files exist on disk from previous version)
                m_size = re.search(r'"SizeOnDisk"\s+"([1-9]\d*)"', content)
                if m_size:
                    return True

                # Check StateFlags & 4 != 0 (installed bit)
                m = re.search(r'"StateFlags"\s+"(\d+)"', content)
                if m:
                    sf = int(m.group(1))
                    if (sf & 4) != 0 or sf not in (0, 1026):
                        return True
            except Exception:
                pass
    return False


def _clear_steam_license_cache(steam_base=None):
    """Delete appinfo.vdf and packageinfo.vdf so Steam does a fresh license check on next start."""
    if not steam_base:
        steam_base = get_steam_path()
    appcache_dir = os.path.join(steam_base, "appcache")
    for cache_file in ("appinfo.vdf", "packageinfo.vdf"):
        cache_path = os.path.join(appcache_dir, cache_file)
        try:
            if os.path.exists(cache_path):
                os.remove(cache_path)
        except Exception:
            pass


def _install_steam_cleaner_task(steam_base=None):
    """
    Register a logon autorun entry (HKCU registry) that deletes appinfo.vdf
    on every Windows login. Uses HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Run
    which does NOT require admin privileges.

    This ensures manual Steam restarts (not through GameZone) also always start
    fresh without the cached 'not owned' license data.
    """
    import winreg
    import subprocess
    if not steam_base:
        steam_base = get_steam_path()
    appcache_dir = os.path.join(steam_base, "appcache")

    # Create a .bat file in AppData that does the cleanup
    bat_dir = os.path.join(os.environ.get("APPDATA", ""), "GameZone")
    try:
        os.makedirs(bat_dir, exist_ok=True)
    except Exception:
        return False

    bat_path = os.path.join(bat_dir, "steam_license_cleaner.bat")
    bat_content = (
        "@echo off\r\n"
        f'del /f /q "{os.path.join(appcache_dir, "appinfo.vdf")}" 2>nul\r\n'
        f'del /f /q "{os.path.join(appcache_dir, "packageinfo.vdf")}" 2>nul\r\n'
    )
    try:
        with open(bat_path, "w", encoding="ascii") as f:
            f.write(bat_content)
    except Exception:
        return False

    # Register in HKCU Run key (no admin needed, runs on logon)
    try:
        reg_key = winreg.OpenKey(
            winreg.HKEY_CURRENT_USER,
            r"Software\Microsoft\Windows\CurrentVersion\Run",
            0, winreg.KEY_SET_VALUE
        )
        winreg.SetValueEx(reg_key, "GameZone_SteamCacheClear", 0, winreg.REG_SZ, f'"{bat_path}"')
        winreg.CloseKey(reg_key)
        return True
    except Exception:
        return False


def is_steam_cleaner_task_installed():
    """Returns True if the HKCU logon autorun registry entry exists."""
    import winreg
    try:
        reg_key = winreg.OpenKey(
            winreg.HKEY_CURRENT_USER,
            r"Software\Microsoft\Windows\CurrentVersion\Run",
            0, winreg.KEY_READ
        )
        _, _ = winreg.QueryValueEx(reg_key, "GameZone_SteamCacheClear")
        winreg.CloseKey(reg_key)
        return True
    except Exception:
        return False


def uninstall_steam_cleaner_task():
    """Remove the HKCU logon autorun registry entry and bat script."""
    import winreg
    success = False
    try:
        reg_key = winreg.OpenKey(
            winreg.HKEY_CURRENT_USER,
            r"Software\Microsoft\Windows\CurrentVersion\Run",
            0, winreg.KEY_SET_VALUE
        )
        winreg.DeleteValue(reg_key, "GameZone_SteamCacheClear")
        winreg.CloseKey(reg_key)
        success = True
    except Exception:
        pass

    bat_path = os.path.join(os.environ.get("APPDATA", ""), "GameZone", "steam_license_cleaner.bat")
    if os.path.exists(bat_path):
        try:
            os.remove(bat_path)
        except Exception:
            pass
    return success


def toggle_steam_cleaner_task(enable: bool):
    """Enable or disable the logon autorun cleaner task."""
    if enable:
        return _install_steam_cleaner_task()
    else:
        return uninstall_steam_cleaner_task()



def fix_purchase_loop(appids=None, status_callback=None):
    """
    Fix the alternating Purchase <-> Play bug on SteamTools injected games — PERMANENTLY.

    ROOT CAUSE: appinfo.vdf (Steam license cache) stores "not owned" status for injected
    games. On Steam startup, this cache is read BEFORE SteamTools can hook the license
    check API, so Steam shows Purchase. When appinfo.vdf is absent, Steam does a fresh
    API check which SteamTools properly intercepts — hence 'clear download cache' always
    fixes it.

    Three-step permanent fix:
      1. Unlock ACF files (if we read-only locked them before — that was a mistake).
      2. Patch ACF fields (UpdateResult=0, remove FullValidate flags — so Steam doesn't
         trigger extra license checks on top of the cache issue).
      3. Delete appinfo.vdf + packageinfo.vdf so the next Steam start does a fresh check.
      4. Install a Windows Task Scheduler task to auto-delete appinfo.vdf on every logon,
         so manual Steam restarts also work correctly without needing GameZone.
    """
    import stat as _stat
    import subprocess
    steam_base = get_steam_path()
    all_steamapps = get_all_steamapps_paths()
    if not all_steamapps:
        return False, "Tidak dapat menemukan direktori Steam."

    # --- Step 1: Collect all appmanifest targets ---
    targets = []
    if appids:
        for aid in (appids if isinstance(appids, (list, tuple)) else [appids]):
            for sa in all_steamapps:
                p = os.path.join(sa, f"appmanifest_{aid}.acf")
                if os.path.exists(p):
                    targets.append(p)
    else:
        for sa in all_steamapps:
            try:
                for f in os.listdir(sa):
                    if f.startswith("appmanifest_") and f.endswith(".acf"):
                        targets.append(os.path.join(sa, f))
            except Exception:
                pass

    if not targets:
        return False, "Tidak ada file appmanifest yang ditemukan."

    patched = 0
    for acf_path in targets:
        try:
            # Unlock read-only (our previous fix was WRONG — read-only makes Steam confused)
            try:
                os.chmod(acf_path, _stat.S_IWRITE | _stat.S_IREAD)
                subprocess.run(["attrib", "-R", acf_path], capture_output=True)
            except Exception:
                pass

            with open(acf_path, "r", encoding="utf-8", errors="ignore") as f:
                content = f.read()
            original = content

            # Patch ACF fields that trigger extra license re-checks
            content = re.sub(r'"UpdateResult"\s+"[^"]*"', '"UpdateResult"\t\t"0"', content)
            content = re.sub(r'\t?"FullValidateBeforeNextUpdate"\s+"[^"]*"\r?\n?', '', content)
            content = re.sub(r'\t?"FullValidateAfterNextUpdate"\s+"[^"]*"\r?\n?', '', content)
            content = re.sub(r'"ScheduledAutoUpdate"\s+"[^"]*"', '"ScheduledAutoUpdate"\t\t"0"', content)
            content = re.sub(r'"DownloadType"\s+"[^"]*"', '"DownloadType"\t\t"0"', content)
            if '"AutoUpdateBehavior"' in content:
                content = re.sub(r'"AutoUpdateBehavior"\s+"[^"]*"', '"AutoUpdateBehavior"\t\t"1"', content)

            # Write back (leave writable so Steam can update playtime etc.)
            with open(acf_path, "w", encoding="utf-8") as f:
                f.write(content)

            if content != original:
                patched += 1
        except Exception:
            pass

    # --- Step 2: Delete appinfo.vdf + packageinfo.vdf RIGHT NOW ---
    # This is the REAL fix. Without these files, Steam does a fresh API license check
    # on next startup, which SteamTools properly intercepts to show Play.
    _clear_steam_license_cache(steam_base)

    # --- Step 3: Install a Windows Scheduled Task for manual Steam restarts ---
    # Runs on every Windows logon to delete appinfo.vdf before first Steam open.
    _install_steam_cleaner_task(steam_base)

    return True, (
        f"Fix selesai! {patched} manifest diperbaiki, cache lisensi Steam dihapus.\n"
        f"Sekarang buka Steam — akan tampil tombol Play. Task otomatis juga sudah dipasang "
        f"agar tetap bekerja setelah restart Windows."
    )


def patch_appmanifest_state(appid, latest_buildid=None, depot_manifests=None, force_installed_state=False):

    """
    Patch appmanifest_{appid}.acf across all Steam libraries.
    If force_installed_state=True:
        Sets StateFlags=4 (Fully Installed & Up to Date), UpdateResult=0,
        resets download byte counters to 0, and cleans up downloading/temp folders.
        Use ONLY when game is fully installed on disk.
    If force_installed_state=False (Default for downloading/NetFix):
        Preserves downloading/temp folders, preserves StateFlags and download counters,
        and ONLY updates InstalledDepots manifest GIDs and buildid.
        This allows Steam to seamlessly resume downloading without file validation!
    """
    import stat
    import shutil
    import requests
    
    all_steamapps = get_all_steamapps_paths()
    if not all_steamapps:
        return False
    
    # 1. Clean stuck update cache folders ONLY if force_installed_state is True
    if force_installed_state:
        for sa_path in all_steamapps:
            for sub in ("downloading", "temp"):
                d = os.path.join(sa_path, sub, str(appid))
                if os.path.exists(d):
                    try:
                        shutil.rmtree(d, ignore_errors=True)
                    except Exception:
                        pass

    # 2. Find target appmanifest files in ALL steamapps directories
    target_acfs = []
    for sa_path in all_steamapps:
        candidate = os.path.join(sa_path, f"appmanifest_{appid}.acf")
        if os.path.exists(candidate):
            target_acfs.append(candidate)

    if not target_acfs:
        primary_steamapps = all_steamapps[0]
        acf_path = os.path.join(primary_steamapps, f"appmanifest_{appid}.acf")
        default_acf_content = f'''"AppState"
{{
\t"appid"\t\t"{appid}"
\t"Universe"\t\t"1"
\t"name"\t\t"AppID {appid}"
\t"StateFlags"\t\t"1026"
\t"installdir"\t\t"AppID {appid}"
\t"LastUpdated"\t\t"{int(time.time())}"
\t"UpdateResult"\t\t"0"
\t"buildid"\t\t"0"
\t"InstalledDepots"
\t{{
\t}}
}}
'''
        try:
            with open(acf_path, "w", encoding="utf-8") as f:
                f.write(default_acf_content)
            target_acfs.append(acf_path)
        except Exception:
            pass
        except Exception:
            return False

    # 3. If latest_buildid or depot_manifests not provided, try fetching from SteamCMD API
    if not latest_buildid or not depot_manifests:
        try:
            url = f"https://api.steamcmd.net/v1/info/{appid}"
            res = requests.get(url, timeout=12)
            if res.status_code == 200:
                data = res.json().get("data", {}).get(str(appid), {})
                depots = data.get("depots", {})
                if not latest_buildid:
                    latest_buildid = depots.get("branches", {}).get("public", {}).get("buildid")
                if not depot_manifests:
                    depot_manifests = {}
                    for k, v in depots.items():
                        if isinstance(v, dict) and "manifests" in v:
                            gid = v.get("manifests", {}).get("public", {}).get("gid")
                            if gid:
                                depot_manifests[str(k)] = str(gid)
        except Exception:
            pass

    for acf_path in target_acfs:
        try:
            os.chmod(acf_path, stat.S_IWRITE | stat.S_IREAD)
        except Exception:
            pass

        try:
            with open(acf_path, "r", encoding="utf-8", errors="ignore") as f:
                content = f.read()

            if latest_buildid:
                content = re.sub(r'"buildid"\s+"\d+"', f'"buildid"\t\t"{latest_buildid}"', content)
                content = re.sub(r'"TargetBuildID"\s+"\d+"', f'"TargetBuildID"\t\t"{latest_buildid}"', content)

            content = re.sub(r'"UpdateResult"\s+"\d+"', '"UpdateResult"\t\t"0"', content)

            if force_installed_state:
                content = re.sub(r'"StateFlags"\s+"\d+"', '"StateFlags"\t\t"4"', content)
                content = re.sub(r'"ScheduledAutoUpdate"\s+"\d+"', '"ScheduledAutoUpdate"\t\t"0"', content)
                content = re.sub(r'"BytesToDownload"\s+"\d+"', '"BytesToDownload"\t\t"0"', content)
                content = re.sub(r'"BytesDownloaded"\s+"\d+"', '"BytesDownloaded"\t\t"0"', content)
                content = re.sub(r'"BytesToStage"\s+"\d+"', '"BytesToStage"\t\t"0"', content)
                content = re.sub(r'"BytesStaged"\s+"\d+"', '"BytesStaged"\t\t"0"', content)

            if depot_manifests:
                if '"InstalledDepots"' not in content:
                    content = re.sub(r'(\}\s*)$', '\t"InstalledDepots"\n\t{\n\t}\n\\1', content)

                for did, mid in depot_manifests.items():
                    did_str = str(did)
                    mid_str = str(mid)
                    pat = rf'("{did_str}"\s*\{{\s*"manifest"\s+")[0-9]+(")'
                    if re.search(pat, content):
                        content = re.sub(pat, rf'\g<1>{mid_str}\2', content)
                    else:
                        depot_block = f'\t\t"{did_str}"\n\t\t{{\n\t\t\t"manifest"\t\t"{mid_str}"\n\t\t}}\n'
                        if '"InstalledDepots"' in content:
                            content = re.sub(r'("InstalledDepots"\s*\{)', rf'\1\n{depot_block}', content)

            with open(acf_path, "w", encoding="utf-8") as f:
                f.write(content)
        except Exception:
            pass

    return True
