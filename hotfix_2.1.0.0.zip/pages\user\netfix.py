import customtkinter
import tkinter.messagebox as messagebox
import threading
import os
import requests
import zipfile
import shutil
import time
from services.steam_service import get_steam_path
ALREADY_FIXED_APPIDS = set()
class NoConnectionFixPage(customtkinter.CTkFrame):
    def __init__(self, parent, db_manager):
        super().__init__(parent, fg_color="transparent")
        self.db_manager = db_manager
        
        # Bind klik background untuk close dropdown
        self.winfo_toplevel().bind("<Button-1>", self.on_window_click, add="+")
        
        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(0, weight=0)
        self.grid_rowconfigure(1, weight=1)
        
        # Title Container to prevent overlaps on fullscreen/resizing
        title_container = customtkinter.CTkFrame(self, fg_color="transparent")
        title_container.grid(row=0, column=0, sticky="w", padx=25, pady=(15, 0))
        
        lbl_page_title = customtkinter.CTkLabel(title_container, text="Internet Fix", font=customtkinter.CTkFont(family="Segoe UI Black", size=28), text_color="#000000")
        lbl_page_title.pack(side="left")
        
        customtkinter.CTkLabel(title_container, text="✦", font=("Segoe UI Black", 24), text_color="#FFD800", fg_color="#FFFFFF").pack(side="left", padx=(15, 0))
        customtkinter.CTkLabel(title_container, text="🙂", font=("Segoe UI Emoji", 26), fg_color="#FFFFFF").pack(side="left", padx=(5, 0))
        
        main_frame = customtkinter.CTkFrame(self, fg_color="#FFFFFF", border_width=3, border_color="#000000", corner_radius=0)
        main_frame.grid(row=1, column=0, sticky="nsew", padx=25, pady=(15, 25))
        main_frame.grid_columnconfigure(0, weight=1)
        
        lbl_title = customtkinter.CTkLabel(main_frame, text="Koneksi Bermasalah?", font=customtkinter.CTkFont(family="Segoe UI Black", size=24), text_color="#000000")
        lbl_title.grid(row=0, column=0, pady=(50, 5))
        
        desc_text = "Perbaiki error 'Tidak ada koneksi internet' saat download game di Steam.\nPastikan game sedang dalam antrean download / gagal di Steam."
        lbl_desc = customtkinter.CTkLabel(main_frame, text=desc_text, font=customtkinter.CTkFont(family="Segoe UI Black", size=14), text_color="#333333", justify="center")
        lbl_desc.grid(row=1, column=0, pady=(0, 40))
        
        self.selected_appid = None
        self._search_timer = None
        
        # Search Container to keep search entry and ornaments together on resize
        search_container = customtkinter.CTkFrame(main_frame, fg_color="transparent")
        search_container.grid(row=2, column=0, pady=(0, 20))
        
        customtkinter.CTkLabel(search_container, text="*", font=("Segoe UI Black", 40), text_color="#5D5FEF", fg_color="#FFFFFF").pack(side="left", padx=(0, 15))
        
        self.entry_appid = customtkinter.CTkEntry(search_container, placeholder_text="Cari nama game atau masukkan AppID...", width=350, height=45, font=customtkinter.CTkFont(family="Segoe UI", size=14, weight="bold"), fg_color="#FFFFFF", text_color="#000000", border_width=3, border_color="#000000", corner_radius=0, justify="center")
        self.entry_appid.pack(side="left")
        self.entry_appid.bind("<KeyRelease>", self.on_search_type)
        self.entry_appid.bind("<FocusIn>", self.on_search_focus)
        
        customtkinter.CTkLabel(search_container, text="✨", font=("Segoe UI Emoji", 26), fg_color="#FFFFFF").pack(side="left", padx=(15, 0))
        
        self.search_results_frame = customtkinter.CTkScrollableFrame(main_frame, fg_color="#FFFFFF", border_width=3, border_color="#000000", corner_radius=0, height=180)
        
        self.btn_fix = customtkinter.CTkButton(main_frame, text="Fix Sekarang", font=customtkinter.CTkFont(family="Segoe UI Black", size=16), text_color="#000000", fg_color="#FF499E", hover_color="#E63F8A", corner_radius=0, border_width=3, border_color="#000000", height=45, width=250, command=self.start_fix)
        self.btn_fix.grid(row=3, column=0, pady=(0, 20))
        
        self.btn_guide = customtkinter.CTkButton(main_frame, text="📖 Baca Panduan", font=customtkinter.CTkFont(family="Segoe UI Black", size=12), text_color="#000000", fg_color="#FFD800", hover_color="#E6C300", border_width=3, border_color="#000000", corner_radius=0, width=150, height=35, command=self.open_guide)
        self.btn_guide.grid(row=4, column=0, pady=(0, 25))
        
        # Manifest Pinning / Protection Container (Fitur dari CloudRedirect)
        pin_container = customtkinter.CTkFrame(main_frame, fg_color="#F8F9FA", border_width=3, border_color="#000000", corner_radius=0)
        pin_container.grid(row=5, column=0, sticky="ew", padx=30, pady=(0, 30))
        pin_container.grid_columnconfigure(0, weight=1)
        
        lbl_pin_title = customtkinter.CTkLabel(pin_container, text="📌 MANIFEST LOCK & ANTI AUTO-UPDATE", font=customtkinter.CTkFont(family="Segoe UI Black", size=14), text_color="#000000")
        lbl_pin_title.pack(anchor="w", padx=15, pady=(12, 4))
        
        lbl_pin_desc = customtkinter.CTkLabel(pin_container, text="Kunci file manifest depot agar Steam tidak memaksa auto-update yang merusak file lisensi game.", font=customtkinter.CTkFont(family="Segoe UI", size=11, weight="bold"), text_color="#555555", justify="left")
        lbl_pin_desc.pack(anchor="w", padx=15, pady=(0, 10))
        
        btn_pin_frame = customtkinter.CTkFrame(pin_container, fg_color="transparent")
        btn_pin_frame.pack(anchor="w", padx=15, pady=(0, 12))
        
        self.btn_pin_toggle = customtkinter.CTkButton(btn_pin_frame, text="🔒 KUNCI MANIFEST (PIN)", font=customtkinter.CTkFont(family="Segoe UI Black", size=12), text_color="#FFFFFF", fg_color="#5D5FEF", hover_color="#4B4DDB", border_width=2, border_color="#000000", corner_radius=0, height=32, command=self.toggle_manifest_pin)
        self.btn_pin_toggle.pack(side="left", padx=(0, 10))
        
        self.lbl_pin_status = customtkinter.CTkLabel(btn_pin_frame, text="Status: Pilihlah game terlebih dahulu", font=customtkinter.CTkFont(family="Segoe UI", size=11, weight="bold"), text_color="#666666")
        self.lbl_pin_status.pack(side="left")


    def toggle_manifest_pin(self):
        if not self.selected_appid:
            messagebox.showwarning("Peringatan", "Silakan pilih game dari pencarian terlebih dahulu!", parent=self.winfo_toplevel())
            return
        
        from services.steam_pinning_service import is_manifest_pinned, pin_manifest, unpin_manifest
        currently_pinned = is_manifest_pinned(self.selected_appid)
        
        if currently_pinned:
            ok, msg = unpin_manifest(self.selected_appid)
        else:
            ok, msg = pin_manifest(self.selected_appid)
            
        if ok:
            messagebox.showinfo("Sukses", msg, parent=self.winfo_toplevel())
            self.update_pin_status_ui()
        else:
            messagebox.showerror("Gagal", msg, parent=self.winfo_toplevel())

    def update_pin_status_ui(self):
        if not self.selected_appid:
            self.lbl_pin_status.configure(text="Status: Pilihlah game terlebih dahulu", text_color="#666666")
            self.btn_pin_toggle.configure(text="🔒 KUNCI MANIFEST (PIN)", fg_color="#5D5FEF", hover_color="#4B4DDB")
            return
            
        from services.steam_pinning_service import is_manifest_pinned
        pinned = is_manifest_pinned(self.selected_appid)
        if pinned:
            self.lbl_pin_status.configure(text="Status: 🔒 TERKUNCI (Terlindungi dari Auto-Update)", text_color="#10B981")
            self.btn_pin_toggle.configure(text="🔓 BUKA KUNCI MANIFEST", fg_color="#EF4444", hover_color="#DC2626")
        else:
            self.lbl_pin_status.configure(text="Status: 🔓 TERBUKA (Bisa Auto-Update)", text_color="#333333")
            self.btn_pin_toggle.configure(text="🔒 KUNCI MANIFEST (PIN)", fg_color="#5D5FEF", hover_color="#4B4DDB")
        
    def open_guide(self):
        messagebox.showinfo("Panduan", "Pastikan game sudah mulai didownload di Steam namun terhenti dengan pesan 'No Internet Connection' atau 'Tidak ada koneksi internet'.\n\nMasukkan AppID game tersebut di kolom, lalu klik FIX SEKARANG.", parent=self.winfo_toplevel())


    def on_window_click(self, event):
        try:
            x, y = self.winfo_toplevel().winfo_pointerxy()
            widget = self.winfo_toplevel().winfo_containing(x, y)
            if widget != self.entry_appid and widget != self.search_results_frame and not str(widget).startswith(str(self.search_results_frame)):
                self.search_results_frame.place_forget()
        except Exception:
            pass

    def on_search_focus(self, event):
        query = self.entry_appid.get().strip()
        if len(query) >= 1:
            if hasattr(self, '_search_timer') and self._search_timer:
                self.after_cancel(self._search_timer)
            self._search_timer = self.after(100, lambda: self.perform_live_search(query))

    def on_search_type(self, event):
        if event.keysym not in ("Return", "Up", "Down", "Escape"):
            self.selected_appid = None
            
        query = self.entry_appid.get().strip()
        if len(query) < 1:
            self.hide_search_results()
            return
            
        if hasattr(self, '_search_timer') and self._search_timer:
            self.after_cancel(self._search_timer)
        self._search_timer = self.after(150, lambda: self.perform_live_search(query))

    def perform_live_search(self, query):
        threading.Thread(target=self._async_fetch_search, args=(query,), daemon=True).start()

    def _async_fetch_search(self, query):
        query_clean = query.strip().lower()
        if not query_clean:
            self.after(0, self.hide_search_results)
            return

        games = []
        try:
            from core.database import get_injected_games
            db_games = get_injected_games()
            for g in db_games:
                appid = str(g[0])
                title = str(g[1])
                games.append({"appid": appid, "title": title})
        except Exception:
            pass

        if hasattr(self, "db_manager") and self.db_manager:
            try:
                if hasattr(self.db_manager, "get_all_games"):
                    all_g = self.db_manager.get_all_games()
                    for g in all_g:
                        appid = str(g.get("appid", ""))
                        title = g.get("title") or g.get("name", f"AppID {appid}")
                        if appid and not any(x["appid"] == appid for x in games):
                            games.append({"appid": appid, "title": title})
            except Exception:
                pass

        results = []
        for g in games:
            appid = g["appid"]
            title = g["title"]
            if query_clean in appid.lower() or query_clean in title.lower():
                results.append(g)

        results = results[:10]
        self.after(0, lambda: self._update_search_results_ui(results))

    def _update_search_results_ui(self, results):
        for child in self.search_results_frame.winfo_children():
            child.destroy()

        if not results:
            self.hide_search_results()
            return

        for item in results:
            appid = item["appid"]
            title = item["title"]
            btn = customtkinter.CTkButton(
                self.search_results_frame,
                text=f"{title} ({appid})",
                anchor="w",
                fg_color="transparent",
                hover_color="#E0E0E0",
                text_color="#000000",
                font=customtkinter.CTkFont(family="Segoe UI", size=12, weight="bold"),
                height=30,
                command=lambda a=appid, t=title: self.select_search_result(a, t)
            )
            btn.pack(fill="x", padx=5, pady=2)

        self.show_search_results()

    def select_search_result(self, appid, title):
        self.entry_appid.delete(0, "end")
        self.entry_appid.insert(0, f"{title} ({appid})")
        self.selected_appid = appid
        self.hide_search_results()
        self.update_pin_status_ui()

    def show_search_results(self):
        if not self.search_results_frame.winfo_children():
            return
        if not self.search_results_frame.winfo_ismapped():
            self.entry_appid.update_idletasks()
            x = self.entry_appid.master.winfo_x() + self.entry_appid.winfo_x()
            y = self.entry_appid.master.winfo_y() + self.entry_appid.winfo_y() + self.entry_appid.winfo_height()
            w = self.entry_appid.winfo_width()
            self.search_results_frame.configure(width=max(w, 350))
            self.search_results_frame.place(in_=self.entry_appid.master, x=x, y=y)
            self.search_results_frame.lift()

    def hide_search_results(self):
        if self.search_results_frame.winfo_ismapped():
            self.search_results_frame.place_forget()

    def start_fix(self):
        import re
        query = self.entry_appid.get().strip()
        appid_to_fix = self.selected_appid

        if not appid_to_fix and query:
            m = re.search(r'\b(\d+)\b', query)
            if m:
                appid_to_fix = m.group(1)

        steam_base = get_steam_path()
        if not steam_base:
            messagebox.showerror("Error", "Instalasi Steam tidak ditemukan di komputer ini.", parent=self.winfo_toplevel())
            return

        if appid_to_fix:
            FixNoInternetDialog(self.winfo_toplevel(), appid=appid_to_fix, steam_base=steam_base)
        else:
            # Jika tidak ada AppID spesifik yang diisi/dipilih, jalankan auto-scan game yang mengunduh
            FixNoInternetDialog(self.winfo_toplevel(), appid=None, steam_base=steam_base)

def auto_scan_and_fix(master):
    steam_base = get_steam_path()
    if not steam_base:
        messagebox.showerror("Error", "Instalasi Steam tidak ditemukan.", parent=master.winfo_toplevel())
        return
        
    FixNoInternetDialog(master.winfo_toplevel(), None, steam_base)

class FixNoInternetDialog(customtkinter.CTkToplevel):
    def __init__(self, master, appid=None, steam_base=None, **kwargs):
        super().__init__(master, **kwargs)
        self.configure(fg_color="#F4EFEB")
        self.title("Perbaikan Koneksi")
        w = 450
        h = 580
        self.update_idletasks()
        try:
            x = master.winfo_rootx() + (master.winfo_width() // 2) - (w // 2)
            y = master.winfo_rooty() + (master.winfo_height() // 2) - (h // 2)
        except Exception:
            x = self.winfo_screenwidth() // 2 - w // 2
            y = self.winfo_screenheight() // 2 - h // 2
        self.geometry(f"{w}x{h}+{x}+{y}")
        self.resizable(False, False)
        self.attributes("-topmost", True)
        self.grab_set()

        self.appids = [appid] if appid else []
        self.steam_base = steam_base

        self.grid_columnconfigure(0, weight=1)

        self.lbl_title = customtkinter.CTkLabel(self, text="Memperbaiki Koneksi", font=customtkinter.CTkFont(family="Segoe UI Black", size=24), text_color="#000000")
        self.lbl_title.grid(row=0, column=0, pady=(20, 20))

        customtkinter.CTkLabel(self, text="✦", font=("Segoe UI Black", 30), text_color="#FF499E", fg_color="#F4EFEB").place(x=20, y=10)
        customtkinter.CTkLabel(self, text="*", font=("Segoe UI Black", 40), text_color="#00D084", fg_color="#F4EFEB").place(x=380, y=20)
        customtkinter.CTkLabel(self, text="⚡", font=("Segoe UI Emoji", 40), fg_color="#F4EFEB").place(x=30, y=480)
        customtkinter.CTkLabel(self, text="+", font=("Segoe UI Black", 50), text_color="#5D5FEF", fg_color="#F4EFEB").place(x=380, y=480)

        # Step 1: Konfigurasi Frame
        self.frame_config = customtkinter.CTkFrame(self, fg_color="#FFFFFF", border_width=3, border_color="#000000", corner_radius=0)
        self.frame_config.grid(row=1, column=0, padx=20, pady=(0, 10), sticky="ew")
        self.frame_config.grid_columnconfigure(1, weight=1)
        
        self.lbl_config_title = customtkinter.CTkLabel(self.frame_config, text="Konfigurasi & API", font=customtkinter.CTkFont(family="Segoe UI Black", size=14), text_color="#000000")
        self.lbl_config_title.grid(row=0, column=0, padx=15, pady=15, sticky="w")
        
        self.lbl_config_status = customtkinter.CTkLabel(self.frame_config, text="Menunggu...", font=customtkinter.CTkFont(family="Segoe UI Black", size=13), text_color="#555555")
        self.lbl_config_status.grid(row=0, column=1, padx=15, pady=15, sticky="e")

        # Step 2: Download Frame
        self.frame_dl = customtkinter.CTkFrame(self, fg_color="#FFFFFF", border_width=3, border_color="#000000", corner_radius=0)
        self.frame_dl.grid(row=2, column=0, padx=20, pady=(0, 20), sticky="ew")
        self.frame_dl.grid_columnconfigure(1, weight=1)
        
        self.lbl_dl_title = customtkinter.CTkLabel(self.frame_dl, text="Unduhan Manifest", font=customtkinter.CTkFont(family="Segoe UI Black", size=14), text_color="#000000")
        self.lbl_dl_title.grid(row=0, column=0, padx=15, pady=15, sticky="w")
        
        self.lbl_dl_status = customtkinter.CTkLabel(self.frame_dl, text="Menunggu...", font=customtkinter.CTkFont(family="Segoe UI Black", size=13), text_color="#555555")
        self.lbl_dl_status.grid(row=0, column=1, padx=15, pady=15, sticky="e")

        # Status Akhir
        self.lbl_final_icon = customtkinter.CTkLabel(self, text="", font=customtkinter.CTkFont(family="Segoe UI Black", size=14))
        self.lbl_final_icon.grid(row=3, column=0, pady=(10, 5))
        
        self.progress = customtkinter.CTkProgressBar(self, mode="indeterminate", fg_color="#FFFFFF", progress_color="#5D5FEF", border_color="#000000", border_width=3, corner_radius=0, height=12)
        self.progress.grid(row=4, column=0, padx=20, pady=(0, 10), sticky="ew")
        self.progress.start()

        self.lbl_final_text = customtkinter.CTkLabel(self, text="Memulai proses perbaikan...", font=customtkinter.CTkFont(family="Segoe UI Black", size=12), text_color="#000000", wraplength=400, justify="center")
        self.lbl_final_text.grid(row=5, column=0, pady=(0, 15))
        
        self.btn_ok = customtkinter.CTkButton(self, text="OK", font=customtkinter.CTkFont(family="Segoe UI Black", size=16), text_color="#000000", fg_color="#FFD800", hover_color="#E6C300", border_width=3, border_color="#000000", corner_radius=0, command=self.destroy)

        self.protocol("WM_DELETE_WINDOW", self.on_closing)

        def _fade_in(step=0):
            if step <= 10:
                self.attributes("-alpha", step/10.0)
                self.after(16, lambda: _fade_in(step+1))
                
        self.attributes("-alpha", 0.0)
        _fade_in()

        # Start process
        threading.Thread(target=self._process_fix, daemon=True).start()

    def on_closing(self):
        self.destroy()

    def safe_config(self, widget, **kwargs):
        if self.winfo_exists() and widget.winfo_exists():
            widget.configure(**kwargs)

    def safe_progress_set(self, val):
        if self.winfo_exists() and self.progress.winfo_exists():
            self.progress.set(val)

    def safe_progress_stop(self):
        if self.winfo_exists() and self.progress.winfo_exists():
            self.progress.stop()

    def _process_fix(self):
        import re
        import os
        import requests
        import time
        
        steam_base = self.steam_base
        
        if not self.appids:
            self.after(0, lambda: self.safe_config(self.lbl_final_text, text="Mencari game yang sedang mengunduh...", text_color="#f59e0b"))
            self.after(0, lambda: self.safe_config(self.lbl_config_status, text="Mencari...", text_color="#f59e0b"))
            self.after(0, lambda: self.safe_config(self.lbl_dl_status, text="Menunggu...", text_color="#9ca3af"))
            time.sleep(0.1) # Efek visual mencari

            libraries = [steam_base]
            vdf_path = os.path.join(steam_base, "steamapps", "libraryfolders.vdf")
            if os.path.exists(vdf_path):
                try:
                    with open(vdf_path, "r", encoding="utf-8") as f:
                        content = f.read()
                        paths = re.findall(r'"path"\s+"([^"]+)"', content)
                        for p in paths:
                            libraries.append(p.replace("\\\\", "\\"))
                except Exception:
                    pass

            unique_libs = []
            for lib in libraries:
                norm = os.path.normpath(lib.replace("\\\\", "\\")).lower()
                if norm not in [os.path.normpath(l.replace("\\\\", "\\")).lower() for l in unique_libs]:
                    unique_libs.append(lib)
            libraries = unique_libs
            
            try:
                from core.database import get_injected_games
                db_games = get_injected_games()
                db_names = {str(g[0]): g[1] for g in db_games}
            except Exception:
                db_names = {}

            candidate_games = []
            seen_appids = set()
            
            stplug = os.path.join(steam_base, "config", "stplug-in")
            if os.path.exists(stplug):
                for f in os.listdir(stplug):
                    if not self.winfo_exists(): return
                    if f.endswith(".lua"):
                        appid = f.replace(".lua", "")
                        if appid in seen_appids: continue
                        seen_appids.add(appid)
                        
                        acf_path = None
                        downloading_exists = False
                        
                        for lib in libraries:
                            p = os.path.join(lib, "steamapps", f"appmanifest_{appid}.acf")
                            if os.path.exists(p):
                                acf_path = p
                            
                            dl_p = os.path.join(lib, "steamapps", "downloading", appid)
                            if os.path.isdir(dl_p):
                                downloading_exists = True
                                
                        if acf_path:
                            try:
                                mtime = os.path.getmtime(acf_path)
                                with open(acf_path, "r", encoding="utf-8") as acf:
                                    content = acf.read()
                                    
                                    name_match = re.search(r'"name"\s+"([^"]+)"', content)
                                    game_name = name_match.group(1) if name_match else db_names.get(appid, f"AppID {appid}")
                                    
                                    state = re.search(r'"StateFlags"\s+"(\d+)"', content)
                                    if state:
                                        val = int(state.group(1))
                                        if val != 4:
                                            candidate_games.append({"appid": appid, "mtime": mtime, "name": game_name})
                            except Exception:
                                pass
                        elif downloading_exists:
                            # Game inject yang sedang di-download tapi .acf belum dibuat (gagal fresh install)
                            try:
                                lua_full = os.path.join(stplug, f)
                                mtime = os.path.getmtime(lua_full)
                                game_name = db_names.get(appid, f"AppID {appid}")
                                candidate_games.append({"appid": appid, "mtime": mtime, "name": game_name})
                            except Exception:
                                pass
                            
            if candidate_games:
                candidate_games.sort(key=lambda x: x["mtime"], reverse=True)
                self.after(0, lambda: self.safe_config(self.lbl_config_status, text="Ditemukan!", text_color="#10b981"))
                self.after(0, lambda: self._show_selection_ui(candidate_games))
                return
                
            self.after(0, lambda: self.safe_config(self.lbl_final_text, text="Tidak ditemukan game yang mengunduh!", text_color="#ef4444"))
            self.after(0, lambda: self.safe_config(self.lbl_config_status, text="Gagal!", text_color="#ef4444"))
            self.after(0, lambda: self.safe_progress_stop())
            return
            
        else:
            # Jika self.appids sudah terisi (misal dipanggil langsung dari luar)
            threading.Thread(target=self._download_games, daemon=True).start()

    def _show_selection_ui(self, candidate_games):
        self.safe_progress_stop()
        if hasattr(self, "progress") and self.progress.winfo_exists():
            self.progress.grid_forget()
        
        self.lbl_final_text.grid(row=3, column=0, pady=(10, 5))
        self.safe_config(self.lbl_final_text, text=f"Ditemukan {len(candidate_games)} game. Pilih yang ingin diperbaiki:", text_color="#000000")
        self.safe_config(self.lbl_config_status, text="Pilih Game", text_color="#f59e0b")
        
        self.selection_frame = customtkinter.CTkScrollableFrame(self, fg_color="#FFFFFF", border_width=3, border_color="#000000", corner_radius=0, height=160)
        self.selection_frame.grid(row=4, column=0, padx=20, pady=(0, 10), sticky="ew")
        
        self.checkboxes = []
        for g in candidate_games:
            var = customtkinter.StringVar(value=g["appid"])  # Default terpilih
            display_text = f"{g['name']}  (AppID: {g['appid']})"
            chk = customtkinter.CTkCheckBox(
                self.selection_frame,
                text=display_text,
                variable=var,
                onvalue=g["appid"],
                offvalue="",
                font=customtkinter.CTkFont(family="Segoe UI Black", size=12),
                text_color="#000000",
                border_color="#000000",
                border_width=3,
                fg_color="#00D084",
                hover_color="#00B875"
            )
            chk.pack(anchor="w", padx=10, pady=6)
            self.checkboxes.append({"var": var, "name": g["name"], "appid": g["appid"]})
            
        self.btn_container = customtkinter.CTkFrame(self, fg_color="transparent")
        self.btn_container.grid(row=5, column=0, pady=(0, 15))

        self.btn_process = customtkinter.CTkButton(
            self.btn_container,
            text="🚀 PROSES PERBAIKAN",
            font=customtkinter.CTkFont(family="Segoe UI Black", size=13),
            fg_color="#5D5FEF",
            hover_color="#4B4CD9",
            text_color="#FFFFFF",
            border_width=3,
            border_color="#000000",
            corner_radius=0,
            height=42,
            width=180,
            command=self._on_process_clicked
        )
        self.btn_process.pack(side="left", padx=5)

        self.btn_skip = customtkinter.CTkButton(
            self.btn_container,
            text="⏭️ SKIP UPDATE",
            font=customtkinter.CTkFont(family="Segoe UI Black", size=13),
            fg_color="#F59E0B",
            hover_color="#D97706",
            text_color="#FFFFFF",
            border_width=3,
            border_color="#000000",
            corner_radius=0,
            height=42,
            width=160,
            command=self._on_skip_update_clicked
        )
        self.btn_skip.pack(side="left", padx=5)

    def _on_skip_update_clicked(self):
        selected = []
        for c in self.checkboxes:
            val = c["var"].get()
            if val != "":
                selected.append({"appid": val, "name": c["name"]})
                
        if not selected:
            self.safe_config(self.lbl_final_text, text="⚠️ Pilih minimal 1 game untuk dilewati updatenya!", text_color="#ef4444")
            return
            
        self.lbl_final_text.grid(row=3, column=0, pady=(10, 5))
        self.safe_config(self.lbl_config_status, text="Bypassing...", text_color="#f59e0b")
        
        if hasattr(self, "btn_container") and self.btn_container.winfo_exists():
            self.btn_container.grid_forget()
        if hasattr(self, "selection_frame") and self.selection_frame.winfo_exists():
            self.selection_frame.grid_forget()
        
        self.progress.grid(row=4, column=0, padx=20, pady=(0, 10), sticky="ew")
        self.progress.start()
        
        def _worker():
            try:
                from services.steam_service import patch_appmanifest_state, restart_steam
                for g in selected:
                    appid = g["appid"]
                    patch_appmanifest_state(appid, force_installed_state=True)
                
                restart_steam()
                
                if not self.winfo_exists(): return
                msg = f"Selesai! Update untuk {len(selected)} game berhasil dilewati! Steam dimuat ulang & game siap dimainkan (PLAY)."
                self.after(0, lambda: self._finish(True, msg))
            except Exception as e:
                if not self.winfo_exists(): return
                self.after(0, lambda: self._finish(False, f"Gagal melewati update: {e}"))
                
        threading.Thread(target=_worker, daemon=True).start()

    def _on_process_clicked(self):
        selected = []
        for c in self.checkboxes:
            val = c["var"].get()
            if val != "":
                selected.append({"appid": val, "name": c["name"]})
                
        if not selected:
            self.safe_config(self.lbl_final_text, text="⚠️ Pilih minimal 1 game untuk diperbaiki!", text_color="#ef4444")
            return
            
        self.lbl_final_text.grid(row=3, column=0, pady=(10, 5))
        self.safe_config(self.lbl_config_status, text="Memperbaiki...", text_color="#3b82f6")
        
        if hasattr(self, "btn_container") and self.btn_container.winfo_exists():
            self.btn_container.grid_forget()
        if hasattr(self, "selection_frame") and self.selection_frame.winfo_exists():
            self.selection_frame.grid_forget()
        
        self.progress.grid(row=4, column=0, padx=20, pady=(0, 10), sticky="ew")
        self.progress.start()
        
        self.appids = selected
        threading.Thread(target=self._download_games, daemon=True).start()

    def _download_games(self):
        import os
        import re
        import time
        import requests
        from core.config import load_config
        local_config = load_config()
        
        from core.firebase_sync import fetch_api_keys
        api_keys = fetch_api_keys()
        
        morrenus_key = api_keys.get("morrenus_key", "").strip()
        if not morrenus_key:
            morrenus_key = local_config.get("morrenus_key", "").strip()
            
        manifesthub_key = api_keys.get("manifesthub_key", "").strip()
        if not manifesthub_key:
            manifesthub_key = local_config.get("manifesthub_key", "").strip()
        
        steam_base = self.steam_base
        libraries = [steam_base]
        vdf_path = os.path.join(steam_base, "steamapps", "libraryfolders.vdf")
        if os.path.exists(vdf_path):
            try:
                with open(vdf_path, "r", encoding="utf-8") as f:
                    content = f.read()
                    paths = re.findall(r'"path"\s+"([^"]+)"', content)
                    for p in paths:
                        libraries.append(p.replace("\\\\", "\\"))
            except Exception:
                pass
                
        total_games = len(self.appids)
        failed_any = False
        missing_manifests = []
        total_manifests_needed = 0
        total_manifests_success = 0
        
        def is_valid_manifest_file(file_path):
            if not os.path.exists(file_path):
                return False
            size = os.path.getsize(file_path)
            if size < 512:
                return False
            try:
                with open(file_path, "rb") as f:
                    header = f.read(512).lower()
                    if b"<!doc" in header or b"<html" in header or b"404" in header or b'{"error"' in header or b"not found" in header:
                        return False
            except Exception:
                return False
            return True

        all_depot_maps = {}
        all_buildids = {}
        
        for idx, item_data in enumerate(self.appids):
            current_appid = item_data["appid"]
            if not self.winfo_exists(): return
            self.after(0, lambda: self.safe_config(self.lbl_final_text, text=f"[{idx+1}/{total_games}] {'Memperbaiki AppID'} {current_appid}...", text_color="#000000"))
            self.after(0, lambda: self.safe_config(self.lbl_config_status, text="Membaca .lua...", text_color="#f59e0b"))
            self.after(0, lambda: self.safe_config(self.lbl_dl_status, text="Menunggu...", text_color="#9ca3af"))
            
            lua_path = os.path.join(steam_base, "config", "stplug-in", f"{current_appid}.lua")
        
            if not os.path.exists(lua_path):
                self.after(0, lambda: self.safe_config(self.lbl_config_status, text="File .lua tidak ditemukan!", text_color="#ef4444"))
                failed_any = True
                continue
                
            # 1. Parse Lua for Depot IDs
            depot_ids = []
            try:
                with open(lua_path, "r", encoding="utf-8") as f:
                    content = f.read()
                    matches = re.findall(r'addappid\s*\(\s*(\d+)\s*,\s*\d+\s*,\s*"[a-fA-F0-9]+"', content)
                    depot_ids = list(set(matches))
            except Exception:
                pass
                
            if not depot_ids:
                self.after(0, lambda: self.safe_config(self.lbl_config_status, text="Depot ID tidak ditemukan di .lua!", text_color="#ef4444"))
                failed_any = True
                continue
                
            # 2. SteamCMD
            self.after(0, lambda: self.safe_config(self.lbl_config_status, text="Mengecek SteamCMD...", text_color="#3b82f6"))
            
            download_queue = []
            latest_buildid = None
            try:
                app_info_url = f"https://api.steamcmd.net/v1/info/{current_appid}"
                res = requests.get(app_info_url, timeout=30)
                if res.status_code == 200:
                    data = res.json()
                    if data.get("status") == "success":
                        app_data = data.get("data", {}).get(str(current_appid), {})
                        depots_data = app_data.get("depots", {})
                        latest_buildid = depots_data.get("branches", {}).get("public", {}).get("buildid")
                        for did in depot_ids:
                            manifest_id = depots_data.get(did, {}).get("manifests", {}).get("public", {}).get("gid")
                            if manifest_id:
                                download_queue.append({"depot_id": did, "manifest_id": str(manifest_id)})
            except Exception:
                pass
                
            if not download_queue:
                self.after(0, lambda: self.safe_config(self.lbl_config_status, text="Gagal mendapatkan info SteamCMD!", text_color="#ef4444"))
                failed_any = True
                continue
                
            total_manifests_needed += len(download_queue)
            self.after(0, lambda: self.safe_config(self.lbl_config_status, text="Selesai!", text_color="#10b981"))
            
            # 3. Download
            self.after(0, lambda dl_len=len(download_queue): self.safe_config(self.lbl_dl_status, text=f"0/{dl_len} {'Manifest'}", text_color="#f59e0b"))
            self.after(0, lambda: self.safe_config(self.progress, mode="determinate"))
            self.after(0, lambda: self.safe_progress_set(0))
            
            depotcache_dir = os.path.join(steam_base, "depotcache")
            config_depotcache_dir = os.path.join(steam_base, "config", "depotcache")
            if not os.path.exists(depotcache_dir):
                os.makedirs(depotcache_dir)
            if not os.path.exists(config_depotcache_dir):
                os.makedirs(config_depotcache_dir)
                
            success_count = 0
            headers = {"User-Agent": "Mozilla/5.0"}
            total_downloaded = 0
            
            import concurrent.futures
            progress_lock = threading.Lock()
            
            def update_bytes(chunk_len, idx_val=idx):
                nonlocal total_downloaded
                with progress_lock:
                    total_downloaded += chunk_len
                    kb = total_downloaded / 1024
                    if kb > 1024:
                        mb = kb / 1024
                        text = f"[{idx_val+1}/{total_games}] {'Mendownload'}: {mb:.2f} MB"
                    else:
                        text = f"[{idx_val+1}/{total_games}] {'Mendownload'}: {kb:.0f} KB"
                self.after(0, lambda text_val=text: self.safe_config(self.lbl_final_text, text=text_val))
            import random
            USER_AGENTS = [
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36",
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36",
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:128.0) Gecko/20100101 Firefox/128.0",
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36 Edg/127.0.0.0",
            ]
            
            def get_anti_bot_headers():
                return {
                    "User-Agent": random.choice(USER_AGENTS),
                    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
                    "Accept-Language": "en-US,en;q=0.9",
                    "Accept-Encoding": "gzip, deflate, br",
                    "Connection": "keep-alive",
                    "Upgrade-Insecure-Requests": "1",
                    "Sec-Fetch-Dest": "document",
                    "Sec-Fetch-Mode": "navigate",
                    "Sec-Fetch-Site": "cross-site",
                    "Sec-Fetch-User": "?1",
                }
            from core.firebase_sync import ambil_daftar_netfix_server
            netfix_dinamis = ambil_daftar_netfix_server()
            
            def download_single(m_idx, item):
                nonlocal success_count, failed_any
                if not self.winfo_exists(): return
                did = item["depot_id"]
                mid = item["manifest_id"]
                target_file = os.path.join(depotcache_dir, f"{did}_{mid}.manifest")
                
                # Validasi file lokal jika sudah ada
                if os.path.exists(target_file):
                    if is_valid_manifest_file(target_file):
                        try:
                            config_target = os.path.join(config_depotcache_dir, f"{did}_{mid}.manifest")
                            if not os.path.exists(config_target):
                                shutil.copy2(target_file, config_target)
                        except Exception:
                            pass
                        with progress_lock:
                            success_count += 1
                            c = success_count
                        self.after(0, lambda c_val=c, t_val=len(download_queue): self.safe_config(self.lbl_dl_status, text=f"{c_val}/{t_val} {'Manifest'}", text_color="#3b82f6"))
                        self.after(0, lambda i=m_idx, t_val=len(download_queue): self.safe_progress_set((i+1) / t_val))
                        return
                    else:
                        # Hapus file corrupt/HTML error lama
                        try:
                            os.remove(target_file)
                        except Exception:
                            pass
                    
                downloaded = False
                urls = []
                if netfix_dinamis:
                    for s in netfix_dinamis:
                        name = s.get("name", "")
                        url_template = s.get("url", "")
                        if name and url_template:
                            u = url_template.replace("{did}", str(did)).replace("{mid}", str(mid))
                            u = u.replace("{appid}", str(current_appid))
                            u = u.replace("{morrenus_key}", morrenus_key).replace("{manifesthub_key}", manifesthub_key)
                            if u not in urls:
                                urls.append(u)
                            
                # Selalu gabungkan server fallback default sebagai jaminan failover
                default_fallback_urls = [
                    f"https://cdn.jsdelivr.net/gh/LightnigFast/ProjectLightningManifests@{current_appid}/{did}_{mid}.manifest",
                    f"https://fastly.jsdelivr.net/gh/LightnigFast/ProjectLightningManifests@{current_appid}/{did}_{mid}.manifest",
                    f"https://raw.githubusercontent.com/LightnigFast/ProjectLightningManifests/{current_appid}/{did}_{mid}.manifest",
                    f"https://raw.githubusercontent.com/qwe213312/k25FCdfEOoEJ42S6/main/{did}_{mid}.manifest"
                ]
                if morrenus_key:
                    default_fallback_urls.append(f"https://hubcapmanifest.com/api/v1/generate/manifest?depot_id={did}&manifest_id={mid}&api_key={morrenus_key}")
                if manifesthub_key:
                    default_fallback_urls.append(f"https://api.manifesthub1.filegear-sg.me/manifest?apikey={manifesthub_key}&depotid={did}&manifestid={mid}")
                
                for df_url in default_fallback_urls:
                    if df_url not in urls:
                        urls.append(df_url)
                
                # Coba unduh secara berurutan ke Server 1 -> Server 2 -> Server 3 ...
                for url in urls:
                    if getattr(self, "_skip_requested", False): break
                    try:
                        req_headers = get_anti_bot_headers()
                        r = requests.get(url, headers=req_headers, stream=True, timeout=12)
                        if r.status_code == 200:
                            # Cek chunk pertama apakah HTML/JSON error
                            content_chunks = r.iter_content(chunk_size=16384)
                            first_chunk = next(content_chunks, None)
                            if not first_chunk:
                                continue
                            
                            header_check = first_chunk[:512].lower()
                            if b"<!doc" in header_check or b"<html" in header_check or b"404" in header_check or b'{"error"' in header_check:
                                # Merupakan halaman error HTML, abaikan dan coba server berikutnya
                                r.close()
                                continue
                                
                            with open(target_file, "wb") as f:
                                f.write(first_chunk)
                                update_bytes(len(first_chunk))
                                for chunk in content_chunks:
                                    if not self.winfo_exists(): return
                                    f.write(chunk)
                                    update_bytes(len(chunk))
                                    
                            if is_valid_manifest_file(target_file):
                                downloaded = True
                                try:
                                    from services.steam_service import get_all_steamapps_paths
                                    for sa in get_all_steamapps_paths():
                                        dc_dir = os.path.join(os.path.dirname(sa), "depotcache")
                                        os.makedirs(dc_dir, exist_ok=True)
                                        shutil.copy2(target_file, os.path.join(dc_dir, f"{did}_{mid}.manifest"))
                                    shutil.copy2(target_file, os.path.join(config_depotcache_dir, f"{did}_{mid}.manifest"))
                                except Exception:
                                    pass
                                with progress_lock:
                                    success_count += 1
                                    c = success_count
                                break
                            else:
                                try: os.remove(target_file)
                                except Exception: pass
                        elif r.status_code in (429, 403):
                            time.sleep(random.uniform(0.2, 0.5))
                    except Exception:
                        if os.path.exists(target_file):
                            try: os.remove(target_file)
                            except Exception: pass
                
                if not downloaded:
                    if os.path.exists(target_file):
                        try: os.remove(target_file)
                        except Exception: pass
                    with progress_lock:
                        missing_manifests.append(f"{did}_{mid}")
                    
                self.after(0, lambda c_val=success_count, t_val=len(download_queue): self.safe_config(self.lbl_dl_status, text=f"{c_val}/{t_val} {'Manifest'}", text_color="#10b981" if c_val==t_val else "#f59e0b"))
                self.after(0, lambda i=m_idx, t_val=len(download_queue): self.safe_progress_set((i+1) / t_val))

            with concurrent.futures.ThreadPoolExecutor(max_workers=min(5, len(download_queue))) as pool:
                futures = [pool.submit(download_single, m_idx, item) for m_idx, item in enumerate(download_queue)]
                concurrent.futures.wait(futures)
            
            total_manifests_success += success_count
            if success_count < len(download_queue):
                failed_any = True
            else:
                depot_map = {}
                for item in download_queue:
                    depot_map[str(item["depot_id"])] = str(item["manifest_id"])
                all_depot_maps[str(current_appid)] = depot_map
                if latest_buildid:
                    all_buildids[str(current_appid)] = str(latest_buildid)
                
                # Patch appmanifest state so Steam knows the new manifest GIDs and buildid
                try:
                    from services.steam_service import patch_appmanifest_state
                    patch_appmanifest_state(
                        current_appid, 
                        latest_buildid=latest_buildid, 
                        depot_manifests=depot_map, 
                        force_installed_state=False
                    )
                except Exception:
                    pass
            
            time.sleep(0.1)

        # Smart Restart Logic:
        # Case A: FRESH DOWNLOAD -> DO NOT RESTART STEAM! User clicks "Lanjutkan Unduhan" (Resume) seamlessly.
        # Case B: GAME UPDATE (Game file exists on disk) -> RESTART STEAM so Steam reads new buildid & manifest GIDs!
        is_update_job = False
        if not failed_any and total_manifests_success > 0:
            try:
                from services.steam_service import restart_steam, is_game_update
                is_update_job = any(is_game_update(aid) for aid in all_depot_maps.keys())
                if is_update_job:
                    restart_steam(status_callback=None, force=False, appids_to_patch=list(all_depot_maps.keys()), depot_manifests_map=all_depot_maps, buildids_map=all_buildids)
            except Exception:
                pass

        if not self.winfo_exists(): return
        if failed_any or total_manifests_needed == 0 or total_manifests_success < total_manifests_needed:
            if missing_manifests:
                msg = "File Fix Net (Manifest) belum tersedia di server manapun untuk game ini!"
            else:
                msg = "Gagal memperbaiki koneksi game! Pastikan data manifest & jaringan tersedia."
            self.after(0, lambda: self._finish(False, msg))
        else:
            if is_update_job:
                msg = "Selesai! Manifest Update berhasil dipasang & Steam dimuat ulang. Game siap diperbarui!"
            else:
                msg = "Selesai! File Fix Net berhasil dipasang. Silakan klik 'Lanjutkan Unduhan' (Resume) di Steam!"
            self.after(0, lambda: self._finish(True, msg))
            
    def _finish(self, success, text):
        if not self.winfo_exists(): return
        self.safe_progress_stop()
        self.safe_config(self.progress, mode="determinate")
        self.safe_progress_set(1.0 if success else 0)
        self.safe_config(self.progress, progress_color="#10b981" if success else "#ef4444")
        
        if success:
            self.safe_config(self.lbl_final_icon, text="✔️ BERHASIL!", text_color="#10b981")
            self.safe_config(self.lbl_final_text, text=text, text_color="#10b981")
        else:
            self.safe_config(self.lbl_final_icon, text="⚠️ GAGAL!", text_color="#ef4444")
            self.safe_config(self.lbl_final_text, text=text, text_color="#ef4444")
            
        self.after(0, lambda: self.btn_ok.grid(row=6, column=0, pady=(0, 15)))
