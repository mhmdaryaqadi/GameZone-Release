import os
import requests
import zipfile
import shutil
from core.database import insert_injected_game
import concurrent.futures
from services.steam_service import get_steam_path

def download_and_inject(appid, title="Unknown Game", status_callback=None):
    headers_browser = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
    }

    # Ambil daftar server dari Firebase database secara dinamis
    from core.firebase_sync import ambil_daftar_server, fetch_api_keys
    from core.config import load_config
    
    server_dinamis = ambil_daftar_server()
    api_keys = fetch_api_keys()
    local_config = load_config()
    
    morrenus_key = api_keys.get("morrenus_key", "").strip()
    if not morrenus_key:
        morrenus_key = local_config.get("morrenus_key", "").strip()

    manifesthub_key = api_keys.get("manifesthub_key", "").strip()
    if not manifesthub_key:
        manifesthub_key = local_config.get("manifesthub_key", "").strip()

    api_sources = []
    if server_dinamis:
        for s in server_dinamis:
            name = s.get("name", "")
            url_template = s.get("url", "")
            if name and url_template:
                url = url_template.replace("{appid}", str(appid)).replace("<appid>", str(appid))
                url = url.replace("{morrenus_key}", morrenus_key).replace("<moapikey>", morrenus_key)
                url = url.replace("{manifesthub_key}", manifesthub_key)
                api_sources.append({"name": name, "url": url})

    # Jika database kosong atau offline, pakai fallback server bawaan yang terbukti aktif & kencang
    if not api_sources:
        api_sources = [
            {"name": "SkyApi (Raw GitHub)", "url": f"https://raw.githubusercontent.com/skyflarefox/Skyapi/refs/heads/main/{appid}.zip"},
            {"name": "SkyApi (jsDelivr CDN)", "url": f"https://cdn.jsdelivr.net/gh/skyflarefox/Skyapi@main/{appid}.zip"},
            {"name": "SkyApi (GitHub)", "url": f"https://github.com/skyflarefox/Skyapi/raw/refs/heads/main/{appid}.zip"},
            {"name": "Sushi Repo (Raw GitHub)", "url": f"https://raw.githubusercontent.com/sushi-dev55-alt/sushitools-games-repo-alt/refs/heads/main/{appid}.zip"},
            {"name": "Sushi Repo (jsDelivr CDN)", "url": f"https://cdn.jsdelivr.net/gh/sushi-dev55-alt/sushitools-games-repo-alt@main/{appid}.zip"},
            {"name": "Sushi Repo (GitHub)", "url": f"https://github.com/sushi-dev55-alt/sushitools-games-repo-alt/raw/refs/heads/main/{appid}.zip"},
            {"name": "Morrenus Manifest API", "url": f"https://hubcapmanifest.com/api/v1/manifest/{appid}?api_key={morrenus_key}"},
            {"name": "ManifestHub Zip API", "url": f"https://api.manifesthub1.filegear-sg.me/download?appid={appid}&apikey={manifesthub_key}"}
        ]

    temp_dir = "temp"
    if not os.path.exists(temp_dir):
        os.makedirs(temp_dir)

    zip_path = os.path.join(temp_dir, f"{appid}.zip")
    download_success = False
    method_used = ""

    def check_source(source):
        try:
            res = requests.get(source['url'], headers=headers_browser, stream=True, timeout=5)
            if res.status_code == 200:
                total_len = res.headers.get('content-length')
                if total_len is not None and int(total_len) < 50:
                    res.close()
                    return None, None
                return source, res
            else:
                res.close()
        except requests.RequestException:
            pass
        return None, None

    if status_callback:
        status_callback("Mencari di semua server secara bersamaan (Fast Search)...")

    # Jalankan request paralel sejumlah total cermin server aktif
    with concurrent.futures.ThreadPoolExecutor(max_workers=max(1, len(api_sources))) as executor:
        futures = {executor.submit(check_source, s): s for s in api_sources}
        for future in concurrent.futures.as_completed(futures):
            source_info, response = future.result()
            if response is not None:
                if status_callback:
                    status_callback(f"Paket ditemukan! Mengunduh dari {source_info['name']}...")
                
                total_length = response.headers.get('content-length')
                if total_length is None:
                    total_length = 0
                else:
                    total_length = int(total_length)
                    
                downloaded = 0
                with open(zip_path, 'wb') as f:
                    for data in response.iter_content(chunk_size=131072):
                        f.write(data)
                        downloaded += len(data)
                        if status_callback:
                            status_callback({"type": "progress", "downloaded": downloaded, "total": total_length})
                
                response.close()

                # Verifikasi keabsahan file ZIP sebelum menyelesaikan pencarian
                try:
                    with zipfile.ZipFile(zip_path, 'r') as z_check:
                        if len(z_check.namelist()) > 0:
                            download_success = True
                            method_used = source_info['name']
                            break
                except zipfile.BadZipFile:
                    if os.path.exists(zip_path):
                        os.remove(zip_path)
                    continue
    
    if not download_success:
        return False, "Game tidak tersedia di semua server komunitas aktif (404/Timeout)."

    if status_callback:
        status_callback("Mengekstrak berkas paket manifest...")
        
    extract_folder = os.path.join(temp_dir, f"extracted_{appid}")
    try:
        with zipfile.ZipFile(zip_path, 'r') as zip_ref:
            zip_ref.extractall(extract_folder)
    except zipfile.BadZipFile:
        if os.path.exists(zip_path):
            os.remove(zip_path)
        return False, "File ZIP dari server rusak atau korup."

    if status_callback:
        status_callback("Menyuntikkan lisensi berkas ke sistem Steam...")

    steam_base = get_steam_path()
    steam_depotcache = os.path.join(steam_base, "depotcache")
    steam_stplugin = os.path.join(steam_base, "config", "stplug-in")

    if not os.path.exists(steam_depotcache): os.makedirs(steam_depotcache)
    if not os.path.exists(steam_stplugin): os.makedirs(steam_stplugin)

    depot_manifest_pairs = []
    for root, dirs, files in os.walk(extract_folder):
        for file in files:
            if file.endswith(".manifest"):
                shutil.copy2(os.path.join(root, file), steam_depotcache)
            elif file.endswith(".lua"):
                shutil.copy2(os.path.join(root, file), steam_stplugin)

    # Pembersihan berkas sampah otomatis
    if os.path.exists(zip_path): os.remove(zip_path)
    if os.path.exists(extract_folder): shutil.rmtree(extract_folder)
    
    insert_injected_game(appid, title)
    
    # Silent Steam restart (without writing ACF files)
    _register_game_in_steam(appid, title, steam_base, status_callback)
    
    return True, f"Sukses di-inject via {method_used}! Steam berhasil dimuat ulang."


def _register_game_in_steam(appid, title, steam_base, status_callback=None):
    """
    Silently restart Steam using the unified clean restart mechanism.
    Removes any queued download appmanifest so Steam displays the clean "INSTALL" button
    and prevents auto-downloading.
    """
    from services.steam_service import get_all_steamapps_paths
    for sa_path in get_all_steamapps_paths():
        acf_path = os.path.join(sa_path, f"appmanifest_{appid}.acf")
        if os.path.exists(acf_path):
            try:
                with open(acf_path, "r", encoding="utf-8", errors="ignore") as f:
                    content = f.read()
                # If game is not fully installed, remove dummy acf so Steam shows "INSTALL" button
                if '"SizeOnDisk"\t\t"0"' in content or '"StateFlags"\t\t"1026"' in content or '"StateFlags"\t\t"1024"' in content:
                    os.remove(acf_path)
            except Exception:
                pass

        # Clean up leftover downloading artifacts
        dl_folder = os.path.join(sa_path, "downloading", str(appid))
        if os.path.isdir(dl_folder):
            try:
                shutil.rmtree(dl_folder)
            except Exception:
                pass
            
    from services.steam_service import restart_steam
    restart_steam(status_callback=status_callback)


def inject_manual_files(file_paths, title="Manual Injection", status_callback=None):
    steam_base = get_steam_path()
    steam_depotcache = os.path.join(steam_base, "depotcache")
    steam_stplugin = os.path.join(steam_base, "config", "stplug-in")

    if not os.path.exists(steam_depotcache): os.makedirs(steam_depotcache)
    if not os.path.exists(steam_stplugin): os.makedirs(steam_stplugin)

    has_lua = False
    has_manifest = False
    
    temp_dir = "temp_manual"
    if not os.path.exists(temp_dir):
        os.makedirs(temp_dir)

    try:
        # Step 1: Ekstrak zip jika ada
        for file_path in file_paths:
            if file_path.endswith('.zip'):
                if status_callback: status_callback(f"Mengekstrak {os.path.basename(file_path)}...")
                try:
                    with zipfile.ZipFile(file_path, 'r') as zip_ref:
                        zip_ref.extractall(temp_dir)
                except zipfile.BadZipFile:
                    return False, f"File ZIP rusak: {os.path.basename(file_path)}"

        # Step 2: Proses semua file (yang dipilih langsung + hasil ekstrak zip)
        files_to_process = []
        for file_path in file_paths:
            if not file_path.endswith('.zip'):
                files_to_process.append(file_path)
                
        for root, dirs, files in os.walk(temp_dir):
            for file in files:
                files_to_process.append(os.path.join(root, file))

        # Step 3: Validasi isi
        for file_path in files_to_process:
            filename = file_path.lower()
            if filename.endswith('.lua'): 
                has_lua = True
            elif filename.endswith('.manifest'): 
                has_manifest = True
            else:
                if os.path.exists(temp_dir): shutil.rmtree(temp_dir)
                return False, f"Ditolak: File tidak diizinkan ditemukan ({os.path.basename(file_path)}). Hanya boleh .lua atau .manifest!"

        if not has_lua and not has_manifest:
             if os.path.exists(temp_dir): shutil.rmtree(temp_dir)
             return False, "Ditolak: File yang dipilih/diekstrak kosong atau tidak mengandung file .lua / .manifest!"

        # Step 4: Salin ke folder Steam
        if status_callback: status_callback("Menyuntikkan berkas manual ke sistem Steam...")
        for file_path in files_to_process:
            if file_path.endswith('.lua'):
                shutil.copy2(file_path, steam_stplugin)
            elif file_path.endswith('.manifest'):
                shutil.copy2(file_path, steam_depotcache)

        # Cleanup
        if os.path.exists(temp_dir): shutil.rmtree(temp_dir)
        insert_injected_game("MANUAL", title)
        return True, "File injeksi manual berhasil disuntikkan! Restart Steam untuk memunculkan game di library."

    except Exception as e:
        if os.path.exists(temp_dir): shutil.rmtree(temp_dir)
        return False, f"Terjadi kesalahan saat memproses file: {str(e)}"
