import customtkinter
import os
import threading
import json
import webbrowser
from PIL import Image, ImageOps
from io import BytesIO

def wrap_text(text, width=15):
    import textwrap
    lines = textwrap.wrap(text, width=width)
    return "\n".join(lines)

class HomePage(customtkinter.CTkFrame):
    def __init__(self, parent, main_app):
        super().__init__(parent, fg_color="#FFFFFF")
        self.parent = parent
        self.main_app = main_app
        self.is_destroyed = False
        self.home_deals_data = {}
        self.home_deals_cat = "freebies"
        self._last_ann_hash = None
        
        self.button_data = {
            "panduan": """📌 [PANDUAN PENGGUNAAN GAMEZONE]

1. Cara Injeksi Game:
- Buka tab 'Inject' di menu samping.
- Pilih game yang ingin diinjeksi dan klik tombol 'INJECT GAME'.
- Tunggu hingga proses verifikasi lisensi dan pembuatan file manifest selesai.
- Buka Steam, game akan muncul di library dan siap untuk dimainkan!

2. Cara Menggunakan Fix Purchase:
- Jika tombol di Steam berubah menjadi 'Purchase', klik tombol 'Fix Purchase' di sidebar.
- GameZone akan mereset cache lisensi Steam dan memperbaiki file manifest secara otomatis.

3. Cara Memperbaiki Koneksi (NetFix):
- Jika game butuh pembaruan / unduhan, jalankan fitur 'Fix No Internet' untuk mengunduh file manifest depot terbaru.""",
            "pembaruan": """✨ [v2.0.7]:
- 🔥 Integrasi Radar Deals & Freebies: Info otomatis 24/7 game PC gratis (Epic/Steam/GOG), diskon besar & Steam Events.
- 🔍 Diagnostik & Perbaiki 1-Klik: Pemeriksa kesehatan khusus game inject.
- 🧹 Auto Steam License Cleaner Toggle Switch di Settings.
- 🛒 Sidebar Fix Purchase Loop button.""",
            "donasi": "https://saweria.co/"
        }
        
        # Grid layout: Column 0 (Left 45%), Column 1 (Right 55%)
        self.grid_columnconfigure(0, weight=45)
        self.grid_columnconfigure(1, weight=55)
        self.grid_rowconfigure(1, weight=1)

        # Theme Colors - Neo-Brutalism
        self.CARD_BG = "#FFFFFF"
        self.ACCENT_YELLOW = "#FFD800"
        self.ACCENT_PINK = "#FF499E"
        self.ACCENT_GREEN = "#00D084"
        self.ACCENT_BLUE = "#5D5FEF"
        self.BORDER_COLOR = "#000000"
        self.TEXT_BLACK = "#000000"
        self.TEXT_MUTED = "#555555"
        
        # Top Bar Title
        top_bar = customtkinter.CTkFrame(self, fg_color="transparent")
        top_bar.grid(row=0, column=0, columnspan=2, pady=(0, 6), sticky="ew")
        
        title = customtkinter.CTkLabel(
            top_bar, text="Home Dashboard", 
            font=customtkinter.CTkFont(family="Segoe UI Black", size=18), 
            text_color=self.TEXT_BLACK
        )
        title.grid(row=0, column=0, sticky="w")

        # =========================================================================
        # LEFT COLUMN (Welcome Card + Pengumuman Card)
        # =========================================================================
        left_column = customtkinter.CTkFrame(self, fg_color="transparent")
        left_column.grid(row=1, column=0, padx=(0, 8), sticky="nsew")
        left_column.grid_columnconfigure(0, weight=1)
        left_column.grid_rowconfigure(1, weight=1)

        # 1. Hero Welcome Card (Top Left)
        self.hero_card = customtkinter.CTkFrame(
            left_column, fg_color=self.CARD_BG, 
            border_width=3, border_color=self.BORDER_COLOR, corner_radius=0
        )
        self.hero_card.grid(row=0, column=0, sticky="ew", pady=(0, 10))
        
        self.lbl_welcome = customtkinter.CTkLabel(
            self.hero_card, text="WELCOME BACK!", 
            font=customtkinter.CTkFont(family="Segoe UI Black", size=20), 
            text_color=self.TEXT_BLACK, anchor="w", justify="left"
        )
        self.lbl_welcome.pack(fill="x", padx=15, pady=(15, 2))
        
        self.lbl_level = customtkinter.CTkLabel(
            self.hero_card, text="Premium User", 
            font=customtkinter.CTkFont(family="Segoe UI Black", size=12), 
            text_color=self.ACCENT_GREEN, anchor="w", justify="left"
        )
        self.lbl_level.pack(fill="x", padx=15, pady=(0, 15))

        # 2. Pengumuman Card (Bottom Left)
        self.ann_card = customtkinter.CTkFrame(
            left_column, fg_color=self.CARD_BG, 
            border_width=3, border_color=self.BORDER_COLOR, corner_radius=0
        )
        self.ann_card.grid(row=1, column=0, sticky="nsew")

        lbl_ann_title = customtkinter.CTkLabel(
            self.ann_card, text="📢 PENGUMUMAN", 
            font=customtkinter.CTkFont(family="Segoe UI Black", size=15), 
            text_color=self.TEXT_BLACK, anchor="w"
        )
        lbl_ann_title.pack(fill="x", padx=15, pady=(12, 5))
        
        self.announce_scroll = customtkinter.CTkScrollableFrame(
            self.ann_card, fg_color="#FFFFFF", border_width=2, 
            border_color=self.BORDER_COLOR, corner_radius=0
        )
        self.announce_scroll.pack(fill="both", expand=True, padx=12, pady=(0, 12))

        # =========================================================================
        # RIGHT COLUMN (Deals, Freebies & Events Widget + Utility Buttons)
        # =========================================================================
        right_column = customtkinter.CTkFrame(self, fg_color="transparent")
        right_column.grid(row=1, column=1, padx=(8, 0), sticky="nsew")
        right_column.grid_columnconfigure(0, weight=1)
        right_column.grid_rowconfigure(0, weight=1)

        # 1. Deals & Promo Widget Card (Right Full Height)
        self.deals_card = customtkinter.CTkFrame(
            right_column, fg_color=self.CARD_BG, 
            border_width=3, border_color=self.BORDER_COLOR, corner_radius=0
        )
        self.deals_card.grid(row=0, column=0, sticky="nsew", pady=(0, 10))
        self.deals_card.grid_columnconfigure(0, weight=1)
        self.deals_card.grid_rowconfigure(2, weight=1)

        # Header Deals
        lbl_deals_title = customtkinter.CTkLabel(
            self.deals_card, text="🔥 DEALS, FREEBIES & STEAM EVENTS", 
            font=customtkinter.CTkFont(family="Segoe UI Black", size=15), 
            text_color=self.TEXT_BLACK, anchor="w"
        )
        lbl_deals_title.grid(row=0, column=0, sticky="w", padx=15, pady=(12, 2))

        lbl_deals_sub = customtkinter.CTkLabel(
            self.deals_card, text="Info promo game PC 100% gratis, diskon & event resmi.", 
            font=customtkinter.CTkFont(family="Segoe UI Black", size=11), 
            text_color=self.TEXT_MUTED, anchor="w"
        )
        lbl_deals_sub.grid(row=1, column=0, sticky="w", padx=15, pady=(0, 8))

        # Filter Tabs inside Deals Card
        deals_tab_frame = customtkinter.CTkFrame(self.deals_card, fg_color="transparent")
        deals_tab_frame.grid(row=2, column=0, sticky="ew", padx=12, pady=(0, 6))

        self.btn_h_free = customtkinter.CTkButton(
            deals_tab_frame, text="🎁 Game Gratis", font=customtkinter.CTkFont(family="Segoe UI Black", size=11),
            fg_color="#FFD800", text_color="#000000", hover_color="#E6C300", border_width=2, border_color="#000000", corner_radius=0, height=30,
            command=lambda: self.switch_home_deals_cat("freebies")
        )
        self.btn_h_free.pack(side="left", padx=(0, 4))

        self.btn_h_deals = customtkinter.CTkButton(
            deals_tab_frame, text="🔥 Diskon Besar", font=customtkinter.CTkFont(family="Segoe UI Black", size=11),
            fg_color="#FFFFFF", text_color="#000000", hover_color="#E0E0E0", border_width=2, border_color="#000000", corner_radius=0, height=30,
            command=lambda: self.switch_home_deals_cat("discounts")
        )
        self.btn_h_deals.pack(side="left", padx=4)

        self.btn_h_events = customtkinter.CTkButton(
            deals_tab_frame, text="🎪 Steam Events", font=customtkinter.CTkFont(family="Segoe UI Black", size=11),
            fg_color="#FFFFFF", text_color="#000000", hover_color="#E0E0E0", border_width=2, border_color="#000000", corner_radius=0, height=30,
            command=lambda: self.switch_home_deals_cat("events")
        )
        self.btn_h_events.pack(side="left", padx=(4, 0))

        # Scrollable Frame for Deals Items
        self.deals_cards_scroll = customtkinter.CTkScrollableFrame(
            self.deals_card, fg_color="#FFFFFF", border_width=2, 
            border_color=self.BORDER_COLOR, corner_radius=0
        )
        self.deals_cards_scroll.grid(row=3, column=0, sticky="nsew", padx=12, pady=(0, 12))

        # 2. Bottom Utility Buttons (Panduan, Pembaruan, Donasi)
        bot_btns = customtkinter.CTkFrame(right_column, fg_color="transparent")
        bot_btns.grid(row=1, column=0, sticky="ew")
        bot_btns.grid_columnconfigure(0, weight=1)
        bot_btns.grid_columnconfigure(1, weight=1)
        bot_btns.grid_columnconfigure(2, weight=1)

        btn_panduan = customtkinter.CTkButton(
            bot_btns, text="PANDUAN", fg_color="#5D5FEF", hover_color="#4B4CD9", 
            text_color="#FFFFFF", font=customtkinter.CTkFont(family="Segoe UI Black", size=11), 
            corner_radius=0, border_width=3, border_color="#000000", command=self.open_guide, height=36
        )
        btn_panduan.grid(row=0, column=0, padx=(0, 4), sticky="ew")

        btn_pembaruan = customtkinter.CTkButton(
            bot_btns, text="PEMBARUAN", fg_color="#00D084", hover_color="#00B875", 
            text_color="#000000", font=customtkinter.CTkFont(family="Segoe UI Black", size=11), 
            corner_radius=0, border_width=3, border_color="#000000", command=self.open_changelog, height=36
        )
        btn_pembaruan.grid(row=0, column=1, padx=4, sticky="ew")

        btn_donasi = customtkinter.CTkButton(
            bot_btns, text="DONASI", fg_color="#FF499E", hover_color="#E63F8A", 
            text_color="#000000", font=customtkinter.CTkFont(family="Segoe UI Black", size=11), 
            corner_radius=0, border_width=3, border_color="#000000", command=self.open_donasi, height=36
        )
        btn_donasi.grid(row=0, column=2, padx=(4, 0), sticky="ew")

        # Start Realtime Background Sync Loop for Announcements and Deals
        self.start_realtime_announcements()
        self.load_live_deals()

    # =========================================================================
    # DEALS RENDERING LOGIC
    # =========================================================================
    def load_live_deals(self):
        threading.Thread(target=self._async_load_deals, daemon=True).start()

    def _async_load_deals(self):
        try:
            from services.deals_service import fetch_live_deals_and_events
            self.home_deals_data = fetch_live_deals_and_events()
        except Exception:
            self.home_deals_data = {"freebies": [], "discounts": [], "events": []}
        self.after(0, lambda: self.render_home_deals(getattr(self, "home_deals_cat", "freebies")))

    def switch_home_deals_cat(self, cat_key):
        self.home_deals_cat = cat_key
        self.btn_h_free.configure(fg_color="#FFD800" if cat_key == "freebies" else "#FFFFFF")
        self.btn_h_deals.configure(fg_color="#FFD800" if cat_key == "discounts" else "#FFFFFF")
        self.btn_h_events.configure(fg_color="#FFD800" if cat_key == "events" else "#FFFFFF")
        self.render_home_deals(cat_key)

    def render_home_deals(self, cat_key):
        if not hasattr(self, "deals_cards_scroll") or not self.deals_cards_scroll.winfo_exists():
            return

        for w in self.deals_cards_scroll.winfo_children():
            w.destroy()

        items = self.home_deals_data.get(cat_key, [])
        if not items:
            customtkinter.CTkLabel(self.deals_cards_scroll, text="Belum ada data promo untuk kategori ini.", font=customtkinter.CTkFont(family="Segoe UI Black", size=13), text_color="#777777").pack(pady=30)
            return

        from pages.user.deals import get_store_button_label

        for item in items:
            card = customtkinter.CTkFrame(self.deals_cards_scroll, fg_color="#FFFFFF", border_width=2, border_color="#000000", corner_radius=0)
            card.pack(fill="x", padx=4, pady=4)

            top_box = customtkinter.CTkFrame(card, fg_color="transparent")
            top_box.pack(fill="x", padx=10, pady=(8, 2))

            badge_text = item.get("savings_pct") or item.get("discount_pct") or "PROMO"
            badge_bg = "#FF499E" if "GRATIS" in item.get("sale_price", "") or badge_text == "100%" else "#10b981"
            
            lbl_badge = customtkinter.CTkLabel(top_box, text=f" {badge_text} ", font=customtkinter.CTkFont(family="Segoe UI Black", size=11), fg_color=badge_bg, text_color="#FFFFFF", corner_radius=0)
            lbl_badge.pack(side="right")

            lbl_name = customtkinter.CTkLabel(top_box, text=item.get("title", ""), font=customtkinter.CTkFont(family="Segoe UI Black", size=13), text_color="#000000", anchor="w")
            lbl_name.pack(side="left", fill="x", expand=True)

            price_box = customtkinter.CTkFrame(card, fg_color="transparent")
            price_box.pack(fill="x", padx=10, pady=(0, 6))

            sale_p = item.get("sale_price") or item.get("final_price") or "GRATIS"
            norm_p = item.get("normal_price") or ""

            lbl_price = customtkinter.CTkLabel(price_box, text=f"Harga: {sale_p}  ", font=customtkinter.CTkFont(family="Segoe UI Black", size=12), text_color="#000000")
            lbl_price.pack(side="left")

            if norm_p and norm_p != sale_p:
                lbl_norm = customtkinter.CTkLabel(price_box, text=norm_p, font=customtkinter.CTkFont(family="Segoe UI", size=10, overstrike=True), text_color="#888888")
                lbl_norm.pack(side="left")

            target_url = item.get("store_url", "https://store.steampowered.com/")
            store_label = get_store_button_label(target_url, item.get("store_name", ""))

            btn_open = customtkinter.CTkButton(card, text=store_label, font=customtkinter.CTkFont(family="Segoe UI Black", size=11), fg_color="#5D5FEF", hover_color="#4B4DDC", text_color="#FFFFFF", border_width=2, border_color="#000000", corner_radius=0, height=28, command=lambda url=target_url: webbrowser.open(url))
            btn_open.pack(fill="x", padx=10, pady=(0, 8))


    # =========================================================================
    # UTILITY HANDLERS & ANNOUNCEMENT LOGIC
    # =========================================================================
    def open_guide(self):
        from components.dialogs import InfoDialog
        text = self.button_data.get("panduan", "")
        InfoDialog(self.winfo_toplevel(), "Panduan Penggunaan", text)

    def open_changelog(self):
        from components.dialogs import InfoDialog
        text = self.button_data.get("pembaruan", "")
        InfoDialog(self.winfo_toplevel(), "Update Terbaru", text)

    def open_donasi(self):
        url = self.button_data.get("donasi", "https://saweria.co/")
        webbrowser.open(url)

    def destroy(self):
        self.is_destroyed = True
        super().destroy()

    def refresh_page(self):
        self._last_ann_hash = None
        self.load_announcement()

    def load_announcement(self):
        threading.Thread(target=self._async_load_announcement, daemon=True).start()

    def start_realtime_announcements(self):
        threading.Thread(target=self._realtime_loop, daemon=True).start()

    def _realtime_loop(self):
        import time
        while not self.is_destroyed:
            try:
                from core.firebase_sync import fetch_announcements
                ann_data = fetch_announcements()
                
                cur_hash = hash(json.dumps(ann_data, sort_keys=True)) if ann_data else 0
                if cur_hash != self._last_ann_hash:
                    self._last_ann_hash = cur_hash
                    self.after(0, lambda data=ann_data: self._render_announcement_items(data))
            except Exception:
                pass
            time.sleep(3)

    def _async_load_announcement(self):
        try:
            from core.firebase_sync import fetch_announcements
            ann_data = fetch_announcements()
            self.after(0, lambda: self._render_announcement_items(ann_data))
        except Exception:
            pass

    def _render_announcement_items(self, ann_data):
        if not hasattr(self, 'announce_scroll') or not self.announce_scroll.winfo_exists():
            return
            
        for child in self.announce_scroll.winfo_children():
            child.destroy()
            
        if not ann_data or not isinstance(ann_data, dict):
            empty_lbl = customtkinter.CTkLabel(
                self.announce_scroll, text="Belum ada pengumuman.", 
                font=customtkinter.CTkFont(family="Segoe UI Black", size=13), text_color=self.TEXT_MUTED
            )
            empty_lbl.pack(pady=20)
            return

        sorted_items = sorted(
            ann_data.items(), 
            key=lambda x: x[1].get('timestamp', '') if isinstance(x[1], dict) else '', 
            reverse=True
        )

        from core import discord_auth, firebase_sync
        current_dc = discord_auth.get_cached_username()

        for ann_id, item in sorted_items:
            if not isinstance(item, dict): continue
            
            content = item.get('content', '')
            reactions = item.get('reactions', {})
            
            box = customtkinter.CTkFrame(
                self.announce_scroll, fg_color="#FFFFFF", 
                border_width=2, border_color=self.BORDER_COLOR, corner_radius=0
            )
            box.pack(fill="x", pady=6, padx=2)
            
            txt_lbl = customtkinter.CTkLabel(
                box, text=content, 
                font=customtkinter.CTkFont(family="Segoe UI", size=12, weight="bold"), 
                text_color=self.TEXT_BLACK, wraplength=260, justify="left", anchor="w"
            )
            txt_lbl.pack(fill="x", padx=12, pady=(10, 8))
            
            react_bar = customtkinter.CTkFrame(box, fg_color="transparent")
            react_bar.pack(fill="x", padx=12, pady=(0, 10))
            
            emojis = [("fire", "🔥"), ("like", "👍"), ("rocket", "🚀")]
            for e_key, e_symbol in emojis:
                users_list = reactions.get(e_key, [])
                if not isinstance(users_list, list): users_list = []
                count = len(users_list)
                has_reacted = current_dc in users_list
                
                btn_bg = self.ACCENT_YELLOW if has_reacted else "#FFFFFF"
                
                btn = customtkinter.CTkButton(
                    react_bar, text=f"{e_symbol} {count}", 
                    font=customtkinter.CTkFont(family="Segoe UI Black", size=11),
                    fg_color=btn_bg, hover_color="#E6C300" if has_reacted else "#F0F0F0",
                    text_color="#000000", border_width=2, border_color="#000000",
                    corner_radius=0, width=50, height=26,
                    command=lambda aid=ann_id, ek=e_key: self._toggle_reaction(aid, ek)
                )
                btn.pack(side="left", padx=(0, 6))

    def _toggle_reaction(self, ann_id, emoji_key):
        from core import discord_auth, firebase_sync
        current_dc = discord_auth.get_cached_username()
        if not current_dc: return
        
        threading.Thread(
            target=lambda: firebase_sync.toggle_announcement_reaction(ann_id, emoji_key, current_dc), 
            daemon=True
        ).start()
