import customtkinter
import webbrowser
import sys
import os
import subprocess

def set_dialog_icon(dialog):
    try:
        if getattr(sys, 'frozen', False):
            base_path = sys._MEIPASS
        else:
            base_path = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
        icon_path = os.path.join(base_path, 'assets', 'app_icon_real.ico')
        dialog.iconbitmap(icon_path)
    except Exception:
        pass

class LoadingDialog(customtkinter.CTkToplevel):
    def __init__(self, parent, mode="inject"):
        super().__init__(parent)
        if mode == "inject": win_title = "Proses Injeksi"
        elif mode == "netfix": win_title = "Perbaikan Koneksi"
        else: win_title = "Pembaruan Aplikasi"
        self.title(win_title)
        set_dialog_icon(self)
        
        w, h = 500, 420
        self.resizable(False, False)
        self.transient(parent)
        self.grab_set()

        self.update_idletasks()
        try:
            x = parent.winfo_rootx() + (parent.winfo_width() // 2) - (w // 2)
            y = parent.winfo_rooty() + (parent.winfo_height() // 2) - (h // 2)
        except Exception:
            x = self.winfo_screenwidth() // 2 - w // 2
            y = self.winfo_screenheight() // 2 - h // 2
        self.geometry(f"{w}x{h}+{x}+{y}")
        self.configure(fg_color="#F4EFEB")

        if mode == "inject": title_text = "Inject Berlangsung"
        elif mode == "netfix": title_text = "Memperbaiki Koneksi"
        else: title_text = "Mengunduh Pembaruan"

        lbl_title = customtkinter.CTkLabel(self, text=title_text, font=customtkinter.CTkFont(family="Segoe UI Black", size=24), text_color="#000000")
        lbl_title.pack(pady=(20, 15))
        
        # Decorations
        customtkinter.CTkLabel(self, text="✨", font=("Segoe UI Emoji", 24), fg_color="#F4EFEB").place(x=30, y=20)
        customtkinter.CTkLabel(self, text="✦", font=("Segoe UI Black", 20), text_color="#FF499E", fg_color="#F4EFEB").place(x=430, y=10)
        customtkinter.CTkLabel(self, text="*", font=("Segoe UI Black", 40), text_color="#5D5FEF", fg_color="#F4EFEB").place(x=40, y=340)
        customtkinter.CTkLabel(self, text="✔", font=("Segoe UI Emoji", 28), text_color="#00D084", fg_color="#F4EFEB").place(x=430, y=340)
        
        if mode == "inject":
            self.servers = {
                "Lightning Repo": {"label": "Lightning Repo", "var": customtkinter.StringVar(value="Menunggu...")},
                "SkyApi": {"label": "SkyApi Cloud", "var": customtkinter.StringVar(value="Menunggu...")},
                "Sushi Repo": {"label": "Sushi Repo", "var": customtkinter.StringVar(value="Menunggu...")}
            }
        elif mode == "netfix":
            self.servers = {
                "GitHub": {"label": "GitHub Mirror", "var": customtkinter.StringVar(value="Menunggu...")},
                "ManifestHub": {"label": "ManifestHub API", "var": customtkinter.StringVar(value="Menunggu...")}
            }
        else:
            self.servers = {}

        self.server_frames = {}
        for key, data in self.servers.items():
            f = customtkinter.CTkFrame(self, fg_color="#FFFFFF", border_width=3, border_color="#000000", corner_radius=0)
            f.pack(fill="x", padx=30, pady=5)
            customtkinter.CTkLabel(f, text=data["label"], font=customtkinter.CTkFont(family="Segoe UI Black", size=14), text_color="#000000").pack(side="left", padx=15, pady=10)
            status_lbl = customtkinter.CTkLabel(f, textvariable=data["var"], font=customtkinter.CTkFont(family="Segoe UI Black", size=13), text_color="#555555")
            status_lbl.pack(side="right", padx=15, pady=10)
            self.server_frames[key] = {"frame": f, "status_lbl": status_lbl}
            
        self.lbl_progress = customtkinter.CTkLabel(self, text="☁ Memulai...", font=customtkinter.CTkFont(family="Segoe UI Black", size=14), text_color="#000000")
        self.lbl_progress.pack(pady=(15, 5))
        
        self.progressbar = customtkinter.CTkProgressBar(self, mode="indeterminate", fg_color="#FFFFFF", progress_color="#5D5FEF", border_color="#000000", border_width=3, corner_radius=0, height=12)
        self.progressbar.pack(fill="x", padx=30, pady=5)
        self.progressbar.start()
        
        self.lbl_mb = customtkinter.CTkLabel(self, text="", font=customtkinter.CTkFont(family="Segoe UI", size=12, weight="bold"), text_color="#333333", wraplength=440, justify="center")
        self.lbl_mb.pack(anchor="center", padx=30, pady=(5, 0))
        
        self.btn_ok = customtkinter.CTkButton(self, text="Sembunyikan", command=self.destroy, width=150, height=35, fg_color="#FF499E", hover_color="#E63F8A", border_color="#000000", border_width=3, text_color="#000000", font=customtkinter.CTkFont(family="Segoe UI Black", size=12), corner_radius=0)
        self.btn_ok.pack(pady=(5, 20))

    def update_status(self, text):
        if isinstance(text, dict):
            if text.get("type") == "progress":
                dl = text.get("downloaded", 0)
                tot = text.get("total", 0)
                if tot > 0:
                    self.progressbar.configure(mode="determinate")
                    self.progressbar.set(dl / tot)
                    self.lbl_mb.configure(text=f"Mendownload: {dl/1024/1024:.2f} MB / {tot/1024/1024:.2f} MB")
                else:
                    self.progressbar.configure(mode="indeterminate")
                    if not self.progressbar._is_started: self.progressbar.start()
                    self.lbl_mb.configure(text=f"Mendownload: {dl/1024/1024:.2f} MB")
                return
            else:
                text = text.get("msg", "")

        self.lbl_progress.configure(text=f"☁️ {text}")
        
        if "Menghubungkan ke" in text:
            for s in self.servers.keys():
                if self.servers[s]["var"].get() == "Mencari..." or self.servers[s]["var"].get() == "Mencari...":
                    self.servers[s]["var"].set("Dilewati ➖")
                    self.server_frames[s]["status_lbl"].configure(text_color="#ef4444")
            for s in self.servers.keys():
                if s in text:
                    self.servers[s]["var"].set("Mencari...")
                    self.server_frames[s]["status_lbl"].configure(text_color="#F59E0B")
        elif "Mengunduh" in text:
            for s in self.servers.keys():
                if s in text:
                    self.servers[s]["var"].set("Ditemukan ✔️")
                    self.server_frames[s]["status_lbl"].configure(text_color="#10B981")

    def set_done(self, success, message):
        self.progressbar.stop()
        self.progressbar.configure(mode="determinate")
        self.progressbar.set(1.0 if success else 0.0)
        
        if success:
            self.lbl_progress.configure(text="☁️ BERHASIL!", text_color="#10b981")
            self.lbl_mb.configure(text=message, text_color="#10b981")
        else:
            self.lbl_progress.configure(text="⚠️ GAGAL!", text_color="#ef4444")
            self.lbl_mb.configure(text=message, text_color="#ef4444")
            
        self.btn_ok.configure(text="Tutup")

class InfoDialog(customtkinter.CTkToplevel):
    def __init__(self, parent, title, message):
        super().__init__(parent)
        self.title(title)
        set_dialog_icon(self)
        
        w = 600
        h = 450
        x = self.winfo_screenwidth() // 2 - w // 2
        y = self.winfo_screenheight() // 2 - h // 2
        
        if parent:
            x = parent.winfo_rootx() + (parent.winfo_width() // 2) - (w // 2)
            y = parent.winfo_rooty() + (parent.winfo_height() // 2) - (h // 2)

        self.geometry(f"{w}x{h}+{x}+{y}")
        self.configure(fg_color="#F4EFEB")
        self.attributes("-topmost", True)
        self.grab_set()
        
        lbl_title = customtkinter.CTkLabel(self, text=title, font=customtkinter.CTkFont(family="Segoe UI Black", size=24), text_color="#000000")
        lbl_title.pack(pady=(20, 10))
        
        # Decorations
        customtkinter.CTkLabel(self, text="✦", font=("Segoe UI Black", 20), text_color="#FF499E", fg_color="#F4EFEB").place(x=20, y=10)
        customtkinter.CTkLabel(self, text="🙂", font=("Segoe UI Emoji", 24), fg_color="#F4EFEB").place(x=540, y=15)
        
        frame = customtkinter.CTkFrame(self, fg_color="#FFFFFF", border_width=3, border_color="#000000", corner_radius=0)
        frame.pack(fill="both", expand=True, padx=20, pady=(0, 20))
        
        textbox = customtkinter.CTkTextbox(frame, font=customtkinter.CTkFont(family="Segoe UI", size=13, weight="bold"), text_color="#000000", fg_color="transparent", wrap="word")
        textbox.pack(fill="both", expand=True, padx=10, pady=10)
        textbox.insert("0.0", message)
        textbox.configure(state="disabled")

        def _fade_in(step=0):
            if step <= 10:
                self.attributes("-alpha", step/10.0)
                self.after(16, lambda: _fade_in(step+1))
                
        self.attributes("-alpha", 0.0)
        _fade_in()

class WarningDialog(customtkinter.CTkToplevel):
    def __init__(self, parent, title, message):
        super().__init__(parent)
        self.title(title)
        set_dialog_icon(self)
        
        w = 400
        h = 250
        self.update_idletasks()
        try:
            x = parent.winfo_rootx() + (parent.winfo_width() // 2) - (w // 2)
            y = parent.winfo_rooty() + (parent.winfo_height() // 2) - (h // 2)
        except Exception:
            x = self.winfo_screenwidth() // 2 - w // 2
            y = self.winfo_screenheight() // 2 - h // 2

        self.geometry(f"{w}x{h}+{x}+{y}")
        self.configure(fg_color="#F4EFEB")
        self.attributes("-topmost", True)
        self.grab_set()
        
        lbl_title = customtkinter.CTkLabel(self, text=title, font=customtkinter.CTkFont(family="Segoe UI Black", size=24), text_color="#000000")
        lbl_title.pack(pady=(15, 5))
        
        frame = customtkinter.CTkFrame(self, fg_color="#FFFFFF", border_width=3, border_color="#000000", corner_radius=0)
        frame.pack(fill="both", expand=True, padx=20, pady=(0, 15))
        
        textbox = customtkinter.CTkTextbox(frame, font=customtkinter.CTkFont(family="Segoe UI", size=13, weight="bold"), text_color="#000000", fg_color="transparent", wrap="word")
        textbox.pack(fill="both", expand=True, padx=5, pady=5)
        textbox.insert("0.0", message)
        textbox.configure(state="disabled")
        
        btn_ok = customtkinter.CTkButton(self, text="Mengerti", font=customtkinter.CTkFont(family="Segoe UI Black", size=12), text_color="#000000", fg_color="#FF499E", hover_color="#E63F8A", corner_radius=0, border_width=3, border_color="#000000", command=self.destroy)
        btn_ok.pack(pady=(0, 15))

class ReadyToUpdateDialog(customtkinter.CTkToplevel):
    def __init__(self, parent, new_version, changelog, installer_path):
        super().__init__(parent)
        self.title("Pembaruan Tersedia")
        set_dialog_icon(self)
        
        w = 500
        h = 450
        self.update_idletasks()
        try:
            x = parent.winfo_rootx() + (parent.winfo_width() // 2) - (w // 2)
            y = parent.winfo_rooty() + (parent.winfo_height() // 2) - (h // 2)
        except Exception:
            x = self.winfo_screenwidth() // 2 - w // 2
            y = self.winfo_screenheight() // 2 - h // 2
        self.geometry(f"{w}x{h}+{x}+{y}")
        self.configure(fg_color="#F4EFEB")
        self.attributes("-topmost", True)
        self.grab_set()

        lbl_title = customtkinter.CTkLabel(self, text="Pembaruan Siap Dipasang!", font=customtkinter.CTkFont(family="Segoe UI Black", size=28), text_color="#000000")
        lbl_title.pack(pady=(20, 5))
        
        # Decorations
        customtkinter.CTkLabel(self, text="✨", font=("Segoe UI Emoji", 24), fg_color="#F4EFEB").place(x=20, y=10)
        customtkinter.CTkLabel(self, text="✦", font=("Segoe UI Black", 20), text_color="#5D5FEF", fg_color="#F4EFEB").place(x=450, y=10)
        customtkinter.CTkLabel(self, text="*", font=("Segoe UI Black", 40), text_color="#FF499E", fg_color="#F4EFEB").place(x=30, y=380)
        customtkinter.CTkLabel(self, text="✔", font=("Segoe UI Emoji", 28), text_color="#00D084", fg_color="#F4EFEB").place(x=430, y=390)
        
        lbl_version = customtkinter.CTkLabel(self, text=f"Versi Baru Ditemukan: v{new_version}", font=customtkinter.CTkFont(family="Segoe UI Black", size=14), text_color="#333333")
        lbl_version.pack(pady=(0, 15))

        frame = customtkinter.CTkFrame(self, fg_color="#FFFFFF", border_width=3, border_color="#000000", corner_radius=0)
        frame.pack(fill="both", expand=True, padx=25, pady=(0, 15))
        
        textbox = customtkinter.CTkTextbox(frame, font=customtkinter.CTkFont(family="Segoe UI", size=13, weight="bold"), text_color="#000000", fg_color="transparent", wrap="word")
        textbox.pack(fill="both", expand=True, padx=10, pady=10)
        textbox.insert("0.0", changelog)
        textbox.configure(state="disabled")

        def run_update():
            try:
                import ctypes
                ctypes.windll.shell32.ShellExecuteW(None, "runas", installer_path, "/SILENT", None, 1)
                sys.exit(0)
            except Exception as e:
                pass

        btn_install = customtkinter.CTkButton(self, text="Restart & Perbarui Sekarang", font=customtkinter.CTkFont(family="Segoe UI Black", size=16), text_color="#000000", fg_color="#00D084", hover_color="#00B875", border_width=3, border_color="#000000", corner_radius=0, height=45, command=run_update)
        btn_install.pack(fill="x", padx=25, pady=(0, 10))

        btn_close = customtkinter.CTkButton(self, text="Nanti Saja", font=customtkinter.CTkFont(family="Segoe UI Black", size=14), text_color="#000000", fg_color="#FFFFFF", hover_color="#E0E0E0", corner_radius=0, border_width=3, border_color="#000000", height=35, command=self.destroy)
        btn_close.pack(pady=(0, 20))

class MandatoryUpdateDialog(customtkinter.CTkToplevel):
    def __init__(self, parent, new_version, changelog, download_url):
        super().__init__(parent)
        self.parent = parent
        self.download_url = download_url
        self.title("Pembaruan Wajib Tersedia")
        set_dialog_icon(self)
        
        # Nonaktifkan tombol close (X)
        self.protocol("WM_DELETE_WINDOW", lambda: None)
        
        w = 500
        h = 450
        self.update_idletasks()
        try:
            x = parent.winfo_rootx() + (parent.winfo_width() // 2) - (w // 2)
            y = parent.winfo_rooty() + (parent.winfo_height() // 2) - (h // 2)
        except Exception:
            x = self.winfo_screenwidth() // 2 - w // 2
            y = self.winfo_screenheight() // 2 - h // 2
        self.geometry(f"{w}x{h}+{x}+{y}")
        self.configure(fg_color="#F4EFEB")
        self.attributes("-topmost", True)
        self.grab_set()

        lbl_title = customtkinter.CTkLabel(self, text="Pembaruan Wajib!", font=customtkinter.CTkFont(family="Segoe UI Black", size=28), text_color="#000000")
        lbl_title.pack(pady=(20, 5))
        
        lbl_version = customtkinter.CTkLabel(self, text=f"Versi Baru: v{new_version}", font=customtkinter.CTkFont(family="Segoe UI Black", size=14), text_color="#333333")
        lbl_version.pack(pady=(0, 15))

        frame = customtkinter.CTkFrame(self, fg_color="#FFFFFF", border_width=3, border_color="#000000", corner_radius=0)
        frame.pack(fill="both", expand=True, padx=25, pady=(0, 15))
        
        textbox = customtkinter.CTkTextbox(frame, font=customtkinter.CTkFont(family="Segoe UI", size=13, weight="bold"), text_color="#000000", fg_color="transparent", wrap="word")
        textbox.pack(fill="both", expand=True, padx=10, pady=10)
        textbox.insert("0.0", changelog)
        textbox.configure(state="disabled")

        def start_download_and_update():
            # Hancurkan dialog ini, lalu munculkan dialog loading
            self.destroy()
            loading = LoadingDialog(self.parent, mode="update")
            loading.update_status("Mengunduh Pembaruan...\nMohon jangan tutup aplikasi.")
            
            def download_worker():
                import os, requests, sys, ctypes
                appdata = os.getenv('LOCALAPPDATA', '')
                temp_dir = os.path.join(appdata, 'GameZone', 'temp')
                if not os.path.exists(temp_dir):
                    try: os.makedirs(temp_dir)
                    except: pass
                    
                installer_path = os.path.join(temp_dir, "GameZone_Update_Installer.exe")
                headers = {
                    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36",
                    "Accept": "*/*",
                    "Connection": "keep-alive"
                }
                
                urls_to_try = [self.download_url]
                # If GitHub release URL, fallback to raw CDN URL if connection gets reset
                if "github.com" in self.download_url and "releases/download" in self.download_url:
                    filename = self.download_url.split("/")[-1]
                    urls_to_try.append(f"https://raw.githubusercontent.com/mhmdaryaqadi/GameZone-Release/main/{filename}")

                success = False
                last_error = ""
                for target_url in urls_to_try:
                    try:
                        dl_res = requests.get(target_url, headers=headers, stream=True, timeout=30, allow_redirects=True)
                        if dl_res.status_code == 200:
                            with open(installer_path, 'wb') as f:
                                for chunk in dl_res.iter_content(chunk_size=16384):
                                    if chunk:
                                        f.write(chunk)
                            success = True
                            break
                        else:
                            last_error = f"Server mengembalikan status {dl_res.status_code}"
                    except Exception as err:
                        last_error = str(err)
                        continue

                if success:
                    loading.update_status("Pemasangan otomatis dimulai...")
                    ctypes.windll.shell32.ShellExecuteW(None, "runas", installer_path, "/SILENT", None, 1)
                    os._exit(0)
                else:
                    loading.set_done(False, f"Terjadi kesalahan saat mengunduh: {last_error}")

            import threading
            threading.Thread(target=download_worker, daemon=True).start()

        btn_install = customtkinter.CTkButton(self, text="OK (Perbarui Sekarang)", font=customtkinter.CTkFont(family="Segoe UI Black", size=16), text_color="#000000", fg_color="#00D084", hover_color="#00B875", border_width=3, border_color="#000000", corner_radius=0, height=45, command=start_download_and_update)
        btn_install.pack(fill="x", padx=25, pady=(0, 20))


class DiagnosticDialog(customtkinter.CTkToplevel):
    def __init__(self, parent):
        super().__init__(parent)
        self.parent = parent
        self.title("Diagnostik Kesehatan Game")
        set_dialog_icon(self)

        w, h = 600, 520
        self.resizable(False, False)
        self.transient(parent)
        self.grab_set()

        self.update_idletasks()
        try:
            x = parent.winfo_rootx() + (parent.winfo_width() // 2) - (w // 2)
            y = parent.winfo_rooty() + (parent.winfo_height() // 2) - (h // 2)
        except Exception:
            x = self.winfo_screenwidth() // 2 - w // 2
            y = self.winfo_screenheight() // 2 - h // 2
        self.geometry(f"{w}x{h}+{x}+{y}")
        self.configure(fg_color="#F4EFEB")

        lbl_title = customtkinter.CTkLabel(self, text="🔍 Diagnostik & Health Check", font=customtkinter.CTkFont(family="Segoe UI Black", size=22), text_color="#000000")
        lbl_title.pack(pady=(15, 5))

        self.lbl_subtitle = customtkinter.CTkLabel(self, text="⚡ Memindai seluruh library Steam lokal...", font=customtkinter.CTkFont(family="Segoe UI Black", size=13), text_color="#555555")
        self.lbl_subtitle.pack(pady=(0, 10))

        self.list_frame = customtkinter.CTkScrollableFrame(self, fg_color="#FFFFFF", border_width=3, border_color="#000000", corner_radius=0)
        self.list_frame.pack(fill="both", expand=True, padx=20, pady=(0, 15))

        # Bottom Action Container
        self.action_frame = customtkinter.CTkFrame(self, fg_color="transparent")
        self.action_frame.pack(fill="x", padx=20, pady=(0, 15))
        self.action_frame.grid_columnconfigure(0, weight=1)
        self.action_frame.grid_columnconfigure(1, weight=1)

        self.btn_repair_selected = customtkinter.CTkButton(
            self.action_frame, 
            text="🛠️ PERBAIKI TERPILIH", 
            font=customtkinter.CTkFont(family="Segoe UI Black", size=13), 
            fg_color="#5D5FEF", 
            hover_color="#4B4CD9", 
            text_color="#FFFFFF", 
            border_width=3, 
            border_color="#000000", 
            corner_radius=0, 
            height=42, 
            command=self._start_repair_selected
        )
        self.btn_repair_selected.grid(row=0, column=0, padx=(0, 4), sticky="ew")

        self.btn_repair = customtkinter.CTkButton(
            self.action_frame, 
            text="⚡ PERBAIKI SEMUA (1-KLIK)", 
            font=customtkinter.CTkFont(family="Segoe UI Black", size=13), 
            fg_color="#FFD800", 
            hover_color="#E6C300", 
            text_color="#000000", 
            border_width=3, 
            border_color="#000000", 
            corner_radius=0, 
            height=42, 
            command=self._start_repair
        )
        self.btn_repair.grid(row=0, column=1, padx=(4, 0), sticky="ew")

        self.reports_data = []
        self.selected_appids = set()
        import threading
        threading.Thread(target=self._async_scan, daemon=True).start()

    def _async_scan(self):
        try:
            from services.diagnostic_service import scan_all_games_health
            result = scan_all_games_health()
            self.reports_data = result.get("reports", [])
            healthy = result.get("healthy_count", 0)
            issues = result.get("issues_count", 0)

            # Auto select issues
            self.selected_appids = {item["appid"] for item in self.reports_data if item.get("status") != "healthy"}

            def _update_ui():
                if not self.winfo_exists(): return
                if issues == 0:
                    self.lbl_subtitle.configure(text=f"🟢 Semua Game Sehat! ({healthy} Game Terpindai Normal)", text_color="#10b981")
                else:
                    self.lbl_subtitle.configure(text=f"⚠️ Ditemukan {issues} Game Bermasalah! (Dari {healthy + issues} Game)", text_color="#ef4444")
                self._render_list()

            self.after(0, _update_ui)
        except Exception as e:
            def _err():
                if not self.winfo_exists(): return
                self.lbl_subtitle.configure(text=f"Error saat memindai: {e}", text_color="#ef4444")
            self.after(0, _err)

    def _render_list(self):
        for w in self.list_frame.winfo_children():
            w.destroy()

        if not self.reports_data:
            customtkinter.CTkLabel(self.list_frame, text="Tidak ada game Steam terdeteksi.", font=customtkinter.CTkFont(family="Segoe UI Black", size=13), text_color="#777777").pack(pady=30)
            return

        for item in self.reports_data:
            box = customtkinter.CTkFrame(self.list_frame, fg_color="#F9F9F9", border_width=2, border_color="#000000", corner_radius=0)
            box.pack(fill="x", padx=5, pady=4)

            name = item.get("name", "Unknown Game")
            appid = item.get("appid")
            status = item.get("status")
            issues = item.get("issues", [])

            badge_txt = "🟢 Sehat" if status == "healthy" else "🟡 Butuh Perbaikan"
            badge_bg = "#10b981" if status == "healthy" else "#f59e0b"

            top_row = customtkinter.CTkFrame(box, fg_color="transparent")
            top_row.pack(fill="x", padx=10, pady=5)

            # Checkbox to toggle selection
            var = customtkinter.StringVar(value=appid if appid in self.selected_appids else "")
            def _toggle_sel(aid=appid, v=var):
                if v.get():
                    self.selected_appids.add(aid)
                else:
                    self.selected_appids.discard(aid)

            chk = customtkinter.CTkCheckBox(
                top_row,
                text=name,
                variable=var,
                onvalue=appid,
                offvalue="",
                command=_toggle_sel,
                font=customtkinter.CTkFont(family="Segoe UI Black", size=13),
                text_color="#000000",
                border_color="#000000",
                border_width=2,
                fg_color="#00D084",
                hover_color="#00B875"
            )
            chk.pack(side="left")

            customtkinter.CTkLabel(top_row, text=f" {badge_txt} ", font=customtkinter.CTkFont(family="Segoe UI Black", size=11), fg_color=badge_bg, text_color="#FFFFFF").pack(side="right", padx=(5, 0))

            if issues:
                for iss in issues:
                    customtkinter.CTkLabel(box, text=f"• {iss}", font=customtkinter.CTkFont(family="Segoe UI", size=11, weight="bold"), text_color="#ef4444", anchor="w").pack(fill="x", padx=15, pady=(0, 2))

    def _start_repair_selected(self):
        selected_reports = [item for item in self.reports_data if item["appid"] in self.selected_appids]
        if not selected_reports:
            import tkinter.messagebox as messagebox
            messagebox.showwarning("Perhatian", "Pilih minimal 1 game dengan mencentang kotaknya!", parent=self)
            return
        self._execute_repair(selected_reports)

    def _start_repair(self):
        self._execute_repair(self.reports_data)

    def _execute_repair(self, reports_to_repair):
        if hasattr(self, "btn_repair") and self.btn_repair.winfo_exists():
            self.btn_repair.configure(state="disabled")
        if hasattr(self, "btn_repair_selected") and self.btn_repair_selected.winfo_exists():
            self.btn_repair_selected.configure(state="disabled")

        def _worker():
            try:
                from services.diagnostic_service import repair_all_diagnosed_issues
                ok, cnt, msg = repair_all_diagnosed_issues(reports_to_repair)
                def _done():
                    if not self.winfo_exists(): return
                    if hasattr(self, "btn_repair") and self.btn_repair.winfo_exists():
                        self.btn_repair.configure(state="normal")
                    if hasattr(self, "btn_repair_selected") and self.btn_repair_selected.winfo_exists():
                        self.btn_repair_selected.configure(state="normal")
                    import tkinter.messagebox as messagebox
                    messagebox.showinfo("Berhasil", f"{msg}\n\nPerbaikan selesai & Steam telah dimuat ulang.", parent=self)
                    self._async_scan()
                self.after(0, _done)
            except Exception as e:
                def _err():
                    if not self.winfo_exists(): return
                    if hasattr(self, "btn_repair") and self.btn_repair.winfo_exists():
                        self.btn_repair.configure(state="normal")
                    if hasattr(self, "btn_repair_selected") and self.btn_repair_selected.winfo_exists():
                        self.btn_repair_selected.configure(state="normal")
                    import tkinter.messagebox as messagebox
                    messagebox.showerror("Gagal", str(e), parent=self.winfo_toplevel())
                self.after(0, _err)
        import threading
        threading.Thread(target=_worker, daemon=True).start()


class WorkshopDownloaderDialog(customtkinter.CTkToplevel):
    def __init__(self, parent):
        super().__init__(parent)
        self.title("Wallpaper Engine Workshop Installer")
        set_dialog_icon(self)
        
        w, h = 580, 360
        self.resizable(False, False)
        self.transient(parent)
        self.grab_set()

        self.update_idletasks()
        try:
            x = parent.winfo_rootx() + (parent.winfo_width() // 2) - (w // 2)
            y = parent.winfo_rooty() + (parent.winfo_height() // 2) - (h // 2)
        except Exception:
            x = self.winfo_screenwidth() // 2 - w // 2
            y = self.winfo_screenheight() // 2 - h // 2
        self.geometry(f"{w}x{h}+{x}+{y}")
        self.configure(fg_color="#FFFFFF")

        # Header
        header = customtkinter.CTkFrame(self, fg_color="#F8F9FA", border_width=2, border_color="#000000", corner_radius=0)
        header.pack(fill="x", padx=15, pady=(15, 10))

        lbl_title = customtkinter.CTkLabel(header, text="🎨 Wallpaper Engine Workshop Installer", font=customtkinter.CTkFont(family="Segoe UI Black", size=16), text_color="#000000")
        lbl_title.pack(pady=(10, 2))

        lbl_sub = customtkinter.CTkLabel(header, text="Unduh file wallpaper via Web Downloader, lalu pasang instan via Import File ZIP.", font=customtkinter.CTkFont(family="Segoe UI", size=11, weight="bold"), text_color="#666666")
        lbl_sub.pack(pady=(0, 10))

        # Section 1: Web Downloader Mirrors
        sec1 = customtkinter.CTkFrame(self, fg_color="#FFFFFF", border_width=2, border_color="#000000", corner_radius=0)
        sec1.pack(fill="x", padx=15, pady=(5, 10))

        lbl_m_title = customtkinter.CTkLabel(sec1, text="🌐 Situs Web Downloader Workshop (Klik untuk Buka di Browser):", font=customtkinter.CTkFont(family="Segoe UI Black", size=12), text_color="#000000", anchor="w")
        lbl_m_title.pack(fill="x", padx=12, pady=(10, 6))

        m_btn_frame = customtkinter.CTkFrame(sec1, fg_color="transparent")
        m_btn_frame.pack(fill="x", padx=12, pady=(0, 12))

        btn_web1 = customtkinter.CTkButton(
            m_btn_frame,
            text="🌐 SteamWorkshop.download",
            font=customtkinter.CTkFont(family="Segoe UI Black", size=11),
            fg_color="#3B82F6", hover_color="#2563EB",
            text_color="#FFFFFF",
            height=34, corner_radius=0, border_width=2, border_color="#000000",
            command=lambda: webbrowser.open("http://steamworkshop.download/")
        )
        btn_web1.pack(side="left", expand=True, fill="x", padx=(0, 3))

        btn_web2 = customtkinter.CTkButton(
            m_btn_frame,
            text="🌐 GGntw Steam",
            font=customtkinter.CTkFont(family="Segoe UI Black", size=11),
            fg_color="#5D5FEF", hover_color="#4B4DDB",
            text_color="#FFFFFF",
            height=34, corner_radius=0, border_width=2, border_color="#000000",
            command=lambda: webbrowser.open("https://ggntw.com/steam")
        )
        btn_web2.pack(side="left", expand=True, fill="x", padx=3)

        btn_web3 = customtkinter.CTkButton(
            m_btn_frame,
            text="🌐 SteamCMD Net",
            font=customtkinter.CTkFont(family="Segoe UI Black", size=11),
            fg_color="#10B981", hover_color="#059669",
            text_color="#FFFFFF",
            height=34, corner_radius=0, border_width=2, border_color="#000000",
            command=lambda: webbrowser.open("https://steamcmd.net/")
        )
        btn_web3.pack(side="right", expand=True, fill="x", padx=(3, 0))

        # Section 2: Import & Install ZIP Action
        sec2 = customtkinter.CTkFrame(self, fg_color="#FFFFFF", border_width=2, border_color="#000000", corner_radius=0)
        sec2.pack(fill="x", padx=15, pady=(0, 15))

        lbl_i_title = customtkinter.CTkLabel(sec2, text="📦 Pasang Wallpaper Ke Wallpaper Engine:", font=customtkinter.CTkFont(family="Segoe UI Black", size=12), text_color="#000000", anchor="w")
        lbl_i_title.pack(fill="x", padx=12, pady=(10, 2))

        self.lbl_status = customtkinter.CTkLabel(sec2, text="Pilih berkas .zip wallpaper yang sudah terunduh untuk dipasang otomatis.", font=customtkinter.CTkFont(family="Segoe UI", size=11, weight="bold"), text_color="#666666", wraplength=520, anchor="w")
        self.lbl_status.pack(fill="x", padx=12, pady=(0, 8))

        self.btn_import = customtkinter.CTkButton(
            sec2,
            text="📁 IMPORT & PASANG BERKAS WALLPAPER (.ZIP)",
            font=customtkinter.CTkFont(family="Segoe UI Black", size=13),
            fg_color="#FFD800", hover_color="#E6C300",
            text_color="#000000",
            height=40, corner_radius=0, border_width=2, border_color="#000000",
            command=self._start_import_zip
        )
        self.btn_import.pack(fill="x", padx=12, pady=(0, 12))

    def _start_import_zip(self):
        import tkinter.filedialog as filedialog
        file_path = filedialog.askopenfilename(
            title="Pilih Berkas Wallpaper (.zip)",
            filetypes=[("ZIP Archives", "*.zip"), ("All Files", "*.*")],
            parent=self
        )
        if not file_path:
            return

        self.btn_import.configure(state="disabled")
        self.lbl_status.configure(text="Memasang wallpaper ke Wallpaper Engine...", text_color="#3b82f6")

        def _worker():
            try:
                from services.workshop_downloader_service import install_wallpaper_from_zip
                ok, msg = install_wallpaper_from_zip(file_path)
                def _done():
                    if not self.winfo_exists(): return
                    self.btn_import.configure(state="normal")
                    self.lbl_status.configure(text=msg, text_color="#10b981" if ok else "#ef4444")
                    import tkinter.messagebox as messagebox
                    if ok:
                        messagebox.showinfo("Berhasil Import Wallpaper", msg, parent=self)
                    else:
                        messagebox.showerror("Gagal Import", msg, parent=self)
                self.after(0, _done)
            except Exception as e:
                def _err():
                    if not self.winfo_exists(): return
                    self.btn_import.configure(state="normal")
                    self.lbl_status.configure(text=f"Error: {e}", text_color="#ef4444")
                self.after(0, _err)

        import threading
        threading.Thread(target=_worker, daemon=True).start()


class SteamCleanupDialog(customtkinter.CTkToplevel):
    def __init__(self, parent):
        super().__init__(parent)
        self.title("🧹 Cleanup Sampah Steam (Orphan Files)")
        set_dialog_icon(self)
        
        w, h = 620, 500
        self.resizable(False, False)
        self.transient(parent)
        self.grab_set()

        self.update_idletasks()
        try:
            x = parent.winfo_rootx() + (parent.winfo_width() // 2) - (w // 2)
            y = parent.winfo_rooty() + (parent.winfo_height() // 2) - (h // 2)
        except Exception:
            x = self.winfo_screenwidth() // 2 - w // 2
            y = self.winfo_screenheight() // 2 - h // 2
        self.geometry(f"{w}x{h}+{x}+{y}")
        self.configure(fg_color="#FFFFFF")
        
        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(1, weight=1)

        # Header Title
        hdr = customtkinter.CTkFrame(self, fg_color="#F8F9FA", border_width=2, border_color="#000000", corner_radius=0)
        hdr.grid(row=0, column=0, sticky="ew", padx=20, pady=(20, 10))
        
        lbl_title = customtkinter.CTkLabel(hdr, text="🧹 CLEANUP SAMPAH STEAM (ORPHAN FILES)", font=customtkinter.CTkFont(family="Segoe UI Black", size=16), text_color="#000000")
        lbl_title.pack(anchor="w", padx=15, pady=(12, 4))
        
        lbl_desc = customtkinter.CTkLabel(hdr, text="Deteksi & bersihkan berkas .lua atau .manifest yatim bekas game yang sudah di-uninstall.", font=customtkinter.CTkFont(family="Segoe UI", size=11, weight="bold"), text_color="#555555", justify="left")
        lbl_desc.pack(anchor="w", padx=15, pady=(0, 12))

        # Main Body Box
        body = customtkinter.CTkFrame(self, fg_color="#FFFFFF", border_width=2, border_color="#000000", corner_radius=0)
        body.grid(row=1, column=0, sticky="nsew", padx=20, pady=(0, 20))
        body.grid_columnconfigure(0, weight=1)
        body.grid_rowconfigure(1, weight=1)

        btn_bar = customtkinter.CTkFrame(body, fg_color="transparent")
        btn_bar.grid(row=0, column=0, sticky="w", padx=15, pady=12)

        btn_scan = customtkinter.CTkButton(btn_bar, text="🔍 SCAN FILE SAMPAH", font=customtkinter.CTkFont(family="Segoe UI Black", size=12), text_color="#000000", fg_color="#FF499E", hover_color="#E63F8A", border_width=2, border_color="#000000", corner_radius=0, height=36, command=self.action_scan_cleanup)
        btn_scan.pack(side="left", padx=(0, 10))

        btn_clean = customtkinter.CTkButton(btn_bar, text="🗑️ BERSIHKAN FILE TERPILIH", font=customtkinter.CTkFont(family="Segoe UI Black", size=12), text_color="#FFFFFF", fg_color="#EF4444", hover_color="#DC2626", border_width=2, border_color="#000000", corner_radius=0, height=36, command=self.action_clean_selected)
        btn_clean.pack(side="left")

        self.cleanup_results_frame = customtkinter.CTkScrollableFrame(body, fg_color="#F8F9FA", border_width=2, border_color="#000000", corner_radius=0)
        self.cleanup_results_frame.grid(row=1, column=0, sticky="nsew", padx=15, pady=(0, 15))

        self.lbl_scan_status = customtkinter.CTkLabel(self.cleanup_results_frame, text="Klik 'SCAN FILE SAMPAH' untuk memulai pemindaian...", font=customtkinter.CTkFont(family="Segoe UI", size=12, weight="bold"), text_color="#666666")
        self.lbl_scan_status.pack(padx=15, pady=30)

        self.checkboxes_clean = []

    def action_scan_cleanup(self):
        for widget in self.cleanup_results_frame.winfo_children():
            widget.destroy()
            
        lbl_loading = customtkinter.CTkLabel(self.cleanup_results_frame, text="Memindai sisa berkas yatim di folder Steam...", font=customtkinter.CTkFont(family="Segoe UI", size=12, weight="bold"), text_color="#5D5FEF")
        lbl_loading.pack(padx=15, pady=30)
        
        def run_scan():
            from services.cleanup_service import scan_orphan_files
            data = scan_orphan_files()
            self.after(0, lambda: self.render_cleanup_results(data))
            
        import threading
        threading.Thread(target=run_scan, daemon=True).start()

    def render_cleanup_results(self, data):
        for widget in self.cleanup_results_frame.winfo_children():
            widget.destroy()
            
        self.checkboxes_clean = []
        stplug_lua = data.get("stplug_lua", [])
        manifests = data.get("depot_manifests", [])
        
        orphans = [item for item in stplug_lua if item.get("is_orphan")]
        
        if not orphans and not manifests:
            lbl_empty = customtkinter.CTkLabel(self.cleanup_results_frame, text="✨ Berkas Steam bersih! Tidak ditemukan file .lua atau .manifest sampah/yatim.", font=customtkinter.CTkFont(family="Segoe UI", size=12, weight="bold"), text_color="#10B981")
            lbl_empty.pack(padx=15, pady=30)
            return
            
        if orphans:
            lbl_hdr = customtkinter.CTkLabel(self.cleanup_results_frame, text="[BERKAS .LUA YATIM (GAME SUDAH DIUNINSTALL)]", font=customtkinter.CTkFont(family="Segoe UI Black", size=12), text_color="#EF4444")
            lbl_hdr.pack(anchor="w", padx=10, pady=(5, 5))
            for item in orphans:
                var = customtkinter.StringVar(value="")
                sz_kb = round(item["size"] / 1024, 1)
                chk = customtkinter.CTkCheckBox(self.cleanup_results_frame, text=f"{item['name']} ({sz_kb} KB)", variable=var, onvalue=item["path"], offvalue="", font=customtkinter.CTkFont(family="Segoe UI", size=11, weight="bold"), text_color="#000000", border_color="#000000", border_width=2, fg_color="#EF4444")
                chk.pack(anchor="w", padx=15, pady=3)
                self.checkboxes_clean.append(var)

    def action_clean_selected(self):
        import tkinter.messagebox as messagebox
        selected_paths = [var.get() for var in self.checkboxes_clean if var.get() != ""]
        if not selected_paths:
            messagebox.showwarning("Peringatan", "Silakan centang berkas sampah yang ingin dihapus!", parent=self)
            return
            
        from services.cleanup_service import clean_selected_files
        cnt, freed, errs = clean_selected_files(selected_paths)
        freed_mb = round(freed / (1024 * 1024), 2)
        
        msg = f"Berhasil menghapus {cnt} berkas sampah!\nRuang penyimpanan dibebaskan: {freed_mb} MB."
        if errs:
            msg += "\n\nCatatan:\n" + "\n".join(errs)
            
        messagebox.showinfo("Pembersihan Selesai", msg, parent=self)
        self.action_scan_cleanup()


class ChangelogDialog(customtkinter.CTkToplevel):
    """Popup Changelog Update Terbaru - Ditampilkan SEKALI SAJA khusus setelah install / update."""
    def __init__(self, parent, version_str="2.1.0", on_close_callback=None):
        super().__init__(parent)
        self.title(f"🚀 Pembaruan Aplikasi - Version {version_str}")
        self.on_close_callback = on_close_callback
        set_dialog_icon(self)
        self.protocol("WM_DELETE_WINDOW", self._on_close)
        
        w, h = 580, 460
        self.resizable(False, False)
        self.transient(parent)
        self.grab_set()

        self.update_idletasks()
        try:
            x = parent.winfo_rootx() + (parent.winfo_width() // 2) - (w // 2)
            y = parent.winfo_rooty() + (parent.winfo_height() // 2) - (h // 2)
        except Exception:
            x = self.winfo_screenwidth() // 2 - w // 2
            y = self.winfo_screenheight() // 2 - h // 2
        self.geometry(f"{w}x{h}+{x}+{y}")
        self.configure(fg_color="#FFFFFF")
        
        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(1, weight=1)

        # Header Title
        hdr = customtkinter.CTkFrame(self, fg_color="#5D5FEF", height=60, corner_radius=0)
        hdr.grid(row=0, column=0, sticky="ew")
        hdr.pack_propagate(False)
        
        lbl_title = customtkinter.CTkLabel(hdr, text=f"🎉 PEMBARUAN GAMEZONE v{version_str}", font=customtkinter.CTkFont(family="Segoe UI Black", size=16), text_color="#FFFFFF")
        lbl_title.pack(anchor="w", padx=20, pady=(12, 2))
        
        lbl_desc = customtkinter.CTkLabel(hdr, text="Riwayat pembaruan & fitur terbaru resmi dari admin GameZone.", font=customtkinter.CTkFont(family="Segoe UI", size=11, weight="bold"), text_color="#E0E7FF")
        lbl_desc.pack(anchor="w", padx=20)

        # Textbox for displaying Admin CRUD Changelog
        self.txt_changelog = customtkinter.CTkTextbox(
            self,
            font=customtkinter.CTkFont(family="Segoe UI", size=12, weight="bold"),
            fg_color="#F8F9FA",
            text_color="#000000",
            border_width=2,
            border_color="#000000",
            corner_radius=0
        )
        self.txt_changelog.grid(row=1, column=0, sticky="nsew", padx=20, pady=15)
        
        default_notes = (
            f"✨ [v{version_str}] PERFORMANCES & STABILITY OVERHAUL:\n\n"
            "• ⚡ NetFix Fresh Download Safeguard: Game baru di-download tidak me-restart Steam atau merusak status manifest (0 KB Completed fix).\n"
            "• 📁 Pilih Folder Steam Manual: Bebas menentukan lokasi instalasi Steam secara manual di halaman Settings.\n"
            "• ☁️ Fix Permanent Steam Cloud Error: Menghilangkan warning kuning 'Sinkronisasi gagal' di seluruh profil Steam.\n"
            "• 🔄 Standard Steam Restart: Restart Steam default jauh lebih cepat & ringan tanpa hapus cache lisensi.\n"
            "• 👤 Persistent Local Nickname & Firebase Sync: Local Nickname tersimpan aman di AppData & Firebase Realtime DB.\n"
            "• 📋 Filter & Tampilkan Semua Game NetFix: Tombol 'Tampilkan Semua Game' otomatis muncul saat tidak ada unduhan aktif."
        )
        self.txt_changelog.insert("1.0", default_notes)

        # Bottom Button
        btn_close = customtkinter.CTkButton(
            self,
            text="🚀 MENGERTI & LANJUTKAN",
            font=customtkinter.CTkFont(family="Segoe UI Black", size=13),
            fg_color="#00D084", hover_color="#00B875",
            text_color="#000000",
            height=40, corner_radius=0, border_width=2, border_color="#000000",
            command=self._on_close
        )
        btn_close.grid(row=2, column=0, padx=20, pady=(0, 15), sticky="ew")

        # Fetch changelog from Firebase /version.json in background thread immediately upon open
        import threading
        threading.Thread(target=self._fetch_changelog_data, args=(version_str,), daemon=True).start()

    def _on_close(self):
        self.destroy()
        if callable(self.on_close_callback):
            try:
                self.on_close_callback()
            except Exception:
                pass

    def _fetch_changelog_data(self, version_str):
        changelog_text = ""
        try:
            from core.firebase_sync import get_db_url, session
            db_base = get_db_url()
            url = f"{db_base}/version.json"
            res = session.get(url, timeout=5)
            if res.status_code == 200:
                data = res.json()
                if data and isinstance(data, dict):
                    changelog_text = data.get("changelog", "").strip()
        except Exception:
            pass

        if changelog_text:
            def _update_ui():
                if not self.winfo_exists(): return
                self.txt_changelog.configure(state="normal")
                self.txt_changelog.delete("1.0", "end")
                self.txt_changelog.insert("1.0", changelog_text)
                self.txt_changelog.configure(state="disabled")

            self.after(0, _update_ui)


class WelcomeFirstLoginDialog(customtkinter.CTkToplevel):
    """Popup Welcome & Input Local Nickname - Ditampilkan SEKALI SAJA khusus pengguna baru setelah login."""
    def __init__(self, parent, on_close_callback=None):
        super().__init__(parent)
        self.title("👋 Selamat Datang di GameZone!")
        self.on_close_callback = on_close_callback
        set_dialog_icon(self)
        self.protocol("WM_DELETE_WINDOW", self._on_close)
        
        w, h = 500, 360
        self.resizable(False, False)
        self.transient(parent)
        self.grab_set()

        self.update_idletasks()
        try:
            x = parent.winfo_rootx() + (parent.winfo_width() // 2) - (w // 2)
            y = parent.winfo_rooty() + (parent.winfo_height() // 2) - (h // 2)
        except Exception:
            x = self.winfo_screenwidth() // 2 - w // 2
            y = self.winfo_screenheight() // 2 - h // 2
        self.geometry(f"{w}x{h}+{x}+{y}")
        self.configure(fg_color="#FFFFFF")
        
        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(1, weight=1)

        # Header Title
        hdr = customtkinter.CTkFrame(self, fg_color="#FFD800", height=65, corner_radius=0)
        hdr.grid(row=0, column=0, sticky="ew")
        hdr.pack_propagate(False)
        
        lbl_title = customtkinter.CTkLabel(hdr, text="🎉 SELAMAT DATANG DI GAMEZONE!", font=customtkinter.CTkFont(family="Segoe UI Black", size=16), text_color="#000000")
        lbl_title.pack(anchor="w", padx=20, pady=(12, 2))
        
        lbl_desc = customtkinter.CTkLabel(hdr, text="Terima kasih telah bergabung! Atur nickname lokal kamu untuk memulai.", font=customtkinter.CTkFont(family="Segoe UI", size=11, weight="bold"), text_color="#333333")
        lbl_desc.pack(anchor="w", padx=20)

        # Main Body
        body = customtkinter.CTkFrame(self, fg_color="#F8F9FA", border_width=2, border_color="#000000", corner_radius=0)
        body.grid(row=1, column=0, sticky="nsew", padx=20, pady=15)
        
        lbl_input_title = customtkinter.CTkLabel(body, text="👤 MASUKKAN LOCAL NICKNAME KAMU:", font=customtkinter.CTkFont(family="Segoe UI Black", size=13), text_color="#000000", anchor="w")
        lbl_input_title.pack(fill="x", padx=15, pady=(15, 5))

        lbl_sub = customtkinter.CTkLabel(body, text="Nama ini akan tampil di profil & status GameZone kamu. Tersimpan permanen ke Firebase.", font=customtkinter.CTkFont(family="Segoe UI", size=11, weight="bold"), text_color="#666666", wraplength=420, justify="left", anchor="w")
        lbl_sub.pack(fill="x", padx=15, pady=(0, 15))

        self.entry_nick = customtkinter.CTkEntry(
            body,
            placeholder_text="Masukkan Local Nickname Kamu...",
            width=360,
            height=38,
            font=customtkinter.CTkFont(family="Segoe UI", size=14, weight="bold"),
            fg_color="#FFFFFF",
            text_color="#000000",
            border_width=2,
            border_color="#000000",
            corner_radius=0
        )
        self.entry_nick.pack(padx=15, pady=(0, 15))

        # Bottom Button
        btn_start = customtkinter.CTkButton(
            self,
            text="🚀 SIMPAN NICKNAME & MULAI BROWSE",
            font=customtkinter.CTkFont(family="Segoe UI Black", size=13),
            fg_color="#5D5FEF", hover_color="#4B4CD9",
            text_color="#FFFFFF",
            height=42, corner_radius=0, border_width=2, border_color="#000000",
            command=self._on_save_start
        )
        btn_start.grid(row=2, column=0, padx=20, pady=(0, 15), sticky="ew")

    def _on_save_start(self):
        nick = self.entry_nick.get().strip()
        if not nick:
            from core import discord_auth
            dc_username = discord_auth.get_cached_username()
            nick = dc_username if (dc_username and dc_username != "Local User" and dc_username != "Unknown") else "GamerZone"
            
        try:
            from core import profile_manager
            profile_manager.save_profile(nick, "avatar1.png")
            from core.config import mark_first_login_welcome_done
            mark_first_login_welcome_done()

            # Trigger immediate UI refresh on top bar & pages
            master_app = getattr(self, 'master', None) or getattr(self, 'parent', None)
            if master_app and hasattr(master_app, 'update_sidebar_profile'):
                master_app.update_sidebar_profile()
        except Exception:
            pass

        self._on_close()

    def _on_close(self):
        self.destroy()
        if callable(self.on_close_callback):
            try:
                self.on_close_callback()
            except Exception:
                pass

