import os
import sys
import threading
import time
import requests
import customtkinter
from core.firebase_sync import session as admin_session

# Add parent directory to sys.path so we can import core modules if run directly
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from core.config import load_config
from pages.admin.users import UserMonitorTab
from pages.admin.accounts import AccountsTab
from pages.admin.announce import AnnouncementsTab
from pages.admin.db_settings import DBSettingsTab
from pages.admin.info_crud import InfoCRUDTab
from pages.admin.live_update import LiveUpdateTab
from pages.admin.reports import ReportsTab
from pages.admin.appeals import AppealsTab

class GameZoneAdminApp(customtkinter.CTk):
    def __init__(self):
        super().__init__()
        self.withdraw() # Hide window during initialization
        
        self.config = load_config()
        self.db_url = self.config.get("firebase_url", "https://gamezone-5d5fef-default-rtdb.firebaseio.com").strip()
        if self.db_url.endswith("/"):
            self.db_url = self.db_url[:-1]

        customtkinter.set_appearance_mode("dark")
        self.title("GameZone - Admin Control Panel")
        
        # Dimensions
        w = 1100
        h = 650
        screen_w = self.winfo_screenwidth()
        screen_h = self.winfo_screenheight()
        pos_x = (screen_w // 2) - (w // 2)
        pos_y = (screen_h // 2) - (h // 2)
        self.geometry(f"{w}x{h}+{pos_x}+{pos_y}")
        self.minsize(1000, 600)
        self.configure(fg_color="#F4EFEB")

        # Layout grid
        self.grid_columnconfigure(0, weight=0) # Sidebar
        self.grid_columnconfigure(1, weight=1) # Main Content
        self.grid_rowconfigure(0, weight=1)

        # =========================================================================
        # SIDEBAR
        # =========================================================================
        self.sidebar = customtkinter.CTkFrame(self, width=220, fg_color="#FFFFFF", border_width=4, border_color="#000000", corner_radius=0)
        self.sidebar.grid(row=0, column=0, sticky="nsew", padx=(20, 0), pady=20)
        self.sidebar.grid_propagate(False)
        self.sidebar.pack_propagate(False)
        self.sidebar.grid_columnconfigure(0, weight=1)

        lbl_logo = customtkinter.CTkLabel(self.sidebar, text="ZONE ADMIN", font=customtkinter.CTkFont(family="Segoe UI Black", size=22), text_color="#000000")
        lbl_logo.pack(pady=(30, 5))
        
        lbl_sub = customtkinter.CTkLabel(self.sidebar, text="✦ Control Center ✦", font=customtkinter.CTkFont(family="Segoe UI", size=13, weight="bold"), text_color="#FF499E")
        lbl_sub.pack(pady=(0, 30))

        # Menu Buttons
        btn_font = customtkinter.CTkFont(family="Segoe UI Black", size=15)
        
        self.btn_users = customtkinter.CTkButton(self.sidebar, text="👤 User Monitor", anchor="w", fg_color="#FFD800", hover_color="#E6C300", text_color="#000000", font=btn_font, border_width=3, border_color="#000000", corner_radius=0, height=45, command=self.show_users_tab)
        self.btn_users.pack(fill="x", padx=15, pady=5)
        
        self.btn_accounts = customtkinter.CTkButton(self.sidebar, text="🔑 Shared Accounts", anchor="w", fg_color="transparent", hover_color="#E0E0E0", text_color="#000000", font=btn_font, border_width=3, border_color="#F4EFEB", corner_radius=0, height=45, command=self.show_accounts_tab)
        self.btn_accounts.pack(fill="x", padx=15, pady=5)
        
        self.btn_announce = customtkinter.CTkButton(self.sidebar, text="📣 Announcements", anchor="w", fg_color="transparent", hover_color="#E0E0E0", text_color="#000000", font=btn_font, border_width=3, border_color="#F4EFEB", corner_radius=0, height=45, command=self.show_announcements_tab)
        self.btn_announce.pack(fill="x", padx=15, pady=5)
        
        self.btn_db = customtkinter.CTkButton(self.sidebar, text="⚙️ Database Settings", anchor="w", fg_color="transparent", hover_color="#E0E0E0", text_color="#000000", font=btn_font, border_width=3, border_color="#F4EFEB", corner_radius=0, height=45, command=self.show_db_tab)
        self.btn_db.pack(fill="x", padx=15, pady=5)

        self.btn_info_crud = customtkinter.CTkButton(self.sidebar, text="📝 Info & Guides", anchor="w", fg_color="transparent", hover_color="#E0E0E0", text_color="#000000", font=btn_font, border_width=3, border_color="#F4EFEB", corner_radius=0, height=45, command=self.show_info_crud_tab)
        self.btn_info_crud.pack(fill="x", padx=15, pady=5)

        self.btn_live_update = customtkinter.CTkButton(self.sidebar, text="🔄 Live Update", anchor="w", fg_color="transparent", hover_color="#E0E0E0", text_color="#000000", font=btn_font, border_width=3, border_color="#F4EFEB", corner_radius=0, height=45, command=self.show_live_update_tab)
        self.btn_live_update.pack(fill="x", padx=15, pady=5)

        self.btn_reports = customtkinter.CTkButton(self.sidebar, text="📥 Bug Reports", anchor="w", fg_color="transparent", hover_color="#E0E0E0", text_color="#000000", font=btn_font, border_width=3, border_color="#F4EFEB", corner_radius=0, height=45, command=self.show_reports_tab)
        self.btn_reports.pack(fill="x", padx=15, pady=5)

        self.btn_appeals = customtkinter.CTkButton(self.sidebar, text="⚖️ Appeals Management", anchor="w", fg_color="transparent", hover_color="#E0E0E0", text_color="#000000", font=btn_font, border_width=3, border_color="#F4EFEB", corner_radius=0, height=45, command=self.show_appeals_tab)
        self.btn_appeals.pack(fill="x", padx=15, pady=5)

        # =========================================================================
        # MAIN CONTENT CONTAINER
        # =========================================================================
        self.content_frame = customtkinter.CTkFrame(self, fg_color="transparent")
        self.content_frame.grid(row=0, column=1, sticky="nsew", padx=20, pady=20)
        self.content_frame.grid_columnconfigure(0, weight=1)
        self.content_frame.grid_rowconfigure(0, weight=1)

        # Initialize Tabs
        self.tab_users = UserMonitorTab(self.content_frame, self)
        self.tab_accounts = AccountsTab(self.content_frame, self)
        self.tab_announce = AnnouncementsTab(self.content_frame, self)
        self.tab_db = DBSettingsTab(self.content_frame, self)
        self.tab_info_crud = InfoCRUDTab(self.content_frame, self)
        self.tab_live_update = LiveUpdateTab(self.content_frame, self)
        self.tab_reports = ReportsTab(self.content_frame, self)
        self.tab_appeals = AppealsTab(self.content_frame, self)

        self.current_tab = None
        self.show_users_tab()

        # Start auto-refresh thread for active tabs
        self.running = True
        threading.Thread(target=self._auto_refresh_loop, daemon=True).start()

        # Force CustomTkinter widgets to complete their _draw cycles
        self.update()
        import time
        time.sleep(0.05)
        self.update()
        self.deiconify()

    # =========================================================================
    # TAB VIEW ROUTING
    # =========================================================================
    def _switch_tab(self, new_tab):
        if self.current_tab == new_tab: return
        if self.current_tab:
            try:
                self.current_tab.grid_forget()
            except Exception:
                pass
        self.current_tab = new_tab
        new_tab.grid(row=0, column=0, sticky="nsew")
        
        try:
            from core.skeleton import show_skeleton
            show_skeleton(new_tab)
        except Exception:
            pass
            
        self.update_idletasks()


    def _reset_sidebar_buttons(self):
        self.btn_users.configure(fg_color="transparent", border_color="#F4EFEB")
        self.btn_accounts.configure(fg_color="transparent", border_color="#F4EFEB")
        self.btn_announce.configure(fg_color="transparent", border_color="#F4EFEB")
        self.btn_db.configure(fg_color="transparent", border_color="#F4EFEB")
        self.btn_info_crud.configure(fg_color="transparent", border_color="#F4EFEB")
        self.btn_live_update.configure(fg_color="transparent", border_color="#F4EFEB")
        self.btn_reports.configure(fg_color="transparent", border_color="#F4EFEB")
        self.btn_appeals.configure(fg_color="transparent", border_color="#F4EFEB")

    def show_users_tab(self):
        self._reset_sidebar_buttons()
        self.btn_users.configure(fg_color="#FFD800", border_color="#000000")
        self._switch_tab(self.tab_users)
        self.tab_users.refresh_users()

    def show_accounts_tab(self):
        self._reset_sidebar_buttons()
        self.btn_accounts.configure(fg_color="#FFD800", border_color="#000000")
        self._switch_tab(self.tab_accounts)
        self.tab_accounts.refresh_accounts()

    def show_announcements_tab(self):
        self._reset_sidebar_buttons()
        self.btn_announce.configure(fg_color="#FFD800", border_color="#000000")
        self._switch_tab(self.tab_announce)
        self.tab_announce.refresh_announcement()

    def show_db_tab(self):
        self._reset_sidebar_buttons()
        self.btn_db.configure(fg_color="#FFD800", border_color="#000000")
        self._switch_tab(self.tab_db)
        self.tab_db.refresh_db_keys()

    def show_info_crud_tab(self):
        self._reset_sidebar_buttons()
        self.btn_info_crud.configure(fg_color="#FFD800", border_color="#000000")
        self._switch_tab(self.tab_info_crud)
        self.tab_info_crud.refresh_info_crud()

    def show_live_update_tab(self):
        self._reset_sidebar_buttons()
        self.btn_live_update.configure(fg_color="#FFD800", border_color="#000000")
        self._switch_tab(self.tab_live_update)
        self.tab_live_update.refresh_live_update()

    def show_reports_tab(self):
        self.btn_reports.configure(text="📥 Bug Reports")
        self._reset_sidebar_buttons()
        self.btn_reports.configure(fg_color="#FFD800", border_color="#000000")
        self._switch_tab(self.tab_reports)
        self.tab_reports.refresh_reports_tab_data()

    def show_appeals_tab(self):
        self.btn_appeals.configure(text="⚖️ Appeals Management")
        self._reset_sidebar_buttons()
        self.btn_appeals.configure(fg_color="#FFD800", border_color="#000000")
        self._switch_tab(self.tab_appeals)
        self.tab_appeals.refresh_appeals()

    def _auto_refresh_loop(self):
        while self.running:
            if self.current_tab and hasattr(self.current_tab, "refresh"):
                # Do not auto-refresh form editing tabs to prevent overwriting admin inputs
                if self.current_tab not in (self.tab_live_update, self.tab_info_crud, self.tab_announce, self.tab_db):
                    try:
                        self.current_tab.refresh()
                    except Exception:
                        pass
            try:
                self._check_admin_notifications()
            except Exception:
                pass
            time.sleep(3)

    def _check_admin_notifications(self):
        has_pending_appeals = False
        try:
            url_app = f"{self.db_url}/appeals.json"
            res = admin_session.get(url_app, timeout=5)
            if res.status_code == 200:
                data = res.json()
                if data:
                    for a in data.values():
                        if a.get("status") == "pending":
                            has_pending_appeals = True
                            break
        except:
            pass
            
        has_bug_reports = False
        try:
            url_rep = f"{self.db_url}/reports.json"
            res = admin_session.get(url_rep, timeout=5)
            if res.status_code == 200:
                data = res.json()
                if data:
                    has_bug_reports = True
        except:
            pass
            
        self.after(0, lambda: self._update_notification_badges(has_pending_appeals, has_bug_reports))

    def _update_notification_badges(self, has_pending, has_bugs):
        target_appeals = "⚖️ Appeals Management"
        if self.current_tab != self.tab_appeals and has_pending:
            target_appeals = "⚖️ Appeals Management 🔴"

        target_reports = "📥 Bug Reports"
        if self.current_tab != self.tab_reports and has_bugs:
            target_reports = "📥 Bug Reports 🔴"

        if self.btn_appeals.cget("text") != target_appeals:
            self.btn_appeals.configure(text=target_appeals)
            
        if self.btn_reports.cget("text") != target_reports:
            self.btn_reports.configure(text=target_reports)

    def destroy(self):
        self.running = False
        super().destroy()

if __name__ == "__main__":
    app = GameZoneAdminApp()
    app.mainloop()
