import concurrent.futures
import threading

# Shared ThreadPoolExecutor with max 8 worker threads for optimal CPU/IO concurrency
_executor = concurrent.futures.ThreadPoolExecutor(max_workers=8, thread_name_prefix="GameZoneWorker")

def run_async(func, *args, **kwargs):
    """
    Submits a task to the shared ThreadPoolExecutor.
    Prevents thread creation overhead and thread exhaustion.
    """
    return _executor.submit(func, *args, **kwargs)

def shutdown_workers():
    """Cleanly shuts down worker pool upon app exit."""
    _executor.shutdown(wait=False)
