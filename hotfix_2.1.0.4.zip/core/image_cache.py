import os
import threading
from PIL import Image, ImageDraw
import customtkinter

_image_cache = {}
_lock = threading.Lock()

def get_cached_ctk_image(image_path, size=(38, 38), circle_mask=False):
    """
    Retrieves or creates a cached CTkImage instance.
    Guarantees 0ms UI latency for previously loaded images.
    """
    cache_key = (str(image_path), size[0], size[1], circle_mask)
    
    with _lock:
        if cache_key in _image_cache:
            return _image_cache[cache_key]

    if not image_path or not os.path.exists(image_path):
        return None

    try:
        pil_img = Image.open(image_path).resize(size).convert("RGBA")
        
        if circle_mask:
            mask = Image.new('L', size, 0)
            draw = ImageDraw.Draw(mask)
            draw.ellipse((0, 0, size[0], size[1]), fill=255)
            
            result = Image.new('RGBA', size, (0, 0, 0, 0))
            result.paste(pil_img, (0, 0), mask=mask)
            pil_img = result

        ctk_img = customtkinter.CTkImage(light_image=pil_img, size=size)
        
        with _lock:
            _image_cache[cache_key] = ctk_img
            
        return ctk_img
    except Exception:
        return None

def clear_image_cache():
    """Clears memory cache when requested."""
    with _lock:
        _image_cache.clear()
