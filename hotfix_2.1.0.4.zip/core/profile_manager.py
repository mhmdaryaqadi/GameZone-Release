import os
import json
import threading

def get_profile_file():
    appdata_dir = os.path.join(os.getenv('LOCALAPPDATA', os.path.expanduser('~')), 'GameZone')
    os.makedirs(appdata_dir, exist_ok=True)
    return os.path.join(appdata_dir, "profile.json")

_cached_profile = None

def fetch_profile_from_firebase(dc_username):
    if not dc_username or dc_username == "Local User":
        return None
    try:
        from core.firebase_sync import get_db_url, sanitize_key, session
        db_base = get_db_url()
        clean_user = sanitize_key(dc_username)
        url = f"{db_base}/users/{clean_user}.json"
        res = session.get(url, timeout=5)
        if res.status_code == 200:
            data = res.json()
            if data and isinstance(data, dict):
                nick = data.get("nickname")
                av = data.get("avatar") or "avatar1.png"
                if nick and nick != "Anonymous":
                    return {"nickname": nick, "avatar": av}
    except Exception:
        pass
    return None

def sync_profile_to_firebase(dc_username, nickname, avatar):
    if not dc_username or dc_username == "Local User":
        return False
    try:
        from core.firebase_sync import get_db_url, sanitize_key, session
        from core import discord_auth
        db_base = get_db_url()
        clean_user = sanitize_key(dc_username)
        url = f"{db_base}/users/{clean_user}.json"
        
        dc_avatar = discord_auth.get_cached_avatar_url()
        payload = {
            "nickname": nickname,
            "avatar": avatar,
        }
        if dc_avatar:
            payload["avatar_url"] = dc_avatar

        res = session.patch(url, json=payload, timeout=5)
        return res.status_code == 200
    except Exception:
        return False

def load_profile():
    global _cached_profile
    if _cached_profile is not None:
        return _cached_profile

    profile_file = get_profile_file()
    legacy_file = os.path.join("cache", "profile.json")

    # 1. Try reading persistent AppData profile.json
    if os.path.exists(profile_file):
        try:
            with open(profile_file, 'r', encoding='utf-8') as f:
                _cached_profile = json.load(f)
                if _cached_profile.get("nickname") and _cached_profile.get("nickname") != "Anonymous":
                    return _cached_profile
        except Exception:
            pass

    # 2. Try reading legacy cache/profile.json
    if os.path.exists(legacy_file):
        try:
            with open(legacy_file, 'r', encoding='utf-8') as f:
                legacy_data = json.load(f)
                if legacy_data.get("nickname") and legacy_data.get("nickname") != "Anonymous":
                    _cached_profile = legacy_data
                    save_profile(_cached_profile.get("nickname"), _cached_profile.get("avatar", "avatar1.png"))
                    return _cached_profile
        except Exception:
            pass

    # 3. Try fetching from Firebase if Discord user is logged in
    try:
        from core import discord_auth
        dc_user = discord_auth.get_cached_username()
        if dc_user and dc_user != "Local User":
            fb_profile = fetch_profile_from_firebase(dc_user)
            if fb_profile and fb_profile.get("nickname"):
                _cached_profile = fb_profile
                save_profile(_cached_profile.get("nickname"), _cached_profile.get("avatar", "avatar1.png"))
                return _cached_profile
    except Exception:
        pass

    _cached_profile = {"nickname": "Anonymous", "avatar": "avatar1.png"}
    return _cached_profile

def save_profile(nickname, avatar):
    global _cached_profile
    _cached_profile = {"nickname": nickname, "avatar": avatar}

    # Save to persistent AppData
    profile_file = get_profile_file()
    try:
        with open(profile_file, 'w', encoding='utf-8') as f:
            json.dump(_cached_profile, f)
    except Exception:
        pass

    # Save to project cache directory
    try:
        os.makedirs("cache", exist_ok=True)
        with open(os.path.join("cache", "profile.json"), 'w', encoding='utf-8') as f:
            json.dump(_cached_profile, f)
    except Exception:
        pass

    # Push to Firebase in background thread
    def _async_sync_fb():
        try:
            from core import discord_auth
            dc_user = discord_auth.get_cached_username()
            if dc_user and dc_user != "Local User":
                sync_profile_to_firebase(dc_user, nickname, avatar)
        except Exception:
            pass

    threading.Thread(target=_async_sync_fb, daemon=True).start()

def sync_on_login(dc_username):
    """Sync profile from Firebase as soon as user logs in via Discord."""
    if not dc_username or dc_username == "Local User":
        return
    def _bg():
        global _cached_profile
        fb_prof = fetch_profile_from_firebase(dc_username)
        if fb_prof and fb_prof.get("nickname"):
            _cached_profile = fb_prof
            profile_file = get_profile_file()
            try:
                with open(profile_file, 'w', encoding='utf-8') as f:
                    json.dump(fb_prof, f)
            except Exception:
                pass
            try:
                os.makedirs("cache", exist_ok=True)
                with open(os.path.join("cache", "profile.json"), 'w', encoding='utf-8') as f:
                    json.dump(fb_prof, f)
            except Exception:
                pass
    threading.Thread(target=_bg, daemon=True).start()
