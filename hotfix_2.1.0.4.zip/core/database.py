import sqlite3
import os

appdata = os.getenv('LOCALAPPDATA', '')
db_dir = os.path.join(appdata, 'GameZone')
if not os.path.exists(db_dir):
    try: os.makedirs(db_dir)
    except: pass

DB_PATH = os.path.join(db_dir, "gamezone_data.db")

def get_connection():
    conn = sqlite3.connect(DB_PATH, timeout=10)
    try:
        conn.execute("PRAGMA journal_mode=WAL;")
        conn.execute("PRAGMA synchronous=NORMAL;")
    except Exception:
        pass
    return conn

def init_db():
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS injected_games (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            appid TEXT,
            title TEXT,
            injected_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    conn.commit()
    conn.close()

def insert_injected_game(appid, title):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT id FROM injected_games WHERE appid = ?", (appid,))
    if not cursor.fetchone():
        cursor.execute("INSERT INTO injected_games (appid, title) VALUES (?, ?)", (appid, title))
        conn.commit()
    conn.close()

def update_injected_game_title(appid, title):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("UPDATE injected_games SET title = ? WHERE appid = ?", (title, appid))
    conn.commit()
    conn.close()

def get_injected_games():
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT appid, title, injected_at FROM injected_games ORDER BY injected_at DESC")
    games = cursor.fetchall()
    conn.close()

    # Automatic filesystem sync with stplug-in .lua files
    try:
        from services.steam_service import get_steam_path
        steam_base = get_steam_path()
        stplug_dir = os.path.join(steam_base, "config", "stplug-in")
        
        valid_games = []
        lua_files = set(os.listdir(stplug_dir)) if os.path.exists(stplug_dir) else set()
        
        orphaned_appids = []
        for appid, title, injected_at in games:
            # Check if appid.lua or appid_*.lua exists in stplug-in
            has_lua = any(f.startswith(str(appid)) and f.endswith('.lua') for f in lua_files)
            if has_lua:
                valid_games.append((appid, title, injected_at))
            else:
                orphaned_appids.append(appid)
        
        # Purge orphaned records from database
        if orphaned_appids:
            conn_del = get_connection()
            cur_del = conn_del.cursor()
            cur_del.executemany("DELETE FROM injected_games WHERE appid = ?", [(aid,) for aid in orphaned_appids])
            conn_del.commit()
            conn_del.close()
            
        return valid_games
    except Exception:
        return games

def delete_injected_game(appid):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM injected_games WHERE appid = ?", (appid,))
    conn.commit()
    conn.close()
