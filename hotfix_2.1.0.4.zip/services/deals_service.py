import os
import json
import time
import requests
import re

CACHE_TTL = 7200  # 2 Hours Cache

def get_cache_path():
    appdata_dir = os.path.join(os.getenv('LOCALAPPDATA', os.path.expanduser('~')), 'GameZone', 'cache')
    os.makedirs(appdata_dir, exist_ok=True)
    return os.path.join(appdata_dir, 'deals_cache.json')

USD_TO_IDR_RATE = 16000  # Kurs standar 1 USD = Rp 16.000

def format_price_idr(usd_amount):
    try:
        val = float(usd_amount)
        if val <= 0:
            return "GRATIS 100%"
        idr_val = int(val * USD_TO_IDR_RATE)
        idr_rounded = (idr_val // 100) * 100
        return f"Rp {idr_rounded:,}".replace(",", ".")
    except Exception:
        return "GRATIS 100%"

def fetch_live_deals_and_events():
    """
    Fetches real-time PC game deals, 100% free games, and Steam sales/events.
    Uses 2-hour local disk cache to ensure 0ms instant load times.
    Deduplicates games strictly by normalized title to prevent duplicates.
    Prioritizes official Steam Indonesia regional prices (IDR).
    """
    cache_path = get_cache_path()
    now = time.time()
    headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"}

    # 1. Check local cache (only accept if discounts is non-empty and deduplicated)
    if os.path.exists(cache_path):
        try:
            with open(cache_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
                cached_at = data.get('cached_at', 0)
                if now - cached_at < CACHE_TTL and data.get('discounts') and len(data['discounts']) > 0:
                    return data
        except Exception:
            pass

    # 2. Fetch fresh data from APIs
    discounts = []
    freebies = []
    events = []
    
    seen_discounts = set()
    seen_events = set()
    seen_freebies = set()

    def _normalize(t):
        return re.sub(r'[^a-zA-Z0-9]', '', str(t or '')).lower()

    # SECTION 1: 🎪 Steam Events & Sales (Official Steam Featured Categories)
    try:
        url_steam = "https://store.steampowered.com/api/featuredcategories?cc=id&l=indonesian"
        res_steam = requests.get(url_steam, headers=headers, timeout=6)
        if res_steam.status_code == 200:
            s_data = res_steam.json()
            
            for category in ["specials", "top_sellers", "new_releases"]:
                cat_items = s_data.get(category, {}).get("items", [])
                for item in cat_items:
                    name = item.get("name")
                    if not name:
                        continue
                    
                    norm_key = _normalize(name)
                    if norm_key in seen_events:
                        continue

                    fin_cents = item.get("final_price") or 0
                    orig_cents = item.get("original_price") or 0
                    disc_pct = item.get("discount_percent") or 0
                    currency = str(item.get("currency", "IDR")).upper()

                    if fin_cents <= 0 and orig_cents <= 0:
                        continue

                    if currency == "IDR":
                        formatted_final = f"Rp {(fin_cents // 100):,}".replace(",", ".")
                        formatted_orig = f"Rp {(orig_cents // 100):,}".replace(",", ".")
                    else:
                        formatted_final = format_price_idr(fin_cents / 100.0)
                        formatted_orig = format_price_idr(orig_cents / 100.0)

                    ev_obj = {
                        "title": name,
                        "discount_pct": f"-{disc_pct}%",
                        "savings_pct": f"-{disc_pct}%",
                        "sale_price": formatted_final,
                        "normal_price": formatted_orig,
                        "final_price": formatted_final,
                        "thumb": item.get("header_image") or item.get("large_capsule_image"),
                        "store_url": f"https://store.steampowered.com/app/{item.get('id')}/",
                        "is_free": (fin_cents == 0 or disc_pct >= 99)
                    }

                    seen_events.add(norm_key)
                    if not ev_obj["is_free"]:
                        events.append(ev_obj)
    except Exception:
        pass

    # SECTION 2: 🔥 Diskon Besar (Deep PC Game Discounts >= 50% OFF)
    try:
        url_deals = "https://www.cheapshark.com/api/1.0/deals?onSale=1&minDiscount=50&pageSize=25&sortBy=Savings"
        res = requests.get(url_deals, headers=headers, timeout=6)
        if res.status_code == 200:
            for item in res.json():
                title = item.get("title", "Game PC")
                norm_key = _normalize(title)
                if norm_key in seen_discounts:
                    continue

                sale_price = float(item.get("salePrice", 0))
                norm_price = float(item.get("normalPrice", 0))
                savings = float(item.get("savings", 0))

                if savings < 40.0:  # Must be a big discount!
                    continue

                steam_appid = item.get("steamAppID")
                thumb = item.get("thumb")
                deal_id = item.get("dealID")
                
                store_url = f"https://www.cheapshark.com/redirect?dealID={deal_id}"
                if steam_appid and str(steam_appid) != "None":
                    store_url = f"https://store.steampowered.com/app/{steam_appid}/"
                    if not thumb:
                        thumb = f"https://cdn.akamai.steamstatic.com/steam/apps/{steam_appid}/header.jpg"

                is_free_game = (sale_price == 0 or savings >= 99.0)
                if is_free_game:
                    continue

                item_obj = {
                    "title": title,
                    "sale_price": format_price_idr(sale_price),
                    "normal_price": format_price_idr(norm_price),
                    "savings_pct": f"-{int(savings)}%",
                    "thumb": thumb,
                    "store_url": store_url,
                    "is_free": False
                }

                seen_discounts.add(norm_key)
                discounts.append(item_obj)
    except Exception:
        pass

    # SECTION 3: 🎁 Game Gratis 100% Freebies
    try:
        url_free = "https://www.gamerpower.com/api/giveaways?platform=pc"
        res_free = requests.get(url_free, headers=headers, timeout=6)
        if res_free.status_code == 200:
            for item in res_free.json()[:10]:
                title = item.get("title", "Free Game")
                norm_key = _normalize(title)
                if norm_key in seen_freebies:
                    continue

                worth_raw = str(item.get("worth", "")).replace("$", "").replace("N/A", "0").strip()
                try:
                    worth_val = float(worth_raw)
                    norm_str = format_price_idr(worth_val) if worth_val > 0 else "GRATIS"
                except Exception:
                    norm_str = "GRATIS"

                seen_freebies.add(norm_key)
                freebies.append({
                    "title": title,
                    "sale_price": "GRATIS 100%",
                    "normal_price": norm_str,
                    "savings_pct": "100%",
                    "thumb": item.get("image", ""),
                    "store_url": item.get("open_giveaway_url", "https://store.steampowered.com/"),
                    "is_free": True
                })
    except Exception:
        pass

    # Fallback mock data if APIs were blocked or offline
    if not discounts and not freebies:
        freebies = [
            {
                "title": "Epic Games Free Weekly Titles",
                "sale_price": "GRATIS 100%",
                "normal_price": "$29.99",
                "savings_pct": "100%",
                "thumb": "https://cdn2.unrealengine.com/egs-freegames-community-capsule-1920x1080-1920x1080-798835012.png",
                "store_url": "https://store.epicgames.com/free-games",
                "is_free": True
            }
        ]
        discounts = [
            {
                "title": "Black Myth: Wukong - Publisher Sale",
                "sale_price": "Rp 489.999",
                "normal_price": "Rp 699.999",
                "savings_pct": "-30%",
                "thumb": "https://cdn.akamai.steamstatic.com/steam/apps/2358720/header.jpg",
                "store_url": "https://store.steampowered.com/app/2358720/",
                "is_free": False
            },
            {
                "title": "Grand Theft Auto V: Premium Edition",
                "sale_price": "Rp 150.000",
                "normal_price": "Rp 300.000",
                "savings_pct": "-50%",
                "thumb": "https://cdn.akamai.steamstatic.com/steam/apps/271590/header.jpg",
                "store_url": "https://store.steampowered.com/app/271590/",
                "is_free": False
            }
        ]

    result = {
        "cached_at": now,
        "freebies": freebies,
        "discounts": discounts,
        "events": events
    }

    # Save to disk cache
    try:
        with open(cache_path, 'w', encoding='utf-8') as f:
            json.dump(result, f, indent=2)
    except Exception:
        pass

    return result
