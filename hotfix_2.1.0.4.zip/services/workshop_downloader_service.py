import os
import re
import zipfile
import subprocess
import shutil
import requests
import webbrowser
from services.steam_service import get_all_steamapps_paths, get_steam_path

def get_wallpaper_engine_path():
    """Locate local Wallpaper Engine installation path across all Steam drives."""
    all_sa = get_all_steamapps_paths()
    for sa in all_sa:
        we_path = os.path.join(sa, "common", "wallpaper_engine")
        if os.path.exists(we_path):
            return we_path
    return None

def extract_workshop_id(url_or_id):
    """Extract numeric PublishedFileID from URL or raw ID string."""
    url_or_id = str(url_or_id).strip()
    match = re.search(r'(?:id=)?(\d{6,12})', url_or_id)
    if match:
        return match.group(1)
    return None

def install_wallpaper_from_zip(zip_or_folder_path, item_id_name=None):
    """Installs a wallpaper directly from a ZIP archive or folder into Wallpaper Engine's myprojects directory."""
    we_path = get_wallpaper_engine_path()
    if not we_path:
        return False, "Wallpaper Engine tidak ditemukan di library Steam manapun."

    base_name = item_id_name or os.path.splitext(os.path.basename(zip_or_folder_path))[0]
    safe_folder_name = re.sub(r'[\\/:*?"<>|]', '_', base_name)
    target_dir = os.path.join(we_path, "projects", "myprojects", safe_folder_name)
    os.makedirs(target_dir, exist_ok=True)

    try:
        if os.path.isfile(zip_or_folder_path) and zip_or_folder_path.lower().endswith('.zip'):
            with zipfile.ZipFile(zip_or_folder_path, 'r') as zip_ref:
                zip_ref.extractall(target_dir)
        elif os.path.isdir(zip_or_folder_path):
            for item in os.listdir(zip_or_folder_path):
                s = os.path.join(zip_or_folder_path, item)
                d = os.path.join(target_dir, item)
                if os.path.isdir(s):
                    shutil.copytree(s, d, dirs_exist_ok=True)
                else:
                    shutil.copy2(s, d)
        else:
            return False, "File yang dipilih harus berupa file .zip atau folder wallpaper."

        # Auto-flatten nested subfolder if ZIP extracted into a single root folder
        sub_items = os.listdir(target_dir)
        if len(sub_items) == 1:
            single_sub = os.path.join(target_dir, sub_items[0])
            if os.path.isdir(single_sub):
                for item in os.listdir(single_sub):
                    shutil.move(os.path.join(single_sub, item), os.path.join(target_dir, item))
                try:
                    os.rmdir(single_sub)
                except Exception:
                    pass

        return True, f"Berhasil menginstal wallpaper ke Wallpaper Engine!\nFolder: {safe_folder_name}"
    except Exception as e:
        return False, f"Gagal menginstal berkas wallpaper: {e}"

def download_and_install_wallpaper(url_or_id, steam_username="anonymous", status_callback=None):
    """
    Downloads and installs a Wallpaper Engine workshop item directly into 
    wallpaper_engine/projects/myprojects/<item_id>/ bypassing Steam license restrictions.
    """
    item_id = extract_workshop_id(url_or_id)
    if not item_id:
        return False, "ID Workshop tidak valid. Masukkan URL atau ID angka 8-10 digit (contoh: 3669681034)."

    we_path = get_wallpaper_engine_path()
    if not we_path:
        return False, "Wallpaper Engine tidak ditemukan di library Steam manapun."

    target_proj_dir = os.path.join(we_path, "projects", "myprojects", item_id)
    os.makedirs(target_proj_dir, exist_ok=True)

    if status_callback:
        status_callback(f"1/4 Memeriksa detail wallpaper ID: {item_id}...")

    # 1. Fetch Item Metadata from Steam Web API safely
    preview_url = ""
    try:
        r = requests.post(
            'https://api.steampowered.com/ISteamRemoteStorage/GetPublishedFileDetails/v1/', 
            data={'itemcount': 1, 'publishedfileids[0]': item_id}, 
            timeout=8
        )
        details = r.json().get('response', {}).get('publishedfiledetails', [{}])[0]
        preview_url = details.get('preview_url', '')
    except Exception:
        pass

    # 2. Check if already downloaded in local workshop content
    all_sa = get_all_steamapps_paths()
    for sa in all_sa:
        local_ws_dir = os.path.join(sa, "workshop", "content", "431960", item_id)
        if os.path.exists(local_ws_dir) and os.listdir(local_ws_dir):
            if status_callback:
                status_callback(f"Ditemukan cache berkas lokal ID {item_id}, memasang ke Wallpaper Engine...")
            try:
                for f_item in os.listdir(local_ws_dir):
                    src_f = os.path.join(local_ws_dir, f_item)
                    dst_f = os.path.join(target_proj_dir, f_item)
                    if os.path.isdir(src_f):
                        if os.path.exists(dst_f): shutil.rmtree(dst_f)
                        shutil.copytree(src_f, dst_f)
                    else:
                        shutil.copy2(src_f, dst_f)
                return True, f"Berhasil memasang wallpaper ID {item_id} dari cache lokal! Buka Wallpaper Engine untuk mengaktifkannya."
            except Exception:
                pass

    if status_callback:
        status_callback(f"2/4 Menyiapkan modul pengunduh SteamCMD...")

    # 3. Setup SteamCMD helper tool in AppData/Local/GameZone/tools
    scratch_dir = os.path.join(os.getenv('LOCALAPPDATA', os.path.expanduser('~')), 'GameZone', 'tools')
    os.makedirs(scratch_dir, exist_ok=True)
    steamcmd_exe = os.path.join(scratch_dir, 'steamcmd.exe')

    if not os.path.exists(steamcmd_exe):
        if status_callback:
            status_callback("Mengunduh komponen SteamCMD (sekali saja, mohon tunggu)...")
        zip_path = os.path.join(scratch_dir, 'steamcmd.zip')
        try:
            r_zip = requests.get('https://steamcdn-a.akamaihd.net/client/installer/steamcmd.zip', timeout=30)
            with open(zip_path, 'wb') as f:
                f.write(r_zip.content)
            with zipfile.ZipFile(zip_path, 'r') as zip_ref:
                zip_ref.extractall(scratch_dir)
            if os.path.exists(zip_path):
                os.remove(zip_path)
        except Exception as e:
            return False, f"Gagal mengunduh modul SteamCMD: {e}"

    if status_callback:
        status_callback(f"3/4 Memproses unduhan dari CDN Steam untuk ID {item_id}...")

    # 4. Execute SteamCMD with non-blocking timeout
    login_user = steam_username.strip() if steam_username and steam_username.strip() else "anonymous"
    cmd = [
        steamcmd_exe,
        "+login", login_user,
        "+workshop_download_item", "431960", item_id,
        "+quit"
    ]
    
    output_logs = []
    try:
        proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, encoding='utf-8', errors='ignore', creationflags=subprocess.CREATE_NO_WINDOW if os.name == 'nt' else 0)
        try:
            out, _ = proc.communicate(timeout=25)
            output_logs = out.splitlines() if out else []
        except subprocess.TimeoutExpired:
            proc.kill()
            proc.communicate()
            output_logs.append("TIMEOUT")
    except Exception as e:
        return False, f"Gagal mengeksekusi unduhan SteamCMD: {e}"

    # 5. Check if downloaded to steamcmd internal output or local workshop
    downloaded_content_dir = os.path.join(scratch_dir, 'steamapps', 'workshop', 'content', '431960', item_id)
    if not os.path.exists(downloaded_content_dir) or not os.listdir(downloaded_content_dir):
        for sa in all_sa:
            alt_dir = os.path.join(sa, "workshop", "content", "431960", item_id)
            if os.path.exists(alt_dir) and os.listdir(alt_dir):
                downloaded_content_dir = alt_dir
                break

    # If SteamCMD downloaded successfully:
    if os.path.exists(downloaded_content_dir) and os.listdir(downloaded_content_dir):
        try:
            if status_callback:
                status_callback("4/4 Menyalin berkas wallpaper ke Wallpaper Engine...")
            for f_item in os.listdir(downloaded_content_dir):
                src_f = os.path.join(downloaded_content_dir, f_item)
                dst_f = os.path.join(target_proj_dir, f_item)
                if os.path.isdir(src_f):
                    if os.path.exists(dst_f): shutil.rmtree(dst_f)
                    shutil.copytree(src_f, dst_f)
                else:
                    shutil.copy2(src_f, dst_f)

            if preview_url and not os.path.exists(os.path.join(target_proj_dir, "preview.jpg")):
                try:
                    r_prev = requests.get(preview_url, timeout=10)
                    with open(os.path.join(target_proj_dir, "preview.jpg"), "wb") as pf:
                        pf.write(r_prev.content)
                except Exception:
                    pass

            return True, f"Berhasil mengunduh & memasang wallpaper ID {item_id}! Buka Wallpaper Engine untuk mengaktifkannya."
        except Exception as e:
            return False, f"Gagal menyalin berkas wallpaper: {e}"

    # Fallback: SteamCMD anonymous block / timeout
    try:
        webbrowser.open(f"http://steamworkshop.download/download/view/{item_id}")
    except Exception:
        pass
    return False, f"Unduhan otomatis via SteamCMD dibatasi oleh Valve untuk ID {item_id}.\n\nHalaman downloader web telah dibuka di browser!\n1. Unduh berkas ZIP wallpaper di browser.\n2. Klik tombol '[IMPORT FILE (.ZIP)]' di GameZone untuk langsung menginstalnya."
