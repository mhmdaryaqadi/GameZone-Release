import os
import re
import stat
import shutil
import requests
from services.steam_service import get_all_steamapps_paths, get_steam_path, _clear_steam_license_cache

def get_injected_appids():
    """
    Returns a set of AppIDs that belong to injected games on this PC.
    Reads .lua files from Steam/config/stplug-in and GameZone database.
    """
    injected = set()
    steam_base = get_steam_path()
    if steam_base:
        stplug = os.path.join(steam_base, "config", "stplug-in")
        if os.path.exists(stplug):
            try:
                for f in os.listdir(stplug):
                    if f.endswith(".lua"):
                        m = re.findall(r"\d+", f)
                        for appid_str in m:
                            injected.add(str(appid_str))
            except Exception:
                pass

    try:
        from core.database import get_database
        db = get_database()
        if db:
            for item in db:
                aid = str(item.get("appid", ""))
                if aid:
                    injected.add(aid)
    except Exception:
        pass

    return injected


def scan_all_games_health():
    """
    Scans appmanifest_*.acf files for INJECTED games across all Steam libraries.
    Checks:
    1. ACF File validity and flags (UpdateResult, FullValidate).
    2. Missing depot .manifest files in depotcache.
    3. Read-only lock status.
    
    Returns a comprehensive diagnostic report dictionary.
    """
    all_steamapps = get_all_steamapps_paths()
    if not all_steamapps:
        return {
            "total_scanned": 0,
            "healthy_count": 0,
            "issues_count": 0,
            "reports": []
        }

    injected_appids = get_injected_appids()

    reports = []
    total_scanned = 0
    healthy_count = 0
    issues_count = 0

    for sa_path in all_steamapps:
        if not os.path.exists(sa_path):
            continue
            
        depotcache_path = os.path.join(sa_path, "depotcache")
        
        try:
            acf_files = [f for f in os.listdir(sa_path) if f.startswith("appmanifest_") and f.endswith(".acf")]
        except Exception:
            continue

        for acf_file in acf_files:
            # Extract AppID
            m_appid = re.search(r"appmanifest_(\d+)\.acf", acf_file)
            appid = m_appid.group(1) if m_appid else "Unknown"

            # FILTER: Khusus Game Inject saja (Abaikan game ori resmi pengguna)
            if injected_appids and appid not in injected_appids:
                continue

            total_scanned += 1
            acf_full = os.path.join(sa_path, acf_file)
            game_name = f"AppID {appid}"
            issues = []
            depot_map = {}

            # Read ACF Content
            try:
                with open(acf_full, "r", encoding="utf-8", errors="ignore") as f:
                    content = f.read()

                # Extract Name
                m_name = re.search(r'"name"\s+"([^"]+)"', content)
                if m_name:
                    game_name = m_name.group(1)

                # Check UpdateResult & FullValidate flags
                m_upd = re.search(r'"UpdateResult"\s+"(\d+)"', content)
                if m_upd and int(m_upd.group(1)) != 0:
                    issues.append(f"Flag error UpdateResult ({m_upd.group(1)}) aktif")

                if "FullValidateBeforeNextUpdate" in content or "FullValidateAfterNextUpdate" in content:
                    issues.append("Flag verifikasi penuh (FullValidate) tertanam")

                # Check InstalledDepots manifest files
                m_depots = re.findall(r'"(\d+)"\s*\{\s*"manifest"\s+"(\d+)"', content)
                for did, mid in m_depots:
                    depot_map[did] = mid
                    # Check if .manifest file exists in depotcache
                    manifest_filename = f"{did}_{mid}.manifest"
                    manifest_exist = False
                    if os.path.exists(os.path.join(depotcache_path, manifest_filename)):
                        manifest_exist = True
                    else:
                        # Check primary steam depotcache as fallback
                        steam_base = get_steam_path()
                        if steam_base:
                            if os.path.exists(os.path.join(steam_base, "depotcache", manifest_filename)) or \
                               os.path.exists(os.path.join(steam_base, "config", "depotcache", manifest_filename)):
                                manifest_exist = True
                    
                    if not manifest_exist:
                        issues.append(f"File manifest {manifest_filename} belum ada di depotcache")

            except Exception as e:
                issues.append(f"Gagal membaca file manifest: {e}")

            # Check Read-Only attribute
            try:
                file_stat = os.stat(acf_full)
                if not (file_stat.st_mode & stat.S_IWRITE):
                    issues.append("File manifest berstatus Read-Only (Terkunci)")
            except Exception:
                pass

            if issues:
                issues_count += 1
                status = "needs_repair"
            else:
                healthy_count += 1
                status = "healthy"

            reports.append({
                "appid": appid,
                "name": game_name,
                "status": status,
                "issues": issues,
                "acf_path": acf_full,
                "depot_map": depot_map
            })

    return {
        "total_scanned": total_scanned,
        "healthy_count": healthy_count,
        "issues_count": issues_count,
        "reports": reports
    }


def repair_all_diagnosed_issues(reports=None, status_callback=None):
    """
    Performs automatic diagnostic repair across specified games:
    1. Cleans appinfo.vdf & packageinfo.vdf license cache.
    2. Unlocks Read-Only attributes on ACF files.
    3. Resets UpdateResult to 0 and fixes flags via patch_appmanifest_state.
    4. Syncs valid .manifest files across all Steam library depotcache folders (C:, D:, E:).
    5. Cleanly restarts Steam.
    
    Returns (success: bool, repaired_count: int, message: str)
    """
    if reports is None:
        diag = scan_all_games_health()
        reports = diag.get("reports", [])

    repaired_count = 0
    steam_base = get_steam_path()

    if status_callback:
        status_callback("Pembersihan cache lisensi Steam...")
    _clear_steam_license_cache(steam_base)

    from services.steam_service import patch_appmanifest_state, get_all_steamapps_paths, restart_steam
    all_sa = get_all_steamapps_paths()

    for item in reports:
        acf_path = item.get("acf_path")
        appid = item.get("appid")
        depot_map = item.get("depot_map", {})
        game_name = item.get("name", f"AppID {appid}")

        if status_callback:
            status_callback(f"Memperbaiki {game_name}...")

        # 1. Unlock Read-Only & Patch ACF
        if acf_path and os.path.exists(acf_path):
            try:
                os.chmod(acf_path, stat.S_IWRITE | stat.S_IREAD)
            except Exception:
                pass

            try:
                patch_appmanifest_state(appid, force_installed_state=True)
                repaired_count += 1
            except Exception:
                pass

        # 2. Sync valid manifest files across all depotcache folders
        for sa in all_sa:
            dc_dir = os.path.join(os.path.dirname(sa), "depotcache")
            os.makedirs(dc_dir, exist_ok=True)
            for did, mid in depot_map.items():
                mf_name = f"{did}_{mid}.manifest"
                found_src = None
                for search_sa in all_sa:
                    search_dc = os.path.join(os.path.dirname(search_sa), "depotcache")
                    c_path = os.path.join(search_dc, mf_name)
                    if os.path.exists(c_path) and os.path.getsize(c_path) > 100:
                        found_src = c_path
                        break
                
                if found_src:
                    dst = os.path.join(dc_dir, mf_name)
                    if not os.path.exists(dst) or os.path.getsize(dst) < 100:
                        try:
                            shutil.copy2(found_src, dst)
                        except Exception:
                            pass

    # 3. Clean Steam restart
    restart_steam()

    return True, repaired_count, f"Berhasil memperbaiki & memulihkan {repaired_count} game terinjeksi! Steam dimuat ulang."
