import os
import re
import shutil
from services.steam_service import get_all_steamapps_paths, restart_steam

def fix_wallpaper_engine_workshop():
    """
    Scans appworkshop_431960.acf across all Steam drives, extracts all subscribed Workshop Item IDs,
    resets NeedsDownload=0 and NeedsUpdate=0, populates WorkshopItemsInstalled block,
    cleans stuck downloading folders, and resets appmanifest StateFlags=4.
    """
    all_sa = get_all_steamapps_paths()
    if not all_sa:
        return False, "Steam Library tidak ditemukan."

    patched_acfs = 0
    total_items_fixed = 0

    for sa in all_sa:
        ws_acf = os.path.join(sa, "workshop", "appworkshop_431960.acf")
        if os.path.exists(ws_acf):
            try:
                with open(ws_acf, "r", encoding="utf-8", errors="ignore") as f:
                    content = f.read()

                # Find all item details in WorkshopItemDetails block
                details_match = re.search(r'"WorkshopItemDetails"\s*\{([\s\S]*?)\}\s*\}', content)
                details_body = details_match.group(1) if details_match else content
                
                items = re.findall(r'"(\d+)"\s*\{\s*"manifest"\s+"(\d+)"', details_body)

                # Reset NeedsDownload=0 and NeedsUpdate=0 to unstick Steam download queue
                content = re.sub(r'"NeedsDownload"\s+"[^"]*"', '"NeedsDownload"\t\t"0"', content)
                content = re.sub(r'"NeedsUpdate"\s+"[^"]*"', '"NeedsUpdate"\t\t"0"', content)

                if items:
                    installed_blocks = []
                    for item_id, m_id in items:
                        total_items_fixed += 1
                        installed_blocks.append(f'\t\t"{item_id}"\n\t\t{{\n\t\t\t"manifest"\t\t"{m_id}"\n\t\t}}')

                    new_installed_str = '"WorkshopItemsInstalled"\n\t{\n' + '\n'.join(installed_blocks) + '\n\t}'
                    if '"WorkshopItemsInstalled"' in content:
                        content = re.sub(r'"WorkshopItemsInstalled"\s*\{[\s\S]*?\}\n\t\}', new_installed_str, content)
                    else:
                        content = re.sub(r'("AppWorkshop"\s*\{)', r'\1\n\t' + new_installed_str, content)

                with open(ws_acf, "w", encoding="utf-8") as f:
                    f.write(content)
                patched_acfs += 1

            except Exception as e:
                pass

        # Clear stuck downloading folders for app 431960
        ws_dl_dir = os.path.join(sa, "workshop", "downloads", "431960")
        if os.path.exists(ws_dl_dir):
            try:
                shutil.rmtree(ws_dl_dir)
            except Exception:
                pass

        # Ensure appmanifest_431960.acf has StateFlags 4 and UpdateResult 0
        acf_path = os.path.join(sa, "appmanifest_431960.acf")
        if os.path.exists(acf_path):
            try:
                with open(acf_path, "r", encoding="utf-8", errors="ignore") as f:
                    acf_content = f.read()

                acf_content = re.sub(r'"StateFlags"\s+"[^"]*"', '"StateFlags"\t\t"4"', acf_content)
                acf_content = re.sub(r'"UpdateResult"\s+"[^"]*"', '"UpdateResult"\t\t"0"', acf_content)
                acf_content = re.sub(r'"BytesToDownload"\s+"[^"]*"', '"BytesToDownload"\t\t"0"', acf_content)
                acf_content = re.sub(r'"BytesDownloaded"\s+"[^"]*"', '"BytesDownloaded"\t\t"0"', acf_content)

                with open(acf_path, "w", encoding="utf-8") as f:
                    f.write(acf_content)
            except Exception:
                pass

    if patched_acfs > 0 or total_items_fixed > 0:
        restart_steam()
        return True, f"Berhasil mereset antrean unduhan Wallpaper Engine ({total_items_fixed} item workshop)! Tombol unduh macet telah diperbaiki & Steam dimuat ulang."
    else:
        return False, "Tidak ditemukan berkas workshop Wallpaper Engine yang bermasalah."
