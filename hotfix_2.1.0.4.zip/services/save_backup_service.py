import os
import shutil
import datetime
import zipfile
from services.steam_service import get_steam_path

def get_backup_dir():
    appdata = os.getenv('LOCALAPPDATA', '')
    p = os.path.join(appdata, 'GameZone', 'LocalCloudSaves')
    os.makedirs(p, exist_ok=True)
    return p

def get_save_locations(appid, game_name=""):
    """
    Scans Windows standard save data locations for a given AppID/game_name.
    Returns a list of existing folder paths containing save files.
    """
    user_home = os.path.expanduser('~')
    appdata = os.getenv('APPDATA', '')
    localappdata = os.getenv('LOCALAPPDATA', '')
    documents = os.path.join(user_home, 'Documents')
    saved_games = os.path.join(user_home, 'Saved Games')
    
    locations = []
    
    # 1. Steam userdata (Local Steam Cloud folder)
    steam_base = get_steam_path()
    if steam_base:
        ud = os.path.join(steam_base, "userdata")
        if os.path.exists(ud):
            try:
                for ufolder in os.listdir(ud):
                    appid_save_dir = os.path.join(ud, ufolder, str(appid))
                    if os.path.exists(appid_save_dir):
                        locations.append(appid_save_dir)
            except Exception:
                pass

    # 2. Common Save folders by Game Name / AppID
    clean_name = "".join(c for c in game_name if c.isalnum() or c in (" ", "_", "-")).strip()
    search_terms = [str(appid)]
    if clean_name and clean_name != f"AppID {appid}":
        search_terms.append(clean_name)

    base_dirs = [
        appdata,
        localappdata,
        os.path.join(documents, 'My Games'),
        documents,
        saved_games,
        os.path.join(localappdata, 'LOW')
    ]

    for b in base_dirs:
        if not b or not os.path.exists(b): continue
        for term in search_terms:
            cand = os.path.join(b, term)
            if os.path.exists(cand) and cand not in locations:
                locations.append(cand)

    return locations

def backup_game_saves(appid, game_name=""):
    """
    Backs up save files for the given AppID into local GameZone Cloud backup storage.
    Returns (success: bool, zip_path: str, message: str)
    """
    locs = get_save_locations(appid, game_name)
    if not locs:
        return False, "", f"Tidak ditemukan folder save data lokal untuk AppID {appid} ({game_name})."

    backup_root = get_backup_dir()
    game_backup_dir = os.path.join(backup_root, str(appid))
    os.makedirs(game_backup_dir, exist_ok=True)

    timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    zip_filename = f"save_backup_{appid}_{timestamp}.zip"
    zip_path = os.path.join(game_backup_dir, zip_filename)

    try:
        with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as z:
            for loc in locs:
                folder_basename = os.path.basename(loc)
                for root, dirs, files in os.walk(loc):
                    for file in files:
                        full_path = os.path.join(root, file)
                        rel_path = os.path.relpath(full_path, os.path.dirname(loc))
                        z.write(full_path, arcname=rel_path)

        return True, zip_path, f"Save data ({len(locs)} lokasi) berhasil di-backup ke Local Cloud GameZone!"
    except Exception as e:
        return False, "", f"Gagal membuat backup save data: {e}"

def list_game_backups(appid):
    """Returns a list of dicts for available local save backups for an AppID."""
    backup_root = get_backup_dir()
    game_backup_dir = os.path.join(backup_root, str(appid))
    if not os.path.exists(game_backup_dir):
        return []

    backups = []
    for f in os.listdir(game_backup_dir):
        if f.startswith("save_backup_") and f.endswith(".zip"):
            full_p = os.path.join(game_backup_dir, f)
            try:
                stat = os.stat(full_p)
                mtime = datetime.datetime.fromtimestamp(stat.st_mtime).strftime("%d %b %Y %H:%M")
                size_kb = round(stat.st_size / 1024, 1)
                backups.append({"filename": f, "path": full_p, "mtime": mtime, "size_kb": size_kb})
            except Exception:
                pass

    backups.sort(key=lambda x: x["filename"], reverse=True)
    return backups
