import customtkinter
import tkinter.messagebox as messagebox
from PIL import Image
import os
import sys
import threading

from core import discord_auth
from core import profile_manager
from core import database
from services.steam_service import get_steam_path

def resource_path(relative_path):
    if getattr(sys, 'frozen', False):
        base_path = sys._MEIPASS
    else:
        base_path = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
    return os.path.join(base_path, relative_path)

class ProfilePage(customtkinter.CTkFrame):
    def __init__(self, parent, main_app, **kwargs):
        super().__init__(parent, fg_color="#FFFFFF", **kwargs)
        self.parent = main_app
        
        self.grid_columnconfigure(0, weight=4)
        self.grid_columnconfigure(1, weight=5)
        self.grid_rowconfigure(1, weight=1)
        
        # Load Data
        self.discord_username = discord_auth.get_cached_username()
        self.prof_data = profile_manager.load_profile()
        self.selected_avatar = self.prof_data.get("avatar", "avatar1.png")
        
        # =========================================================================
        # TOP BAR
        # =========================================================================
        top_bar = customtkinter.CTkFrame(self, fg_color="transparent")
        top_bar.grid(row=0, column=0, columnspan=2, pady=(0, 8), sticky="ew")
        
        title = customtkinter.CTkLabel(top_bar, text="👤 MY PROFILE", font=customtkinter.CTkFont(family="Segoe UI Black", size=18), text_color="#000000")
        title.grid(row=0, column=0, sticky="w")
        
        customtkinter.CTkLabel(top_bar, text="✦", font=("Segoe UI Black", 16), text_color="#FF499E", fg_color="#FFFFFF").grid(row=0, column=1, padx=(10, 0), sticky="w")
        
        # =========================================================================
        # LEFT PANEL (Identity Settings)
        # =========================================================================
        self.left_panel = customtkinter.CTkFrame(self, fg_color="#FFFFFF", corner_radius=0, border_width=3, border_color="#000000")
        self.left_panel.grid(row=1, column=0, sticky="nsew", padx=(0, 10), pady=(0, 10))
        
        lbl_id = customtkinter.CTkLabel(self.left_panel, text="IDENTITY", font=customtkinter.CTkFont(family="Segoe UI Black", size=18), text_color="#000000")
        lbl_id.pack(pady=(15, 5))
        
        # Discord Profile Picture Display
        self.lbl_dc_avatar = customtkinter.CTkLabel(self.left_panel, text="", width=74, height=74)
        self.lbl_dc_avatar.pack(pady=(0, 10))
        self._load_dc_avatar()
        
        # Form
        form_frame = customtkinter.CTkFrame(self.left_panel, fg_color="transparent")
        form_frame.pack(fill="x", padx=20, pady=5)
        
        # Discord Username (Locked)
        lbl_dc = customtkinter.CTkLabel(form_frame, text="Discord Username (Locked)", font=customtkinter.CTkFont(family="Segoe UI Black", size=12), text_color="#555555")
        lbl_dc.pack(anchor="w")
        self.entry_dc = customtkinter.CTkEntry(form_frame, height=38, fg_color="#E0E0E0", border_color="#000000", border_width=2, text_color="#555555", font=customtkinter.CTkFont(family="Segoe UI", size=14, weight="bold"), corner_radius=0)
        self.entry_dc.pack(fill="x", pady=(4, 18))
        self.entry_dc.insert(0, self.discord_username)
        self.entry_dc.configure(state="readonly")
        
        # Role (Locked)
        lbl_role = customtkinter.CTkLabel(form_frame, text="Server Role (Locked)", font=customtkinter.CTkFont(family="Segoe UI Black", size=12), text_color="#555555")
        lbl_role.pack(anchor="w")
        self.entry_role = customtkinter.CTkEntry(form_frame, height=38, fg_color="#E0E0E0", border_color="#000000", border_width=2, text_color="#555555", font=customtkinter.CTkFont(family="Segoe UI", size=14, weight="bold"), corner_radius=0)
        self.entry_role.pack(fill="x", pady=(4, 18))
        role = getattr(self.parent, "CURRENT_ROLE", "basic").upper()
        self.entry_role.insert(0, role)
        self.entry_role.configure(state="readonly")
        
        # Local Nickname (Editable)
        lbl_nick = customtkinter.CTkLabel(form_frame, text="Local Nickname", font=customtkinter.CTkFont(family="Segoe UI Black", size=12), text_color="#000000")
        lbl_nick.pack(anchor="w")
        self.entry_nick = customtkinter.CTkEntry(form_frame, height=40, fg_color="#FFFFFF", border_color="#000000", border_width=3, text_color="#000000", font=customtkinter.CTkFont(family="Segoe UI", size=14, weight="bold"), corner_radius=0)
        self.entry_nick.pack(fill="x", pady=(4, 20))
        self.entry_nick.insert(0, self.prof_data.get("nickname", "Anonymous"))
        
        # Save Button
        self.btn_save = customtkinter.CTkButton(self.left_panel, text="💾 SIMPAN PROFIL", height=44, fg_color="#00D084", hover_color="#00B875", text_color="#000000", font=customtkinter.CTkFont(family="Segoe UI Black", size=13), corner_radius=0, border_width=3, border_color="#000000", command=self.save_profile)
        self.btn_save.pack(fill="x", padx=20, pady=(10, 25))

        # =========================================================================
        # RIGHT PANEL (Overview & Stats & Quick Actions)
        # =========================================================================
        self.right_panel = customtkinter.CTkScrollableFrame(self, fg_color="transparent")
        self.right_panel.grid(row=1, column=1, sticky="nsew", padx=(10, 0), pady=(0, 10))
        self.right_panel.grid_columnconfigure(0, weight=1)

        # -------------------------------------------------------------------------
        # CARD 1: GAMER STATS & BADGES
        # -------------------------------------------------------------------------
        card_stats = customtkinter.CTkFrame(self.right_panel, fg_color="#FFFFFF", border_width=3, border_color="#000000", corner_radius=0)
        card_stats.pack(fill="x", pady=(0, 15))
        card_stats.grid_columnconfigure((0, 1), weight=1)

        lbl_s_title = customtkinter.CTkLabel(card_stats, text="📊 GAMER STATS & BADGES", font=customtkinter.CTkFont(family="Segoe UI Black", size=16), text_color="#000000")
        lbl_s_title.grid(row=0, column=0, columnspan=2, padx=15, pady=(15, 10), sticky="w")

        # Stat Boxes Grid
        # Box 1: Total Games
        b1 = customtkinter.CTkFrame(card_stats, fg_color="#FFD800", border_width=2, border_color="#000000", corner_radius=0)
        b1.grid(row=1, column=0, padx=(15, 5), pady=5, sticky="ew")
        
        injected_count = len(database.get_injected_games())
        self.lbl_game_count = customtkinter.CTkLabel(b1, text=f"{injected_count}", font=customtkinter.CTkFont(family="Segoe UI Black", size=22), text_color="#000000")
        self.lbl_game_count.pack(anchor="w", padx=12, pady=(8, 0))
        customtkinter.CTkLabel(b1, text="🎮 Game Terinjeksi", font=customtkinter.CTkFont(family="Segoe UI", size=11, weight="bold"), text_color="#000000").pack(anchor="w", padx=12, pady=(0, 8))

        # Box 2: Account Role
        b2 = customtkinter.CTkFrame(card_stats, fg_color="#00D084" if role == "PREMIUM" else "#FF499E", border_width=2, border_color="#000000", corner_radius=0)
        b2.grid(row=1, column=1, padx=(5, 15), pady=5, sticky="ew")
        
        self.lbl_role_stat = customtkinter.CTkLabel(b2, text=f"{role}", font=customtkinter.CTkFont(family="Segoe UI Black", size=22), text_color="#000000" if role == "PREMIUM" else "#FFFFFF")
        self.lbl_role_stat.pack(anchor="w", padx=12, pady=(8, 0))
        customtkinter.CTkLabel(b2, text="👑 Keanggotaan Server", font=customtkinter.CTkFont(family="Segoe UI", size=11, weight="bold"), text_color="#000000" if role == "PREMIUM" else "#FFFFFF").pack(anchor="w", padx=12, pady=(0, 8))

        # Box 3: Cloud Status
        b3 = customtkinter.CTkFrame(card_stats, fg_color="#5D5FEF", border_width=2, border_color="#000000", corner_radius=0)
        b3.grid(row=2, column=0, padx=(15, 5), pady=5, sticky="ew")
        
        customtkinter.CTkLabel(b3, text="ONLINE", font=customtkinter.CTkFont(family="Segoe UI Black", size=22), text_color="#FFFFFF").pack(anchor="w", padx=12, pady=(8, 0))
        customtkinter.CTkLabel(b3, text="☁️ Firebase Sync", font=customtkinter.CTkFont(family="Segoe UI", size=11, weight="bold"), text_color="#E0E7FF").pack(anchor="w", padx=12, pady=(0, 8))

        # Box 4: Account Verified
        b4 = customtkinter.CTkFrame(card_stats, fg_color="#F4EFEB", border_width=2, border_color="#000000", corner_radius=0)
        b4.grid(row=2, column=1, padx=(5, 15), pady=5, sticky="ew")
        
        customtkinter.CTkLabel(b4, text="VERIFIED", font=customtkinter.CTkFont(family="Segoe UI Black", size=22), text_color="#000000").pack(anchor="w", padx=12, pady=(8, 0))
        customtkinter.CTkLabel(b4, text="🛡️ Discord OAuth", font=customtkinter.CTkFont(family="Segoe UI", size=11, weight="bold"), text_color="#555555").pack(anchor="w", padx=12, pady=(0, 8))

        # Badges section
        customtkinter.CTkLabel(card_stats, text="🏆 Lencana Komunitas:", font=customtkinter.CTkFont(family="Segoe UI Black", size=12), text_color="#000000").grid(row=3, column=0, columnspan=2, padx=15, pady=(12, 5), sticky="w")
        
        badge_frame = customtkinter.CTkFrame(card_stats, fg_color="transparent")
        badge_frame.grid(row=4, column=0, columnspan=2, padx=15, pady=(0, 15), sticky="ew")
        badge_frame.grid_columnconfigure((0, 1), weight=1)

        badges = [
            ("👑 PREMIUM MEMBER" if role == "PREMIUM" else "🎮 BASIC MEMBER", "#00D084" if role == "PREMIUM" else "#FF499E", "#000000" if role == "PREMIUM" else "#FFFFFF"),
            ("⚡ EARLY ACCESS", "#FFD800", "#000000"),
            ("☁️ FIREBASE SYNCED", "#5D5FEF", "#FFFFFF"),
            ("🛡️ VERIFIED USER", "#F4EFEB", "#000000")
        ]

        for i, (b_text, b_bg, b_fg) in enumerate(badges):
            r = i // 2
            c = i % 2
            b_lbl = customtkinter.CTkLabel(
                badge_frame,
                text=b_text,
                font=customtkinter.CTkFont(family="Segoe UI Black", size=11),
                fg_color=b_bg, text_color=b_fg,
                corner_radius=0,
                border_width=2, border_color="#000000",
                height=32
            )
            px = (0, 4) if c == 0 else (4, 0)
            b_lbl.grid(row=r, column=c, padx=px, pady=3, sticky="ew")

        # -------------------------------------------------------------------------
        # CARD 2: SYSTEM & INTEGRATION INFO
        # -------------------------------------------------------------------------
        card_sys = customtkinter.CTkFrame(self.right_panel, fg_color="#FFFFFF", border_width=3, border_color="#000000", corner_radius=0)
        card_sys.pack(fill="x", pady=(0, 15))

        lbl_sys_title = customtkinter.CTkLabel(card_sys, text="💻 SYSTEM & INTEGRATION", font=customtkinter.CTkFont(family="Segoe UI Black", size=16), text_color="#000000")
        lbl_sys_title.pack(anchor="w", padx=15, pady=(15, 10))

        sys_box = customtkinter.CTkFrame(card_sys, fg_color="#F8F9FA", border_width=2, border_color="#000000", corner_radius=0)
        sys_box.pack(fill="x", padx=15, pady=(0, 15))

        steam_p = get_steam_path()
        appdata_p = os.path.join(os.getenv('LOCALAPPDATA', ''), 'GameZone')

        sys_items = [
            ("📂 Folder Steam:", steam_p),
            ("🌐 Firebase DB:", "https://gamezone-5d5fef-default-rtdb.firebaseio.com"),
            ("💾 AppData Path:", appdata_p)
        ]

        for label_text, val_text in sys_items:
            row_f = customtkinter.CTkFrame(sys_box, fg_color="transparent")
            row_f.pack(fill="x", padx=10, pady=4)
            
            customtkinter.CTkLabel(row_f, text=label_text, font=customtkinter.CTkFont(family="Segoe UI Black", size=11), text_color="#000000", width=110, anchor="w").pack(side="left")
            customtkinter.CTkLabel(row_f, text=val_text, font=customtkinter.CTkFont(family="Segoe UI", size=11, weight="bold"), text_color="#555555", anchor="w").pack(side="left", fill="x", expand=True)

        # -------------------------------------------------------------------------
        # CARD 3: QUICK ACTIONS
        # -------------------------------------------------------------------------
        card_act = customtkinter.CTkFrame(self.right_panel, fg_color="#FFFFFF", border_width=3, border_color="#000000", corner_radius=0)
        card_act.pack(fill="x", pady=(0, 10))

        lbl_act_title = customtkinter.CTkLabel(card_act, text="⚡ QUICK ACTIONS", font=customtkinter.CTkFont(family="Segoe UI Black", size=16), text_color="#000000")
        lbl_act_title.pack(anchor="w", padx=15, pady=(15, 10))

        act_frame = customtkinter.CTkFrame(card_act, fg_color="transparent")
        act_frame.pack(fill="x", padx=15, pady=(0, 15))
        act_frame.grid_columnconfigure((0, 1), weight=1)

        btn_sync_now = customtkinter.CTkButton(
            act_frame,
            text="🔄 SYNC DATA FIREBASE",
            font=customtkinter.CTkFont(family="Segoe UI Black", size=12),
            fg_color="#3B82F6", hover_color="#2563EB", text_color="#FFFFFF",
            height=38, corner_radius=0, border_width=2, border_color="#000000",
            command=self.action_sync_firebase
        )
        btn_sync_now.grid(row=0, column=0, padx=(0, 6), sticky="ew")

        btn_logout = customtkinter.CTkButton(
            act_frame,
            text="🚪 LOGOUT DISCORD",
            font=customtkinter.CTkFont(family="Segoe UI Black", size=12),
            fg_color="#ef4444", hover_color="#dc2626", text_color="#FFFFFF",
            height=38, corner_radius=0, border_width=2, border_color="#000000",
            command=self.action_logout
        )
        btn_logout.grid(row=0, column=1, padx=(6, 0), sticky="ew")

        self.load_history()

    def action_sync_firebase(self):
        nick = self.entry_nick.get().strip() or "Anonymous"
        def _sync():
            try:
                from core import firebase_sync, discord_auth
                dc = discord_auth.get_cached_username()
                av_url = discord_auth.get_cached_avatar_url()
                success = firebase_sync.report_user_presence(dc, nick, av_url)
                if success:
                    self.after(0, lambda: messagebox.showinfo("Sukses", "Data profil berhasil disinkronkan ke Firebase!", parent=self.winfo_toplevel()))
                else:
                    self.after(0, lambda: messagebox.showerror("Gagal", "Gagal menghubungkan ke Firebase DB.", parent=self.winfo_toplevel()))
            except Exception as e:
                self.after(0, lambda: messagebox.showerror("Error", f"Terjadi kesalahan: {e}", parent=self.winfo_toplevel()))

        threading.Thread(target=_sync, daemon=True).start()

    def action_fix_steam_cloud(self):
        def _fix():
            try:
                from services.steam_service import disable_steam_cloud_for_injected_games
                count, errs = disable_steam_cloud_for_injected_games(auto_restart=True)
                msg = f"Berhasil menonaktifkan Steam Cloud pada {count} game terinjeksi!\nSteam telah direstart secara bersih."
                if errs:
                    msg += "\n\nCatatan:\n" + "\n".join(errs)
                self.after(0, lambda: messagebox.showinfo("Fix Steam Cloud", msg, parent=self.winfo_toplevel()))
            except Exception as e:
                self.after(0, lambda: messagebox.showerror("Error", f"Gagal perbaiki Steam Cloud: {e}", parent=self.winfo_toplevel()))

        threading.Thread(target=_fix, daemon=True).start()

    def action_logout(self):
        if messagebox.askyesno("Konfirmasi Logout", "Apakah Anda yakin ingin keluar dari sesi Discord?", parent=self.winfo_toplevel()):
            try:
                from core import discord_auth
                session_file = discord_auth.get_session_file()
                if os.path.exists(session_file):
                    os.remove(session_file)
            except Exception:
                pass
                
            if hasattr(self.parent, '_show_login_ui'):
                self.parent._show_login_ui()

    def load_history(self):
        try:
            from core.skeleton import hide_skeleton
            hide_skeleton(self)
        except Exception:
            pass

    def save_profile(self):
        nick = self.entry_nick.get().strip()
        if not nick:
            messagebox.showerror("Error", "Nickname tidak boleh kosong!", parent=self.winfo_toplevel())
            return
            
        current_avatar = getattr(self, 'selected_avatar', 'default')
        profile_manager.save_profile(nick, current_avatar)
        messagebox.showinfo("Sukses", "Profil berhasil disimpan & disinkronkan ke Firebase!", parent=self.winfo_toplevel())
        
        # Update UI stats and top bar
        if hasattr(self.parent, 'update_sidebar_profile'):
            self.parent.update_sidebar_profile()

    def _load_dc_avatar(self):
        def _bg():
            from core.image_cache import get_cached_ctk_image
            try:
                from core import discord_auth
                avatar_url = discord_auth.get_cached_avatar_url()
                if not avatar_url:
                    avatar_url = "https://cdn.discordapp.com/embed/avatars/0.png"
                    
                import hashlib, requests
                url_hash = hashlib.md5(avatar_url.encode('utf-8')).hexdigest()
                cache_dir = os.path.join(os.getcwd(), "cache", "img")
                os.makedirs(cache_dir, exist_ok=True)
                local_path = os.path.join(cache_dir, f"av_{url_hash}.png")
                
                if not os.path.exists(local_path):
                    res = requests.get(avatar_url, headers={"User-Agent": "Mozilla/5.0"}, timeout=5)
                    if res.status_code == 200:
                        with open(local_path, "wb") as f:
                            f.write(res.content)
                            
                ctk_img = get_cached_ctk_image(local_path, size=(70, 70), circle_mask=True)
                if ctk_img:
                    self.after(0, lambda: self._apply_dc_avatar(ctk_img))
            except Exception:
                pass
                
        from core.async_worker import run_async
        run_async(_bg)

    def _apply_dc_avatar(self, ctk_img):
        try:
            if hasattr(self, 'lbl_dc_avatar') and self.lbl_dc_avatar.winfo_exists():
                self.lbl_dc_avatar.configure(image=ctk_img)
                self.lbl_dc_avatar.image = ctk_img
        except Exception:
            pass

    def update_role_display(self):
        role = getattr(self.parent, "CURRENT_ROLE", "basic").upper()
        self.entry_role.configure(state="normal")
        self.entry_role.delete(0, "end")
        self.entry_role.insert(0, role)
        self.entry_role.configure(state="readonly")
        
        if hasattr(self, 'lbl_role_stat'):
            self.lbl_role_stat.configure(text=role, text_color="#000000" if role == "PREMIUM" else "#FFFFFF")
