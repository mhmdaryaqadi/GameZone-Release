import customtkinter
import tkinter as tk
import tkinter.messagebox as messagebox
import os
import glob
import re
import time
import json
import threading
import concurrent.futures
from core.firebase_sync import session as requests
from io import BytesIO
from PIL import Image, ImageTk, ImageOps

from core.database import get_injected_games, insert_injected_game, delete_injected_game, update_injected_game_title
class LibraryPage(customtkinter.CTkFrame):
    def __init__(self, parent, main_app, **kwargs):
        super().__init__(parent, fg_color="#FFFFFF", **kwargs)
        self.parent = main_app
        
        self.library_loaded = False
        self._first_load_done = False
        self.all_games = []
        self.image_cache = {}
        self.image_executor = concurrent.futures.ThreadPoolExecutor(max_workers=4)
        self._bulk_lock = threading.Lock()
        self._render_id = 0
        self.current_buttons = []
        self.current_canvas_images = {}

        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(2, weight=1)

        top_bar = customtkinter.CTkFrame(self, fg_color="transparent")
        top_bar.grid(row=0, column=0, pady=(0, 4), sticky="ew")
        top_bar.grid_columnconfigure(2, weight=1)
        
        title = customtkinter.CTkLabel(top_bar, text="Koleksi Game Saya", font=customtkinter.CTkFont(family="Segoe UI Black", size=18), text_color="#000000")
        title.grid(row=0, column=0, sticky="w")
        
        # Grid stars side-by-side to prevent overlaps on fullscreen/resizing
        customtkinter.CTkLabel(top_bar, text="✦", font=("Segoe UI Black", 16), text_color="#5D5FEF", fg_color="#FFFFFF").grid(row=0, column=1, padx=(8, 0), sticky="w")
        customtkinter.CTkLabel(top_bar, text="🙂", font=("Segoe UI Emoji", 18), fg_color="#FFFFFF").grid(row=0, column=2, padx=(4, 0), sticky="w")
 
        btn_restart_lib = customtkinter.CTkButton(top_bar, text="Restart Steam", width=110, height=30, fg_color="#FF499E", hover_color="#E63F8A", text_color="#000000", font=customtkinter.CTkFont(family="Segoe UI Black", size=11), border_width=3, border_color="#000000", corner_radius=0, command=lambda: self.parent.hub_page.handle_steam_restart())
        btn_restart_lib.grid(row=0, column=3, sticky="e")
        
        # Search Container to keep search entry and ornaments together on resize
        search_container = customtkinter.CTkFrame(self, fg_color="transparent")
        search_container.grid(row=1, column=0, pady=(0, 8), sticky="w")
        
        self.search_entry = customtkinter.CTkEntry(search_container, placeholder_text="Cari di koleksi...", width=300, height=36, fg_color="#FFFFFF", border_color="#000000", border_width=3, text_color="#000000", corner_radius=0, font=customtkinter.CTkFont(family="Segoe UI", size=12, weight="bold"))
        self.search_entry.pack(side="left")
        self.search_entry.bind("<KeyRelease>", self.filter_library)
        
        customtkinter.CTkLabel(search_container, text="✨", font=("Segoe UI Emoji", 18), fg_color="#FFFFFF").pack(side="left", padx=(10, 0))
        customtkinter.CTkLabel(search_container, text="*", font=("Segoe UI Black", 20), text_color="#FF499E", fg_color="#FFFFFF").pack(side="left", padx=(4, 0))

        self.canvas_frame = customtkinter.CTkFrame(self, fg_color="transparent")
        self.canvas_frame.grid(row=2, column=0, sticky="nsew")
        self.canvas_frame.grid_columnconfigure(0, weight=1)
        self.canvas_frame.grid_rowconfigure(0, weight=1)

        self.lib_canvas = tk.Canvas(self.canvas_frame, bg="#F4EFEB", highlightthickness=0)
        self.lib_canvas.grid(row=0, column=0, sticky="nsew")

        self.lib_scrollbar = customtkinter.CTkScrollbar(self.canvas_frame, command=self.lib_canvas.yview)
        self.lib_scrollbar.grid(row=0, column=1, sticky="ns")
        self.lib_canvas.configure(yscrollcommand=self.lib_scrollbar.set, yscrollincrement=1)
        
        self._scroll_target = 0.0
        self._scroll_frac = 0.0
        self._is_scrolling = False
        
        def _smooth_scroll_loop():
            if abs(self._scroll_target) < 0.1:
                self._scroll_target = 0.0
                self._scroll_frac = 0.0
                self._is_scrolling = False
                return
                
            step = self._scroll_target * 0.12
            self._scroll_frac += step
            step_int = int(self._scroll_frac)
            self._scroll_frac -= step_int
            self._scroll_target -= step
            
            if step_int != 0:
                self.lib_canvas.yview_scroll(step_int, "units")
                
            self.after(10, _smooth_scroll_loop)
            
        def _on_mousewheel(event):
            if self.lib_canvas.winfo_ismapped():
                # Pastikan kursor berada di atas frame library
                x, y = self.winfo_pointerxy()
                widget = self.winfo_containing(x, y)
                is_inside = False
                w = widget
                while w is not None:
                    if w == self.canvas_frame or w == self.lib_canvas:
                        is_inside = True
                        break
                    w = w.master
                    
                if is_inside:
                    self._scroll_target -= (event.delta * 0.6)
                    if not self._is_scrolling:
                        self._is_scrolling = True
                        _smooth_scroll_loop()
                        
        self.parent.bind_all("<MouseWheel>", _on_mousewheel, add="+")

        def _on_canvas_resize(event):
            if not getattr(self, '_first_load_done', False):
                return
            if hasattr(self, '_resize_timer') and self._resize_timer:
                self.after_cancel(self._resize_timer)
            self._resize_timer = self.after(100, self._execute_search)
        self.lib_canvas.bind("<Configure>", _on_canvas_resize)

        self.render_skeleton_grid()
        self._skeleton_timer = self.after(50, self._do_actual_load)
        
    def _do_actual_load(self):
        self.auto_sync_local_files()
        self.refresh_library_list()

    def render_skeleton_grid(self):
        self.lib_canvas.delete("all")
        canvas_width = self.lib_canvas.winfo_width()
        if canvas_width < 100: canvas_width = 950 
            
        card_w = 210
        card_h = 190 
        padding_x = 18
        padding_y = 18
        
        cols = max(1, (canvas_width + padding_x) // (card_w + padding_x))
        total_grid_width = cols * (card_w + padding_x) - padding_x
        start_x = max(10, (canvas_width - total_grid_width) // 2)
        start_y = 20
        
        for i in range(cols * 2): # Render 2 rows of skeletons
            row = i // cols
            col = i % cols
            
            x = start_x + col * (card_w + padding_x)
            y = start_y + row * (card_h + padding_y)
            cx = x + card_w / 2
            
            # Skeleton Card Base
            self.lib_canvas.create_rectangle(x, y, x+card_w, y+card_h, fill="#FFFFFF", outline="#000000", width=3)
            # Skeleton Image Box
            self.lib_canvas.create_rectangle(x+5, y+5, x+card_w-5, y+100, fill="#E0E0E0", outline="#000000", width=2)
            # Skeleton Text Line
            self.lib_canvas.create_rectangle(cx-60, y+120, cx+60, y+130, fill="#E0E0E0", outline="")
            # Skeleton Button Box
            self.lib_canvas.create_rectangle(cx-55, y+148, cx+55, y+174, fill="#E0E0E0", outline="#000000", width=2)
            
        self.lib_canvas.configure(scrollregion=(0, 0, 950, start_y + 2 * (card_h + padding_y)))

    def auto_sync_local_files(self):
        from services.steam_service import get_steam_path, get_all_steamapps_paths
        steam_base = get_steam_path()
        steam_stplugin = os.path.join(steam_base, "config", "stplug-in")
        
        # Build map of appid -> real title from all steamapps appmanifests across all drives
        manifest_names = {}
        for apps_path in get_all_steamapps_paths():
            try:
                for manifest_file in glob.glob(os.path.join(apps_path, "appmanifest_*.acf")):
                    m = re.search(r'appmanifest_(\d+)\.acf', os.path.basename(manifest_file), re.IGNORECASE)
                    if m:
                        appid = m.group(1)
                        try:
                            with open(manifest_file, "r", encoding="utf-8", errors="ignore") as f:
                                content = f.read()
                                match_name = re.search(r'"name"\s+"([^"]+)"', content)
                                if match_name:
                                    manifest_names[appid] = match_name.group(1)
                        except Exception:
                            pass
            except Exception:
                pass

        if os.path.exists(steam_stplugin):
            for file_path in glob.glob(os.path.join(steam_stplugin, "*.lua")):
                filename = os.path.basename(file_path)
                match = re.search(r'(\d+)', filename)
                if match:
                    appid = match.group(1)
                    title = manifest_names.get(appid, f"Game {appid}")
                    insert_injected_game(appid, title)

    def force_reload_library(self):
        self._first_load_done = False
        self.render_skeleton_grid()
        if hasattr(self, '_skeleton_timer') and getattr(self, '_skeleton_timer'):
            self.after_cancel(self._skeleton_timer)
        self._skeleton_timer = self.after(50, self._do_actual_load)

    def _process_image_to_fit(self, img_raw, target_w=200, target_h=95):
        if img_raw.mode != 'RGB':
            img_raw = img_raw.convert('RGB')
            
        orig_w, orig_h = img_raw.size
        if orig_w == 0 or orig_h == 0:
            return img_raw
            
        # ImageOps.pad scales the image to fit 100% inside (target_w, target_h)
        # without cropping a single pixel or distorting aspect ratio, padding with #FFFFFF
        return ImageOps.pad(img_raw, (target_w, target_h), method=Image.Resampling.LANCZOS, color="#FFFFFF", centering=(0.5, 0.5))

    def load_steam_image(self, appid, title, preset_image_url=None):
        if appid in self.image_cache:
            return self.image_cache[appid]
            
        cache_dir = os.path.join(os.getcwd(), "cache", "img")
        os.makedirs(cache_dir, exist_ok=True)
        
        failed_path = os.path.join(cache_dir, f"{appid}.failed")
        if os.path.exists(failed_path):
            return None
            
        local_cache_path = os.path.join(cache_dir, f"{appid}.jpg")

        if os.path.exists(local_cache_path):
            try:
                img_data = Image.open(local_cache_path)
                if img_data.size != (200, 95):
                    img_data = self._process_image_to_fit(img_data, 200, 95)
                    img_data.save(local_cache_path, "JPEG", quality=95)
                tk_img = ImageTk.PhotoImage(img_data)
                self.image_cache[appid] = tk_img
                return tk_img
            except Exception:
                pass 
                
        # Stagger loading to prevent rate limits/bot detection
        time.sleep(0.1)
        headers_req = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/120.0.0.0 Safari/537.36 GameZoneClient/1.0", "Referer": "https://store.steampowered.com/"}

        # 1. Try preset_image_url if passed
        if preset_image_url:
            try:
                img_res = requests.get(preset_image_url, headers=headers_req, timeout=3)
                if img_res.status_code == 200:
                    img_data = Image.open(BytesIO(img_res.content))
                    img_processed = self._process_image_to_fit(img_data, 200, 95)
                    img_processed.save(local_cache_path, "JPEG", quality=95)
                    tk_img = ImageTk.PhotoImage(img_processed)
                    self.image_cache[appid] = tk_img
                    return tk_img
            except Exception:
                pass

        # 2. Prioritize online Steam header.jpg which is natively landscape (~460x215) and has zero rate limits
        cdn_headers = [
            f"https://shared.fastly.steamstatic.com/store_item_assets/steam/apps/{appid}/header.jpg",
            f"https://cdn.cloudflare.steamstatic.com/steam/apps/{appid}/header.jpg",
            f"https://steamcdn-a.akamaihd.net/steam/apps/{appid}/header.jpg"
        ]
        
        for url in cdn_headers:
            try:
                response = requests.get(url, headers=headers_req, timeout=2)
                if response.status_code == 200:
                    img_data = Image.open(BytesIO(response.content))
                    img_processed = self._process_image_to_fit(img_data, 200, 95)
                    img_processed.save(local_cache_path, "JPEG", quality=95)
                    tk_img = ImageTk.PhotoImage(img_processed)
                    self.image_cache[appid] = tk_img
                    return tk_img
            except Exception:
                continue

        # 3. Try online Steam appdetails API to fetch correct header URL (handles custom/hash URLs) - Fallback
        try:
            res = requests.get(f"https://store.steampowered.com/api/appdetails?appids={appid}", headers=headers_req, timeout=3)
            if res.status_code == 200:
                data = res.json()
                if str(appid) in data and data[str(appid)].get('success'):
                    header_url = data[str(appid)]['data'].get('header_image')
                    if header_url:
                        img_res = requests.get(header_url, headers=headers_req, timeout=3)
                        if img_res.status_code == 200:
                            img_data = Image.open(BytesIO(img_res.content))
                            img_processed = self._process_image_to_fit(img_data, 200, 95)
                            img_processed.save(local_cache_path, "JPEG", quality=95)
                            tk_img = ImageTk.PhotoImage(img_processed)
                            self.image_cache[appid] = tk_img
                            return tk_img
        except Exception:
            pass

        # 4. Check local Steam installation paths as secondary source
        from services.steam_service import get_steam_path
        steam_base = get_steam_path()
        steam_cache_paths = [
            os.path.join(steam_base, "appcache", "librarycache", f"{appid}_header.jpg"),
            os.path.join(steam_base, "appcache", "librarycache", appid, "header.jpg"),
            os.path.join(steam_base, "appcache", "librarycache", appid, "library_hero.jpg"),
            os.path.join(steam_base, "appcache", "librarycache", appid, "library_600x900.jpg")
        ]
        
        userdata_path = os.path.join(steam_base, "userdata")
        if os.path.exists(userdata_path):
            for user_id in os.listdir(userdata_path):
                grid_path = os.path.join(userdata_path, user_id, "config", "grid")
                steam_cache_paths.extend([
                    os.path.join(grid_path, f"{appid}.png"),
                    os.path.join(grid_path, f"{appid}.jpg"),
                    os.path.join(grid_path, f"{appid}p.png"),
                    os.path.join(grid_path, f"{appid}p.jpg")
                ])
                
        for scp in steam_cache_paths:
            if os.path.exists(scp):
                try:
                    img_data = Image.open(scp)
                    img_processed = self._process_image_to_fit(img_data, 200, 95)
                    img_processed.save(local_cache_path, "JPEG", quality=95)
                    tk_img = ImageTk.PhotoImage(img_processed)
                    self.image_cache[appid] = tk_img
                    return tk_img
                except Exception:
                    pass

        # 5. Fallback capsule and avatar generator
        safe_title = title.replace(' ', '+')
        fallback_urls = [
            f"https://shared.fastly.steamstatic.com/store_item_assets/steam/apps/{appid}/capsule_616x353.jpg",
            f"https://ui-avatars.com/api/?name={safe_title}&background=14141E&color=fff&size=256&font-size=0.25&bold=true"
        ]
        
        for url in fallback_urls:
            try:
                response = requests.get(url, headers=headers_req, timeout=2)
                if response.status_code == 200:
                    img_data = Image.open(BytesIO(response.content))
                    img_processed = self._process_image_to_fit(img_data, 200, 95)
                    if "ui-avatars.com" not in url:
                        img_processed.save(local_cache_path, "JPEG", quality=95)
                    tk_img = ImageTk.PhotoImage(img_processed)
                    self.image_cache[appid] = tk_img
                    return tk_img
            except Exception:
                continue
                
        try:
            with open(failed_path, "w") as f:
                f.write("")
        except Exception:
            pass
            
        return None

    def get_steam_name_from_bulk(self, appid):
        with self._bulk_lock:
            if not hasattr(self, "steam_bulk_dict"):
                self.steam_bulk_dict = {}
                cache_dir = os.path.join(os.getcwd(), "cache")
                os.makedirs(cache_dir, exist_ok=True)
                list_path = os.path.join(cache_dir, "applist.json")
                
                try:
                    if not os.path.exists(list_path) or time.time() - os.path.getmtime(list_path) > 86400 * 7:
                        headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/120.0.0.0 Safari/537.36 GameZoneClient/1.0"}
                        res = requests.get("https://api.steampowered.com/ISteamApps/GetAppList/v2/", headers=headers, timeout=5)
                        if res.status_code == 200:
                            with open(list_path, 'w', encoding='utf-8') as f:
                                f.write(res.text)
                    
                    if os.path.exists(list_path):
                        with open(list_path, 'r', encoding='utf-8') as f:
                            data = json.load(f)
                            for app in data.get('applist', {}).get('apps', []):
                                self.steam_bulk_dict[str(app['appid'])] = app['name']
                except Exception:
                    pass
        return self.steam_bulk_dict.get(str(appid), None)

    def refresh_library_list(self):
        self.all_games = sorted(get_injected_games(), key=lambda x: x[1].lower())
        self._first_load_done = True
        self.render_grid(self.all_games)

    def silent_background_reload(self):
        self.all_games = sorted(get_injected_games(), key=lambda x: x[1].lower())
        query = self.search_entry.get().lower()
        filtered_games = [g for g in self.all_games if query in g[1].lower()]
        self.render_grid(filtered_games)

    def filter_content(self, query):
        self._execute_search_query(query)

    def _execute_search_query(self, query):
        filtered_games = [g for g in self.all_games if query in g[1].lower()]
        self.render_grid(filtered_games)

    def filter_library(self, event):
        if hasattr(self, '_search_timer') and self._search_timer:
            self.after_cancel(self._search_timer)
        self._search_timer = self.after(150, self._execute_search)

    def _execute_search(self):
            if not getattr(self, '_first_load_done', False):
                return
            query = self.search_entry.get().lower()
            filtered_games = [g for g in self.all_games if query in g[1].lower()]
            self.render_grid(filtered_games)

    def handle_delete_game(self, appid, title):
        if messagebox.askyesno("Konfirmasi Hapus", f"{'Hapus instalasi injeksi untuk'} {title}?", parent=self.winfo_toplevel()):
            try:
                from services.steam_service import get_steam_path
                steam_base = get_steam_path()
                stplugin_path = os.path.join(steam_base, "config", "stplug-in")
                if os.path.exists(stplugin_path):
                    for f in glob.glob(os.path.join(stplugin_path, f"*{appid}*.lua")):
                        try: os.remove(f)
                        except Exception: pass
                
                depotcache_path = os.path.join(steam_base, "depotcache")
                if os.path.exists(depotcache_path):
                    for f in glob.glob(os.path.join(depotcache_path, f"*{appid}*.manifest")):
                        try: os.remove(f)
                        except Exception: pass
                        
                delete_injected_game(appid)
                self.force_reload_library()
            except Exception as e:
                messagebox.showerror("Eror", f"{'Gagal menghapus file: '}{e}", parent=self.winfo_toplevel())

    def render_grid(self, games):
        self._render_id = getattr(self, "_render_id", 0) + 1
        current_render_id = self._render_id

        self.lib_canvas.delete("all")
        if hasattr(self, 'current_buttons'):
            for b in self.current_buttons:
                b.destroy()
        self.current_buttons = [] 
        self.current_canvas_images = {} 
        
        if not games:
            self.lib_canvas.create_text(400, 100, text="Tidak ada game", fill="#000000", font=("Segoe UI Black", 20))
            return
            
        canvas_width = self.lib_canvas.winfo_width()
        if canvas_width < 100:
            canvas_width = 950 
            
        card_w = 210
        card_h = 190 
        padding_x = 18
        padding_y = 18
        
        cols = max(1, (canvas_width + padding_x) // (card_w + padding_x))
        
        total_grid_width = cols * (card_w + padding_x) - padding_x
        start_x = max(10, (canvas_width - total_grid_width) // 2)
        start_y = 20
        
        total_rows = (len(games) + cols - 1) // cols
        total_height = start_y + total_rows * (card_h + padding_y)
        self.lib_canvas.configure(scrollregion=(0, 0, 950, max(total_height, self.lib_canvas.winfo_height())))
        
        for i, (appid, title, injected_at) in enumerate(games):
            row = i // cols
            col = i % cols
            
            x = start_x + col * (card_w + padding_x)
            y = start_y + row * (card_h + padding_y)
            cx = x + card_w / 2
            img_cy = y + 52.5
            
            # Outer Card Frame (Neo-Brutalism)
            self.lib_canvas.create_rectangle(x, y, x+card_w, y+card_h, fill="#FFFFFF", outline="#000000", width=3, tags=(f"card_{appid}", f"card_bg_{appid}"))
            # Image Container Frame (200x95 px)
            self.lib_canvas.create_rectangle(x+5, y+5, x+card_w-5, y+100, fill="#FFFFFF", outline="#000000", width=2, tags=(f"card_{appid}",))
            
            text_id = self.lib_canvas.create_text(cx, img_cy, text="Loading...", fill="#000000", font=("Segoe UI", 10, "bold"), tags=(f"card_{appid}",))
            title_id = self.lib_canvas.create_text(cx, y + 125, text=title, fill="#000000", font=("Segoe UI Black", 11), width=195, justify="center", tags=(f"card_{appid}",))
            
            btn = tk.Button(self.lib_canvas, text="🗑 Hapus", width=12, bg="#FF499E", fg="#000000", font=("Segoe UI Black", 9), cursor="hand2", relief="solid", bd=2, activebackground="#E63F8A", activeforeground="#000000", command=lambda a=appid, t=title: self.handle_delete_game(a, t))
            self.lib_canvas.create_window(cx, y + 158, window=btn, width=130, height=26)
            self.current_buttons.append(btn)
            
            self.lib_canvas.tag_bind(f"card_{appid}", "<Enter>", lambda e, a=appid: self._on_card_hover(a, True))
            self.lib_canvas.tag_bind(f"card_{appid}", "<Leave>", lambda e, a=appid: self._on_card_hover(a, False))
            
            def process_image(app_id, t_id, t_title_id, curr_title, rx, ry, r_id):
                if current_render_id != self._render_id: return
                
                final_title = curr_title
                preset_image_url = None
                if curr_title.startswith("Game ") or "(Auto-Detected)" in curr_title or "Game ID:" in curr_title:
                    real_name = self.get_steam_name_from_bulk(app_id)
                    if real_name:
                        final_title = real_name
                    else:
                        time.sleep(0.35)
                        try:
                            headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/120.0.0.0 Safari/537.36 GameZoneClient/1.0"}
                            res = requests.get(f"https://store.steampowered.com/api/appdetails?appids={app_id}", headers=headers, timeout=3)
                            if res.status_code == 200:
                                data = res.json()
                                if str(app_id) in data and data[str(app_id)].get('success'):
                                    final_title = data[str(app_id)]['data'].get('name', final_title)
                                    preset_image_url = data[str(app_id)]['data'].get('header_image')
                        except Exception:
                            pass
                            
                    if final_title != curr_title:
                        update_injected_game_title(app_id, final_title)
                        for idx, g in enumerate(self.all_games):
                            if str(g[0]) == str(app_id):
                                self.all_games[idx] = (g[0], final_title, g[2])
                                break
                        def update_canvas_title(new_title=final_title):
                            if current_render_id == self._render_id:
                                self.lib_canvas.itemconfig(t_title_id, text=new_title)
                        self.after(0, update_canvas_title)
                                
                img = self.load_steam_image(app_id, final_title, preset_image_url)
                if img:
                    def update_canvas_img(final_img=img):
                        if current_render_id == self._render_id:
                            self.lib_canvas.delete(t_id)
                            self.lib_canvas.create_image(rx, ry, image=final_img, tags=(f"card_{app_id}",))
                            self.current_canvas_images[app_id] = final_img
                    self.after(0, update_canvas_img)
                else:
                    self.after(0, lambda: self.lib_canvas.itemconfig(t_id, text="No Image") if current_render_id == self._render_id else None)

            cached_img = self.image_cache.get(appid)
            if cached_img:
                self.lib_canvas.delete(text_id)
                self.lib_canvas.create_image(cx, img_cy, image=cached_img, tags=(f"card_{appid}",))
                self.current_canvas_images[appid] = cached_img
            else:
                self.image_executor.submit(process_image, appid, text_id, title_id, title, cx, img_cy, current_render_id)

    def _on_card_hover(self, appid, is_hover):
        # Neo Brutalism Hover: Increase border width and change color to highlight
        color = "#5D5FEF" if is_hover else "#000000"
        width = 4 if is_hover else 3
        
        self.lib_canvas.itemconfig(f"card_bg_{appid}", outline=color, width=width)
        
        state_attr = f"_is_hovering_{appid}"
        current_state = getattr(self, state_attr, False)
        
        if is_hover and not current_state:
            setattr(self, state_attr, True)
            try:
                x1, y1, x2, y2 = self.lib_canvas.coords(f"card_bg_{appid}")
                self.lib_canvas.coords(f"card_bg_{appid}", x1-2, y1-2, x2+2, y2+2)
            except Exception:
                pass
        elif not is_hover and current_state:
            setattr(self, state_attr, False)
            try:
                x1, y1, x2, y2 = self.lib_canvas.coords(f"card_bg_{appid}")
                self.lib_canvas.coords(f"card_bg_{appid}", x1+2, y1+2, x2-2, y2-2)
            except Exception:
                pass
