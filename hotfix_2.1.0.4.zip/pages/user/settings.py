import customtkinter
import threading
import sys
import os
import subprocess
import tkinter.messagebox as messagebox
from core.config import load_config, save_config

class SettingsPage(customtkinter.CTkFrame):
    def __init__(self, parent, main_app):
        super().__init__(parent, fg_color="#FFFFFF")
        self.parent = parent
        self.main_app = main_app
        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(0, weight=0)
        self.grid_rowconfigure(1, weight=1)
        
        self.config = load_config()
        
        # Header
        header = customtkinter.CTkFrame(self, fg_color="#FFFFFF", border_width=3, border_color="#000000", corner_radius=0)
        header.grid(row=0, column=0, sticky="ew", padx=25, pady=(15, 5))
        
        # Title Container to keep title and ornaments perfectly aligned and consistent on resize
        title_container = customtkinter.CTkFrame(header, fg_color="transparent")
        title_container.pack(pady=(12, 2))
        
        customtkinter.CTkLabel(title_container, text="🙂", font=("Segoe UI Emoji", 20), fg_color="#FFFFFF").pack(side="left", padx=(0, 10))
        
        lbl_title = customtkinter.CTkLabel(title_container, text="Pengaturan Aplikasi", font=customtkinter.CTkFont(family="Segoe UI Black", size=22), text_color="#000000")
        lbl_title.pack(side="left")
        
        customtkinter.CTkLabel(title_container, text="✦", font=("Segoe UI Black", 18), text_color="#5D5FEF", fg_color="#FFFFFF").pack(side="left", padx=(10, 0))
        
        lbl_subtitle = customtkinter.CTkLabel(header, text="Kustomisasi pengalaman pengguna & pemeliharaan sistem.", font=customtkinter.CTkFont(family="Segoe UI Black", size=12), text_color="#333333")
        lbl_subtitle.pack(pady=(0, 12))

        # Settings Container Card (Compact Single Card Top-Aligned)
        settings_card = customtkinter.CTkFrame(self, fg_color="#FFFFFF", corner_radius=0, border_width=3, border_color="#000000")
        settings_card.grid(row=1, column=0, sticky="nsew", padx=25, pady=(10, 25))
        settings_card.grid_columnconfigure(0, weight=1)

        # -------------------------------------------------------------------------
        # ROW 0: Steam Folder Path (Manual Selection - Paling Atas)
        # -------------------------------------------------------------------------
        row_steam_path = customtkinter.CTkFrame(settings_card, fg_color="#F8F9FA", border_width=2, border_color="#000000", corner_radius=0)
        row_steam_path.pack(fill="x", padx=15, pady=(15, 8))
        row_steam_path.grid_columnconfigure(0, weight=1)

        txt_box_steam = customtkinter.CTkFrame(row_steam_path, fg_color="transparent")
        txt_box_steam.pack(side="top", fill="x", padx=15, pady=(10, 5))

        lbl_steam = customtkinter.CTkLabel(txt_box_steam, text="📁 Lokasi Folder Steam", font=customtkinter.CTkFont(family="Segoe UI Black", size=14), text_color="#000000", anchor="w")
        lbl_steam.pack(anchor="w")

        lbl_steam_desc = customtkinter.CTkLabel(txt_box_steam, text="Atur atau pilih lokasi folder instalasi Steam secara manual jika tidak terdeteksi otomatis.", font=customtkinter.CTkFont(family="Segoe UI", size=11, weight="bold"), text_color="#666666", anchor="w")
        lbl_steam_desc.pack(anchor="w")

        input_box = customtkinter.CTkFrame(row_steam_path, fg_color="transparent")
        input_box.pack(side="top", fill="x", padx=15, pady=(0, 10))

        from services.steam_service import get_steam_path
        current_steam_path = get_steam_path()

        self.entry_steam_path = customtkinter.CTkEntry(
            input_box,
            font=customtkinter.CTkFont(family="Segoe UI", size=12),
            fg_color="#FFFFFF",
            text_color="#000000",
            border_width=2,
            border_color="#000000",
            corner_radius=0,
            height=34
        )
        self.entry_steam_path.insert(0, current_steam_path)
        self.entry_steam_path.pack(side="left", fill="x", expand=True, padx=(0, 8))

        btn_browse_steam = customtkinter.CTkButton(
            input_box,
            text="📂 Pilih Folder",
            width=120, height=34,
            fg_color="#3B82F6", hover_color="#2563EB",
            text_color="#FFFFFF",
            font=customtkinter.CTkFont(family="Segoe UI Black", size=12),
            corner_radius=0, border_width=2, border_color="#000000",
            command=self.browse_steam_folder
        )
        btn_browse_steam.pack(side="left", padx=(0, 5))

        btn_reset_steam = customtkinter.CTkButton(
            input_box,
            text="🔄 Auto",
            width=70, height=34,
            fg_color="#9CA3AF", hover_color="#6B7280",
            text_color="#FFFFFF",
            font=customtkinter.CTkFont(family="Segoe UI Black", size=12),
            corner_radius=0, border_width=2, border_color="#000000",
            command=self.reset_steam_folder
        )
        btn_reset_steam.pack(side="left")

        # -------------------------------------------------------------------------
        # ROW 1: Update Application
        # -------------------------------------------------------------------------
        row_update = customtkinter.CTkFrame(settings_card, fg_color="#F8F9FA", border_width=2, border_color="#000000", corner_radius=0)
        row_update.pack(fill="x", padx=15, pady=8)
        row_update.grid_columnconfigure(0, weight=1)

        txt_box1 = customtkinter.CTkFrame(row_update, fg_color="transparent")
        txt_box1.pack(side="left", padx=15, pady=10)
        
        lbl_update = customtkinter.CTkLabel(txt_box1, text="🔄 Pembaruan Aplikasi", font=customtkinter.CTkFont(family="Segoe UI Black", size=14), text_color="#000000", anchor="w")
        lbl_update.pack(anchor="w")
        
        lbl_update_desc = customtkinter.CTkLabel(txt_box1, text="Pastikan GameZone Anda selalu menggunakan versi terbaru.", font=customtkinter.CTkFont(family="Segoe UI", size=11, weight="bold"), text_color="#666666", anchor="w")
        lbl_update_desc.pack(anchor="w")
        
        btn_update = customtkinter.CTkButton(
            row_update, 
            text="Periksa Pembaruan", 
            width=160, height=34, 
            fg_color="#00D084", hover_color="#00B875", 
            text_color="#000000", 
            font=customtkinter.CTkFont(family="Segoe UI Black", size=12), 
            corner_radius=0, border_width=2, border_color="#000000", 
            command=self.check_for_update
        )
        btn_update.pack(side="right", padx=15, pady=10)

        # -------------------------------------------------------------------------
        # ROW 2: Clear Cache & Depotcache
        # -------------------------------------------------------------------------
        row_cache = customtkinter.CTkFrame(settings_card, fg_color="#F8F9FA", border_width=2, border_color="#000000", corner_radius=0)
        row_cache.pack(fill="x", padx=15, pady=8)
        row_cache.grid_columnconfigure(0, weight=1)

        txt_box2 = customtkinter.CTkFrame(row_cache, fg_color="transparent")
        txt_box2.pack(side="left", padx=15, pady=10)

        lbl_cache = customtkinter.CTkLabel(txt_box2, text="🧹 Pembersihan Cache", font=customtkinter.CTkFont(family="Segoe UI Black", size=14), text_color="#000000", anchor="w")
        lbl_cache.pack(anchor="w")
        
        lbl_cache_desc = customtkinter.CTkLabel(txt_box2, text="Bersihkan cache gambar, data sementara & file .manifest depotcache.", font=customtkinter.CTkFont(family="Segoe UI", size=11, weight="bold"), text_color="#666666", anchor="w")
        lbl_cache_desc.pack(anchor="w")
        
        btn_clear_cache = customtkinter.CTkButton(
            row_cache, 
            text="Bersihkan Cache", 
            width=160, height=34, 
            fg_color="#FF499E", hover_color="#E63F8A", 
            text_color="#000000", 
            font=customtkinter.CTkFont(family="Segoe UI Black", size=12), 
            corner_radius=0, border_width=2, border_color="#000000", 
            command=self.clear_all_cache
        )
        btn_clear_cache.pack(side="right", padx=15, pady=10)

        # -------------------------------------------------------------------------
        # ROW 3: Cleanup Sampah Steam (Orphan Files Dialog Popup)
        # -------------------------------------------------------------------------
        row_orphan = customtkinter.CTkFrame(settings_card, fg_color="#F8F9FA", border_width=2, border_color="#000000", corner_radius=0)
        row_orphan.pack(fill="x", padx=15, pady=(8, 15))
        row_orphan.grid_columnconfigure(0, weight=1)

        txt_box_orphan = customtkinter.CTkFrame(row_orphan, fg_color="transparent")
        txt_box_orphan.pack(side="left", padx=15, pady=10)

        lbl_orphan = customtkinter.CTkLabel(txt_box_orphan, text="🧹 Cleanup Sampah Steam (Orphan Files)", font=customtkinter.CTkFont(family="Segoe UI Black", size=14), text_color="#000000", anchor="w")
        lbl_orphan.pack(anchor="w")

        lbl_orphan_desc = customtkinter.CTkLabel(txt_box_orphan, text="Deteksi & bersihkan berkas .lua atau .manifest yatim bekas game yang sudah di-uninstall.", font=customtkinter.CTkFont(family="Segoe UI", size=11, weight="bold"), text_color="#666666", anchor="w")
        lbl_orphan_desc.pack(anchor="w")

        btn_open_orphan = customtkinter.CTkButton(
            row_orphan, 
            text="🧹 Cleanup Sampah", 
            width=160, height=34, 
            fg_color="#EF4444", hover_color="#DC2626", 
            text_color="#FFFFFF", 
            font=customtkinter.CTkFont(family="Segoe UI Black", size=12), 
            corner_radius=0, border_width=2, border_color="#000000", 
            command=self.open_steam_cleanup_dialog
        )
        btn_open_orphan.pack(side="right", padx=15, pady=10)

    def browse_steam_folder(self):
        from tkinter import filedialog
        from services.steam_service import get_steam_path
        initial_dir = self.entry_steam_path.get().strip() or get_steam_path()
        selected_dir = filedialog.askdirectory(
            title="Pilih Folder Utama Steam (misal: C:\\Program Files (x86)\\Steam)",
            initialdir=initial_dir if os.path.exists(initial_dir) else "C:\\"
        )
        if selected_dir:
            norm_path = os.path.normpath(selected_dir)
            if not os.path.exists(os.path.join(norm_path, "steam.exe")) and not os.path.exists(os.path.join(norm_path, "steamapps")):
                messagebox.showwarning(
                    "Peringatan Folder Steam",
                    "Folder yang dipilih tampaknya bukan folder utama Steam (tidak ditemukan steam.exe / steamapps).\nTetap menyimpan lokasi ini?",
                    parent=self.winfo_toplevel()
                )
            
            self.entry_steam_path.delete(0, "end")
            self.entry_steam_path.insert(0, norm_path)
            
            self.config["custom_steam_path"] = norm_path
            save_config(self.config)
            messagebox.showinfo("Sukses", f"Lokasi folder Steam berhasil disimpan:\n{norm_path}", parent=self.winfo_toplevel())

    def reset_steam_folder(self):
        if "custom_steam_path" in self.config:
            del self.config["custom_steam_path"]
            save_config(self.config)
        from services.steam_service import get_steam_path
        auto_path = get_steam_path()
        self.entry_steam_path.delete(0, "end")
        self.entry_steam_path.insert(0, auto_path)
        messagebox.showinfo("Reset Auto", f"Lokasi folder Steam dikembalikan ke terdeteksi otomatis:\n{auto_path}", parent=self.winfo_toplevel())

    def open_steam_cleanup_dialog(self):
        try:
            from components.dialogs import SteamCleanupDialog
            SteamCleanupDialog(self.winfo_toplevel())
        except Exception as e:
            messagebox.showerror("Error", f"Gagal membuka dialog Cleanup Sampah Steam: {e}", parent=self.winfo_toplevel())

    def check_for_update(self):
        # Memanggil metode async check update dengan argumen 'manual=True' 
        # (kita akan update fungsi _async_check_update di main.py untuk menerima argumen ini)
        threading.Thread(target=self.main_app._async_check_update, args=(True,), daemon=True).start()


    def clear_all_cache(self):
        if messagebox.askyesno("Konfirmasi", "Apakah Anda yakin ingin membersihkan semua cache aplikasi?", parent=self.winfo_toplevel()):
            def _async_clear():
                try:
                    # 1. Clear local cache directory
                    cache_dir = os.path.join(os.getcwd(), "cache")
                    if os.path.exists(cache_dir):
                        for item in os.listdir(cache_dir):
                            if item in ("discord_session.json", "profile.json"):
                                continue
                            item_path = os.path.join(cache_dir, item)
                            try:
                                if os.path.isfile(item_path):
                                    os.remove(item_path)
                                elif os.path.isdir(item_path):
                                    import shutil
                                    shutil.rmtree(item_path)
                            except Exception:
                                pass

                    # 2. Clear AppData deals cache
                    appdata_deals_cache = os.path.join(os.getenv('LOCALAPPDATA', os.path.expanduser('~')), 'GameZone', 'deals_cache.json')
                    if os.path.exists(appdata_deals_cache):
                        try:
                            os.remove(appdata_deals_cache)
                        except Exception:
                            pass

                    # 3. Clear memory image caches & trigger live refresh
                    if hasattr(self.main_app, "library_page") and self.main_app.library_page:
                        try:
                            self.main_app.library_page.image_cache.clear()
                            self.main_app.library_page.force_reload_library()
                        except Exception:
                            pass

                    if hasattr(self.main_app, "home_page") and self.main_app.home_page:
                        try:
                            self.main_app.home_page.deal_img_cache.clear()
                            self.main_app.home_page.load_live_deals()
                        except Exception:
                            pass

                    # 4. Clear Steam depotcache manifest files (.manifest) across all Steam drives
                    try:
                        from services.steam_service import get_all_steamapps_paths
                        for sa_path in get_all_steamapps_paths():
                            depotcache_path = os.path.join(os.path.dirname(sa_path), "depotcache")
                            if os.path.exists(depotcache_path):
                                for f in os.listdir(depotcache_path):
                                    if f.endswith(".manifest"):
                                        try:
                                            os.remove(os.path.join(depotcache_path, f))
                                        except Exception:
                                            pass
                    except Exception:
                        pass

                    self.after(0, lambda: messagebox.showinfo("Sukses", "Semua cache aplikasi & manifest depotcache Steam berhasil dibersihkan!", parent=self.winfo_toplevel()))
                except Exception as e:
                    self.after(0, lambda: messagebox.showerror("Gagal", f"Gagal membersihkan cache: {e}", parent=self.winfo_toplevel()))

            threading.Thread(target=_async_clear, daemon=True).start()

