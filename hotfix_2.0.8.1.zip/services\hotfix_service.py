import os
import sys
import json
import zipfile
import io
import threading
import requests

session = requests.Session()

def get_hotfix_dir():
    appdata_dir = os.path.join(os.getenv('LOCALAPPDATA', os.path.expanduser('~')), 'GameZone')
    hotfix_path = os.path.join(appdata_dir, 'hotfixes', 'current')
    os.makedirs(hotfix_path, exist_ok=True)
    return hotfix_path

def apply_hotfix_path(base_app_version="2.0.8"):
    """Ensure hotfix directory is in sys.path on app startup if hotfix is newer than base app version."""
    hotfix_dir = get_hotfix_dir()
    hotfix_ver = get_current_hotfix_version()
    
    # If stale hotfix is <= base_app_version, purge stale hotfix files so fresh EXE payload is used!
    try:
        from packaging import version
        if version.parse(hotfix_ver) <= version.parse(base_app_version):
            import shutil
            meta_path = os.path.join(hotfix_dir, 'hotfix_meta.json')
            if os.path.exists(meta_path):
                try: os.remove(meta_path)
                except Exception: pass
            for item in os.listdir(hotfix_dir):
                item_path = os.path.join(hotfix_dir, item)
                try:
                    if os.path.isfile(item_path):
                        os.remove(item_path)
                    elif os.path.isdir(item_path):
                        shutil.rmtree(item_path)
                except Exception:
                    pass
            hotfix_ver = "0.0.0"
    except Exception:
        pass

    if getattr(sys, 'frozen', False):
        if hotfix_ver != "0.0.0":
            if hotfix_dir not in sys.path:
                sys.path.insert(0, hotfix_dir)
    else:
        if hotfix_dir in sys.path:
            sys.path.remove(hotfix_dir)

def get_current_hotfix_version():
    meta_path = os.path.join(get_hotfix_dir(), 'hotfix_meta.json')
    if os.path.exists(meta_path):
        try:
            with open(meta_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
                return data.get('version', '0.0.0')
        except Exception:
            pass
    return "0.0.0"

def check_and_apply_hotfix_async(app_instance=None):
    """
    Asynchronously check Firebase for OTA Hotfixes and download if new version is available.
    """
    def _worker():
        try:
            from core.firebase_sync import get_db_url
            db_base = get_db_url()
            res = session.get(f"{db_base}/hotfix.json", timeout=5)
            if res.status_code != 200:
                return
            
            data = res.json()
            if not data or not isinstance(data, dict):
                return
            
            remote_ver = data.get('version', '0.0.0')
            download_url = data.get('download_url', '')
            files = data.get('files', {})  # Map of file_path -> raw_code (or zip download)
            
            local_ver = get_current_hotfix_version()
            
            # Compare versions
            remote_tuple = tuple(map(int, remote_ver.split('.'))) if '.' in remote_ver else (0, 0, 0)
            local_tuple = tuple(map(int, local_ver.split('.'))) if '.' in local_ver else (0, 0, 0)
            
            if remote_tuple > local_tuple:
                hotfix_dir = get_hotfix_dir()
                
                # Case A: ZIP Download
                if download_url.startswith('http'):
                    dl_res = session.get(download_url, timeout=15)
                    if dl_res.status_code == 200:
                        with zipfile.ZipFile(io.BytesIO(dl_res.content)) as z:
                            z.extractall(hotfix_dir)
                
                # Case B: Inline file map (Direct code patches for small fixes)
                elif files and isinstance(files, dict):
                    for rel_path, code in files.items():
                        target_file = os.path.join(hotfix_dir, rel_path)
                        os.makedirs(os.path.dirname(target_file), exist_ok=True)
                        with open(target_file, 'w', encoding='utf-8') as f:
                            f.write(code)
                
                # Save metadata
                meta_path = os.path.join(hotfix_dir, 'hotfix_meta.json')
                with open(meta_path, 'w', encoding='utf-8') as f:
                    json.dump({
                        'version': remote_ver,
                        'description': data.get('description', 'Auto Hotfix'),
                        'applied_at': data.get('updated_at', '')
                    }, f, indent=2)
                
                print(f"[Hotfix Engine] Applied OTA Hotfix v{remote_ver} successfully!")
        except Exception as e:
            print(f"[Hotfix Engine] Warning: Failed to check/apply hotfix: {e}")

    threading.Thread(target=_worker, daemon=True).start()
