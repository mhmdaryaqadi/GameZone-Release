import customtkinter
import threading
import time
import os
import sys
import subprocess
import requests
import datetime
import json
import hashlib
from PIL import Image, ImageTk, ImageOps
from io import BytesIO
import base64

def wrap_text(text, max_len=15):
    words = text.split(" ")
    lines = []
    current_line = []
    current_len = 0
    for word in words:
        if current_len + len(word) + (1 if current_line else 0) <= max_len:
            current_line.append(word)
            current_len += len(word) + (1 if current_line else 0)
        else:
            if current_line:
                lines.append(" ".join(current_line))
            current_line = [word]
            current_len = len(word)
    if current_line:
        lines.append(" ".join(current_line))
    return "\n".join(lines)

class HomePage(customtkinter.CTkFrame):
    def __init__(self, parent, main_app, **kwargs):
        super().__init__(parent, fg_color="#FFFFFF", **kwargs)
        self.parent = main_app
        self.is_destroyed = False
        self._last_ann_hash = None
        self.button_data = {
            "panduan": """📖 PANDUAN PENGGUNAAN GAMEZONE:

🎮 1. FITUR INJECT GAME:
- Cari game yang diinginkan pada tab 'Inject'.
- Pilih game, lalu klik tombol kuning 'TAMBAH GAME'.
- Game akan ter-inject secara otomatis. Untuk memunculkannya di library, Anda harus me-restart Steam client Anda (keluar dan masuk kembali).
- Jika file game sudah ditaruh di folder 'steamapps/common', klik 'Pasang/Install' di Steam untuk mendeteksi file lokal secara cepat.

🔧 2. FITUR FIX NO INTERNET (NETFIX):
- Klik tombol hijau 'Fix No Internet (Auto Scan)' di sidebar bawah.
- Pilih game yang unduhannya macet di Steam, lalu klik 'Fix Sekarang'.
- Setelah selesai, resume/lanjutkan kembali unduhan di Steam.

🌐 3. FITUR ONLINE FIX:
- Dapatkan Akun Sharing Steam gratis di tab 'Online Fix' untuk masuk ke Steam.
- Unduh berkas 'Fix Repair' multiplayer dari situs online-fix.me.
- Ekstrak dan copy-paste (timpa) file tersebut ke folder instalasi game Anda agar bisa bermain online/multiplayer.

👤 4. PROFIL & STATUS:
- Klik foto profil bulat untuk mengganti nickname dan avatar.
- Klik tombol '🟢 Status' di samping foto profil untuk melihat siapa saja anggota komunitas yang sedang aktif.

☁️ 5. FITUR SAVE CLOUD & UTILITY:
- Buka tab 'Cloud Save' di menu navigasi utama.
- Pencadangan Save Game: Cadangkan (backup) dan pulihkan (restore) save game lokal ke folder cadangan agar progres game injected tetap aman.
- Manifest Lock (Steam Pinning): Kunci file manifest depot (.acf) game agar Steam tidak memaksa auto-update yang merusak lisensi injected.
- Pembersih Sampah Steam: Pindai dan hapus file .lua / .manifest yatim bekas game yang di-uninstall secara 1-klik.""",
            "pembaruan": """📜 RIWAYAT PEMBARUAN (CHANGELOG):

✨ [v2.0.7] (Terbaru):
- 📌 System Tray & Single Instance: Minimize ke Tray saat klik 'X' & cegah aplikasi berjalan ganda.
- 🛒 Fix Purchase Button: Perbaiki tombol Beli (Purchase <-> Play) selang-seling di Sidebar & Settings.
- ⚡ Smart NetFix Update: Perbaikan unduhan update game otomatis tanpa menimpa buildid prematur.
- 🧹 Auto Steam License Cache Cleaner: Pembersihan cache appinfo.vdf di latar belakang secara otomatis.

✨ [v2.0.6]:
- ⚡ Mesin OTA Hotfix Patch: Dukungan pembaruan otomatis tanpa perlu unduh ulang installer .exe untuk perbaikan bug kecil.
- 🔄 Sistem Live Update Ganda: Pilihan rilis Major (.exe) dan rilis OTA Hotfix Kilat di Panel Admin.

✨ [v2.0.5]:
- ☁️ Save Cloud Redirect & Backup Engine: Cadangkan & pulihkan save game lokal agar progres tetap aman.
- 🔒 Manifest Lock & Anti Auto-Update: Kunci file .acf (Steam Pinning) agar lisensi game injected tidak tertimpa.
- 🧹 Pembersih Sampah Steam: Pindai & hapus file .lua / .manifest yatim bekas game yang di-uninstall 1-klik.
- 🚀 Graceful Steam Restart: Restart Steam secara bersih (-shutdown 15s poll) tanpa bug 'Purchase'.
- 💀 Floating Overlay Search Dropdown: Pencarian game interaktif dengan skeleton loader animasi.

✨ [v2.0.4]:
- 🚀 Steam Graceful Restart Fix: Penyempurnaan penutupan bersih steamwebhelper.exe untuk mencegah bug status 'Purchase' saat inject.
- 🔗 Dynamic Steam Registry Path: Deteksi lokasi instalasi Steam secara dinamis dari Windows Registry.
- 🎨 Neo-Brutalism UI: Navigasi cepat 0ms dengan optimasi memori.

✨ [v2.0.3]:
- 🚀 Recommended Games: Menambahkan widget 12 game rekomendasi populer di kolom kiri halaman utama dengan loading gambar CDN Steam asinkron & instan (0ms).
- 🛠️ Bug Fixes: Menyelesaikan masalah overlapping teks judul game yang panjang pada resolusi kecil, serta memperbaiki warning penskalaan HighDPI (CTkImage).
- 🎨 Neo-Brutalism UI: Navigasi cepat 0ms dengan optimasi penggunaan memori.

✨ [v2.0.2]:
- Menambahkan 5 API manifest komunitas baru (Morrenus, Ryuu, TwentyTwo Cloud, Sushi, SkyApi).
- Otomatisasi pengisian morrenus_key/moapikey secara dinamis dari Firebase database & config lokal.
- Menambahkan tombol sinkronisasi otomatis 5 API baru tersebut di menu pengaturan admin.
- Mempercepat pencarian manifest secara paralel (Fast Search) menggunakan ThreadPoolExecutor.

✨ [v2.0.1]:
- Transisi antar halaman menjadi sangat lancar dan ringan bebas lag.
- Pembatasan request database Firebase untuk menghemat kuota internet dan mempercepat loading.
- Memperbaiki pencarian game di tab Inject agar lebih stabil dengan jeda ketik 350ms.
- Mengurangi error Steam 429 dengan menyimpan riwayat pencarian game di memori cache.
- Visual loading skeleton loader kini lebih stabil dan tidak berantakan saat dimuat.
- Mengurangi beban memori dengan memperbarui tombol reaksi chat hanya saat diperlukan.

✨ [v2.0.0]:
- 🎨 Perombakan UI Lengkap: Pemolesan seluruh tampilan ke estetika Neo Brutalism 60 FPS, membuang animasi berat, dan memberikan layout yang lebih ringkas.
- 🚀 Transisi Instan: Navigasi perpindahan antar halaman kini instan dan bebas lag (0ms delay).
- 🐛 Fix Bug Layout: Perbaikan border bleed dan button layout shift pada sidebar menu.

✨ [v1.0.7]:
- 🛡️ Pembaruan Wajib: Notifikasi update kini muncul instan dan bersifat wajib.
- Pengguna harus mengklik OK dan tidak bisa diabaikan demi keamanan & kestabilan versi terbaru.

✨ [v1.0.6]:
- 🛡️ Update Senyap (Auto-Restart): Sekarang aplikasi langsung tertutup saat klik update, berjalan senyap, dan otomatis menyala kembali setelah selesai (Bypass WinError UAC).
- 🎮 Steam Graceful Restart: Menggunakan protokol Steam asli (-shutdown) untuk mencegah game yang baru diinjeksi tertelan oleh Crash Recovery Steam.
- 🌐 NetFix Multi-Drive: Pengecekan game yang sedang didownload kini menjangkau ke semua Disk/Steam Library (D:, E:, dll).
- 🥷 Animasi CMD: Jendela hitam CMD yang berkedip-kedip saat memantau status Steam telah dihilangkan.

✨ [v1.0.5]:
- 🎮 Username Steam (Auto-Detect): Aplikasi kini otomatis mengenali username Steam lokal secara aman di pojok kiri bawah.
- 🎨 UI Posisi Tombol: Tombol Restart Steam dan SteamDB disempurnakan.
- 🧹 Cleanup: Penghapusan total artefak tema gelap karena mengganggu estetik.

✨ [v1.0.4]:
- 🔧 Perbaikan Bug (Hotfix): Mencegah error injeksi ketika pengguna mengeklik 'Tambah Game' tanpa mengisi kolom pencarian.

✨ [v1.0.3]:
- ✨ Fitur Baru: Menambahkan menu khusus 'Fix No Internet'.
- ✨ Peningkatan UX: Menggabungkan pencarian Nama Game & AppID menjadi satu kolom cerdas di halaman Inject.
- ✨ Transisi ke Installer: Aplikasi kini di-build sebagai Full Installer yang ringan.
- 🔧 Perbaikan Bug: Memperbaiki masalah kritis sertifikat SSL (HTTPS).
- 🛡️ Perbaikan Izin Windows: Pemindahan direktori ke AppData mengatasi masalah macet total.
- 🎨 Pembaruan UI: Tombol SteamDB dipindah ke kanan atas.
- 🌐 Perbaikan Bahasa: Memastikan semua halaman baru 100% mendukung terjemahan dwibahasa secara dinamis.

✨ [v1.0.2]:
- Perbaikan sistem dan Rebranding nama secara keseluruhan ke GameZone.

✨ [v1.0.1]:
- UI Pop-up Overhaul: Tampilan Loading Live Injeksi interaktif.
- Smart Search UX: Daftar pencarian merespons klik luar otomatis.
- Alternative Injections Paths: Area Dropzone untuk file lokal.

✨ [v1.0.0]:
- Rilis Awal (Initial Release).
- Injeksi otomatis didukung oleh 3 Server Manifest Komunitas.""",
            "donasi": "https://saweria.co/"
        }
        
        self.grid_columnconfigure(0, weight=6)
        self.grid_columnconfigure(1, weight=4)
        self.grid_rowconfigure(1, weight=1)

        # Theme Colors - Neo-Brutalism
        self.CARD_BG = "#FFFFFF"
        self.ACCENT_YELLOW = "#FFD800"
        self.ACCENT_PINK = "#FF499E"
        self.ACCENT_GREEN = "#00D084"
        self.ACCENT_BLUE = "#5D5FEF"
        self.BORDER_COLOR = "#000000"
        self.TEXT_BLACK = "#000000"
        self.TEXT_MUTED = "#555555"
        
        # =========================================================================
        # TOP BAR
        # =========================================================================
        top_bar = customtkinter.CTkFrame(self, fg_color="transparent")
        top_bar.grid(row=0, column=0, columnspan=2, pady=(0, 10), sticky="ew")
        
        title = customtkinter.CTkLabel(
            top_bar, text="Home Dashboard", 
            font=customtkinter.CTkFont(family="Segoe UI Black", size=18), 
            text_color=self.TEXT_BLACK
        )
        title.grid(row=0, column=0, sticky="w")

        # =========================================================================
        # LEFT COLUMN (Hero Banner)
        # =========================================================================
        left_column = customtkinter.CTkFrame(self, fg_color="transparent")
        left_column.grid(row=1, column=0, padx=(0, 10), sticky="nsew")
        left_column.grid_columnconfigure(0, weight=1)

        # 1. Hero Welcome Card
        self.hero_card = customtkinter.CTkFrame(
            left_column, fg_color=self.CARD_BG, 
            border_width=3, border_color=self.BORDER_COLOR, corner_radius=0
        )
        self.hero_card.pack(fill="x", pady=(0, 15))
        
        self.lbl_welcome = customtkinter.CTkLabel(
            self.hero_card, text="WELCOME BACK!", 
            font=customtkinter.CTkFont(family="Segoe UI Black", size=22), 
            text_color=self.TEXT_BLACK, anchor="w", justify="left"
        )
        self.lbl_welcome.pack(fill="x", padx=20, pady=(20, 5))
        
        self.lbl_level = customtkinter.CTkLabel(
            self.hero_card, text="Premium User", 
            font=customtkinter.CTkFont(family="Segoe UI Black", size=12), 
            text_color=self.ACCENT_GREEN, anchor="w", justify="left"
        )
        self.lbl_level.pack(fill="x", padx=20, pady=(0, 20))

        # 2. Recommended Games Card
        self.rec_card = customtkinter.CTkFrame(
            left_column, fg_color=self.CARD_BG, 
            border_width=3, border_color=self.BORDER_COLOR, corner_radius=0
        )
        self.rec_card.pack(fill="both", expand=True, pady=(0, 5))
        
        lbl_rec_title = customtkinter.CTkLabel(
            self.rec_card, text="🔥 RECOMMENDED & HOT GAMES", 
            font=customtkinter.CTkFont(family="Segoe UI Black", size=13), 
            text_color=self.TEXT_BLACK, anchor="w", justify="left"
        )
        lbl_rec_title.pack(fill="x", padx=15, pady=(15, 10))
        
        # CTkScrollableFrame to enable scrolling of 10+ games
        self.rec_scroll = customtkinter.CTkScrollableFrame(
            self.rec_card, fg_color="transparent", corner_radius=0
        )
        self.rec_scroll.pack(fill="both", expand=True, padx=10, pady=(0, 10))
        self.rec_scroll.grid_columnconfigure(0, weight=1)
        self.rec_scroll.grid_columnconfigure(1, weight=1)
        self.rec_scroll.grid_columnconfigure(2, weight=1)
        
        self.recommended_list = [
            {"appid": "2358720", "name": "Black Myth: Wukong"},
            {"appid": "1245620", "name": "Elden Ring"},
            {"appid": "1091500", "name": "Cyberpunk 2077"},
            {"appid": "271590", "name": "GTA V"},
            {"appid": "1174180", "name": "Red Dead Redemption 2"},
            {"appid": "990080", "name": "Hogwarts Legacy"},
            {"appid": "1817070", "name": "Spider-Man Remastered"},
            {"appid": "1593500", "name": "God of War"},
            {"appid": "2050650", "name": "Resident Evil 4"},
            {"appid": "1551360", "name": "Forza Horizon 5"},
            {"appid": "814380", "name": "Sekiro: Shadows Die Twice"},
            {"appid": "2215430", "name": "Ghost of Tsushima"}
        ]
        self.rec_images = {}
        self.rec_img_labels = {}
        
        # Build UI grid instantly on start (0ms load)
        for i, game in enumerate(self.recommended_list):
            appid = game["appid"]
            name = game["name"]
            row = i // 3
            col = i % 3
            
            card = customtkinter.CTkFrame(
                self.rec_scroll, fg_color="#FFFFFF",
                border_width=2, border_color="#000000", corner_radius=0
            )
            card.grid(row=row, column=col, padx=5, pady=5, sticky="nsew")
            card.grid_columnconfigure(0, weight=1)
            
            img_label = customtkinter.CTkLabel(
                card, text="Loading Cover...", 
                font=customtkinter.CTkFont(family="Segoe UI", size=9, weight="bold"),
                height=66,
                fg_color="#F0F0F0"
            )
            img_label.pack(fill="x", padx=5, pady=(5, 2))
            self.rec_img_labels[appid] = img_label
            
            wrapped_name = wrap_text(name, 14)
            title_lbl = customtkinter.CTkLabel(
                card, text=wrapped_name, 
                font=customtkinter.CTkFont(family="Segoe UI", size=9, weight="bold"),
                text_color="#000000",
                anchor="center",
                justify="center"
            )
            title_lbl.pack(fill="x", padx=5, pady=(2, 5))
            
            btn_quick_inject = customtkinter.CTkButton(
                card, text="⚡ INJECT",
                fg_color="#FF499E", hover_color="#E63F8A",
                text_color="#000000",
                font=customtkinter.CTkFont(family="Segoe UI Black", size=10),
                height=26,
                corner_radius=0,
                border_width=2,
                border_color="#000000",
                command=lambda a=appid, n=name: self.handle_quick_inject(a, n)
            )
            btn_quick_inject.pack(fill="x", padx=5, pady=(0, 5))
            
        self.load_recommended_games()

        # =========================================================================
        # RIGHT COLUMN (Full Height Interactive Pengumuman Card + Utility Buttons)
        # =========================================================================
        right_column = customtkinter.CTkFrame(self, fg_color="transparent")
        right_column.grid(row=1, column=1, padx=(10, 0), sticky="nsew")
        right_column.grid_columnconfigure(0, weight=1)
        right_column.grid_rowconfigure(0, weight=1)

        # Pengumuman Card (Full Height)
        self.ann_card = customtkinter.CTkFrame(
            right_column, fg_color=self.CARD_BG, 
            border_width=3, border_color=self.BORDER_COLOR, corner_radius=0
        )
        self.ann_card.pack(fill="both", expand=True, pady=(0, 10))

        lbl_ann_title = customtkinter.CTkLabel(
            self.ann_card, text="📢 PENGUMUMAN", 
            font=customtkinter.CTkFont(family="Segoe UI Black", size=15), 
            text_color=self.TEXT_BLACK, anchor="w"
        )
        lbl_ann_title.pack(fill="x", padx=20, pady=(18, 5))
        
        self.announce_scroll = customtkinter.CTkScrollableFrame(
            self.ann_card, fg_color="#FFFFFF", border_width=2, 
            border_color=self.BORDER_COLOR, corner_radius=0
        )
        self.announce_scroll.pack(fill="both", expand=True, padx=15, pady=(5, 15))

        # Bottom Utility Buttons (Panduan, Pembaruan, Donasi)
        bot_btns = customtkinter.CTkFrame(right_column, fg_color="transparent")
        bot_btns.pack(fill="x")
        bot_btns.grid_columnconfigure(0, weight=1)
        bot_btns.grid_columnconfigure(1, weight=1)
        bot_btns.grid_columnconfigure(2, weight=1)

        btn_panduan = customtkinter.CTkButton(
            bot_btns, text="PANDUAN", fg_color="#5D5FEF", hover_color="#4B4CD9", 
            text_color="#FFFFFF", font=customtkinter.CTkFont(family="Segoe UI Black", size=11), 
            corner_radius=0, border_width=3, border_color="#000000", command=self.open_guide, height=36
        )
        btn_panduan.grid(row=0, column=0, padx=(0, 4), sticky="ew")

        btn_pembaruan = customtkinter.CTkButton(
            bot_btns, text="PEMBARUAN", fg_color="#00D084", hover_color="#00B875", 
            text_color="#000000", font=customtkinter.CTkFont(family="Segoe UI Black", size=11), 
            corner_radius=0, border_width=3, border_color="#000000", command=self.open_changelog, height=36
        )
        btn_pembaruan.grid(row=0, column=1, padx=4, sticky="ew")

        btn_donasi = customtkinter.CTkButton(
            bot_btns, text="DONASI", fg_color="#FF499E", hover_color="#E63F8A", 
            text_color="#000000", font=customtkinter.CTkFont(family="Segoe UI Black", size=11), 
            corner_radius=0, border_width=3, border_color="#000000", command=self.open_donasi, height=36
        )
        btn_donasi.grid(row=0, column=2, padx=(4, 0), sticky="ew")

        # Start Realtime Background Sync Loop for Announcements
        self.start_realtime_announcements()

    def open_guide(self):
        from components.dialogs import InfoDialog
        text = self.button_data.get("panduan", "")
        InfoDialog(self.winfo_toplevel(), "Panduan Penggunaan", text)

    def open_changelog(self):
        from components.dialogs import InfoDialog
        text = self.button_data.get("pembaruan", "")
        InfoDialog(self.winfo_toplevel(), "Update Terbaru", text)

    def open_donasi(self):
        import webbrowser
        url = self.button_data.get("donasi", "https://saweria.co/")
        webbrowser.open(url)

    def load_recommended_games(self):
        threading.Thread(target=self._async_load_recommended, daemon=True).start()

    def _async_load_recommended(self):
        from PIL import Image, ImageOps
        import requests
        
        cache_dir = os.path.join(os.getcwd(), "cache", "img")
        os.makedirs(cache_dir, exist_ok=True)
        
        headers = {"User-Agent": "Mozilla/5.0"}
        
        for game in self.recommended_list:
            appid = game["appid"]
            local_path = os.path.join(cache_dir, f"{appid}.jpg")
            img_loaded = None
            
            if os.path.exists(local_path):
                try:
                    img_loaded = Image.open(local_path)
                except Exception:
                    pass
                    
            if not img_loaded:
                url = f"https://shared.fastly.steamstatic.com/store_item_assets/steam/apps/{appid}/header.jpg"
                try:
                    req = requests.get(url, headers=headers, timeout=5)
                    if req.status_code == 200:
                        img_loaded = Image.open(BytesIO(req.content))
                        img_loaded.convert("RGB").save(local_path, "JPEG", quality=90)
                except Exception:
                    pass
                    
            if img_loaded:
                try:
                    img_resized = ImageOps.pad(img_loaded, (280, 132), method=Image.Resampling.LANCZOS, color="#FFFFFF")
                    self.rec_images[appid] = img_resized
                    self.after(0, lambda a=appid, img=img_resized: self._update_single_image(a, img))
                except Exception:
                    pass
            else:
                self.after(0, lambda a=appid: self._update_single_image_fail(a))

    def _update_single_image(self, appid, pil_img):
        if not self.winfo_exists():
            return
        img_label = self.rec_img_labels.get(appid)
        if img_label and img_label.winfo_exists():
            ctk_img = customtkinter.CTkImage(light_image=pil_img, dark_image=pil_img, size=(140, 66))
            img_label.configure(image=ctk_img, text="", fg_color="transparent")
            img_label.image = ctk_img

    def _update_single_image_fail(self, appid):
        if not self.winfo_exists():
            return
        img_label = self.rec_img_labels.get(appid)
        if img_label and img_label.winfo_exists():
            img_label.configure(text="No Cover", fg_color="#E0E0E0")

    def handle_quick_inject(self, appid, name):
        self.parent.show_injection_hub()
        self.after(100, lambda: self.parent.hub_page.direct_inject_game(appid, name))

    def refresh_page(self):
        self._last_ann_hash = None
        self.load_announcement()

    def load_announcement(self):
        threading.Thread(target=self._async_load_announcement, daemon=True).start()

    def start_realtime_announcements(self):
        threading.Thread(target=self._realtime_loop, daemon=True).start()

    def _realtime_loop(self):
        while not self.is_destroyed:
            try:
                from core.firebase_sync import fetch_announcements
                ann_data = fetch_announcements()
                
                try:
                    payload_str = json.dumps(ann_data, sort_keys=True)
                    current_hash = hashlib.md5(payload_str.encode('utf-8')).hexdigest()
                except Exception:
                    current_hash = str(ann_data)

                if current_hash != self._last_ann_hash:
                    self._last_ann_hash = current_hash
                    self._async_load_announcement(ann_data=ann_data)
            except Exception:
                pass
            time.sleep(15)

    def _async_load_announcement(self, ann_data=None):
        try:
            from core.firebase_sync import fetch_announcements, fetch_button_texts
            if ann_data is None:
                ann_data = fetch_announcements()
                
            btn_data = fetch_button_texts()
            if btn_data:
                for key in ["panduan", "pembaruan", "donasi"]:
                    if btn_data.get(key):
                        self.button_data[key] = btn_data.get(key)
                
            anns_to_load = []
            if ann_data:
                if isinstance(ann_data, dict):
                    if "text" in ann_data or "image_url" in ann_data or "image_base64" in ann_data:
                        ann_data["id"] = "ann1"
                        anns_to_load.append(ann_data)
                    else:
                        for key in ["ann1", "ann2"]:
                            if ann_data.get(key):
                                item = ann_data.get(key)
                                item["id"] = key
                                anns_to_load.append(item)
                        
            loaded_announcements = []
            for item in anns_to_load:
                text = item.get("text", "").strip()
                image_url = item.get("image_url", "").strip()
                image_base64 = item.get("image_base64", "").strip()
                
                if not text and not image_url and not image_base64:
                    continue
                    
                image_loaded = None
                if image_base64:
                    try:
                        if "," in image_base64:
                            image_base64_data = image_base64.split(",")[1]
                        else:
                            image_base64_data = image_base64
                        img_bytes = base64.b64decode(image_base64_data)
                        img_data = BytesIO(img_bytes)
                        pil_img = Image.open(img_data)
                        pil_img.load()
                        try: resampling = Image.Resampling.LANCZOS
                        except AttributeError: resampling = Image.ANTIALIAS
                        pil_img = pil_img.resize((260, 146), resampling)
                        image_loaded = pil_img
                    except Exception:
                        pass
                elif image_url:
                    try:
                        headers = {"User-Agent": "Mozilla/5.0"}
                        res = requests.get(image_url, headers=headers, timeout=5)
                        if res.status_code == 200:
                            img_data = BytesIO(res.content)
                            pil_img = Image.open(img_data)
                            pil_img.load()
                            try: resampling = Image.Resampling.LANCZOS
                            except AttributeError: resampling = Image.ANTIALIAS
                            pil_img = pil_img.resize((260, 146), resampling)
                            image_loaded = pil_img
                    except Exception:
                        pass
                        
                loaded_announcements.append({
                    "id": item.get("id", "ann1"),
                    "text": text,
                    "image": image_loaded,
                    "reactions": item.get("reactions", {})
                })

            def update_ui():
                if not self.winfo_exists():
                    return
                for widget in self.announce_scroll.winfo_children():
                    widget.destroy()
                    
                if not loaded_announcements:
                    lbl_empty = customtkinter.CTkLabel(
                        self.announce_scroll, text="Belum ada pengumuman terbaru.", 
                        font=customtkinter.CTkFont(family="Segoe UI Black", size=13), 
                        text_color="#555555"
                    )
                    lbl_empty.pack(pady=40)
                    return
                    
                for ann in loaded_announcements:
                    card = customtkinter.CTkFrame(
                        self.announce_scroll, fg_color="#FFFFFF", 
                        border_width=3, border_color="#000000", corner_radius=0
                    )
                    card.pack(fill="x", padx=5, pady=8)
                    
                    if ann["image"]:
                        try:
                            img_frame = customtkinter.CTkFrame(card, fg_color="#FFFFFF", border_width=3, border_color="#000000", corner_radius=0, height=152)
                            img_frame.pack(fill="x", padx=10, pady=(10, 5))
                            img_frame.pack_propagate(False)
                            
                            lbl_img = customtkinter.CTkLabel(img_frame, text="")
                            lbl_img.pack(fill="both", expand=True)
                            
                            ctk_img = customtkinter.CTkImage(light_image=ann["image"], dark_image=ann["image"], size=(260, 146))
                            lbl_img.configure(image=ctk_img)
                            lbl_img.image = ctk_img
                        except Exception:
                            pass
                            
                    txt_height = 60 if ann["image"] else 120
                    txt_box = customtkinter.CTkTextbox(card, height=txt_height, fg_color="transparent", text_color="#000000", border_width=0, corner_radius=0, font=customtkinter.CTkFont(family="Segoe UI Black", size=12))
                    txt_box.pack(fill="x", padx=10, pady=(5, 5))
                    txt_box.insert("1.0", ann["text"])
                    txt_box.configure(state="disabled")

                    reacts_frame = customtkinter.CTkFrame(card, fg_color="transparent")
                    reacts_frame.pack(fill="x", padx=10, pady=(0, 10))
                    
                    reactions = ann.get("reactions") or {}
                    like_count = reactions.get("like", 0)
                    love_count = reactions.get("love", 0)
                    fire_count = reactions.get("fire", 0)
                    
                    ann_id = ann.get("id", "ann1")
                    
                    btn_like = customtkinter.CTkButton(reacts_frame, text=f"👍 {like_count}", width=60, height=28, fg_color="#F4EFEB", hover_color="#E0E0E0", text_color="#000000", font=customtkinter.CTkFont(family="Segoe UI Black", size=11), border_width=2, border_color="#000000", corner_radius=0, command=lambda aid=ann_id: self.react_to_announcement(aid, "like"))
                    btn_like.pack(side="left", padx=(0, 5))
                    
                    btn_love = customtkinter.CTkButton(reacts_frame, text=f"❤️ {love_count}", width=60, height=28, fg_color="#F4EFEB", hover_color="#E0E0E0", text_color="#000000", font=customtkinter.CTkFont(family="Segoe UI Black", size=11), border_width=2, border_color="#000000", corner_radius=0, command=lambda aid=ann_id: self.react_to_announcement(aid, "love"))
                    btn_love.pack(side="left", padx=5)
                    
                    btn_fire = customtkinter.CTkButton(reacts_frame, text=f"🔥 {fire_count}", width=60, height=28, fg_color="#F4EFEB", hover_color="#E0E0E0", text_color="#000000", font=customtkinter.CTkFont(family="Segoe UI Black", size=11), border_width=2, border_color="#000000", corner_radius=0, command=lambda aid=ann_id: self.react_to_announcement(aid, "fire"))
                    btn_fire.pack(side="left", padx=5)
                
            self.after(0, update_ui)
        except Exception:
            pass

    def react_to_announcement(self, ann_id, emoji):
        from core.firebase_sync import add_announcement_reaction
        def worker():
            new_count = add_announcement_reaction(ann_id, emoji)
            if new_count is not False:
                self.load_announcement()
        threading.Thread(target=worker, daemon=True).start()

    def destroy(self):
        self.is_destroyed = True
        super().destroy()
