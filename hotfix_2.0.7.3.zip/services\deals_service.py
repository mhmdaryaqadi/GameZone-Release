import os
import json
import time
import requests

CACHE_TTL = 7200  # 2 Hours Cache

def get_cache_path():
    appdata_dir = os.path.join(os.getenv('LOCALAPPDATA', os.path.expanduser('~')), 'GameZone', 'cache')
    os.makedirs(appdata_dir, exist_ok=True)
    return os.path.join(appdata_dir, 'deals_cache.json')

def fetch_live_deals_and_events():
    """
    Fetches real-time PC game deals, 100% free games, and Steam sales/events.
    Uses 2-hour local disk cache to ensure 0ms instant load times.
    Failsafe: Returns curated offline fallback data if network request fails.
    """
    cache_path = get_cache_path()
    now = time.time()

    # 1. Check local cache
    if os.path.exists(cache_path):
        try:
            with open(cache_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
                cached_at = data.get('cached_at', 0)
                if now - cached_at < CACHE_TTL and data.get('discounts'):
                    return data
        except Exception:
            pass

    # 2. Fetch fresh data from APIs
    discounts = []
    freebies = []
    events = []

    # API A: CheapShark Top PC Game Discounts
    try:
        url_deals = "https://www.cheapshark.com/api/1.0/deals?onSale=1&pageSize=12&sortBy=Savings"
        res = requests.get(url_deals, timeout=6)
        if res.status_code == 200:
            for item in res.json():
                title = item.get("title", "Game PC")
                sale_price = float(item.get("salePrice", 0))
                norm_price = float(item.get("normalPrice", 0))
                savings = float(item.get("savings", 0))
                steam_appid = item.get("steamAppID")
                thumb = item.get("thumb")
                deal_id = item.get("dealID")
                
                store_url = f"https://www.cheapshark.com/redirect?dealID={deal_id}"
                if steam_appid and str(steam_appid) != "None":
                    store_url = f"https://store.steampowered.com/app/{steam_appid}/"
                    if not thumb:
                        thumb = f"https://cdn.akamai.steamstatic.com/steam/apps/{steam_appid}/header.jpg"

                item_obj = {
                    "title": title,
                    "sale_price": f"${sale_price:.2f}" if sale_price > 0 else "GRATIS",
                    "normal_price": f"${norm_price:.2f}",
                    "savings_pct": f"{int(savings)}%",
                    "thumb": thumb,
                    "store_url": store_url,
                    "is_free": sale_price == 0 or savings >= 99.9
                }

                if item_obj["is_free"]:
                    freebies.append(item_obj)
                else:
                    discounts.append(item_obj)
    except Exception:
        pass

    # API B: GamerPower PC 100% Free Giveaways
    try:
        url_free = "https://www.gamerpower.com/api/giveaways?platform=pc"
        res_free = requests.get(url_free, timeout=6)
        if res_free.status_code == 200:
            for item in res_free.json()[:6]:
                freebies.append({
                    "title": item.get("title", "Free Game"),
                    "sale_price": "GRATIS 100%",
                    "normal_price": item.get("worth", "FREE"),
                    "savings_pct": "100%",
                    "thumb": item.get("image", ""),
                    "store_url": item.get("open_giveaway_url", "https://store.steampowered.com/"),
                    "is_free": True
                })
    except Exception:
        pass

    # API C: Steam Featured Categories / Events
    try:
        url_steam = "https://store.steampowered.com/api/featuredcategories"
        res_steam = requests.get(url_steam, timeout=6)
        if res_steam.status_code == 200:
            s_data = res_steam.json()
            specials = s_data.get("specials", {}).get("items", [])
            for item in specials[:6]:
                events.append({
                    "title": item.get("name", "Steam Special"),
                    "discount_pct": f"-{item.get('discount_percent', 0)}%",
                    "final_price": f"Rp {item.get('final_price', 0)//100:,}".replace(",", "."),
                    "thumb": item.get("header_image") or item.get("large_capsule_image"),
                    "store_url": f"https://store.steampowered.com/app/{item.get('id')}/"
                })
    except Exception:
        pass

    # Fallback mock data if APIs were blocked or offline
    if not discounts and not freebies:
        freebies = [
            {
                "title": "Epic Games Free Weekly Titles",
                "sale_price": "GRATIS 100%",
                "normal_price": "$29.99",
                "savings_pct": "100%",
                "thumb": "https://cdn2.unrealengine.com/egs-freegames-community-capsule-1920x1080-1920x1080-798835012.png",
                "store_url": "https://store.epicgames.com/free-games",
                "is_free": True
            }
        ]
        discounts = [
            {
                "title": "Black Myth: Wukong - Publisher Sale",
                "sale_price": "$49.99",
                "normal_price": "$59.99",
                "savings_pct": "15%",
                "thumb": "https://cdn.akamai.steamstatic.com/steam/apps/2358720/header.jpg",
                "store_url": "https://store.steampowered.com/app/2358720/",
                "is_free": False
            },
            {
                "title": "Grand Theft Auto V: Premium Edition",
                "sale_price": "$14.99",
                "normal_price": "$29.99",
                "savings_pct": "50%",
                "thumb": "https://cdn.akamai.steamstatic.com/steam/apps/271590/header.jpg",
                "store_url": "https://store.steampowered.com/app/271590/",
                "is_free": False
            }
        ]

    result = {
        "cached_at": now,
        "freebies": freebies,
        "discounts": discounts,
        "events": events
    }

    # Save to disk cache
    try:
        with open(cache_path, 'w', encoding='utf-8') as f:
            json.dump(result, f, indent=2)
    except Exception:
        pass

    return result
