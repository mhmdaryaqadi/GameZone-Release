import os
import sys
import json
import zipfile
import io
import threading
import requests

session = requests.Session()

def get_hotfix_dir():
    appdata_dir = os.path.join(os.getenv('LOCALAPPDATA', os.path.expanduser('~')), 'GameZone')
    hotfix_path = os.path.join(appdata_dir, 'hotfixes', 'current')
    os.makedirs(hotfix_path, exist_ok=True)
    return hotfix_path

def apply_hotfix_path():
    """Ensure hotfix directory is in sys.path on app startup."""
    hotfix_dir = get_hotfix_dir()
    if getattr(sys, 'frozen', False):
        # In compiled EXE mode, hotfixes take precedence over bundle
        if hotfix_dir not in sys.path:
            sys.path.insert(0, hotfix_dir)
    else:
        # In DEV source mode, local project_dir must take precedence!
        if hotfix_dir in sys.path:
            sys.path.remove(hotfix_dir)
        sys.path.append(hotfix_dir)

def get_current_hotfix_version():
    meta_path = os.path.join(get_hotfix_dir(), 'hotfix_meta.json')
    if os.path.exists(meta_path):
        try:
            with open(meta_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
                return data.get('version', '0.0.0')
        except Exception:
            pass
    return "0.0.0"

def check_and_apply_hotfix_async(app_instance=None):
    """
    Asynchronously check Firebase for OTA Hotfixes and download if new version is available.
    """
    def _worker():
        try:
            from core.firebase_sync import get_db_url
            db_base = get_db_url()
            res = session.get(f"{db_base}/hotfix.json", timeout=5)
            if res.status_code != 200:
                return
            
            data = res.json()
            if not data or not isinstance(data, dict):
                return
            
            remote_ver = data.get('version', '0.0.0')
            download_url = data.get('download_url', '')
            files = data.get('files', {})  # Map of file_path -> raw_code (or zip download)
            
            local_ver = get_current_hotfix_version()
            
            # Compare versions
            remote_tuple = tuple(map(int, remote_ver.split('.'))) if '.' in remote_ver else (0, 0, 0)
            local_tuple = tuple(map(int, local_ver.split('.'))) if '.' in local_ver else (0, 0, 0)
            
            if remote_tuple > local_tuple:
                hotfix_dir = get_hotfix_dir()
                
                # Case A: ZIP Download
                if download_url.startswith('http'):
                    dl_res = session.get(download_url, timeout=15)
                    if dl_res.status_code == 200:
                        with zipfile.ZipFile(io.BytesIO(dl_res.content)) as z:
                            z.extractall(hotfix_dir)
                
                # Case B: Inline file map (Direct code patches for small fixes)
                elif files and isinstance(files, dict):
                    for rel_path, code in files.items():
                        target_file = os.path.join(hotfix_dir, rel_path)
                        os.makedirs(os.path.dirname(target_file), exist_ok=True)
                        with open(target_file, 'w', encoding='utf-8') as f:
                            f.write(code)
                
                # Save metadata
                meta_path = os.path.join(hotfix_dir, 'hotfix_meta.json')
                with open(meta_path, 'w', encoding='utf-8') as f:
                    json.dump({
                        'version': remote_ver,
                        'description': data.get('description', 'Auto Hotfix'),
                        'applied_at': data.get('updated_at', '')
                    }, f, indent=2)
                
                print(f"[Hotfix Engine] Applied OTA Hotfix v{remote_ver} successfully!")
        except Exception as e:
            print(f"[Hotfix Engine] Warning: Failed to check/apply hotfix: {e}")

    threading.Thread(target=_worker, daemon=True).start()
