import customtkinter
import tkinter.messagebox as messagebox
import threading
import time
import os
import webbrowser
import requests
import zipfile
from tkinter import filedialog
from PIL import Image
from io import BytesIO
from core.injector import download_and_inject
from components.dialogs import LoadingDialog
import sys

def resource_path(relative_path):
    if getattr(sys, 'frozen', False):
        base_path = sys._MEIPASS
    else:
        base_path = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
    return os.path.join(base_path, relative_path)

class InjectionHubPage(customtkinter.CTkFrame):
    def __init__(self, parent, main_app, **kwargs):
        super().__init__(parent, fg_color="#FFFFFF", **kwargs)
        self.parent = main_app
        
        # Grid layout for the whole page
        self.grid_columnconfigure(0, weight=6)
        self.grid_columnconfigure(1, weight=4)
        self.grid_rowconfigure(1, weight=1)

        # =========================================================================
        # TOP BAR
        # =========================================================================
        top_bar = customtkinter.CTkFrame(self, fg_color="transparent")
        top_bar.grid(row=0, column=0, columnspan=2, pady=(0, 4), sticky="ew")
        top_bar.grid_columnconfigure(0, weight=1)
        
        # Title "WELCOME"
        self.title_lbl = customtkinter.CTkLabel(top_bar, text="? WELCOME", font=customtkinter.CTkFont(family="Segoe UI Black", size=18), text_color="#000000")
        self.title_lbl.grid(row=0, column=0, sticky="w")
        
        # Decorations
        customtkinter.CTkLabel(top_bar, text="✦", font=("Segoe UI Black", 16), text_color="#FF499E", fg_color="#FFFFFF").grid(row=0, column=1, padx=(8, 0), sticky="w")
        customtkinter.CTkLabel(top_bar, text="🙂", font=("Segoe UI Emoji", 18), fg_color="#FFFFFF").grid(row=0, column=2, padx=(4, 0), sticky="w")

        # =========================================================================
        # 2-COLUMN SPLIT LAYOUT (Left: Inject Form | Right: Empty Pengumuman Panel)
        # =========================================================================
        self.grid_columnconfigure(0, weight=6)
        self.grid_columnconfigure(1, weight=4)
        self.grid_rowconfigure(1, weight=1)

        # LEFT PANEL (Inject Form)
        self.left_panel = customtkinter.CTkFrame(self, fg_color="#FFFFFF", corner_radius=0, border_width=3, border_color="#000000")
        self.left_panel.grid(row=1, column=0, padx=(0, 15), sticky="nsew")
        self.left_panel.grid_columnconfigure(0, weight=1)
        
        title_container = customtkinter.CTkFrame(self.left_panel, fg_color="transparent")
        title_container.grid(row=0, column=0, pady=(10, 4))
        
        customtkinter.CTkLabel(title_container, text="*", font=("Segoe UI Black", 30), text_color="#00D084", fg_color="#FFFFFF").pack(side="left", padx=(0, 10))
        
        lbl_inject_title = customtkinter.CTkLabel(title_container, text="INJECT", font=customtkinter.CTkFont(family="Segoe UI Black", size=30), text_color="#000000")
        lbl_inject_title.pack(side="left")
        
        customtkinter.CTkLabel(title_container, text="✨", font=("Segoe UI Emoji", 22), fg_color="#FFFFFF").pack(side="left", padx=(10, 0))
        
        desc = customtkinter.CTkLabel(self.left_panel, text="GAME LANGSUNG MASUK KE LIBRARY STEAM.", font=customtkinter.CTkFont(family="Segoe UI", size=11, weight="bold"), text_color="#333333")
        desc.grid(row=1, column=0, pady=(0, 8))

        top_btns_container = customtkinter.CTkFrame(self.left_panel, fg_color="transparent")
        top_btns_container.grid(row=2, column=0, pady=(0, 6), sticky="ew", padx=20)
        top_btns_container.grid_columnconfigure(1, weight=1)
        
        btn_steamdb = customtkinter.CTkButton(top_btns_container, text="SteamDB", width=80, height=28, fg_color="#FFD800", hover_color="#E6C300", text_color="#000000", font=customtkinter.CTkFont(family="Segoe UI Black", size=11), corner_radius=0, border_width=3, border_color="#000000", command=lambda: webbrowser.open("https://steamdb.info/"))
        btn_steamdb.grid(row=0, column=0, sticky="w")
        
        btn_restart_hub = customtkinter.CTkButton(top_btns_container, text="RESTART STEAM", width=100, height=28, fg_color="#FF499E", hover_color="#E63F8A", text_color="#000000", font=customtkinter.CTkFont(family="Segoe UI Black", size=11), border_width=3, border_color="#000000", corner_radius=0, command=self.handle_steam_restart)
        btn_restart_hub.grid(row=0, column=2, sticky="e")
        
        search_container = customtkinter.CTkFrame(self.left_panel, fg_color="transparent")
        search_container.grid(row=3, column=0, pady=(0, 8), sticky="ew", padx=20)
        search_container.grid_columnconfigure(0, weight=1)
        
        self.entry_appid = customtkinter.CTkEntry(search_container, placeholder_text="CARI NAMA GAME ATAU APPID...", height=36, justify="center", fg_color="#FFFFFF", border_color="#000000", border_width=3, text_color="#000000", font=customtkinter.CTkFont(family="Segoe UI", size=12, weight="bold"), corner_radius=0)
        self.entry_appid.grid(row=0, column=0, sticky="ew")
        
        self.entry_appid.bind("<KeyRelease>", self.on_search_type)
        self.entry_appid.bind("<FocusIn>", self.on_search_focus)
        
        # Inject Button
        self.btn_inject = customtkinter.CTkButton(self.left_panel, text="TAMBAH GAME", width=250, height=36, fg_color="#00D084", hover_color="#00B875", text_color="#000000", font=customtkinter.CTkFont(family="Segoe UI Black", size=14), corner_radius=0, border_width=3, border_color="#000000", command=self.handle_inject)
        self.btn_inject.grid(row=4, column=0, pady=(0, 8))

        self.lbl_status = customtkinter.CTkLabel(self.left_panel, text="", text_color="#333333", font=customtkinter.CTkFont(family="Segoe UI", size=12, weight="bold"))
        self.lbl_status.grid(row=5, column=0, pady=(0, 4))

        # Alternatif Section
        lbl_alt = customtkinter.CTkLabel(self.left_panel, text="ALTERNATIF:", font=customtkinter.CTkFont(family="Segoe UI Black", size=12), text_color="#000000")
        lbl_alt.grid(row=6, column=0, pady=(0, 4))

        btn_alt = customtkinter.CTkButton(self.left_panel, text="PILIH FILE\n.ZIP / .LUA\n/ .MANIFEST", width=130, height=80, fg_color="#FFFFFF", hover_color="#E0E0E0", text_color="#000000", font=customtkinter.CTkFont(family="Segoe UI Black", size=11), border_width=3, border_color="#000000", corner_radius=0, command=self.handle_alternatif)
        btn_alt.grid(row=7, column=0, pady=(0, 20))

        # RIGHT PANEL (Recommended & Hot Games Panel)
        self.right_panel = customtkinter.CTkFrame(self, fg_color="#FFFFFF", border_width=3, border_color="#000000", corner_radius=0)
        self.right_panel.grid(row=1, column=1, sticky="nsew")
        self.right_panel.grid_columnconfigure(0, weight=1)
        self.right_panel.grid_rowconfigure(1, weight=1)

        header_frame = customtkinter.CTkFrame(self.right_panel, fg_color="transparent")
        header_frame.grid(row=0, column=0, pady=(12, 6), padx=10, sticky="ew")
        header_frame.grid_columnconfigure(0, weight=1)

        lbl_hist_head = customtkinter.CTkLabel(
            header_frame, text="🔥 RECOMMENDED & HOT GAMES", 
            font=customtkinter.CTkFont(family="Segoe UI Black", size=15), 
            text_color="#000000", anchor="w"
        )
        lbl_hist_head.pack(side="left", padx=10)

        self.trending_scroll = customtkinter.CTkScrollableFrame(self.right_panel, fg_color="transparent", border_width=0, corner_radius=0)
        self.trending_scroll.grid(row=1, column=0, padx=10, pady=(0, 10), sticky="nsew")
        self.trending_scroll.grid_columnconfigure(0, weight=1)
        self.trending_scroll.grid_columnconfigure(1, weight=1)
        self.trending_scroll.grid_columnconfigure(2, weight=1)

        self.button_texts = {
            "panduan": "",
            "pembaruan": "",
            "donasi": ""
        }
        
        self.trending_img_cache = {}
        self.load_live_trending_games()

        # Overlay Search Results
        self.search_results_frame = customtkinter.CTkScrollableFrame(self.left_panel, fg_color="#FFFFFF", border_width=3, border_color="#000000", corner_radius=0, height=120)
        
        self.search_after_id = None
        self.search_cache = {}
        self.selected_appid = None
        self.search_buttons = []
        self.parent.bind("<Button-1>", self.on_window_click, add="+")
        
        self.applist_data = []
        self._load_applist_thread()
        self._last_ann_hash = None
        self.load_announcement()
        
    def _load_applist_thread(self):
        def loader():
            try:
                list_path = os.path.join(os.getcwd(), "cache", "applist.json")
                if os.path.exists(list_path):
                    import json
                    with open(list_path, 'r', encoding='utf-8') as f:
                        data = json.load(f)
                        self.applist_data = data.get('applist', {}).get('apps', [])
            except: pass
        threading.Thread(target=loader, daemon=True).start()

    def on_window_click(self, event):
        x, y = self.winfo_pointerxy()
        widget = self.winfo_containing(x, y)
        is_inside_search = False
        w = widget
        while w is not None:
            if w == self.search_results_frame or w == self.entry_appid:
                is_inside_search = True
                break
            w = w.master
        if not is_inside_search:
            self.hide_search_results()

    def on_search_focus(self, event):
        if self.entry_appid.get().strip() and not self.entry_appid.get().isdigit():
            self.show_search_results()

    def on_search_type(self, event):
        query = self.entry_appid.get().strip()
        self.selected_appid = None
        
        # Batalkan penundaan pencarian sebelumnya jika user mengetik lagi
        if self.search_after_id is not None:
            self.after_cancel(self.search_after_id)
            self.search_after_id = None
            
        if not query or len(query) < 1 or query.isdigit():
            self.hide_search_results()
            return

        # Jadwalkan pencarian setelah jeda ketik 350ms
        self.search_after_id = self.after(350, lambda: self.perform_search_async(query))

    def show_search_skeleton(self):
        if hasattr(self, "search_buttons"):
            for btn in self.search_buttons:
                try:
                    btn.destroy()
                except:
                    pass
        self.search_buttons = []
        
        # Buat 4 suggestion bar abu-abu (skeleton)
        for _ in range(4):
            sk_frame = customtkinter.CTkFrame(
                self.search_results_frame, 
                height=32, 
                fg_color="#FFFFFF",
                corner_radius=0
            )
            sk_frame.pack(fill="x", padx=5, pady=2)
            
            # Bar loading abu-abu di dalam frame
            bar = customtkinter.CTkFrame(
                sk_frame,
                width=180,
                height=14,
                fg_color="#E0E0E0",
                corner_radius=4
            )
            bar.pack(side="left", padx=10, pady=9)
            
            self.search_buttons.append(sk_frame)
            
        self.show_search_results()

    def perform_search_async(self, query):
        query_lower = query.lower()
        
        # Cek cache memori terlebih dahulu agar super instan
        if query_lower in self.search_cache:
            self.update_search_results(self.search_cache[query_lower])
            return
            
        # Tampilkan skeleton loader di dropdown suggestion
        self.show_search_skeleton()
        
        # Jalankan pencarian asinkronus di background thread
        threading.Thread(target=self._async_fetch_search, args=(query,), daemon=True).start()

    def _async_fetch_search(self, query):
        query_lower = query.lower()
        items = []
        
        # 1. Cari di local applist (jika tersedia)
        if self.applist_data:
            for app in self.applist_data:
                app_name = app.get("name", "")
                if query_lower in app_name.lower():
                    items.append({"id": app["appid"], "name": app_name})
                    if len(items) >= 7:
                        break
                        
        # 2. Jika tidak ada di local, cari ke store Steam online
        if not items:
            try:
                url = f"https://store.steampowered.com/api/storesearch/?term={query}&l=english&cc=US"
                headers = {
                    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/120.0.0.0 Safari/537.36 GameZoneClient/1.0",
                    "Referer": "https://store.steampowered.com/"
                }
                res = requests.get(url, headers=headers, timeout=5)
                if res.status_code == 200:
                    data = res.json()
                    items = data.get("items", [])
            except Exception:
                pass
                
        # Simpan hasil ke cache
        self.search_cache[query_lower] = items
        
        # Update tampilan UI di main thread
        self.after(0, lambda: self.update_search_results(items))

    def update_search_results(self, items):
        if hasattr(self, "search_buttons"):
            for btn in self.search_buttons:
                try:
                    btn.destroy()
                except:
                    pass
        self.search_buttons = []

        if not items:
            self.hide_search_results()
            return

        for item in items[:7]:
            appid = str(item.get("id", ""))
            name = item.get("name", "Unknown Game")
            
            btn = customtkinter.CTkButton(
                self.search_results_frame, 
                text=name, 
                anchor="w", 
                fg_color="transparent", 
                hover_color="#E0E0E0", 
                text_color="#000000",
                font=customtkinter.CTkFont(family="Segoe UI", size=13, weight="bold"),
                command=lambda a=appid, n=name: self.select_search_result(a, n)
            )
            btn.pack(fill="x", padx=5, pady=2)
            self.search_buttons.append(btn)
            
        self.show_search_results()

    def select_search_result(self, appid, name):
        self.entry_appid.delete(0, "end")
        self.entry_appid.insert(0, name)
        self.selected_appid = appid
        self.hide_search_results()
        self.entry_appid.master.focus_set()

    def show_search_results(self):
        if not hasattr(self, "search_buttons") or not self.search_buttons:
            return
            
        if not self.search_results_frame.winfo_ismapped():
            self.entry_appid.update_idletasks()
            x = self.entry_appid.master.winfo_x() + self.entry_appid.winfo_x()
            y = self.entry_appid.master.winfo_y() + self.entry_appid.winfo_y() + self.entry_appid.winfo_height()
            w = self.entry_appid.winfo_width()
            # Set minimum width to fit entry
            self.search_results_frame.configure(width=max(w - 20, 10))
            self.search_results_frame.place(x=x, y=y)

    def hide_search_results(self):
        if self.search_results_frame.winfo_ismapped():
            self.search_results_frame.place_forget()

    def show_custom_info_dialog(self, title, emoji, text):
        dlg = customtkinter.CTkToplevel(self)
        dlg.title(title)
        
        self.update_idletasks()
        parent = self.winfo_toplevel()
        dlg_x = parent.winfo_x() + (parent.winfo_width() // 2) - 350
        dlg_y = parent.winfo_y() + (parent.winfo_height() // 2) - 250
        dlg.geometry(f"700x500+{dlg_x}+{dlg_y}")
        
        dlg.resizable(False, False)
        dlg.transient(self.winfo_toplevel())
        dlg.grab_set()
        
        dlg.configure(fg_color="#F4EFEB")
        
        customtkinter.CTkLabel(dlg, text="✦", font=("Segoe UI Black", 30), text_color="#FF499E").place(x=20, y=10)
        customtkinter.CTkLabel(dlg, text="*", font=("Segoe UI Black", 40), text_color="#00D084").place(x=640, y=20)
        customtkinter.CTkLabel(dlg, text=emoji, font=("Segoe UI Emoji", 40)).place(x=30, y=420)
        customtkinter.CTkLabel(dlg, text="+", font=("Segoe UI Black", 50), text_color="#5D5FEF").place(x=620, y=400)

        textbox = customtkinter.CTkTextbox(dlg, fg_color="#FFFFFF", border_color="#000000", border_width=3, corner_radius=0, text_color="#000000", font=customtkinter.CTkFont(family="Segoe UI", size=13, weight="bold"), wrap="word")
        textbox.pack(fill="both", expand=True, padx=40, pady=(40, 10))
        textbox.insert("0.0", text)
        textbox.configure(state="disabled")
        
        btn = customtkinter.CTkButton(dlg, text="TUTUP", command=dlg.destroy, width=150, height=35, fg_color="#FF499E", hover_color="#E63F8A", text_color="#000000", font=customtkinter.CTkFont(family="Segoe UI Black", size=14), border_width=3, border_color="#000000", corner_radius=0)
        btn.pack(pady=(0, 20))
        
        def _fade_in(step=0):
            if step <= 10:
                dlg.attributes("-alpha", step/10.0)
                dlg.after(16, lambda: _fade_in(step+1))
                
        dlg.attributes("-alpha", 0.0)
        _fade_in()

    def open_guide(self):
        text = self.button_texts.get("panduan", "").strip()
        if not text:
            text = "1. Cari game atau masukkan AppID.\n2. Klik Tambah Game.\n3. Tunggu hingga proses selesai.\n4. Restart Steam."
        self.show_custom_info_dialog("Buku Panduan", "📖", text)

    def open_changelog(self):
        text = self.button_texts.get("pembaruan", "").strip()
        if not text:
            text = """📜 RIWAYAT PEMBARUAN (CHANGELOG):

✨ [v2.0.7] (Terbaru):
- 📌 System Tray & Single Instance: Minimize ke Tray saat klik 'X' & cegah aplikasi berjalan ganda.
- 🛒 Fix Purchase Button: Perbaiki tombol Beli (Purchase <-> Play) selang-seling di Sidebar & Settings.
- ⚡ Smart NetFix Update: Perbaikan unduhan update game otomatis tanpa menimpa buildid prematur.
- 🧹 Auto Steam License Cache Cleaner: Pembersihan cache appinfo.vdf di latar belakang secara otomatis.

✨ [v2.0.6]:
- ⚡ Mesin OTA Hotfix Patch: Dukungan pembaruan otomatis tanpa perlu unduh ulang installer .exe untuk perbaikan bug kecil.
- 🔄 Sistem Live Update Ganda: Pilihan rilis Major (.exe) dan rilis OTA Hotfix Kilat di Panel Admin.

✨ [v2.0.5]:
- ☁️ Save Cloud Redirect & Backup Engine: Cadangkan & pulihkan save game lokal agar progres tetap aman.
- 🔒 Manifest Lock & Anti Auto-Update: Kunci file .acf (Steam Pinning) agar lisensi game injected tidak tertimpa.
- 🧹 Pembersih Sampah Steam: Pindai & hapus file .lua / .manifest yatim bekas game yang di-uninstall 1-klik.
- 🚀 Graceful Steam Restart: Restart Steam secara bersih (-shutdown 15s poll) tanpa bug 'Purchase'.
- 💀 Floating Overlay Search Dropdown: Pencarian game interaktif dengan skeleton loader animasi.

✨ [v2.0.4]:
- 🚀 Steam Graceful Restart Fix: Penyempurnaan penutupan bersih steamwebhelper.exe untuk mencegah bug status 'Purchase' saat inject.
- 🔗 Dynamic Steam Registry Path: Deteksi lokasi instalasi Steam secara dinamis dari Windows Registry.
- 🎨 Neo-Brutalism UI: Navigasi cepat 0ms dengan optimasi memori.

✨ [v2.0.3]:
- 🚀 Recommended Games: Menambahkan widget 12 game rekomendasi populer di kolom kiri halaman utama dengan loading gambar CDN Steam asinkron & instan (0ms).
- 🛠️ Bug Fixes: Menyelesaikan masalah overlapping teks judul game yang panjang pada resolusi kecil, serta memperbaiki warning penskalaan HighDPI (CTkImage).
- 🎨 Neo-Brutalism UI: Navigasi cepat 0ms dengan optimasi penggunaan memori.

✨ [v2.0.2]:
- Menambahkan 5 API manifest komunitas baru (Morrenus, Ryuu, TwentyTwo Cloud, Sushi, SkyApi).
- Otomatisasi pengisian morrenus_key/moapikey secara dinamis dari Firebase database & config lokal.
- Menambahkan tombol sinkronisasi otomatis 5 API baru tersebut di menu pengaturan admin.
- Mempercepat pencarian manifest secara paralel (Fast Search) menggunakan ThreadPoolExecutor.

✨ [v2.0.1]:
- Transisi antar halaman menjadi sangat lancar dan ringan bebas lag.
- Pembatasan request database Firebase untuk menghemat kuota internet dan mempercepat loading.
- Memperbaiki pencarian game di tab Inject agar lebih stabil dengan jeda ketik 350ms.
- Mengurangi error Steam 429 dengan menyimpan riwayat pencarian game di memori cache.
- Visual loading skeleton loader kini lebih stabil dan tidak berantakan saat dimuat.
- Mengurangi beban memori dengan memperbarui tombol reaksi chat hanya saat diperlukan.

✨ [v2.0.0]:
- 🎨 Perombakan UI Lengkap: Pemolesan seluruh tampilan ke estetika Neo Brutalism 60 FPS, membuang animasi berat, dan memberikan layout yang lebih ringkas.
- 🚀 Transisi Instan: Navigasi perpindahan antar halaman kini instan dan bebas lag (0ms delay).
- 🐛 Fix Bug Layout: Perbaikan border bleed dan button layout shift pada sidebar menu.

✨ [v1.0.7]:
- 🛡️ Pembaruan Wajib: Notifikasi update kini muncul instan dan bersifat wajib.
- Pengguna harus mengklik OK dan tidak bisa diabaikan demi keamanan & kestabilan versi terbaru.

✨ [v1.0.6]:
- 🛡️ Update Senyap (Auto-Restart): Sekarang aplikasi langsung tertutup saat klik update, berjalan senyap, dan otomatis menyala kembali setelah selesai (Bypass WinError UAC).
- 🎮 Steam Graceful Restart: Menggunakan protokol Steam asli (-shutdown) untuk mencegah game yang baru diinjeksi tertelan oleh Crash Recovery Steam.
- 🌐 NetFix Multi-Drive: Pengecekan game yang sedang didownload kini menjangkau ke semua Disk/Steam Library (D:, E:, dll).
- 🥷 Animasi CMD: Jendela hitam CMD yang berkedip-kedip saat memantau status Steam telah dihilangkan.

✨ [v1.0.5]:
- 🎮 Username Steam (Auto-Detect): Aplikasi kini otomatis mengenali username Steam lokal secara aman di pojok kiri bawah.
- 🎨 UI Posisi Tombol: Tombol Restart Steam dan SteamDB disempurnakan.
- 🧹 Cleanup: Penghapusan total artefak tema gelap karena mengganggu estetik.

✨ [v1.0.4]:
- 🔧 Perbaikan Bug (Hotfix): Mencegah error injeksi ketika pengguna mengeklik 'Tambah Game' tanpa mengisi kolom pencarian.

v1.0.3
- ✨ Fitur Baru: Menambahkan menu khusus 'Fix No Internet'.
- ✨ Peningkatan UX: Menggabungkan pencarian Nama Game & AppID menjadi satu kolom cerdas di halaman Inject.
- ✨ Transisi ke Installer: Aplikasi kini di-build sebagai Full Installer yang ringan.
- 🔧 Perbaikan Bug: Memperbaiki masalah kritis sertifikat SSL (HTTPS).
- 🛡️ Perbaikan Izin Windows: Pemindahan direktori ke AppData mengatasi masalah macet total.
- 🎨 Pembaruan UI: Tombol SteamDB dipindah ke kanan atas.
- 🌐 Perbaikan Bahasa: Memastikan semua halaman baru 100% mendukung terjemahan dwibahasa secara dinamis.

v1.0.2
- Perbaikan sistem dan Rebranding nama secara keseluruhan ke GameZone.

v1.0.1
- UI Pop-up Overhaul: Tampilan Loading Live Injeksi interaktif.
- Smart Search UX: Daftar pencarian merespons klik luar otomatis.
- Alternative Injections Paths: Area Dropzone untuk file lokal.

v1.0.0
- Rilis Awal (Initial Release).
- Injeksi otomatis didukung oleh 3 Server Manifest Komunitas."""
        self.show_custom_info_dialog("Update Terbaru", "📜", text)

    def open_donasi(self):
        url = self.button_texts.get("donasi", "").strip()
        if not url:
            url = "https://saweria.co/" # Fallback default
            
        # Ensure it has protocol
        if not url.startswith("http://") and not url.startswith("https://"):
            if "." in url:
                url = "https://" + url
            else:
                # If it's just raw text, fall back to dialog popup
                self.show_custom_info_dialog("Donasi", "💖", url)
                return
        
        try:
            import webbrowser
            webbrowser.open(url)
        except Exception:
            self.show_custom_info_dialog("Donasi", "💖", url)

    def handle_alternatif(self):
        filepath = filedialog.askopenfilename(filetypes=[("Supported Files", "*.zip *.lua *.manifest")])
        if not filepath:
            return
            
        if filepath.lower().endswith('.zip'):
            try:
                with zipfile.ZipFile(filepath, 'r') as z:
                    names = z.namelist()
                    valid = any(n.lower().endswith('.lua') or n.lower().endswith('.manifest') for n in names)
                    if not valid:
                        messagebox.showerror("Ditolak", "File ZIP tidak valid!\nDi dalam file .zip harus berisi file konfigurasi .lua atau .manifest agar bisa diinjeksi.", parent=self.winfo_toplevel())
                        return
            except Exception as e:
                messagebox.showerror("Error", f"Gagal membaca file ZIP:\n{e}", parent=self.winfo_toplevel())
                return
                
        # Jika lolos pengecekan (baik .zip valid maupun .lua / .manifest langsung)
        def _run_manual():
            loading = None
            try:
                def init_dialog():
                    nonlocal loading
                    loading = LoadingDialog(self.winfo_toplevel(), mode="inject")
                self.after(0, init_dialog)
                time.sleep(0.2)
                
                from core.injector import inject_manual_files
                success, msg = inject_manual_files([filepath], os.path.basename(filepath))
                
                if loading:
                    self.after(0, lambda: loading.set_done(success, msg))
                else:
                    if success:
                        self.after(0, lambda: messagebox.showinfo("Sukses", msg, parent=self.winfo_toplevel()))
                    else:
                        self.after(0, lambda: messagebox.showerror("Error", msg, parent=self.winfo_toplevel()))
                
                if success:
                    self.after(0, self.parent.show_library)
            except Exception as e:
                if loading:
                    self.after(0, lambda: loading.set_done(False, str(e)))
                    
        threading.Thread(target=_run_manual, daemon=True).start()

    def handle_steam_restart(self):
        if not messagebox.askyesno("Restart Steam", "Yakin restart Steam sekarang?", parent=self.winfo_toplevel()):
            return
            
        from services.steam_service import restart_steam_async
        def on_err(msg):
            self.after(0, lambda: messagebox.showerror("Error", f"Failed to restart Steam: {msg}", parent=self.winfo_toplevel()))
            
        restart_steam_async(on_error_cb=on_err)

    def handle_inject(self):
        if self.selected_appid:
            appid = self.selected_appid
            name = self.entry_appid.get()
        else:
            val = self.entry_appid.get().strip()
            if not val:
                messagebox.showerror("Error", "Masukkan nama game atau appid", parent=self.winfo_toplevel())
                return
            if not val.isdigit():
                messagebox.showerror("Error", "Harap masukkan AppID berupa angka atau pilih dari pencarian!", parent=self.winfo_toplevel())
                return
            appid = val
            name = f"Game {appid}"

        self.btn_inject.configure(state="disabled", text="INJECTING...")
        self.lbl_status.configure(text=f"Menambahkan {name}...")
        
        def _run():
            loading = None
            try:
                def init_dialog():
                    nonlocal loading
                    loading = LoadingDialog(self.winfo_toplevel(), mode="inject")
                self.after(0, init_dialog)
                time.sleep(0.2)
                
                def progress_cb(msg):
                    # msg could be dict for progress, or string
                    str_msg = msg if isinstance(msg, str) else ""
                    if str_msg:
                        self.after(0, lambda: self.lbl_status.configure(text=str_msg))
                    if loading:
                        self.after(0, lambda m=msg: loading.update_status(m))
                        
                success, final_msg = download_and_inject(appid, name, status_callback=progress_cb)
                
                if loading:
                    self.after(0, lambda: loading.set_done(success, final_msg))
                else:
                    if success:
                        self.after(0, lambda: messagebox.showinfo("Sukses", final_msg, parent=self.winfo_toplevel()))
                    else:
                        self.after(0, lambda: messagebox.showerror("Error", final_msg, parent=self.winfo_toplevel()))

                if success:
                    self.after(0, self.parent.show_library)
                    
            except Exception as e:
                if loading:
                    self.after(0, lambda: loading.set_done(False, str(e)))
            finally:
                self.after(0, lambda: self.btn_inject.configure(state="normal", text="TAMBAH GAME"))
                self.after(0, lambda: self.lbl_status.configure(text=""))
                
        threading.Thread(target=_run, daemon=True).start()

    def direct_inject_game(self, appid, name):
        self.btn_inject.configure(state="disabled", text="INJECTING...")
        self.lbl_status.configure(text=f"Menambahkan {name}...")
        
        def _run():
            loading = None
            try:
                def init_dialog():
                    nonlocal loading
                    loading = LoadingDialog(self.winfo_toplevel(), mode="inject")
                self.after(0, init_dialog)
                time.sleep(0.2)
                
                def progress_cb(msg):
                    str_msg = msg if isinstance(msg, str) else ""
                    if str_msg:
                        self.after(0, lambda: self.lbl_status.configure(text=str_msg))
                    if loading:
                        self.after(0, lambda m=msg: loading.update_status(m))
                        
                success, final_msg = download_and_inject(appid, name, status_callback=progress_cb)
                
                if loading:
                    self.after(0, lambda: loading.set_done(success, final_msg))
                else:
                    if success:
                        self.after(0, lambda: messagebox.showinfo("Sukses", final_msg, parent=self.winfo_toplevel()))
                    else:
                        self.after(0, lambda: messagebox.showerror("Error", final_msg, parent=self.winfo_toplevel()))

                if success:
                    self.after(0, self.load_history)
                    self.after(0, self.parent.show_library)
                    
            except Exception as e:
                if loading:
                    self.after(0, lambda: loading.set_done(False, str(e)))
            finally:
                self.after(0, lambda: self.btn_inject.configure(state="normal", text="TAMBAH GAME"))
                self.after(0, lambda: self.lbl_status.configure(text=""))
                
        threading.Thread(target=_run, daemon=True).start()

    def filter_content(self, query):
        pass

    def update_username(self, username):
        if username and username != "?":
            self.title_lbl.configure(text=f"{username.upper()} WELCOME")
        else:
            self.title_lbl.configure(text="WELCOME")

    def load_live_trending_games(self):
        self.render_trending_skeleton()
        threading.Thread(target=self._async_fetch_trending_games, daemon=True).start()

    def render_trending_skeleton(self):
        if not hasattr(self, 'trending_scroll') or not self.trending_scroll.winfo_exists():
            return
            
        for w in self.trending_scroll.winfo_children():
            w.destroy()

        for i in range(6):
            row = i // 3
            col = i % 3

            card = customtkinter.CTkFrame(
                self.trending_scroll, fg_color="#FFFFFF", 
                border_width=2, border_color="#000000", corner_radius=0
            )
            card.grid(row=row, column=col, padx=4, pady=5, sticky="nsew")
            card.grid_columnconfigure(0, weight=1)

            # Skeleton Cover Box
            img_box = customtkinter.CTkFrame(card, fg_color="#E5E7EB", height=65, corner_radius=0, border_width=0)
            img_box.pack(fill="x", padx=4, pady=(4, 2))

            # Skeleton Title Line
            txt_box = customtkinter.CTkFrame(card, fg_color="#E5E7EB", height=12, width=90, corner_radius=0, border_width=0)
            txt_box.pack(anchor="center", pady=(4, 4))

            # Skeleton Button Box
            btn_box = customtkinter.CTkFrame(card, fg_color="#D1D5DB", height=26, corner_radius=0, border_width=2, border_color="#000000")
            btn_box.pack(fill="x", padx=4, pady=(0, 4))

    def _async_fetch_trending_games(self):
        trending = []
        try:
            url = 'https://store.steampowered.com/api/featuredcategories?cc=id&l=indonesian'
            res = requests.get(url, timeout=6)
            if res.status_code == 200:
                data = res.json()
                seen = set()
                for cat_key in ['top_sellers', 'specials', 'new_releases', 'coming_soon']:
                    items = data.get(cat_key, {}).get('items', [])
                    for item in items:
                        appid = str(item.get('id', ''))
                        name = item.get('name', '')
                        if appid and appid not in seen and not any(hw in name for hw in ['Machine', 'Deck', 'Controller', 'Hardware']):
                            seen.add(appid)
                            thumb = item.get('header_image') or item.get('large_capsule_image') or f"https://cdn.akamai.steamstatic.com/steam/apps/{appid}/header.jpg"
                            trending.append({
                                'appid': appid,
                                'title': name,
                                'thumb': thumb
                            })
        except Exception:
            pass

        if not trending:
            trending = [
                {"appid": "2358720", "title": "Black Myth: Wukong", "thumb": "https://cdn.akamai.steamstatic.com/steam/apps/2358720/header.jpg"},
                {"appid": "1245620", "title": "Elden Ring", "thumb": "https://cdn.akamai.steamstatic.com/steam/apps/1245620/header.jpg"},
                {"appid": "1091500", "title": "Cyberpunk 2077", "thumb": "https://cdn.akamai.steamstatic.com/steam/apps/1091500/header.jpg"},
                {"appid": "271590", "title": "GTA V", "thumb": "https://cdn.akamai.steamstatic.com/steam/apps/271590/header.jpg"},
                {"appid": "1174180", "title": "Red Dead Redemption 2", "thumb": "https://cdn.akamai.steamstatic.com/steam/apps/1174180/header.jpg"},
                {"appid": "990080", "title": "Hogwarts Legacy", "thumb": "https://cdn.akamai.steamstatic.com/steam/apps/990080/header.jpg"},
                {"appid": "1817070", "title": "Spider-Man Remastered", "thumb": "https://cdn.akamai.steamstatic.com/steam/apps/1817070/header.jpg"},
                {"appid": "1593500", "title": "God of War", "thumb": "https://cdn.akamai.steamstatic.com/steam/apps/1593500/header.jpg"},
                {"appid": "2050650", "title": "Resident Evil 4", "thumb": "https://cdn.akamai.steamstatic.com/steam/apps/2050650/header.jpg"},
            ]

        self.live_trending_data = trending[:15]
        if not getattr(self, 'is_destroyed', False):
            self.after(0, self.render_trending_games)

    def render_trending_games(self):
        if not hasattr(self, 'trending_scroll') or not self.trending_scroll.winfo_exists():
            return
            
        for w in self.trending_scroll.winfo_children():
            try:
                w.grid_forget()
                w.pack_forget()
                w.destroy()
            except Exception:
                pass

        games = getattr(self, 'live_trending_data', [])
        if not games:
            return

        for idx, item in enumerate(games):
            row = idx // 3
            col = idx % 3

            card = customtkinter.CTkFrame(
                self.trending_scroll, fg_color="#FFFFFF", 
                border_width=2, border_color="#000000", corner_radius=0
            )
            card.grid(row=row, column=col, padx=4, pady=5, sticky="nsew")
            card.grid_columnconfigure(0, weight=1)

            # Image Container Box
            img_frame = customtkinter.CTkFrame(card, fg_color="#EAEAEA", height=65, corner_radius=0, border_width=0)
            img_frame.pack(fill="x", padx=4, pady=(4, 2))
            img_frame.pack_propagate(False)

            img_lbl = customtkinter.CTkLabel(
                img_frame, text="🎮 Loading...", 
                font=customtkinter.CTkFont(family="Segoe UI Black", size=9),
                text_color="#888888", fg_color="transparent"
            )
            img_lbl.pack(expand=True, fill="both")

            # Load Steam Cover Header Image
            cover_url = item.get("thumb") or f"https://cdn.akamai.steamstatic.com/steam/apps/{item['appid']}/header.jpg"
            self._async_load_trending_img(cover_url, img_lbl, size=(125, 65))

            # Game Title
            raw_title = item['title']
            clean_title = raw_title[:14] + "..." if len(raw_title) > 16 else raw_title

            lbl_title = customtkinter.CTkLabel(
                card, text=clean_title, 
                font=customtkinter.CTkFont(family="Segoe UI Black", size=10), 
                text_color="#000000", justify="center", anchor="center"
            )
            lbl_title.pack(fill="x", padx=4, pady=(2, 4))

            # Inject Button
            btn_inj = customtkinter.CTkButton(
                card, text="⚡ INJECT", 
                font=customtkinter.CTkFont(family="Segoe UI Black", size=10), 
                fg_color="#FF499E", hover_color="#E63F8A", text_color="#FFFFFF", 
                border_width=2, border_color="#000000", corner_radius=0, height=26, 
                command=lambda appid=item['appid'], t=item['title']: self._quick_inject_trending(appid, t)
            )
            btn_inj.pack(fill="x", padx=4, pady=(0, 4))

    def _quick_inject_trending(self, appid, title):
        self.entry_appid.delete(0, "end")
        self.entry_appid.insert(0, str(appid))
        self.selected_appid = str(appid)
        self.handle_inject()

    def _async_load_trending_img(self, url, img_label, size=(125, 65)):
        if not url: return
        if url in self.trending_img_cache:
            try:
                img_label.configure(image=self.trending_img_cache[url], text="")
            except Exception:
                pass
            return

        def _worker():
            try:
                from io import BytesIO
                from PIL import Image, ImageOps
                headers = {"User-Agent": "Mozilla/5.0"}
                res = requests.get(url, headers=headers, timeout=5)
                if res.status_code == 200:
                    pil_img = Image.open(BytesIO(res.content))
                    pil_img = ImageOps.fit(pil_img, size, Image.Resampling.LANCZOS)
                    ctk_img = customtkinter.CTkImage(light_image=pil_img, dark_image=pil_img, size=size)
                    self.trending_img_cache[url] = ctk_img
                    if not getattr(self, 'is_destroyed', False):
                        self.after(0, lambda: self._safe_set_trending_img(img_label, ctk_img))
            except Exception:
                pass

        threading.Thread(target=_worker, daemon=True).start()

    def _safe_set_trending_img(self, img_label, ctk_img):
        try:
            if img_label.winfo_exists():
                img_label.configure(image=ctk_img, text="")
        except Exception:
            pass

    def load_history(self):
        pass

    def load_announcement(self):
        try:
            from core.skeleton import hide_skeleton
            hide_skeleton(self)
        except Exception:
            pass

    def _async_load_announcement(self):
        pass

    def open_comments_dialog(self, ann_id):
        AnnouncementCommentsDialog(self, ann_id, self.parent)

    def react_to_announcement(self, ann_id, emoji):
        from core.firebase_sync import add_announcement_reaction
        def worker():
            new_count = add_announcement_reaction(ann_id, emoji)
            if new_count is not False:
                self.load_announcement()
        threading.Thread(target=worker, daemon=True).start()

class AnnouncementCommentsDialog(customtkinter.CTkToplevel):
    def __init__(self, parent, ann_id, main_app, **kwargs):
        super().__init__(parent, **kwargs)
        self.title("Komentar Pengumuman")
        self.ann_id = ann_id
        self.main_app = main_app
        
        # Geometry and centering
        self.update_idletasks()
        parent_top = parent.winfo_toplevel()
        w = 600
        h = 500
        dlg_x = parent_top.winfo_x() + (parent_top.winfo_width() // 2) - (w // 2)
        dlg_y = parent_top.winfo_y() + (parent_top.winfo_height() // 2) - (h // 2)
        self.geometry(f"{w}x{h}+{dlg_x}+{dlg_y}")
        self.resizable(False, False)
        self.transient(parent_top)
        self.grab_set()
        
        self.configure(fg_color="#F4EFEB") # Cream background
        
        # Grid layout
        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(0, weight=1) # Scrollable area
        self.grid_rowconfigure(1, weight=0) # Entry area
        
        # Scrollable Frame for comments
        self.comments_scroll = customtkinter.CTkScrollableFrame(self, fg_color="#FFFFFF", border_width=3, border_color="#000000", corner_radius=0)
        self.comments_scroll.grid(row=0, column=0, padx=20, pady=(20, 10), sticky="nsew")
        
        # Input Frame
        input_frame = customtkinter.CTkFrame(self, fg_color="transparent")
        input_frame.grid(row=1, column=0, padx=20, pady=(0, 20), sticky="ew")
        input_frame.grid_columnconfigure(0, weight=1)
        
        self.entry_comment = customtkinter.CTkEntry(input_frame, placeholder_text="Tulis komentar Anda di sini...", fg_color="#FFFFFF", text_color="#000000", border_width=3, border_color="#000000", corner_radius=0, height=40, font=("Segoe UI", 12, "bold"))
        self.entry_comment.grid(row=0, column=0, sticky="ew", padx=(0, 10))
        self.entry_comment.bind("<Return>", lambda event: self.handle_send())
        
        self.btn_send = customtkinter.CTkButton(input_frame, text="KIRIM 🚀", font=customtkinter.CTkFont(family="Segoe UI Black", size=12), text_color="#000000", fg_color="#5D5FEF", hover_color="#4B4CD9", border_width=3, border_color="#000000", corner_radius=0, height=40, width=100, command=self.handle_send)
        self.btn_send.grid(row=0, column=1, sticky="e")
        
        # Default avatar placeholder
        self.default_avatar = None
        try:
            default_av_path = self.main_app.resource_path(os.path.join("assets", "avatars", "avatar1.png"))
            if os.path.exists(default_av_path):
                img = Image.open(default_av_path).resize((32, 32)).convert("RGBA")
                from PIL import ImageDraw
                mask = Image.new('L', (32, 32), 0)
                draw = ImageDraw.Draw(mask)
                draw.ellipse((0, 0, 32, 32), fill=255)
                result = Image.new('RGBA', (32, 32), (0,0,0,0))
                result.paste(img, (0,0), mask=mask)
                self.default_avatar = customtkinter.CTkImage(light_image=result, size=(32, 32))
        except:
            pass
            
        self.polling_active = True
        self.last_comment_ids = set()
        
        # Initial load and background polling
        self.refresh_comments()
        self.poll_thread = threading.Thread(target=self._polling_loop, daemon=True)
        self.poll_thread.start()
        
    def _polling_loop(self):
        while self.polling_active:
            try:
                if self.winfo_exists():
                    self.refresh_comments()
            except Exception:
                pass
            time.sleep(4)
            
    def refresh_comments(self):
        try:
            if not self.winfo_exists():
                return
        except Exception:
            return
            
        from core.firebase_sync import fetch_announcement_comments
        comments_data = fetch_announcement_comments(self.ann_id)
        
        try:
            if not self.winfo_exists():
                return
        except Exception:
            return
            
        if not comments_data:
            try:
                # Clear old comments and show empty label
                for w in self.comments_scroll.winfo_children():
                    try:
                        if w.winfo_exists():
                            w.destroy()
                    except Exception:
                        pass
                lbl_empty = customtkinter.CTkLabel(self.comments_scroll, text="Belum ada komentar. Jadilah yang pertama berkomentar!", font=customtkinter.CTkFont(family="Segoe UI", size=12, weight="bold"), text_color="#777777")
                lbl_empty.pack(pady=30)
                self.last_comment_ids.clear()
            except Exception:
                pass
            return
            
        # Parse and sort
        try:
            sorted_comments = []
            for k, v in comments_data.items():
                v["id"] = k
                sorted_comments.append(v)
            sorted_comments.sort(key=lambda x: x.get("timestamp", ""))
            
            # Check if changed
            current_ids = {c["id"] for c in sorted_comments}
            if current_ids == self.last_comment_ids:
                return
                
            self.last_comment_ids = current_ids
            
            # Render UI on main thread safely
            def safe_update():
                try:
                    if self.winfo_exists() and self.comments_scroll.winfo_exists():
                        self._update_ui(sorted_comments)
                except Exception:
                    pass
            self.after(0, safe_update)
        except Exception:
            pass
        
    def _update_ui(self, comments):
        try:
            if not self.winfo_exists() or not self.comments_scroll.winfo_exists():
                return
        except Exception:
            return
            
        try:
            for w in self.comments_scroll.winfo_children():
                try:
                    if w.winfo_exists():
                        w.pack_forget()
                        w.destroy()
                except Exception:
                    pass
        except Exception:
            pass
            
        for c in comments:
            try:
                if not self.winfo_exists() or not self.comments_scroll.winfo_exists():
                    return
                    
                card = customtkinter.CTkFrame(self.comments_scroll, fg_color="#F4EFEB", border_width=2, border_color="#000000", corner_radius=0)
                card.pack(fill="x", padx=5, pady=4)
                
                # Left: Avatar
                lbl_avatar = customtkinter.CTkLabel(card, text="")
                lbl_avatar.pack(side="left", padx=10, pady=5, anchor="n")
                if self.default_avatar:
                    lbl_avatar.configure(image=self.default_avatar)
                    lbl_avatar.image = self.default_avatar
                    
                # Right: Text
                txt_frame = customtkinter.CTkFrame(card, fg_color="transparent")
                txt_frame.pack(side="left", fill="both", expand=True, padx=(0, 10), pady=5)
                
                header = customtkinter.CTkFrame(txt_frame, fg_color="transparent")
                header.pack(fill="x")
                
                display_name = f"@{c.get('username', 'User')}"
                nick = c.get("nickname")
                if nick and nick != c.get('username'):
                    display_name = f"{nick} (@{c.get('username')})"
                    
                user_lbl = customtkinter.CTkLabel(header, text=display_name, font=customtkinter.CTkFont(family="Segoe UI Black", size=11), text_color="#000000")
                user_lbl.pack(side="left")
                
                ts = c.get("timestamp", "")
                time_str = ts[11:16] if len(ts) >= 16 else ""
                time_lbl = customtkinter.CTkLabel(header, text=time_str, font=customtkinter.CTkFont(family="Segoe UI", size=9, weight="bold"), text_color="#666666")
                time_lbl.pack(side="right")
                
                comment_lbl = customtkinter.CTkLabel(txt_frame, text=c.get("comment", ""), font=customtkinter.CTkFont(family="Segoe UI", size=12, weight="bold"), text_color="#333333", justify="left", anchor="w")
                comment_lbl.pack(fill="x", pady=(2, 0))
                
                txt_frame.bind("<Configure>", lambda event, lbl=comment_lbl: self._safe_wrap_label(lbl, event.width))
            except Exception:
                pass
                
        try:
            if self.winfo_exists() and self.comments_scroll.winfo_exists():
                self.comments_scroll.update_idletasks()
                self.comments_scroll._parent_canvas.yview_moveto(1.0)
        except Exception:
            pass

    def _safe_wrap_label(self, lbl, width):
        try:
            if lbl.winfo_exists():
                lbl.configure(wraplength=max(50, width - 10))
        except Exception:
            pass
        
    def handle_send(self):
        try:
            if not self.winfo_exists():
                return
        except Exception:
            return
            
        comment_text = self.entry_comment.get().strip()
        if not comment_text:
            return
            
        from core import discord_auth, profile_manager
        username = discord_auth.get_cached_username()
        if not username or username in ("User", "?"):
            username = "AnonUser"
        nickname = username
        try:
            cached_profile = profile_manager.load_profile()
            if cached_profile and cached_profile.get("nickname"):
                nickname = cached_profile["nickname"]
        except:
            pass
            
        avatar_url = discord_auth.get_cached_avatar_url()
        
        try:
            self.entry_comment.delete(0, "end")
            self.btn_send.configure(state="disabled")
        except Exception:
            pass
        
        def worker():
            from core.firebase_sync import submit_announcement_comment
            success = submit_announcement_comment(self.ann_id, username, nickname, comment_text, avatar_url)
            
            def after_send():
                try:
                    if self.winfo_exists():
                        self.btn_send.configure(state="normal")
                        if success:
                            self.refresh_comments()
                        else:
                            messagebox.showerror("Gagal", "Gagal mengirim komentar.", parent=self)
                except Exception:
                    pass
            try:
                if self.winfo_exists():
                    self.after(0, after_send)
            except Exception:
                pass
                
        threading.Thread(target=worker, daemon=True).start()
        
    def destroy(self):
        self.polling_active = False
        try:
            super().destroy()
        except Exception:
            pass
