import customtkinter
from core.firebase_sync import session as requests
import threading
import json
import tkinter.messagebox as messagebox

class InfoCRUDTab(customtkinter.CTkFrame):
    def __init__(self, parent, app, **kwargs):
        super().__init__(parent, fg_color="transparent", **kwargs)
        self.app = app
        self._last_data_hash = None
        
        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(1, weight=1)

        hdr = customtkinter.CTkFrame(self, fg_color="#FFFFFF", border_width=3, border_color="#000000", corner_radius=0)
        hdr.grid(row=0, column=0, sticky="ew", pady=(0, 15))
        customtkinter.CTkLabel(hdr, text="📝 APP INFO & GUIDES CRUD", font=customtkinter.CTkFont(family="Segoe UI Black", size=24), text_color="#000000").pack(padx=20, pady=15, side="left")

        main_box = customtkinter.CTkFrame(self, fg_color="#FFFFFF", border_width=3, border_color="#000000", corner_radius=0)
        main_box.grid(row=1, column=0, sticky="nsew")
        main_box.grid_columnconfigure(0, weight=1)
        main_box.grid_rowconfigure(2, weight=1)

        select_frame = customtkinter.CTkFrame(main_box, fg_color="transparent")
        select_frame.grid(row=0, column=0, padx=30, pady=(20, 10), sticky="ew")
        
        lbl_select = customtkinter.CTkLabel(select_frame, text="Pilih Tombol Klien yang Ingin Di-edit:", font=customtkinter.CTkFont(family="Segoe UI Black", size=13), text_color="#000000")
        lbl_select.pack(side="left", padx=(0, 10))

        self.info_type_var = customtkinter.StringVar(value="panduan")
        self.opt_info_type = customtkinter.CTkOptionMenu(
            select_frame, 
            values=["panduan", "pembaruan", "donasi"], 
            variable=self.info_type_var, 
            width=200, 
            height=35, 
            fg_color="#E0E0E0", 
            button_color="#D0D0D0", 
            button_hover_color="#C0C0C0", 
            text_color="#000000", 
            dropdown_fg_color="#FFFFFF", 
            dropdown_text_color="#000000", 
            font=customtkinter.CTkFont(family="Segoe UI", size=12, weight="bold"), 
            corner_radius=0,
            command=self.on_info_type_change
        )
        self.opt_info_type.pack(side="left")

        lbl_content = customtkinter.CTkLabel(main_box, text="Isi Konten (Format Teks Bebas / Markdown):", font=customtkinter.CTkFont(family="Segoe UI Black", size=13), text_color="#000000")
        lbl_content.grid(row=1, column=0, padx=30, pady=(5, 5), sticky="w")

        self.txt_info_content = customtkinter.CTkTextbox(main_box, fg_color="#FFFFFF", text_color="#000000", border_width=3, border_color="#000000", corner_radius=0, font=("Segoe UI", 13))
        self.txt_info_content.grid(row=2, column=0, padx=30, pady=(0, 20), sticky="nsew")

        self.info_cache = {"panduan": "", "pembaruan": "", "donasi": ""}

        btn_save = customtkinter.CTkButton(main_box, text="💾 SIMPAN KONTEN INFO", fg_color="#00D084", hover_color="#00B875", text_color="#000000", font=customtkinter.CTkFont(family="Segoe UI Black", size=14), border_width=3, border_color="#000000", corner_radius=0, height=45, command=self.save_info_crud)
        btn_save.grid(row=3, column=0, padx=30, pady=(0, 25), sticky="ew")

    def refresh(self):
        self.refresh_info_crud()

    def refresh_info_crud(self):
        if self._last_data_hash is None:
            self.txt_info_content.configure(state="normal")
            self.txt_info_content.delete("1.0", "end")
            self.txt_info_content.insert("1.0", "Memuat data dari Firebase...")
            self.txt_info_content.configure(state="disabled")
            self.opt_info_type.configure(state="disabled")
        
        threading.Thread(target=self._async_load_info_crud, daemon=True).start()

    def _async_load_info_crud(self):
        try:
            url = f"{self.app.db_url}/buttons.json"
            res = requests.get(url, timeout=10)
            data = {}
            if res.status_code == 200:
                res_data = res.json()
                if res_data:
                    data = res_data
            
            data_hash = hash(json.dumps(data, sort_keys=True, default=str))
            if data_hash == self._last_data_hash:
                self.after(0, lambda: self.opt_info_type.configure(state="normal"))
                self.after(0, lambda: self.txt_info_content.configure(state="normal"))
                try:
                    from core.skeleton import hide_skeleton
                    self.after(0, lambda: hide_skeleton(self))
                except Exception:
                    pass
                return
            self._last_data_hash = data_hash
            
            self.info_cache["panduan"] = data.get("panduan", "1. Cari game atau masukkan AppID.\n2. Klik Tambah Game.\n3. Tunggu hingga proses selesai.\n4. Restart Steam.")
            self.info_cache["pembaruan"] = data.get("pembaruan", """📜 RIWAYAT PEMBARUAN (CHANGELOG):

✨ [v2.0.7] (Terbaru):
- 📌 System Tray & Single Instance: Minimize ke Tray saat klik 'X' & cegah aplikasi berjalan ganda.
- 🛒 Fix Purchase Button: Perbaiki tombol Beli (Purchase <-> Play) selang-seling di Sidebar & Settings.
- ⚡ Smart NetFix Update: Perbaikan unduhan update game otomatis tanpa menimpa buildid prematur.
- 🧹 Auto Steam License Cache Cleaner: Pembersihan cache appinfo.vdf di latar belakang secara otomatis.

✨ [v2.0.6]:
- ⚡ Mesin OTA Hotfix Patch: Dukungan pembaruan otomatis tanpa perlu unduh ulang installer .exe untuk perbaikan bug kecil.
- 🔄 Sistem Live Update Ganda: Pilihan rilis Major (.exe) dan rilis OTA Hotfix Kilat di Panel Admin.

✨ [v2.0.5]:
- ☁️ Save Cloud Redirect & Backup Engine: Cadangkan & pulihkan save game lokal agar progres tetap aman.
- 🔒 Manifest Lock & Anti Auto-Update: Kunci file .acf (Steam Pinning) agar lisensi game injected tidak tertimpa.
- 🧹 Pembersih Sampah Steam: Pindai & hapus file .lua / .manifest yatim bekas game yang di-uninstall 1-klik.
- 🚀 Graceful Steam Restart: Restart Steam secara bersih (-shutdown 15s poll) tanpa bug 'Purchase'.
- 💀 Floating Overlay Search Dropdown: Pencarian game interaktif dengan skeleton loader animasi.

✨ [v2.0.4]:
- 🚀 Steam Graceful Restart Fix: Penyempurnaan penutupan bersih steamwebhelper.exe untuk mencegah bug status 'Purchase' saat inject.
- 🔗 Dynamic Steam Registry Path: Deteksi lokasi instalasi Steam secara dinamis dari Windows Registry.
- 🎨 Neo-Brutalism UI: Navigasi cepat 0ms dengan optimasi memori.

✨ [v2.0.3]:
- 🚀 Recommended Games: Menambahkan widget 12 game rekomendasi populer di kolom kiri halaman utama dengan loading gambar CDN Steam asinkron & instan (0ms).
- 🛠️ Bug Fixes: Menyelesaikan masalah overlapping teks judul game yang panjang pada resolusi kecil, serta memperbaiki warning penskalaan HighDPI (CTkImage).
- 🎨 Neo-Brutalism UI: Navigasi cepat 0ms dengan optimasi penggunaan memori.

✨ [v2.0.2]:
- Menambahkan 5 API manifest komunitas baru (Morrenus, Ryuu, TwentyTwo Cloud, Sushi, SkyApi).
- Otomatisasi pengisian morrenus_key/moapikey secara dinamis dari Firebase database & config lokal.
- Menambahkan tombol sinkronisasi otomatis 5 API baru tersebut di menu pengaturan admin.
- Mempercepat pencarian manifest secara paralel (Fast Search) menggunakan ThreadPoolExecutor.

✨ [v2.0.1]:
- Transisi antar halaman menjadi sangat lancar dan ringan bebas lag.
- Pembatasan request database Firebase untuk menghemat kuota internet dan mempercepat loading.
- Memperbaiki pencarian game di tab Inject agar lebih stabil dengan jeda ketik 350ms.
- Mengurangi error Steam 429 dengan menyimpan riwayat pencarian game di memori cache.
- Visual loading skeleton loader kini lebih stabil dan tidak berantakan saat dimuat.
- Mengurangi beban memori dengan memperbarui tombol reaksi chat hanya saat diperlukan.

✨ [v2.0.0]:
- 🎨 Perombakan UI Lengkap: Pemolesan seluruh tampilan ke estetika Neo Brutalism 60 FPS, membuang animasi berat, dan memberikan layout yang lebih ringkas.
- 🚀 Transisi Instan: Navigasi perpindahan antar halaman kini instan dan bebas lag (0ms delay).
- 🐛 Fix Bug Layout: Perbaikan border bleed dan button layout shift pada sidebar menu.

✨ [v1.0.7]:
- 🛡️ Pembaruan Wajib: Notifikasi update kini muncul instan dan bersifat wajib.
- Pengguna harus mengklik OK dan tidak bisa diabaikan demi keamanan & kestabilan versi terbaru.

✨ [v1.0.6]:
- 🛡️ Update Senyap (Auto-Restart): Sekarang aplikasi langsung tertutup saat klik update, berjalan senyap, dan otomatis menyala kembali setelah selesai (Bypass WinError UAC).
- 🎮 Steam Graceful Restart: Menggunakan protokol Steam asli (-shutdown) untuk mencegah game yang baru diinjeksi tertelan oleh Crash Recovery Steam.
- 🌐 NetFix Multi-Drive: Pengecekan game yang sedang didownload kini menjangkau ke semua Disk/Steam Library (D:, E:, dll).
- 🥷 Animasi CMD: Jendela hitam CMD yang berkedip-kedip saat memantau status Steam telah dihilangkan.

✨ [v1.0.5]:
- 🎮 Username Steam (Auto-Detect): Aplikasi kini otomatis mengenali username Steam lokal secara aman di pojok kiri bawah.
- 🎨 UI Posisi Tombol: Tombol Restart Steam dan SteamDB disempurnakan.
- 🧹 Cleanup: Penghapusan total artefak tema gelap karena mengganggu estetik.

✨ [v1.0.4]:
- 🔧 Perbaikan Bug (Hotfix): Mencegah error injeksi ketika pengguna mengeklik 'Tambah Game' tanpa mengisi kolom pencarian.

v1.0.3
- ✨ Fitur Baru: Menambahkan menu khusus 'Fix No Internet'.
- ✨ Peningkatan UX: Menggabungkan pencarian Nama Game & AppID menjadi satu kolom cerdas di halaman Inject.
- ✨ Transisi ke Installer: Aplikasi kini di-build sebagai Full Installer yang ringan.
- 🔧 Perbaikan Bug: Memperbaiki masalah kritis sertifikat SSL (HTTPS).
- 🛡️ Perbaikan Izin Windows: Pemindahan direktori ke AppData mengatasi masalah macet total.
- 🎨 Pembaruan UI: Tombol SteamDB dipindah ke kanan atas.
- 🌐 Perbaikan Bahasa: Memastikan semua halaman baru 100% mendukung terjemahan dwibahasa secara dinamis.

v1.0.2
- Perbaikan sistem dan Rebranding nama secara keseluruhan ke GameZone.

v1.0.1
- UI Pop-up Overhaul: Tampilan Loading Live Injeksi interaktif.
- Smart Search UX: Daftar pencarian merespons klik luar otomatis.
- Alternative Injections Paths: Area Dropzone untuk file lokal.

v1.0.0
- Rilis Awal (Initial Release).
- Injeksi otomatis didukung oleh 3 Server Manifest Komunitas.""")
            self.info_cache["donasi"] = data.get("donasi", "https://saweria.co/")
            
            self.after(0, self._update_info_crud_ui)
        except Exception as e:
            if self._last_data_hash is None:
                self._last_data_hash = "failed"
                self.after(0, lambda: messagebox.showerror("Error", f"Gagal memuat info: {e}", parent=self.app))
            try:
                from core.skeleton import hide_skeleton
                self.after(0, lambda: hide_skeleton(self))
            except Exception:
                pass

    def _update_info_crud_ui(self):
        self.opt_info_type.configure(state="normal")
        self.txt_info_content.configure(state="normal")
        self.txt_info_content.delete("1.0", "end")
        
        selected = self.info_type_var.get()
        content = self.info_cache.get(selected, "")
        self.txt_info_content.insert("1.0", content)

        try:
            from core.skeleton import hide_skeleton
            hide_skeleton(self)
        except Exception:
            pass

    def on_info_type_change(self, value):
        self._update_info_crud_ui()

    def save_info_crud(self):
        selected = self.info_type_var.get()
        content = self.txt_info_content.get("1.0", "end-1c").strip()
        self.info_cache[selected] = content

        def _async_save():
            try:
                url = f"{self.app.db_url}/buttons.json"
                payload = {
                    "panduan": self.info_cache["panduan"],
                    "pembaruan": self.info_cache["pembaruan"],
                    "donasi": self.info_cache["donasi"]
                }
                res = requests.put(url, json=payload, timeout=10)
                if res.status_code == 200:
                    self._last_data_hash = None
                    self.after(0, lambda: messagebox.showinfo("Sukses", f"Konten '{selected.upper()}' berhasil diperbarui di Firebase!", parent=self.app))
                else:
                    self.after(0, lambda: messagebox.showerror("Gagal", f"Gagal menyimpan ke Firebase. Status: {res.status_code}", parent=self.app))
            except Exception as e:
                self.after(0, lambda: messagebox.showerror("Error", f"Koneksi gagal: {e}", parent=self.app))

        threading.Thread(target=_async_save, daemon=True).start()
