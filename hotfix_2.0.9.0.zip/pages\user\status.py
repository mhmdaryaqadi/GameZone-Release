import customtkinter
import threading
import time
import datetime
import requests
import os
from PIL import Image, ImageDraw
from io import BytesIO
from core.firebase_sync import fetch_users_status


class StatusPage(customtkinter.CTkFrame):
    def __init__(self, parent, main_app, **kwargs):
        super().__init__(parent, fg_color="#FFFFFF", **kwargs)
        self.parent = main_app

        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(1, weight=1)

        # Title bar
        top_bar = customtkinter.CTkFrame(self, fg_color="transparent")
        top_bar.grid(row=0, column=0, pady=(0, 4), sticky="ew")

        title = customtkinter.CTkLabel(
            top_bar, text="🟢 Status Pengguna",
            font=customtkinter.CTkFont(family="Segoe UI Black", size=18),
            text_color="#000000"
        )
        title.pack(side="left")

        # Online count badge
        self.online_badge = customtkinter.CTkLabel(
            top_bar, text="0 online",
            font=customtkinter.CTkFont(family="Segoe UI Black", size=11),
            text_color="#FFFFFF", fg_color="#00D084",
            corner_radius=0, padx=10, pady=3
        )
        self.online_badge.pack(side="left", padx=(10, 0))

        # Refresh button
        self.btn_refresh = customtkinter.CTkButton(
            top_bar, text="🔄", width=42, height=32,
            font=customtkinter.CTkFont(family="Segoe UI Black", size=14),
            fg_color="#FFD800", hover_color="#E6C300",
            text_color="#000000", corner_radius=0,
            border_width=3, border_color="#000000",
            command=self.manual_refresh
        )
        self.btn_refresh.pack(side="right")

        # User list scrollable
        self.user_scroll = customtkinter.CTkScrollableFrame(
            self, fg_color="#FFFFFF", border_width=3,
            border_color="#000000", corner_radius=0
        )
        self.user_scroll.grid(row=1, column=0, sticky="nsew")
        self.user_scroll.grid_columnconfigure(0, weight=1)

        # State
        self.avatar_images = {}
        self.downloading_avatars = set()
        self.polling_active = True
        self.loading = False
        self._current_avatar_labels = {}
        self.user_cards = {}  # Cache user card frames keyed by clean_username

        # Default avatar
        self.default_ctk_img = None
        try:
            if hasattr(self.parent, 'resource_path'):
                default_av_path = self.parent.resource_path(os.path.join("assets", "avatars", "avatar1.png"))
            else:
                default_av_path = os.path.join("assets", "avatars", "avatar1.png")

            if os.path.exists(default_av_path):
                img = Image.open(default_av_path).resize((36, 36)).convert("RGBA")
                mask = Image.new('L', (36, 36), 0)
                draw = ImageDraw.Draw(mask)
                draw.ellipse((0, 0, 36, 36), fill=255)

                result = Image.new('RGBA', (36, 36), (0, 0, 0, 0))
                result.paste(img, (0, 0), mask=mask)
                self.default_ctk_img = customtkinter.CTkImage(light_image=result, size=(36, 36))
        except Exception:
            pass

        # Polling thread
        self.poll_thread = threading.Thread(target=self._status_polling_loop, daemon=True)
        self.poll_thread.start()

    def filter_content(self, query):
        self.search_query = query
        if hasattr(self, "_last_users_data") and self._last_users_data:
            self._update_status_ui(self._last_users_data)

    def manual_refresh(self):
        self.btn_refresh.configure(state="disabled")
        threading.Thread(target=self._async_load_status, args=(True,), daemon=True).start()

    def _status_polling_loop(self):
        while self.polling_active:
            try:
                if self.winfo_exists() and self.winfo_ismapped():
                    self._async_load_status()
            except Exception:
                pass
            time.sleep(10)

    def _async_load_status(self, force=False):
        if self.loading and not force:
            return
        self.loading = True

        try:
            users_data = fetch_users_status()
        except Exception:
            users_data = {}

        self._last_users_data = users_data
        self.loading = False
        self.after(0, lambda: self._update_status_ui(users_data))

    def _get_time_diff_text(self, last_active_str):
        """Hitung perbedaan waktu dan return teks status"""
        try:
            last_active = datetime.datetime.strptime(last_active_str, "%Y-%m-%d %H:%M:%S")
            now = datetime.datetime.now()
            diff = now - last_active

            total_seconds = int(diff.total_seconds())
            if total_seconds < 0:
                total_seconds = 0

            if total_seconds < 300:  # < 5 menit = aktif
                return "online", "Aktif sekarang"
            elif total_seconds < 3600:  # < 1 jam
                minutes = total_seconds // 60
                return "away", f"Terakhir aktif {minutes} menit lalu"
            elif total_seconds < 86400:  # < 1 hari
                hours = total_seconds // 3600
                return "offline", f"Terakhir aktif {hours} jam lalu"
            else:
                days = total_seconds // 86400
                return "offline", f"Terakhir aktif {days} hari lalu"
        except Exception:
            return "offline", "Status tidak diketahui"

    def _update_status_ui(self, users_data):
        # Re-enable refresh button
        try:
            self.btn_refresh.configure(state="normal")
        except Exception:
            pass

        if not users_data:
            for card in self.user_cards.values():
                card.destroy()
            self.user_cards.clear()
            self._current_avatar_labels.clear()

            lbl_empty = customtkinter.CTkLabel(
                self.user_scroll,
                text="Belum ada pengguna yang terdaftar.",
                font=customtkinter.CTkFont(family="Segoe UI", size=14, weight="bold"),
                text_color="#999999"
            )
            lbl_empty.grid(row=0, column=0, pady=50)
            self.online_badge.configure(text="0 online")
            try:
                from core.skeleton import hide_skeleton
                hide_skeleton(self)
            except Exception:
                pass
            return

        # Destroy empty label if present
        for w in self.user_scroll.winfo_children():
            if isinstance(w, customtkinter.CTkLabel) and w.cget("text") == "Belum ada pengguna yang terdaftar.":
                w.destroy()

        # Parse and sort users: online first, then by last_active
        user_list = []
        for key, val in users_data.items():
            if isinstance(val, dict):
                val["_key"] = key
                user_list.append(val)

        # Determine status for each user
        for user in user_list:
            la = user.get("last_active", "")
            status_type, status_text = self._get_time_diff_text(la)
            user["_status_type"] = status_type
            user["_status_text"] = status_text

        # Sort: online > away > offline, then by last_active desc
        status_order = {"online": 0, "away": 1, "offline": 2}
        online_users = [u for u in user_list if u["_status_type"] == "online"]
        other_users = [u for u in user_list if u["_status_type"] != "online"]
        other_users.sort(key=lambda u: u.get("last_active", ""), reverse=True)
        user_list = online_users + other_users

        # Filter based on search query
        query = getattr(self, "search_query", "").strip().lower()
        if query:
            filtered_list = []
            for u in user_list:
                nick = u.get("nickname", "").lower()
                dc = u.get("discord_username", "").lower()
                role = u.get("role", "").lower()
                if query in nick or query in dc or query in role:
                    filtered_list.append(u)
            user_list = filtered_list

        online_count = len(online_users)
        self.online_badge.configure(text=f"{online_count} online")

        # Update or create cards
        active_keys = set()
        for idx, user in enumerate(user_list):
            key = user["_key"]
            active_keys.add(key)
            self._update_or_create_user_card(idx, user)

        # Remove cards for users that no longer exist
        for key in list(self.user_cards.keys()):
            if key not in active_keys:
                self.user_cards[key].destroy()
                del self.user_cards[key]
                
        try:
            from core.skeleton import hide_skeleton
            hide_skeleton(self)
        except Exception:
            pass

    def _update_or_create_user_card(self, idx, user):
        key = user["_key"]
        status_type = user.get("_status_type", "offline")
        status_text = user.get("_status_text", "")
        nickname = user.get("nickname", "Unknown")
        dc_username = user.get("discord_username", "")
        avatar_url = user.get("avatar_url", "")
        
        # Role Badge styling
        role = user.get("role", "basic").upper()
        if role == "PREMIUM":
            role_bg = "#A388EE"
            role_fg = "#FFFFFF"
        elif role == "BLOCK":
            role_bg = "#FF499E"
            role_fg = "#FFFFFF"
        else:
            role_bg = "#E0E0E0"
            role_fg = "#000000"

        # Card colors based on status
        if status_type == "online":
            card_bg = "#E8FFF0"
            indicator_color = "#00D084"
            indicator_text = "🟢"
        elif status_type == "away":
            card_bg = "#FFF8E0"
            indicator_color = "#FFB800"
            indicator_text = "🟡"
        else:
            card_bg = "#F4EFEB"
            indicator_color = "#999999"
            indicator_text = "🔴"

        if key in self.user_cards:
            card = self.user_cards[key]
            card.configure(fg_color=card_bg)
            card.grid(row=idx, column=0, sticky="ew", padx=10, pady=4)
            card.lbl_nick.configure(text=nickname)
            if hasattr(card, "lbl_dc"):
                card.lbl_dc.configure(text=f"@{dc_username}" if dc_username else "")
            if hasattr(card, "lbl_role_badge"):
                card.lbl_role_badge.configure(text=f" {role} ", text_color=role_fg, fg_color=role_bg)
            card.lbl_status.configure(text=f"{indicator_text} {status_text}", text_color=indicator_color)

            if avatar_url and getattr(card, "current_avatar_url", "") != avatar_url:
                card.current_avatar_url = avatar_url
                ctk_avatar = self.default_ctk_img
                if avatar_url in self.avatar_images:
                    ctk_avatar = self.avatar_images[avatar_url]
                else:
                    if avatar_url not in self._current_avatar_labels:
                        self._current_avatar_labels[avatar_url] = []
                    self._current_avatar_labels[avatar_url].append(card.lbl_avatar)
                    self._download_avatar(avatar_url)

                if ctk_avatar:
                    card.lbl_avatar.configure(image=ctk_avatar)
                    card.lbl_avatar.image = ctk_avatar
        else:
            card = customtkinter.CTkFrame(
                self.user_scroll, fg_color=card_bg,
                border_width=2, border_color="#000000", corner_radius=0
            )
            card.grid(row=idx, column=0, sticky="ew", padx=10, pady=4)
            card.grid_columnconfigure(1, weight=1)
            card.current_avatar_url = avatar_url

            card.lbl_avatar = customtkinter.CTkLabel(card, text="", width=36, height=36)
            card.lbl_avatar.grid(row=0, column=0, rowspan=2, padx=(12, 8), pady=10)

            ctk_avatar = self.default_ctk_img
            if avatar_url:
                if avatar_url in self.avatar_images:
                    ctk_avatar = self.avatar_images[avatar_url]
                else:
                    if avatar_url not in self._current_avatar_labels:
                        self._current_avatar_labels[avatar_url] = []
                    self._current_avatar_labels[avatar_url].append(card.lbl_avatar)
                    self._download_avatar(avatar_url)

            if ctk_avatar:
                card.lbl_avatar.configure(image=ctk_avatar)
                card.lbl_avatar.image = ctk_avatar

            name_frame = customtkinter.CTkFrame(card, fg_color="transparent")
            name_frame.grid(row=0, column=1, sticky="ew", padx=(0, 10), pady=(10, 0))

            card.lbl_nick = customtkinter.CTkLabel(
                name_frame, text=nickname,
                font=customtkinter.CTkFont(family="Segoe UI Black", size=14),
                text_color="#000000"
            )
            card.lbl_nick.pack(side="left")

            if dc_username:
                card.lbl_dc = customtkinter.CTkLabel(
                    name_frame, text=f"@{dc_username}",
                    font=customtkinter.CTkFont(family="Segoe UI", size=11, weight="bold"),
                    text_color="#666666"
                )
                card.lbl_dc.pack(side="left", padx=(8, 0))

            card.lbl_role_badge = customtkinter.CTkLabel(
                name_frame, text=f" {role} ",
                font=customtkinter.CTkFont(family="Segoe UI Black", size=9),
                text_color=role_fg, fg_color=role_bg,
                corner_radius=4
            )
            card.lbl_role_badge.pack(side="left", padx=(8, 0))

            status_frame = customtkinter.CTkFrame(card, fg_color="transparent")
            status_frame.grid(row=1, column=1, sticky="ew", padx=(0, 10), pady=(0, 10))

            card.lbl_status = customtkinter.CTkLabel(
                status_frame,
                text=f"{indicator_text} {status_text}",
                font=customtkinter.CTkFont(family="Segoe UI", size=12, weight="bold"),
                text_color=indicator_color
            )
            card.lbl_status.pack(side="left")

            self.user_cards[key] = card

    def _download_avatar(self, avatar_url):
        if not avatar_url:
            return
        if avatar_url in self.downloading_avatars:
            return
        if avatar_url in self.avatar_images:
            return

        import hashlib
        # Generate a unique hash for the avatar URL
        url_hash = hashlib.md5(avatar_url.encode('utf-8')).hexdigest()
        cache_dir = os.path.join(os.getcwd(), "cache", "img")
        os.makedirs(cache_dir, exist_ok=True)
        local_path = os.path.join(cache_dir, f"av_{url_hash}.png")

        # 1. Try to load from disk cache first (instantly, no threads or requests needed!)
        if os.path.exists(local_path):
            try:
                img = Image.open(local_path).resize((36, 36)).convert("RGBA")
                mask = Image.new('L', (36, 36), 0)
                draw = ImageDraw.Draw(mask)
                draw.ellipse((0, 0, 36, 36), fill=255)

                result = Image.new('RGBA', (36, 36), (0, 0, 0, 0))
                result.paste(img, (0, 0), mask=mask)

                ctk_img = customtkinter.CTkImage(light_image=result, size=(36, 36))
                self.avatar_images[avatar_url] = ctk_img
                self._apply_avatar(avatar_url, ctk_img)
                return
            except Exception:
                # If disk cache is corrupted, delete it
                try: os.remove(local_path)
                except Exception: pass

        # 2. If not in disk cache, download it in a background thread
        self.downloading_avatars.add(avatar_url)

        def worker():
            try:
                headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"}
                res = requests.get(avatar_url, headers=headers, timeout=5)
                if res.status_code == 200:
                    # Save raw downloaded bytes to disk cache
                    with open(local_path, "wb") as f:
                        f.write(res.content)

                    img = Image.open(local_path).resize((36, 36)).convert("RGBA")
                    mask = Image.new('L', (36, 36), 0)
                    draw = ImageDraw.Draw(mask)
                    draw.ellipse((0, 0, 36, 36), fill=255)

                    result = Image.new('RGBA', (36, 36), (0, 0, 0, 0))
                    result.paste(img, (0, 0), mask=mask)

                    ctk_img = customtkinter.CTkImage(light_image=result, size=(36, 36))
                    self.avatar_images[avatar_url] = ctk_img

                    self.after(0, lambda: self._apply_avatar(avatar_url, ctk_img))
            except Exception:
                pass
            finally:
                self.downloading_avatars.discard(avatar_url)

        threading.Thread(target=worker, daemon=True).start()

    def _apply_avatar(self, url, img):
        if url in self._current_avatar_labels:
            for lbl in self._current_avatar_labels[url]:
                try:
                    if lbl.winfo_exists():
                        lbl.configure(image=img)
                        lbl.image = img
                except Exception:
                    pass

    def destroy(self):
        self.polling_active = False
        super().destroy()
