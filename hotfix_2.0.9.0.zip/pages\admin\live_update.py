import customtkinter
from core.firebase_sync import session as requests
import threading
import datetime
import json
import tkinter.messagebox as messagebox

class LiveUpdateTab(customtkinter.CTkFrame):
    def __init__(self, parent, app, **kwargs):
        super().__init__(parent, fg_color="transparent", **kwargs)
        self.app = app
        self._last_data_hash = None
        
        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(1, weight=1)

        hdr = customtkinter.CTkFrame(self, fg_color="#FFFFFF", border_width=3, border_color="#000000", corner_radius=0)
        hdr.grid(row=0, column=0, sticky="ew", pady=(0, 15))
        customtkinter.CTkLabel(hdr, text="🔄 CONFIGURE LIVE UPDATE & OTA HOTFIX", font=customtkinter.CTkFont(family="Segoe UI Black", size=22), text_color="#000000").pack(padx=20, pady=15, side="left")

        # Scrollable Container
        scroll_box = customtkinter.CTkScrollableFrame(self, fg_color="#FFFFFF", border_width=3, border_color="#000000", corner_radius=0)
        scroll_box.grid(row=1, column=0, sticky="nsew")
        scroll_box.grid_columnconfigure(0, weight=1)

        # ---------------------------------------------------------------------
        # SECTION 1: FULL INSTALLER RELEASE (MAJOR UPDATE)
        # ---------------------------------------------------------------------
        sec1 = customtkinter.CTkFrame(scroll_box, fg_color="#F9F6F0", border_width=2, border_color="#000000", corner_radius=0)
        sec1.pack(fill="x", padx=20, pady=15)
        sec1.grid_columnconfigure(0, weight=1)

        customtkinter.CTkLabel(sec1, text="📦 1. RELEASE UPDATE MAJOR (Installer .EXE)", font=customtkinter.CTkFont(family="Segoe UI Black", size=15), text_color="#000000").grid(row=0, column=0, padx=20, pady=(15, 5), sticky="w")
        customtkinter.CTkLabel(sec1, text="Gunakan ini HANYA jika ada fitur baru skala besar yang membutuhkan Installer .exe baru.", font=("Segoe UI", 11), text_color="#666666").grid(row=1, column=0, padx=20, pady=(0, 10), sticky="w")

        lbl_ver = customtkinter.CTkLabel(sec1, text="Versi Terbaru (contoh: 2.0.5):", font=customtkinter.CTkFont(family="Segoe UI Black", size=12), text_color="#000000")
        lbl_ver.grid(row=2, column=0, padx=20, pady=(5, 2), sticky="w")
        self.entry_update_ver = customtkinter.CTkEntry(sec1, placeholder_text="Masukkan versi terbaru...", fg_color="#FFFFFF", text_color="#000000", border_width=2, border_color="#000000", corner_radius=0, height=35)
        self.entry_update_ver.grid(row=3, column=0, padx=20, pady=(0, 10), sticky="ew")

        lbl_dl = customtkinter.CTkLabel(sec1, text="URL Download Installer (.exe):", font=customtkinter.CTkFont(family="Segoe UI Black", size=12), text_color="#000000")
        lbl_dl.grid(row=4, column=0, padx=20, pady=(5, 2), sticky="w")
        self.entry_update_dl = customtkinter.CTkEntry(sec1, placeholder_text="Masukkan link download installer (.exe)...", fg_color="#FFFFFF", text_color="#000000", border_width=2, border_color="#000000", corner_radius=0, height=35)
        self.entry_update_dl.grid(row=5, column=0, padx=20, pady=(0, 10), sticky="ew")

        lbl_change = customtkinter.CTkLabel(sec1, text="Riwayat Pembaruan / Changelog:", font=customtkinter.CTkFont(family="Segoe UI Black", size=12), text_color="#000000")
        lbl_change.grid(row=6, column=0, padx=20, pady=(5, 2), sticky="w")
        self.txt_update_changelog = customtkinter.CTkTextbox(sec1, fg_color="#FFFFFF", text_color="#000000", border_width=2, border_color="#000000", corner_radius=0, height=120, font=("Segoe UI", 12))
        self.txt_update_changelog.grid(row=7, column=0, padx=20, pady=(0, 15), sticky="ew")

        btn_container = customtkinter.CTkFrame(sec1, fg_color="transparent")
        btn_container.grid(row=8, column=0, padx=20, pady=(0, 20), sticky="ew")
        btn_container.grid_columnconfigure((0, 1), weight=1)

        btn_save = customtkinter.CTkButton(btn_container, text="💾 SIMPAN & RILIS UPDATE MAJOR", fg_color="#00D084", hover_color="#00B875", text_color="#000000", font=customtkinter.CTkFont(family="Segoe UI Black", size=13), border_width=2, border_color="#000000", corner_radius=0, height=40, command=self.save_live_update)
        btn_save.grid(row=0, column=0, padx=(0, 10), sticky="ew")

        btn_delete = customtkinter.CTkButton(btn_container, text="🗑️ BATALKAN UPDATE MAJOR", fg_color="#ef4444", hover_color="#dc2626", text_color="#FFFFFF", font=customtkinter.CTkFont(family="Segoe UI Black", size=13), border_width=2, border_color="#000000", corner_radius=0, height=40, command=self.delete_live_update)
        btn_delete.grid(row=0, column=1, padx=(10, 0), sticky="ew")

        # ---------------------------------------------------------------------
        # SECTION 2: OTA HOTFIX PATCH (MINOR BUG FIXES WITHOUT DOWNLOADING EXE)
        # ---------------------------------------------------------------------
        sec2 = customtkinter.CTkFrame(scroll_box, fg_color="#F0F8FF", border_width=2, border_color="#000000", corner_radius=0)
        sec2.pack(fill="x", padx=20, pady=(0, 20))
        sec2.grid_columnconfigure(0, weight=1)

        customtkinter.CTkLabel(sec2, text="⚡ 2. RILIS OTA HOTFIX KILAT (Tanpa Re-build .EXE)", font=customtkinter.CTkFont(family="Segoe UI Black", size=15), text_color="#000000").grid(row=0, column=0, padx=20, pady=(15, 5), sticky="w")
        customtkinter.CTkLabel(sec2, text="Pembaruan otomatis di background tanpa perlu user mengunduh installer .exe baru!", font=("Segoe UI", 11), text_color="#666666").grid(row=1, column=0, padx=20, pady=(0, 10), sticky="w")

        lbl_hver = customtkinter.CTkLabel(sec2, text="Versi Hotfix (contoh: 2.0.5.1):", font=customtkinter.CTkFont(family="Segoe UI Black", size=12), text_color="#000000")
        lbl_hver.grid(row=2, column=0, padx=20, pady=(5, 2), sticky="w")
        self.entry_hotfix_ver = customtkinter.CTkEntry(sec2, placeholder_text="Masukkan versi hotfix...", fg_color="#FFFFFF", text_color="#000000", border_width=2, border_color="#000000", corner_radius=0, height=35)
        self.entry_hotfix_ver.grid(row=3, column=0, padx=20, pady=(0, 10), sticky="ew")

        lbl_hurl = customtkinter.CTkLabel(sec2, text="URL File Patch / Zip (Opsional jika pakai ZIP):", font=customtkinter.CTkFont(family="Segoe UI Black", size=12), text_color="#000000")
        lbl_hurl.grid(row=4, column=0, padx=20, pady=(5, 2), sticky="w")
        self.entry_hotfix_url = customtkinter.CTkEntry(sec2, placeholder_text="Masukkan URL zip patch jika ada...", fg_color="#FFFFFF", text_color="#000000", border_width=2, border_color="#000000", corner_radius=0, height=35)
        self.entry_hotfix_url.grid(row=5, column=0, padx=20, pady=(0, 10), sticky="ew")

        lbl_hdesc = customtkinter.CTkLabel(sec2, text="Keterangan Perbaikan (Hotfix Notes):", font=customtkinter.CTkFont(family="Segoe UI Black", size=12), text_color="#000000")
        lbl_hdesc.grid(row=6, column=0, padx=20, pady=(5, 2), sticky="w")
        self.txt_hotfix_desc = customtkinter.CTkTextbox(sec2, fg_color="#FFFFFF", text_color="#000000", border_width=2, border_color="#000000", corner_radius=0, height=80, font=("Segoe UI", 12))
        self.txt_hotfix_desc.grid(row=7, column=0, padx=20, pady=(0, 15), sticky="ew")

        btn_hcontainer = customtkinter.CTkFrame(sec2, fg_color="transparent")
        btn_hcontainer.grid(row=8, column=0, padx=20, pady=(0, 20), sticky="ew")
        btn_hcontainer.grid_columnconfigure((0, 1), weight=1)

        btn_hsave = customtkinter.CTkButton(btn_hcontainer, text="🚀 RILIS HOTFIX KILAT KE USER", fg_color="#FFD800", hover_color="#E6C300", text_color="#000000", font=customtkinter.CTkFont(family="Segoe UI Black", size=13), border_width=2, border_color="#000000", corner_radius=0, height=40, command=self.save_hotfix_update)
        btn_hsave.grid(row=0, column=0, padx=(0, 10), sticky="ew")

        btn_hdel = customtkinter.CTkButton(btn_hcontainer, text="🗑️ BATALKAN HOTFIX", fg_color="#ef4444", hover_color="#dc2626", text_color="#FFFFFF", font=customtkinter.CTkFont(family="Segoe UI Black", size=13), border_width=2, border_color="#000000", corner_radius=0, height=40, command=self.delete_hotfix_update)
        btn_hdel.grid(row=0, column=1, padx=(10, 0), sticky="ew")

    def _is_user_editing(self):
        try:
            focused = self.focus_get()
            if focused:
                w_str = str(focused)
                s_str = str(self)
                if w_str == s_str or w_str.startswith(s_str + "."):
                    return True
        except Exception:
            pass
        return False

    def refresh(self, force=False):
        if not force:
            if self._is_user_editing() or getattr(self, "_loaded_once", False):
                return
        self.refresh_live_update(force=force)

    def refresh_live_update(self, force=False):
        if not force and self._is_user_editing():
            return
        threading.Thread(target=self._async_load_all, args=(force,), daemon=True).start()

    def _async_load_all(self, force=False):
        try:
            # 1. Major version info
            url_ver = f"{self.app.db_url}/version.json"
            res_ver = requests.get(url_ver, timeout=10)
            data_ver = res_ver.json() if res_ver.status_code == 200 and res_ver.json() else {}

            # 2. Hotfix info
            url_hf = f"{self.app.db_url}/hotfix.json"
            res_hf = requests.get(url_hf, timeout=10)
            data_hf = res_hf.json() if res_hf.status_code == 200 and res_hf.json() else {}

            def update_ui():
                if not force and self._is_user_editing():
                    return
                # Major Update fields
                self.entry_update_ver.delete(0, "end")
                self.entry_update_dl.delete(0, "end")
                self.txt_update_changelog.delete("1.0", "end")
                self.entry_update_ver.insert(0, data_ver.get("version", ""))
                self.entry_update_dl.insert(0, data_ver.get("download_url", ""))
                self.txt_update_changelog.insert("1.0", data_ver.get("changelog", ""))

                # Hotfix fields
                self.entry_hotfix_ver.delete(0, "end")
                self.entry_hotfix_url.delete(0, "end")
                self.txt_hotfix_desc.delete("1.0", "end")
                self.entry_hotfix_ver.insert(0, data_hf.get("version", ""))
                self.entry_hotfix_url.insert(0, data_hf.get("download_url", ""))
                self.txt_hotfix_desc.insert("1.0", data_hf.get("description", ""))
                self._loaded_once = True

                try:
                    from core.skeleton import hide_skeleton
                    hide_skeleton(self)
                except Exception:
                    pass

            self.after(0, update_ui)
        except Exception as e:
            try:
                from core.skeleton import hide_skeleton
                self.after(0, lambda: hide_skeleton(self))
            except Exception:
                pass

    def save_live_update(self):
        ver = self.entry_update_ver.get().strip()
        dl_url = self.entry_update_dl.get().strip()
        changelog = self.txt_update_changelog.get("1.0", "end-1c").strip()

        if not ver or not dl_url:
            messagebox.showerror("Error", "Versi Terbaru dan URL Download wajib diisi!", parent=self.app)
            return

        def _async_save():
            try:
                url = f"{self.app.db_url}/version.json"
                payload = {
                    "version": ver,
                    "download_url": dl_url,
                    "changelog": changelog,
                    "updated_at": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                }
                res = requests.put(url, json=payload, timeout=10)
                if res.status_code == 200:
                    self.after(0, lambda: messagebox.showinfo("Sukses", "Pembaruan Major berhasil dirilis!", parent=self.app))
                    self.after(0, lambda: self.refresh_live_update(force=True))
                else:
                    self.after(0, lambda: messagebox.showerror("Gagal", f"Gagal menyimpan. Status: {res.status_code}", parent=self.app))
            except Exception as e:
                self.after(0, lambda: messagebox.showerror("Error", f"Koneksi gagal: {e}", parent=self.app))

        threading.Thread(target=_async_save, daemon=True).start()

    def delete_live_update(self):
        if not messagebox.askyesno("Konfirmasi", "Batalkan rilis update major dari database?", parent=self.app):
            return

        def _async_del():
            try:
                url = f"{self.app.db_url}/version.json"
                res = requests.delete(url, timeout=10)
                if res.status_code == 200:
                    self.after(0, lambda: messagebox.showinfo("Sukses", "Pembaruan major dibatalkan!", parent=self.app))
                    self.after(0, lambda: self.refresh_live_update(force=True))
                else:
                    self.after(0, lambda: messagebox.showerror("Gagal", f"Status: {res.status_code}", parent=self.app))
            except Exception as e:
                self.after(0, lambda: messagebox.showerror("Error", f"Connection error: {e}", parent=self.app))

        threading.Thread(target=_async_del, daemon=True).start()

    def save_hotfix_update(self):
        hver = self.entry_hotfix_ver.get().strip()
        hurl = self.entry_hotfix_url.get().strip()
        hdesc = self.txt_hotfix_desc.get("1.0", "end-1c").strip()

        if not hver:
            messagebox.showerror("Error", "Versi Hotfix wajib diisi!", parent=self.app)
            return

        def _async_hsave():
            try:
                url = f"{self.app.db_url}/hotfix.json"
                payload = {
                    "version": hver,
                    "download_url": hurl,
                    "description": hdesc,
                    "updated_at": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                }
                res = requests.put(url, json=payload, timeout=10)
                if res.status_code == 200:
                    self.after(0, lambda: messagebox.showinfo("Sukses", f"Hotfix OTA v{hver} berhasil dirilis instan!", parent=self.app))
                    self.after(0, lambda: self.refresh_live_update(force=True))
                else:
                    self.after(0, lambda: messagebox.showerror("Gagal", f"Status: {res.status_code}", parent=self.app))
            except Exception as e:
                self.after(0, lambda: messagebox.showerror("Error", f"Koneksi gagal: {e}", parent=self.app))

        threading.Thread(target=_async_hsave, daemon=True).start()

    def delete_hotfix_update(self):
        if not messagebox.askyesno("Konfirmasi", "Batalkan Hotfix OTA dari database?", parent=self.app):
            return

        def _async_hdel():
            try:
                url = f"{self.app.db_url}/hotfix.json"
                res = requests.delete(url, timeout=10)
                if res.status_code == 200:
                    self.after(0, lambda: messagebox.showinfo("Sukses", "Hotfix OTA berhasil dibatalkan!", parent=self.app))
                    self.after(0, lambda: self.refresh_live_update(force=True))
                else:
                    self.after(0, lambda: messagebox.showerror("Gagal", f"Status: {res.status_code}", parent=self.app))
            except Exception as e:
                self.after(0, lambda: messagebox.showerror("Error", f"Connection error: {e}", parent=self.app))

        threading.Thread(target=_async_hdel, daemon=True).start()
