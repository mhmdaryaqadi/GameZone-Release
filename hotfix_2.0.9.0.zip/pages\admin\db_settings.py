import customtkinter
from core.firebase_sync import session as requests
import threading
import json
import tkinter.messagebox as messagebox
from core.config import save_config

DEFAULT_INJECT_SERVERS = [
    {"name": "SkyApi (Raw GitHub)", "url": "https://raw.githubusercontent.com/skyflarefox/Skyapi/refs/heads/main/{appid}.zip"},
    {"name": "SkyApi (jsDelivr CDN)", "url": "https://cdn.jsdelivr.net/gh/skyflarefox/Skyapi@main/{appid}.zip"},
    {"name": "SkyApi (GitHub)", "url": "https://github.com/skyflarefox/Skyapi/raw/refs/heads/main/{appid}.zip"},
    {"name": "Sushi Repo (Raw GitHub)", "url": "https://raw.githubusercontent.com/sushi-dev55-alt/sushitools-games-repo-alt/refs/heads/main/{appid}.zip"},
    {"name": "Sushi Repo (jsDelivr CDN)", "url": "https://cdn.jsdelivr.net/gh/sushi-dev55-alt/sushitools-games-repo-alt@main/{appid}.zip"},
    {"name": "Sushi Repo (GitHub)", "url": "https://github.com/sushi-dev55-alt/sushitools-games-repo-alt/raw/refs/heads/main/{appid}.zip"},
    {"name": "Morrenus Manifest API", "url": "https://hubcapmanifest.com/api/v1/manifest/{appid}?api_key={morrenus_key}"},
    {"name": "ManifestHub Zip API", "url": "https://api.manifesthub1.filegear-sg.me/download?appid={appid}&apikey={manifesthub_key}"}
]

DEFAULT_NETFIX_SERVERS = [
    {"name": "Project Lightning (jsDelivr CDN)", "url": "https://cdn.jsdelivr.net/gh/LightnigFast/ProjectLightningManifests@{appid}/{did}_{mid}.manifest"},
    {"name": "Project Lightning (Fastly CDN)", "url": "https://fastly.jsdelivr.net/gh/LightnigFast/ProjectLightningManifests@{appid}/{did}_{mid}.manifest"},
    {"name": "Project Lightning (GitHub Raw)", "url": "https://raw.githubusercontent.com/LightnigFast/ProjectLightningManifests/{appid}/{did}_{mid}.manifest"},
    {"name": "Qwe Repo (Raw GitHub)", "url": "https://raw.githubusercontent.com/qwe213312/k25FCdfEOoEJ42S6/main/{did}_{mid}.manifest"},
    {"name": "Morrenus Depot API", "url": "https://hubcapmanifest.com/api/v1/generate/manifest?depot_id={did}&manifest_id={mid}&api_key={morrenus_key}"},
    {"name": "ManifestHub Depot API", "url": "https://api.manifesthub1.filegear-sg.me/manifest?apikey={manifesthub_key}&depotid={did}&manifestid={mid}"}
]

DEFAULT_SERVERS = DEFAULT_INJECT_SERVERS

class DBSettingsTab(customtkinter.CTkFrame):
    def __init__(self, parent, app, **kwargs):
        super().__init__(parent, fg_color="transparent", **kwargs)
        self.app = app
        self._last_data_hash = None
        self.inject_servers_cache = []
        self.netfix_servers_cache = []
        
        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(0, weight=1)

        self.scroll_container = customtkinter.CTkScrollableFrame(self, fg_color="transparent", border_width=0, corner_radius=0)
        self.scroll_container.grid(row=0, column=0, sticky="nsew")

        # Header Neo Brutalist
        hdr = customtkinter.CTkFrame(self.scroll_container, fg_color="#FFFFFF", border_width=3, border_color="#000000", corner_radius=0)
        hdr.pack(fill="x", pady=(0, 15))
        customtkinter.CTkLabel(hdr, text="⚙️ ADMIN CONFIG & SERVER MANAGER", font=customtkinter.CTkFont(family="Segoe UI Black", size=22), text_color="#000000").pack(padx=20, pady=15, side="left")

        # Sub-tab Selector (Segmented Button)
        self.tab_selector = customtkinter.CTkSegmentedButton(
            self.scroll_container,
            values=["🗄️ DATABASE CONFIG", "🚀 INJECT SERVERS", "⚡ NETFIX SERVERS"],
            command=self._switch_subtab,
            fg_color="#F0F0F0",
            selected_color="#FF499E",
            selected_hover_color="#E63F8A",
            unselected_color="#FFFFFF",
            unselected_hover_color="#E5E5E5",
            text_color="#000000",
            font=customtkinter.CTkFont(family="Segoe UI Black", size=13),
            corner_radius=0,
            border_width=3,
            height=40
        )
        self.tab_selector.pack(fill="x", pady=(0, 15))
        self.tab_selector.set("🗄️ DATABASE CONFIG")

        # Container Frames for 3 Sub-tabs
        self.frame_db = customtkinter.CTkFrame(self.scroll_container, fg_color="transparent")
        self.frame_inject = customtkinter.CTkFrame(self.scroll_container, fg_color="transparent")
        self.frame_netfix = customtkinter.CTkFrame(self.scroll_container, fg_color="transparent")

        self._build_db_section()
        self._build_inject_servers_section()
        self._build_netfix_servers_section()

        self._switch_subtab("🗄️ DATABASE CONFIG")

    def _switch_subtab(self, value):
        self.frame_db.pack_forget()
        self.frame_inject.pack_forget()
        self.frame_netfix.pack_forget()

        if value == "🗄️ DATABASE CONFIG":
            self.frame_db.pack(fill="x", expand=True)
        elif value == "🚀 INJECT SERVERS":
            self.frame_inject.pack(fill="x", expand=True)
        elif value == "⚡ NETFIX SERVERS":
            self.frame_netfix.pack(fill="x", expand=True)

    # =========================================================================
    # SECTION 1: DATABASE CONFIG
    # =========================================================================
    def _build_db_section(self):
        box_db = customtkinter.CTkFrame(self.frame_db, fg_color="#FFFFFF", border_width=3, border_color="#000000", corner_radius=0)
        box_db.pack(fill="x", pady=(0, 15))

        customtkinter.CTkLabel(box_db, text="🗄️ FIREBASE DATABASE URL", font=customtkinter.CTkFont(family="Segoe UI Black", size=15), text_color="#FF499E").pack(padx=30, pady=(20, 10), anchor="w")

        lbl_url = customtkinter.CTkLabel(box_db, text="Firebase Realtime Database URL:", font=customtkinter.CTkFont(family="Segoe UI Black", size=13), text_color="#000000")
        lbl_url.pack(padx=30, pady=(5, 5), anchor="w")

        self.entry_db_url = customtkinter.CTkEntry(box_db, height=40, fg_color="#FFFFFF", text_color="#000000", border_width=3, border_color="#000000", corner_radius=0, font=("Segoe UI", 12, "bold"))
        self.entry_db_url.insert(0, self.app.db_url)
        self.entry_db_url.pack(padx=30, fill="x", pady=(0, 15))

        btn_save = customtkinter.CTkButton(box_db, text="💾 SIMPAN CONFIG DATABASE URL", fg_color="#FFD800", hover_color="#E6C300", text_color="#000000", font=customtkinter.CTkFont(family="Segoe UI Black", size=13), border_width=3, border_color="#000000", corner_radius=0, height=40, command=self.save_db_url)
        btn_save.pack(padx=30, fill="x", pady=(0, 10))

        self.lbl_status = customtkinter.CTkLabel(box_db, text="Status: Menghubungkan ke Firebase...", font=customtkinter.CTkFont(family="Segoe UI", size=12, weight="bold"), text_color="#555555")
        self.lbl_status.pack(padx=30, pady=(0, 20), anchor="w")

    # =========================================================================
    # SECTION 2: INJECT SERVERS & API KEYS (CRUD)
    # =========================================================================
    def _build_inject_servers_section(self):
        # API Keys Box (Inject Tab)
        box_keys = customtkinter.CTkFrame(self.frame_inject, fg_color="#FFFFFF", border_width=3, border_color="#000000", corner_radius=0)
        box_keys.pack(fill="x", pady=(0, 15))

        customtkinter.CTkLabel(box_keys, text="🔑 API KEYS (MORRENUS & MANIFESTHUB)", font=customtkinter.CTkFont(family="Segoe UI Black", size=15), text_color="#FF499E").pack(padx=30, pady=(20, 10), anchor="w")

        customtkinter.CTkLabel(box_keys, text="Morrenus API Key (SMM):", font=customtkinter.CTkFont(family="Segoe UI Black", size=13), text_color="#000000").pack(padx=30, pady=(5, 5), anchor="w")
        self.entry_morr_key_inj = customtkinter.CTkEntry(box_keys, height=40, fg_color="#FFFFFF", text_color="#000000", border_width=3, border_color="#000000", corner_radius=0, font=("Segoe UI", 12, "bold"), placeholder_text="Masukkan Morrenus API Key...")
        self.entry_morr_key_inj.pack(padx=30, fill="x", pady=(0, 15))

        customtkinter.CTkLabel(box_keys, text="ManifestHub API Key:", font=customtkinter.CTkFont(family="Segoe UI Black", size=13), text_color="#000000").pack(padx=30, pady=(5, 5), anchor="w")
        self.entry_mh_key_inj = customtkinter.CTkEntry(box_keys, height=40, fg_color="#FFFFFF", text_color="#000000", border_width=3, border_color="#000000", corner_radius=0, font=("Segoe UI", 12, "bold"), placeholder_text="Masukkan ManifestHub API Key...")
        self.entry_mh_key_inj.pack(padx=30, fill="x", pady=(0, 15))

        btn_save = customtkinter.CTkButton(box_keys, text="💾 SIMPAN API KEYS", fg_color="#FFD800", hover_color="#E6C300", text_color="#000000", font=customtkinter.CTkFont(family="Segoe UI Black", size=13), border_width=3, border_color="#000000", corner_radius=0, height=40, command=lambda: self.save_api_keys("inj"))
        btn_save.pack(padx=30, fill="x", pady=(0, 20))

        # Inject Server List CRUD Box
        box_srv = customtkinter.CTkFrame(self.frame_inject, fg_color="#FFFFFF", border_width=3, border_color="#000000", corner_radius=0)
        box_srv.pack(fill="x", pady=(0, 20))
        box_srv.grid_columnconfigure(0, weight=1)
        box_srv.grid_columnconfigure(1, weight=1)

        customtkinter.CTkLabel(box_srv, text="🚀 INJECT SERVERS LIST (CRUD)", font=customtkinter.CTkFont(family="Segoe UI Black", size=15), text_color="#FF499E").grid(row=0, column=0, columnspan=2, padx=30, pady=(20, 10), sticky="w")

        self.inject_list_frame = customtkinter.CTkFrame(box_srv, fg_color="transparent")
        self.inject_list_frame.grid(row=1, column=0, columnspan=2, padx=30, pady=(0, 15), sticky="ew")
        self.inject_list_frame.grid_columnconfigure(0, weight=1)

        div = customtkinter.CTkFrame(box_srv, height=3, fg_color="#000000", corner_radius=0)
        div.grid(row=2, column=0, columnspan=2, sticky="ew", padx=30, pady=15)

        customtkinter.CTkLabel(box_srv, text="➕ TAMBAH INJECT SERVER BARU", font=customtkinter.CTkFont(family="Segoe UI Black", size=13), text_color="#000000").grid(row=3, column=0, columnspan=2, padx=30, pady=(5, 5), sticky="w")

        self.entry_new_inject_name = customtkinter.CTkEntry(box_srv, placeholder_text="Masukkan nama server (contoh: SkyApi Mirror 2)...", height=38, fg_color="#FFFFFF", text_color="#000000", border_width=3, border_color="#000000", corner_radius=0, font=("Segoe UI", 12, "bold"))
        self.entry_new_inject_name.grid(row=4, column=0, columnspan=2, padx=30, pady=(0, 10), sticky="ew")

        self.entry_new_inject_url = customtkinter.CTkEntry(box_srv, placeholder_text="Masukkan URL dengan pola {appid}.zip...", height=38, fg_color="#FFFFFF", text_color="#000000", border_width=3, border_color="#000000", corner_radius=0, font=("Segoe UI", 12, "bold"))
        self.entry_new_inject_url.grid(row=5, column=0, columnspan=2, padx=30, pady=(0, 15), sticky="ew")

        btn_add = customtkinter.CTkButton(box_srv, text="➕ TAMBAH INJECT SERVER", fg_color="#00D084", hover_color="#00B875", text_color="#000000", font=customtkinter.CTkFont(family="Segoe UI Black", size=13), border_width=3, border_color="#000000", corner_radius=0, height=40, command=self.add_new_inject_server)
        btn_add.grid(row=6, column=0, padx=(30, 5), pady=(0, 25), sticky="ew")

        btn_reset = customtkinter.CTkButton(box_srv, text="🔄 KEMBALIKAN DEFAULT INJECT", fg_color="#FFD800", hover_color="#E6C300", text_color="#000000", font=customtkinter.CTkFont(family="Segoe UI Black", size=13), border_width=3, border_color="#000000", corner_radius=0, height=40, command=self.reset_default_inject_servers)
        btn_reset.grid(row=6, column=1, padx=(5, 30), pady=(0, 25), sticky="ew")

    # =========================================================================
    # SECTION 3: NETFIX SERVERS & API KEYS (CRUD)
    # =========================================================================
    def _build_netfix_servers_section(self):
        # API Keys Box (NetFix Tab)
        box_keys = customtkinter.CTkFrame(self.frame_netfix, fg_color="#FFFFFF", border_width=3, border_color="#000000", corner_radius=0)
        box_keys.pack(fill="x", pady=(0, 15))

        customtkinter.CTkLabel(box_keys, text="🔑 API KEYS (MORRENUS & MANIFESTHUB)", font=customtkinter.CTkFont(family="Segoe UI Black", size=15), text_color="#FF499E").pack(padx=30, pady=(20, 10), anchor="w")

        customtkinter.CTkLabel(box_keys, text="Morrenus API Key (SMM):", font=customtkinter.CTkFont(family="Segoe UI Black", size=13), text_color="#000000").pack(padx=30, pady=(5, 5), anchor="w")
        self.entry_morr_key_net = customtkinter.CTkEntry(box_keys, height=40, fg_color="#FFFFFF", text_color="#000000", border_width=3, border_color="#000000", corner_radius=0, font=("Segoe UI", 12, "bold"), placeholder_text="Masukkan Morrenus API Key...")
        self.entry_morr_key_net.pack(padx=30, fill="x", pady=(0, 15))

        customtkinter.CTkLabel(box_keys, text="ManifestHub API Key:", font=customtkinter.CTkFont(family="Segoe UI Black", size=13), text_color="#000000").pack(padx=30, pady=(5, 5), anchor="w")
        self.entry_mh_key_net = customtkinter.CTkEntry(box_keys, height=40, fg_color="#FFFFFF", text_color="#000000", border_width=3, border_color="#000000", corner_radius=0, font=("Segoe UI", 12, "bold"), placeholder_text="Masukkan ManifestHub API Key...")
        self.entry_mh_key_net.pack(padx=30, fill="x", pady=(0, 15))

        btn_save_keys = customtkinter.CTkButton(box_keys, text="💾 SIMPAN API KEYS", fg_color="#FFD800", hover_color="#E6C300", text_color="#000000", font=customtkinter.CTkFont(family="Segoe UI Black", size=13), border_width=3, border_color="#000000", corner_radius=0, height=40, command=lambda: self.save_api_keys("net"))
        btn_save_keys.pack(padx=30, fill="x", pady=(0, 20))

        # NetFix Server List CRUD Box
        box_srv = customtkinter.CTkFrame(self.frame_netfix, fg_color="#FFFFFF", border_width=3, border_color="#000000", corner_radius=0)
        box_srv.pack(fill="x", pady=(0, 20))
        box_srv.grid_columnconfigure(0, weight=1)
        box_srv.grid_columnconfigure(1, weight=1)

        customtkinter.CTkLabel(box_srv, text="⚡ NETFIX SERVERS LIST (CRUD)", font=customtkinter.CTkFont(family="Segoe UI Black", size=15), text_color="#FF499E").grid(row=0, column=0, columnspan=2, padx=30, pady=(20, 10), sticky="w")

        self.netfix_list_frame = customtkinter.CTkFrame(box_srv, fg_color="transparent")
        self.netfix_list_frame.grid(row=1, column=0, columnspan=2, padx=30, pady=(0, 15), sticky="ew")
        self.netfix_list_frame.grid_columnconfigure(0, weight=1)

        div = customtkinter.CTkFrame(box_srv, height=3, fg_color="#000000", corner_radius=0)
        div.grid(row=2, column=0, columnspan=2, sticky="ew", padx=30, pady=15)

        customtkinter.CTkLabel(box_srv, text="➕ TAMBAH NETFIX SERVER BARU", font=customtkinter.CTkFont(family="Segoe UI Black", size=13), text_color="#000000").grid(row=3, column=0, columnspan=2, padx=30, pady=(5, 5), sticky="w")

        self.entry_new_netfix_name = customtkinter.CTkEntry(box_srv, placeholder_text="Masukkan nama server (contoh: Depot Mirror 2)...", height=38, fg_color="#FFFFFF", text_color="#000000", border_width=3, border_color="#000000", corner_radius=0, font=("Segoe UI", 12, "bold"))
        self.entry_new_netfix_name.grid(row=4, column=0, columnspan=2, padx=30, pady=(0, 10), sticky="ew")

        self.entry_new_netfix_url = customtkinter.CTkEntry(box_srv, placeholder_text="Masukkan URL dengan pola {did}_{mid}.manifest...", height=38, fg_color="#FFFFFF", text_color="#000000", border_width=3, border_color="#000000", corner_radius=0, font=("Segoe UI", 12, "bold"))
        self.entry_new_netfix_url.grid(row=5, column=0, columnspan=2, padx=30, pady=(0, 15), sticky="ew")

        btn_add = customtkinter.CTkButton(box_srv, text="➕ TAMBAH NETFIX SERVER", fg_color="#00D084", hover_color="#00B875", text_color="#000000", font=customtkinter.CTkFont(family="Segoe UI Black", size=13), border_width=3, border_color="#000000", corner_radius=0, height=40, command=self.add_new_netfix_server)
        btn_add.grid(row=6, column=0, padx=(30, 5), pady=(0, 25), sticky="ew")

        btn_reset = customtkinter.CTkButton(box_srv, text="🔄 KEMBALIKAN DEFAULT NETFIX", fg_color="#FFD800", hover_color="#E6C300", text_color="#000000", font=customtkinter.CTkFont(family="Segoe UI Black", size=13), border_width=3, border_color="#000000", corner_radius=0, height=40, command=self.reset_default_netfix_servers)
        btn_reset.grid(row=6, column=1, padx=(5, 30), pady=(0, 25), sticky="ew")

    # =========================================================================
    # ACTIONS & HELPERS
    # =========================================================================
    def refresh(self):
        self.refresh_db_keys()

    def save_db_url(self):
        new_url = self.entry_db_url.get().strip()

        if not new_url:
            messagebox.showerror("Error", "URL database tidak boleh kosong!", parent=self.app)
            return

        if new_url.endswith("/"):
            new_url = new_url[:-1]

        self.app.db_url = new_url
        self.app.config["firebase_url"] = new_url
        save_config(self.app.config)
        messagebox.showinfo("Sukses", "URL Firebase Realtime Database berhasil disimpan!", parent=self.app)
        self.refresh_db_keys()

    def save_api_keys(self, source_tab="inj"):
        if source_tab == "inj":
            morr_key = self.entry_morr_key_inj.get().strip()
            mh_key = self.entry_mh_key_inj.get().strip()
        else:
            morr_key = self.entry_morr_key_net.get().strip()
            mh_key = self.entry_mh_key_net.get().strip()

        def _async_save():
            try:
                url = f"{self.app.db_url}/keys.json"
                payload = {
                    "morrenus_key": morr_key,
                    "manifesthub_key": mh_key
                }
                res = requests.put(url, json=payload, timeout=10)
                if res.status_code == 200:
                    self._last_data_hash = None
                    self.after(0, lambda: messagebox.showinfo("Sukses", "API Keys (Morrenus & ManifestHub) berhasil disimpan!", parent=self.app))
                    self.after(0, self.refresh_db_keys)
                else:
                    self.after(0, lambda: messagebox.showerror("Gagal", f"Gagal menyimpan API Keys ke Firebase. Status: {res.status_code}", parent=self.app))
            except Exception as e:
                self.after(0, lambda: messagebox.showerror("Error", f"Koneksi gagal: {e}", parent=self.app))

        threading.Thread(target=_async_save, daemon=True).start()

    # INJECT SERVERS ACTIONS
    def add_new_inject_server(self):
        name = self.entry_new_inject_name.get().strip()
        url = self.entry_new_inject_url.get().strip()

        if not name or not url:
            messagebox.showerror("Error", "Nama & URL server tidak boleh kosong!", parent=self.app)
            return

        if "{appid}" not in url:
            if not messagebox.askyesno("Peringatan", "URL tidak mengandung pola '{appid}'. Apakah Anda yakin URL ini valid?", parent=self.app):
                return

        new_server = {"name": name, "url": url}
        updated = list(self.inject_servers_cache)
        updated.append(new_server)

        self.entry_new_inject_name.delete(0, "end")
        self.entry_new_inject_url.delete(0, "end")

        self._upload_inject_servers(updated, "Inject Server baru berhasil ditambahkan!")

    def delete_inject_server(self, idx):
        if not messagebox.askyesno("Hapus Server", f"Apakah Anda yakin ingin menghapus server '{self.inject_servers_cache[idx]['name']}'?", parent=self.app):
            return
        
        updated = list(self.inject_servers_cache)
        updated.pop(idx)
        self._upload_inject_servers(updated, "Inject Server berhasil dihapus!")

    def reset_default_inject_servers(self):
        if not messagebox.askyesno("Kembalikan Default", "Apakah Anda yakin ingin mengembalikan seluruh Inject Server default?", parent=self.app):
            return
        self._upload_inject_servers(DEFAULT_INJECT_SERVERS, "Seluruh Inject Server default berhasil dikembalikan!")

    def _upload_inject_servers(self, servers_list, success_msg):
        def _upload():
            try:
                url = f"{self.app.db_url}/inject_servers.json"
                res = requests.put(url, json=servers_list, timeout=10)
                if res.status_code == 200:
                    self._last_data_hash = None
                    self.after(0, lambda: messagebox.showinfo("Sukses", success_msg, parent=self.app))
                    self.after(0, self.refresh_db_keys)
                else:
                    self.after(0, lambda: messagebox.showerror("Gagal", f"Gagal memperbarui server ke Firebase. Status: {res.status_code}", parent=self.app))
            except Exception as e:
                self.after(0, lambda: messagebox.showerror("Error", f"Koneksi gagal: {e}", parent=self.app))
        threading.Thread(target=_upload, daemon=True).start()

    # NETFIX SERVERS ACTIONS
    def add_new_netfix_server(self):
        name = self.entry_new_netfix_name.get().strip()
        url = self.entry_new_netfix_url.get().strip()

        if not name or not url:
            messagebox.showerror("Error", "Nama & URL NetFix server tidak boleh kosong!", parent=self.app)
            return

        new_server = {"name": name, "url": url}
        updated = list(self.netfix_servers_cache)
        updated.append(new_server)

        self.entry_new_netfix_name.delete(0, "end")
        self.entry_new_netfix_url.delete(0, "end")

        self._upload_netfix_servers(updated, "NetFix Server baru berhasil ditambahkan!")

    def delete_netfix_server(self, idx):
        if not messagebox.askyesno("Hapus Server", f"Apakah Anda yakin ingin menghapus NetFix server '{self.netfix_servers_cache[idx]['name']}'?", parent=self.app):
            return
        
        updated = list(self.netfix_servers_cache)
        updated.pop(idx)
        self._upload_netfix_servers(updated, "NetFix Server berhasil dihapus!")

    def reset_default_netfix_servers(self):
        if not messagebox.askyesno("Kembalikan Default", "Apakah Anda yakin ingin mengembalikan seluruh NetFix Server default?", parent=self.app):
            return
        self._upload_netfix_servers(DEFAULT_NETFIX_SERVERS, "Seluruh NetFix Server default berhasil dikembalikan!")

    def _upload_netfix_servers(self, servers_list, success_msg):
        def _upload():
            try:
                url = f"{self.app.db_url}/netfix_servers.json"
                res = requests.put(url, json=servers_list, timeout=10)
                if res.status_code == 200:
                    self._last_data_hash = None
                    self.after(0, lambda: messagebox.showinfo("Sukses", success_msg, parent=self.app))
                    self.after(0, self.refresh_db_keys)
                else:
                    self.after(0, lambda: messagebox.showerror("Gagal", f"Gagal memperbarui NetFix server ke Firebase. Status: {res.status_code}", parent=self.app))
            except Exception as e:
                self.after(0, lambda: messagebox.showerror("Error", f"Koneksi gagal: {e}", parent=self.app))
        threading.Thread(target=_upload, daemon=True).start()

    # REFRESH & LOAD DATA
    def refresh_db_keys(self):
        if self._last_data_hash is None:
            for entry in [self.entry_morr_key_inj, self.entry_mh_key_inj, self.entry_morr_key_net, self.entry_mh_key_net]:
                entry.configure(state="normal")
                entry.delete(0, "end")
                entry.insert(0, "Memuat...")
                entry.configure(state="disabled")
        
        threading.Thread(target=self._async_load_db_keys, daemon=True).start()

    def _async_load_db_keys(self):
        try:
            # 1. Tarik API Keys
            url_keys = f"{self.app.db_url}/keys.json"
            res_keys = requests.get(url_keys, timeout=10)
            keys_data = {}
            if res_keys.status_code == 200 and res_keys.json():
                keys_data = res_keys.json()

            # 2. Tarik Daftar Inject Servers
            url_inj = f"{self.app.db_url}/inject_servers.json"
            res_inj = requests.get(url_inj, timeout=10)
            inject_data = []
            if res_inj.status_code == 200 and res_inj.json():
                val = res_inj.json()
                if isinstance(val, list): inject_data = [s for s in val if s is not None]
                elif isinstance(val, dict): inject_data = list(val.values())

            # 3. Tarik Daftar NetFix Servers
            url_net = f"{self.app.db_url}/netfix_servers.json"
            res_net = requests.get(url_net, timeout=10)
            netfix_data = []
            if res_net.status_code == 200 and res_net.json():
                val = res_net.json()
                if isinstance(val, list): netfix_data = [s for s in val if s is not None]
                elif isinstance(val, dict): netfix_data = list(val.values())

            try:
                if not self.winfo_exists(): return

                combined_data = {"keys": keys_data, "inject": inject_data, "netfix": netfix_data}
                data_hash = hash(json.dumps(combined_data, sort_keys=True, default=str))

                if data_hash == self._last_data_hash:
                    self.after(0, lambda: self.lbl_status.configure(text="Status: Sinkron", text_color="#00D084"))
                    try:
                        from core.skeleton import hide_skeleton
                        self.after(0, lambda: hide_skeleton(self))
                    except Exception: pass
                    return

                self._last_data_hash = data_hash
                self.inject_servers_cache = inject_data if inject_data else DEFAULT_INJECT_SERVERS
                self.netfix_servers_cache = netfix_data if netfix_data else DEFAULT_NETFIX_SERVERS

                morr_key = keys_data.get("morrenus_key", "")
                mh_key = keys_data.get("manifesthub_key", "")

                self.after(0, lambda: self._update_ui_content(morr_key, mh_key, self.inject_servers_cache, self.netfix_servers_cache))
            except (RuntimeError, Exception):
                pass
        except Exception as e:
            try:
                if not self.winfo_exists(): return
                if self._last_data_hash is None or self._last_data_hash == "failed":
                    self._last_data_hash = "failed"
                    self.after(0, lambda: self._update_ui_content("", "", DEFAULT_INJECT_SERVERS, DEFAULT_NETFIX_SERVERS, error=str(e)))
                else:
                    self.after(0, lambda: self.lbl_status.configure(text=f"Status: Gagal memperbarui data ({e})", text_color="#FF499E"))
            except (RuntimeError, Exception):
                pass

    def _update_ui_content(self, morr_key, mh_key, inject_list, netfix_list, error=None):
        for entry in [self.entry_morr_key_inj, self.entry_mh_key_inj, self.entry_morr_key_net, self.entry_mh_key_net]:
            entry.configure(state="normal")
            entry.delete(0, "end")
        
        if error:
            self.lbl_status.configure(text=f"Status: Offline ({error})", text_color="#FF499E")
            try:
                from core.skeleton import hide_skeleton
                hide_skeleton(self)
            except Exception: pass
            return

        self.lbl_status.configure(text="Status: Sinkron", text_color="#00D084")
        
        # Insert ke Inject Sub-tab
        self.entry_morr_key_inj.insert(0, morr_key)
        self.entry_mh_key_inj.insert(0, mh_key)

        # Insert ke NetFix Sub-tab (Sinkron 100%)
        self.entry_morr_key_net.insert(0, morr_key)
        self.entry_mh_key_net.insert(0, mh_key)

        # Render Inject Servers List
        for widget in self.inject_list_frame.winfo_children(): widget.destroy()
        if not inject_list:
            customtkinter.CTkLabel(self.inject_list_frame, text="Menggunakan fallback server inject bawaan.", font=("Segoe UI", 12, "bold"), text_color="#555555").pack(pady=10)
        else:
            for idx, s in enumerate(inject_list):
                row = customtkinter.CTkFrame(self.inject_list_frame, fg_color="#F4EFEB", border_width=2, border_color="#000000", corner_radius=0)
                row.pack(fill="x", pady=4)
                row.grid_columnconfigure(0, weight=1)

                txt_box = customtkinter.CTkFrame(row, fg_color="transparent")
                txt_box.grid(row=0, column=0, sticky="w", padx=15, pady=8)

                name = s.get("name", "Unknown") if isinstance(s, dict) else str(s)
                customtkinter.CTkLabel(txt_box, text=name, font=customtkinter.CTkFont(family="Segoe UI Black", size=13), text_color="#000000").pack(anchor="w")

                url_str = s.get("url", "") if isinstance(s, dict) else ""
                disp_url = url_str[:65] + "..." if len(url_str) > 68 else url_str
                customtkinter.CTkLabel(txt_box, text=disp_url, font=customtkinter.CTkFont(family="Segoe UI", size=11, weight="bold"), text_color="#555555").pack(anchor="w")

                btn_del = customtkinter.CTkButton(row, text="Hapus 🗑️", fg_color="#FF499E", hover_color="#FF3385", text_color="#FFFFFF", font=customtkinter.CTkFont(family="Segoe UI Black", size=11), border_width=2, border_color="#000000", corner_radius=0, width=70, height=28, command=lambda idx_val=idx: self.delete_inject_server(idx_val))
                btn_del.grid(row=0, column=1, padx=15, pady=8, sticky="e")

        # Render NetFix Servers List
        for widget in self.netfix_list_frame.winfo_children(): widget.destroy()
        if not netfix_list:
            customtkinter.CTkLabel(self.netfix_list_frame, text="Menggunakan fallback server netfix bawaan.", font=("Segoe UI", 12, "bold"), text_color="#555555").pack(pady=10)
        else:
            for idx, s in enumerate(netfix_list):
                row = customtkinter.CTkFrame(self.netfix_list_frame, fg_color="#F4EFEB", border_width=2, border_color="#000000", corner_radius=0)
                row.pack(fill="x", pady=4)
                row.grid_columnconfigure(0, weight=1)

                txt_box = customtkinter.CTkFrame(row, fg_color="transparent")
                txt_box.grid(row=0, column=0, sticky="w", padx=15, pady=8)

                name = s.get("name", "Unknown") if isinstance(s, dict) else str(s)
                customtkinter.CTkLabel(txt_box, text=name, font=customtkinter.CTkFont(family="Segoe UI Black", size=13), text_color="#000000").pack(anchor="w")

                url_str = s.get("url", "") if isinstance(s, dict) else ""
                disp_url = url_str[:65] + "..." if len(url_str) > 68 else url_str
                customtkinter.CTkLabel(txt_box, text=disp_url, font=customtkinter.CTkFont(family="Segoe UI", size=11, weight="bold"), text_color="#555555").pack(anchor="w")

                btn_del = customtkinter.CTkButton(row, text="Hapus 🗑️", fg_color="#FF499E", hover_color="#FF3385", text_color="#FFFFFF", font=customtkinter.CTkFont(family="Segoe UI Black", size=11), border_width=2, border_color="#000000", corner_radius=0, width=70, height=28, command=lambda idx_val=idx: self.delete_netfix_server(idx_val))
                btn_del.grid(row=0, column=1, padx=15, pady=8, sticky="e")

        try:
            from core.skeleton import hide_skeleton
            hide_skeleton(self)
        except Exception: pass
