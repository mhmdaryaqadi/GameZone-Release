import os
import stat
import re
from services.steam_service import get_steam_path, get_all_steamapps_paths

def get_appmanifest_path(appid):
    """
    Find appmanifest_{appid}.acf across ALL Steam library folders (multi-drive).
    Returns the first matching path found, or None.
    """
    all_paths = get_all_steamapps_paths()
    for apps_path in all_paths:
        manifest_file = os.path.join(apps_path, f"appmanifest_{appid}.acf")
        if os.path.exists(manifest_file):
            return manifest_file
    return None

def is_manifest_pinned(appid):
    filepath = get_appmanifest_path(appid)
    if not filepath or not os.path.exists(filepath):
        return False
    
    try:
        # Pengecekan atribut Read-Only di OS Windows
        mode = os.stat(filepath).st_mode
        is_readonly = not bool(mode & stat.S_IWRITE)
        return is_readonly
    except Exception:
        return False

def pin_manifest(appid):
    filepath = get_appmanifest_path(appid)
    if not filepath or not os.path.exists(filepath):
        return False, f"Berkas appmanifest_{appid}.acf tidak ditemukan di direktori steamapps manapun."
    
    try:
        # Set AutoUpdateBehavior = 1 (Never auto-update) jika berkas acf ada
        try:
            with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()
            
            if '"AutoUpdateBehavior"' in content:
                content = re.sub(r'"AutoUpdateBehavior"\s+"[0-9]+"', '"AutoUpdateBehavior"\t\t"1"', content)
            else:
                # Masukkan sebelum kurung kurawa penutup terakhir
                idx = content.rfind('}')
                if idx != -1:
                    content = content[:idx] + '\t"AutoUpdateBehavior"\t\t"1"\n}' + content[idx+1:]
            
            # Tulis ulang sementara buka Read-Only
            os.chmod(filepath, stat.S_IWRITE | stat.S_IREAD)
            with open(filepath, 'w', encoding='utf-8') as f:
                f.write(content)
        except Exception:
            pass

        # Ubah ke Read-Only (Kunci Manifest)
        os.chmod(filepath, stat.S_IREAD)
        return True, f"Manifest AppID {appid} berhasil dikunci (Pinned)!"
    except Exception as e:
        return False, f"Gagal mengunci manifest AppID {appid}: {e}"

def unpin_manifest(appid):
    filepath = get_appmanifest_path(appid)
    if not filepath or not os.path.exists(filepath):
        return False, f"Berkas appmanifest_{appid}.acf tidak ditemukan di direktori steamapps manapun."
    
    try:
        # Lepaskan atribut Read-Only (Buka Kunci Manifest)
        os.chmod(filepath, stat.S_IWRITE | stat.S_IREAD)
        return True, f"Kunci manifest AppID {appid} berhasil dibuka (Unpinned)!"
    except Exception as e:
        return False, f"Gagal membuka kunci manifest AppID {appid}: {e}"

def scan_all_pinned_manifests():
    """Scan ALL Steam library folders for pinned/unpinned manifests."""
    all_paths = get_all_steamapps_paths()
    results = {}
    
    for apps_path in all_paths:
        try:
            for file in os.listdir(apps_path):
                if file.startswith("appmanifest_") and file.endswith(".acf"):
                    appid_str = file.replace("appmanifest_", "").replace(".acf", "")
                    if appid_str.isdigit():
                        appid = int(appid_str)
                        if appid not in results:  # Hindari duplikat
                            filepath = os.path.join(apps_path, file)
                            mode = os.stat(filepath).st_mode
                            is_readonly = not bool(mode & stat.S_IWRITE)
                            results[appid] = is_readonly
        except Exception:
            pass
    return results
