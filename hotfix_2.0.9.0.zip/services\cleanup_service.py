import os
from services.steam_service import get_steam_path, get_all_steamapps_paths

def scan_orphan_files():
    steam_path = get_steam_path()
    if not steam_path:
        return {"stplug_lua": [], "depot_manifests": []}
    
    stplug_dir = os.path.join(steam_path, "config", "stplug-in")
    depotcache_dir = os.path.join(steam_path, "depotcache")
    
    # Get active installed AppIDs from ALL Steam library folders (multi-drive)
    installed_appids = set()
    for apps_path in get_all_steamapps_paths():
        try:
            for f in os.listdir(apps_path):
                if f.startswith("appmanifest_") and f.endswith(".acf"):
                    appid_str = f.replace("appmanifest_", "").replace(".acf", "")
                    if appid_str.isdigit():
                        installed_appids.add(appid_str)
        except Exception:
            pass
                    
    orphan_lua = []
    if os.path.exists(stplug_dir):
        for f in os.listdir(stplug_dir):
            if f.endswith(".lua"):
                appid_str = f.replace(".lua", "")
                # If appid is digit and not in installed_appids, it's potentially orphaned
                filepath = os.path.join(stplug_dir, f)
                orphan_lua.append({
                    "name": f,
                    "path": filepath,
                    "size": os.path.getsize(filepath) if os.path.exists(filepath) else 0,
                    "is_orphan": appid_str.isdigit() and (appid_str not in installed_appids)
                })

    orphan_manifests = []
    if os.path.exists(depotcache_dir):
        for f in os.listdir(depotcache_dir):
            if f.endswith(".manifest"):
                filepath = os.path.join(depotcache_dir, f)
                orphan_manifests.append({
                    "name": f,
                    "path": filepath,
                    "size": os.path.getsize(filepath) if os.path.exists(filepath) else 0
                })
                
    return {
        "stplug_lua": orphan_lua,
        "depot_manifests": orphan_manifests
    }

def clean_selected_files(file_paths):
    cleaned_count = 0
    freed_bytes = 0
    errors = []
    
    for path in file_paths:
        if os.path.exists(path):
            try:
                size = os.path.getsize(path)
                os.remove(path)
                cleaned_count += 1
                freed_bytes += size
            except Exception as e:
                errors.append(f"Gagal menghapus {os.path.basename(path)}: {e}")
                
    return cleaned_count, freed_bytes, errors
