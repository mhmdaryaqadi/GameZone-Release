import os
import shutil
import json
import glob
from services.steam_service import get_steam_path

CONFIG_DIR = os.path.join(os.path.expanduser("~"), ".gamezone")
SAVE_CONFIG_FILE = os.path.join(CONFIG_DIR, "cloud_save_config.json")
DEFAULT_BACKUP_DIR = os.path.join(os.path.expanduser("~"), "GameZone_CloudSaves")

def get_save_config():
    if not os.path.exists(CONFIG_DIR):
        os.makedirs(CONFIG_DIR, exist_ok=True)
    
    if os.path.exists(SAVE_CONFIG_FILE):
        try:
            with open(SAVE_CONFIG_FILE, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception:
            pass
    
    default_cfg = {
        "backup_dir": DEFAULT_BACKUP_DIR,
        "auto_sync": False
    }
    save_config(default_cfg)
    return default_cfg

def save_config(cfg):
    if not os.path.exists(CONFIG_DIR):
        os.makedirs(CONFIG_DIR, exist_ok=True)
    try:
        with open(SAVE_CONFIG_FILE, 'w', encoding='utf-8') as f:
            json.dump(cfg, f, indent=2)
    except Exception:
        pass

def find_game_save_locations(appid):
    user_home = os.path.expanduser("~")
    steam_path = get_steam_path()
    found_paths = []
    
    # 1. Check Steam userdata directory
    if steam_path and os.path.exists(os.path.join(steam_path, "userdata")):
        userdata_dir = os.path.join(steam_path, "userdata")
        try:
            for uid in os.listdir(userdata_dir):
                user_app_dir = os.path.join(userdata_dir, uid, str(appid))
                if os.path.exists(user_app_dir):
                    found_paths.append(user_app_dir)
        except Exception:
            pass
            
    # 2. Check AppData Local & Roaming
    local_appdata = os.path.join(user_home, "AppData", "Local")
    roaming_appdata = os.path.join(user_home, "AppData", "Roaming")
    documents_dir = os.path.join(user_home, "Documents")
    saved_games_dir = os.path.join(user_home, "Saved Games")
    
    # Search AppData for matching AppID folders
    for base in [local_appdata, roaming_appdata, documents_dir, saved_games_dir]:
        if os.path.exists(base):
            try:
                # AppID folder search
                appid_folder = os.path.join(base, str(appid))
                if os.path.exists(appid_folder):
                    found_paths.append(appid_folder)
            except Exception:
                pass

    return found_paths

def backup_game_saves(appid, game_name="Game"):
    cfg = get_save_config()
    backup_base = cfg.get("backup_dir", DEFAULT_BACKUP_DIR)
    target_app_backup = os.path.join(backup_base, f"{appid}_{game_name.replace(' ', '_')}")
    
    save_locations = find_game_save_locations(appid)
    if not save_locations:
        return False, f"Tidak ditemukan lokasi save data lokal untuk AppID {appid} ({game_name})."
    
    os.makedirs(target_app_backup, exist_ok=True)
    copied_count = 0
    
    try:
        for idx, src_dir in enumerate(save_locations):
            dest_dir = os.path.join(target_app_backup, f"location_{idx}")
            if os.path.exists(dest_dir):
                shutil.rmtree(dest_dir)
            shutil.copytree(src_dir, dest_dir)
            copied_count += 1
            
        return True, f"Berhasil mencadangkan {copied_count} lokasi save data untuk {game_name} ke:\n{target_app_backup}"
    except Exception as e:
        return False, f"Gagal mencadangkan save data {game_name}: {e}"

def restore_game_saves(appid, game_name="Game"):
    cfg = get_save_config()
    backup_base = cfg.get("backup_dir", DEFAULT_BACKUP_DIR)
    target_app_backup = os.path.join(backup_base, f"{appid}_{game_name.replace(' ', '_')}")
    
    if not os.path.exists(target_app_backup):
        return False, f"Belum ada berkas cadangan save data untuk AppID {appid} ({game_name}) di:\n{target_app_backup}"
    
    save_locations = find_game_save_locations(appid)
    if not save_locations:
        return False, f"Lokasi asal save data game di PC tidak ditemukan."
    
    restored_count = 0
    try:
        for idx, target_src in enumerate(save_locations):
            backup_src = os.path.join(target_app_backup, f"location_{idx}")
            if os.path.exists(backup_src):
                # Copy contents over
                for item in os.listdir(backup_src):
                    s = os.path.join(backup_src, item)
                    d = os.path.join(target_src, item)
                    if os.path.isdir(s):
                        if os.path.exists(d):
                            shutil.rmtree(d)
                        shutil.copytree(s, d)
                    else:
                        shutil.copy2(s, d)
                restored_count += 1
                
        return True, f"Berhasil memulihkan {restored_count} lokasi save data untuk {game_name}!"
    except Exception as e:
        return False, f"Gagal memulihkan save data {game_name}: {e}"

def list_saved_backups():
    cfg = get_save_config()
    backup_base = cfg.get("backup_dir", DEFAULT_BACKUP_DIR)
    if not os.path.exists(backup_base):
        return []
    
    results = []
    try:
        for folder_name in os.listdir(backup_base):
            folder_path = os.path.join(backup_base, folder_name)
            if os.path.isdir(folder_path):
                # Folder format is appid_Game_Name
                parts = folder_name.split("_", 1)
                appid = parts[0] if parts[0].isdigit() else "0"
                game_name = parts[1].replace("_", " ") if len(parts) > 1 else folder_name
                
                # Calculate total size
                total_bytes = 0
                for root, dirs, files in os.walk(folder_path):
                    for f in files:
                        try:
                            total_bytes += os.path.getsize(os.path.join(root, f))
                        except Exception:
                            pass
                            
                mtime = os.path.getmtime(folder_path)
                results.append({
                    "appid": appid,
                    "game_name": game_name,
                    "folder_name": folder_name,
                    "folder_path": folder_path,
                    "size_mb": round(total_bytes / (1024 * 1024), 2),
                    "mtime": mtime
                })
    except Exception:
        pass
        
    results.sort(key=lambda x: x["mtime"], reverse=True)
    return results

