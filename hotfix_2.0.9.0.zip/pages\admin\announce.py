import customtkinter
from core.firebase_sync import session as requests
import threading
import datetime
import base64
import os
import json
from io import BytesIO
from PIL import Image
import tkinter.messagebox as messagebox
from pages.admin.crop_dialog import AnnounceImageCropDialog

class AnnouncementsTab(customtkinter.CTkFrame):
    def __init__(self, parent, app, **kwargs):
        super().__init__(parent, fg_color="transparent", **kwargs)
        self.app = app
        self._last_data_hash = None
        
        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(1, weight=1)
        self.grid_rowconfigure(2, weight=0)

        hdr = customtkinter.CTkFrame(self, fg_color="#FFFFFF", border_width=3, border_color="#000000", corner_radius=0)
        hdr.grid(row=0, column=0, sticky="ew", pady=(0, 15))
        customtkinter.CTkLabel(hdr, text="📣 UPDATE LIVE ANNOUNCEMENTS", font=customtkinter.CTkFont(family="Segoe UI Black", size=24), text_color="#000000").pack(padx=20, pady=15, side="left")

        # Two Side-by-Side Panels for Announcements
        main_box = customtkinter.CTkFrame(self, fg_color="transparent")
        main_box.grid(row=1, column=0, sticky="nsew")
        main_box.grid_columnconfigure(0, weight=1, uniform="announce")
        main_box.grid_columnconfigure(1, weight=1, uniform="announce")
        main_box.grid_rowconfigure(0, weight=1)

        # ==================== PENGUMUMAN 1 ====================
        box1 = customtkinter.CTkFrame(main_box, fg_color="#FFFFFF", border_width=3, border_color="#000000", corner_radius=0)
        box1.grid(row=0, column=0, sticky="nsew", padx=(0, 10))
        
        lbl1 = customtkinter.CTkLabel(box1, text="📣 PENGUMUMAN 1 (UTAMA)", font=customtkinter.CTkFont(family="Segoe UI Black", size=16), text_color="#000000")
        lbl1.pack(padx=20, pady=(15, 5), anchor="w")
        
        lbl_desc1 = customtkinter.CTkLabel(box1, text="Isi berita/informasi utama:", font=customtkinter.CTkFont(family="Segoe UI", size=12, weight="bold"), text_color="#555555")
        lbl_desc1.pack(padx=20, pady=(5, 2), anchor="w")
        
        self.txt_announce_1 = customtkinter.CTkTextbox(box1, fg_color="#FFFFFF", text_color="#000000", border_width=3, border_color="#000000", corner_radius=0, font=("Segoe UI", 13), height=140)
        self.txt_announce_1.pack(padx=20, fill="both", expand=True, pady=(0, 10))
        
        lbl_img1 = customtkinter.CTkLabel(box1, text="Gambar Banner 1 (Upload/URL):", font=customtkinter.CTkFont(family="Segoe UI", size=12, weight="bold"), text_color="#555555")
        lbl_img1.pack(padx=20, pady=(5, 2), anchor="w")
        
        img_input_container1 = customtkinter.CTkFrame(box1, fg_color="transparent")
        img_input_container1.pack(padx=20, fill="x", pady=(0, 15))
        img_input_container1.grid_columnconfigure(0, weight=1)
        
        self.entry_announce_image_1 = customtkinter.CTkEntry(img_input_container1, placeholder_text="Masukkan URL gambar atau klik tombol upload...", fg_color="#FFFFFF", text_color="#000000", border_width=3, border_color="#000000", corner_radius=0, height=35)
        self.entry_announce_image_1.grid(row=0, column=0, sticky="ew", padx=(0, 5))
        
        btn_upload1 = customtkinter.CTkButton(img_input_container1, text="📁 UPLOAD / CROP", width=110, height=35, fg_color="#FFD800", hover_color="#E6C300", text_color="#000000", font=customtkinter.CTkFont(family="Segoe UI Black", size=10), border_width=3, border_color="#000000", corner_radius=0, command=self.handle_announce_image_action_1)
        btn_upload1.grid(row=0, column=1, sticky="e", padx=(0, 5))
        
        self.btn_reset_upload_1 = customtkinter.CTkButton(img_input_container1, text="🗑️", width=35, height=35, fg_color="#ef4444", hover_color="#dc2626", text_color="#FFFFFF", font=customtkinter.CTkFont(family="Segoe UI Black", size=11), border_width=3, border_color="#000000", corner_radius=0, command=self.reset_announce_image_upload_1)
        self.btn_reset_upload_1.grid(row=0, column=2, sticky="e")

        # ==================== PENGUMUMAN 2 ====================
        box2 = customtkinter.CTkFrame(main_box, fg_color="#FFFFFF", border_width=3, border_color="#000000", corner_radius=0)
        box2.grid(row=0, column=1, sticky="nsew", padx=(10, 0))
        
        lbl2 = customtkinter.CTkLabel(box2, text="📣 PENGUMUMAN 2 (TAMBAHAN)", font=customtkinter.CTkFont(family="Segoe UI Black", size=16), text_color="#000000")
        lbl2.pack(padx=20, pady=(15, 5), anchor="w")
        
        lbl_desc2 = customtkinter.CTkLabel(box2, text="Isi berita/informasi tambahan:", font=customtkinter.CTkFont(family="Segoe UI", size=12, weight="bold"), text_color="#555555")
        lbl_desc2.pack(padx=20, pady=(5, 2), anchor="w")
        
        self.txt_announce_2 = customtkinter.CTkTextbox(box2, fg_color="#FFFFFF", text_color="#000000", border_width=3, border_color="#000000", corner_radius=0, font=("Segoe UI", 13), height=140)
        self.txt_announce_2.pack(padx=20, fill="both", expand=True, pady=(0, 10))
        
        lbl_img2 = customtkinter.CTkLabel(box2, text="Gambar Banner 2 (Upload/URL):", font=customtkinter.CTkFont(family="Segoe UI", size=12, weight="bold"), text_color="#555555")
        lbl_img2.pack(padx=20, pady=(5, 2), anchor="w")
        
        img_input_container2 = customtkinter.CTkFrame(box2, fg_color="transparent")
        img_input_container2.pack(padx=20, fill="x", pady=(0, 15))
        img_input_container2.grid_columnconfigure(0, weight=1)
        
        self.entry_announce_image_2 = customtkinter.CTkEntry(img_input_container2, placeholder_text="Masukkan URL gambar atau klik tombol upload...", fg_color="#FFFFFF", text_color="#000000", border_width=3, border_color="#000000", corner_radius=0, height=35)
        self.entry_announce_image_2.grid(row=0, column=0, sticky="ew", padx=(0, 5))
        
        btn_upload2 = customtkinter.CTkButton(img_input_container2, text="📁 UPLOAD / CROP", width=110, height=35, fg_color="#FFD800", hover_color="#E6C300", text_color="#000000", font=customtkinter.CTkFont(family="Segoe UI Black", size=10), border_width=3, border_color="#000000", corner_radius=0, command=self.handle_announce_image_action_2)
        btn_upload2.grid(row=0, column=1, sticky="e", padx=(0, 5))
        
        self.btn_reset_upload_2 = customtkinter.CTkButton(img_input_container2, text="🗑️", width=35, height=35, fg_color="#ef4444", hover_color="#dc2626", text_color="#FFFFFF", font=customtkinter.CTkFont(family="Segoe UI Black", size=11), border_width=3, border_color="#000000", corner_radius=0, command=self.reset_announce_image_upload_2)
        self.btn_reset_upload_2.grid(row=0, column=2, sticky="e")

        self.uploaded_image_base64_1 = ""
        self.uploaded_image_base64_2 = ""

        btn_save = customtkinter.CTkButton(self, text="💾 BROADCAST SEKARANG (PUBLISH)", fg_color="#00D084", hover_color="#00B875", text_color="#000000", font=customtkinter.CTkFont(family="Segoe UI Black", size=14), border_width=3, border_color="#000000", corner_radius=0, height=45, command=self.save_announcement)
        btn_save.grid(row=2, column=0, sticky="ew", pady=(15, 10))

    def refresh(self):
        self.refresh_announcement()

    def refresh_announcement(self):
        threading.Thread(target=self._async_load_announcement, daemon=True).start()

    def _async_load_announcement(self):
        try:
            url = f"{self.app.db_url}/announcements.json"
            res = requests.get(url, timeout=10)
            ann1 = {}
            ann2 = {}
            data = None
            if res.status_code == 200:
                data = res.json()
                if data:
                    if "text" in data or "image_url" in data or "image_base64" in data:
                        ann1 = {
                            "text": data.get("text", ""),
                            "image_url": data.get("image_url", ""),
                            "image_base64": data.get("image_base64", "")
                        }
                    else:
                        ann1 = data.get("ann1", {})
                        ann2 = data.get("ann2", {})
            data_hash = hash(json.dumps(data, sort_keys=True, default=str))
            if data_hash == self._last_data_hash:
                try:
                    from core.skeleton import hide_skeleton
                    self.after(0, lambda: hide_skeleton(self))
                except Exception:
                    pass
                return
            self._last_data_hash = data_hash
            self.after(0, lambda: self._update_announce_ui(ann1, ann2))
        except Exception:
            pass

    def _update_announce_ui(self, ann1, ann2):
        # Update Ann 1
        new_text_1 = ann1.get("text", "")
        if self.txt_announce_1.get("1.0", "end-1c") != new_text_1:
            self.txt_announce_1.delete("1.0", "end")
            self.txt_announce_1.insert("1.0", new_text_1)

        self.uploaded_image_base64_1 = ann1.get("image_base64", "")
        target_img_1 = "[Gambar Lokal Terunggah dari Database]" if self.uploaded_image_base64_1 else ann1.get("image_url", "")
        if self.entry_announce_image_1.get() != target_img_1:
            self.entry_announce_image_1.configure(state="normal")
            self.entry_announce_image_1.delete(0, "end")
            self.entry_announce_image_1.insert(0, target_img_1)
            if self.uploaded_image_base64_1:
                self.entry_announce_image_1.configure(state="readonly")

        # Update Ann 2
        new_text_2 = ann2.get("text", "")
        if self.txt_announce_2.get("1.0", "end-1c") != new_text_2:
            self.txt_announce_2.delete("1.0", "end")
            self.txt_announce_2.insert("1.0", new_text_2)

        self.uploaded_image_base64_2 = ann2.get("image_base64", "")
        target_img_2 = "[Gambar Lokal Terunggah dari Database]" if self.uploaded_image_base64_2 else ann2.get("image_url", "")
        if self.entry_announce_image_2.get() != target_img_2:
            self.entry_announce_image_2.configure(state="normal")
            self.entry_announce_image_2.delete(0, "end")
            self.entry_announce_image_2.insert(0, target_img_2)
            if self.uploaded_image_base64_2:
                self.entry_announce_image_2.configure(state="readonly")

        try:
            from core.skeleton import hide_skeleton
            hide_skeleton(self)
        except Exception:
            pass

    def handle_announce_image_action_1(self):
        self.handle_announce_image_action_generic(1)
        
    def handle_announce_image_action_2(self):
        self.handle_announce_image_action_generic(2)

    def handle_announce_image_action_generic(self, index):
        entry = self.entry_announce_image_1 if index == 1 else self.entry_announce_image_2
        val = entry.get().strip()
        
        # Jika kolom berisi URL gambar online
        if val.startswith("http://") or val.startswith("https://"):
            def download_and_crop():
                try:
                    headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/120.0.0.0 Safari/537.36"}
                    res = requests.get(val, headers=headers, timeout=10)
                    if res.status_code == 200:
                        pil_img = Image.open(BytesIO(res.content))
                        pil_img.load()
                        
                        def on_crop_done(cropped_img):
                            buffered = BytesIO()
                            cropped_img.save(buffered, format="JPEG", quality=80)
                            img_bytes = buffered.getvalue()
                            
                            # Limit size to 200KB
                            if len(img_bytes) > 200 * 1024:
                                self.after(0, lambda: messagebox.showerror("Error", "Ukuran hasil crop terlalu besar! Gunakan kualitas/gambar lebih kecil.", parent=self.app))
                                return
                                
                            img_base64 = base64.b64encode(img_bytes).decode("utf-8")
                            base64_str = f"data:image/jpeg;base64,{img_base64}"
                            if index == 1:
                                self.uploaded_image_base64_1 = base64_str
                            else:
                                self.uploaded_image_base64_2 = base64_str
                            
                            self.after(0, lambda: entry.configure(state="normal"))
                            self.after(0, lambda: entry.delete(0, "end"))
                            self.after(0, lambda: entry.insert(0, f"[Gambar URL Terpotong]: {val[:35]}..."))
                            self.after(0, lambda: entry.configure(state="readonly"))
                            self.after(0, lambda: messagebox.showinfo("Sukses", f"Gambar {index} dari URL berhasil dipotong. Siap disiarkan!", parent=self.app))
                            
                        # Buka crop dialog di main thread
                        self.after(0, lambda: AnnounceImageCropDialog(self.app, pil_img, on_crop_done))
                    else:
                        self.after(0, lambda: messagebox.showerror("Error", f"Gagal mengunduh gambar dari URL. Status: {res.status_code}", parent=self.app))
                except Exception as e:
                    self.after(0, lambda: messagebox.showerror("Error", f"Gagal mengunduh/membaca gambar dari URL: {e}", parent=self.app))
            
            # Jalankan di background thread agar UI tidak beku
            threading.Thread(target=download_and_crop, daemon=True).start()
        else:
            # Jika kosong atau bukan URL, jalankan upload file lokal
            from tkinter import filedialog
            
            filepath = filedialog.askopenfilename(filetypes=[("Image Files", "*.png *.jpg *.jpeg *.webp")])
            if not filepath:
                return
                
            try:
                pil_img = Image.open(filepath)
                pil_img.load()
                
                def on_crop_done(cropped_img):
                    buffered = BytesIO()
                    cropped_img.save(buffered, format="JPEG", quality=80)
                    img_bytes = buffered.getvalue()
                    
                    if len(img_bytes) > 200 * 1024:
                        messagebox.showerror("Error", "Ukuran hasil crop terlalu besar!", parent=self.app)
                        return
                        
                    img_base64 = base64.b64encode(img_bytes).decode("utf-8")
                    base64_str = f"data:image/jpeg;base64,{img_base64}"
                    if index == 1:
                        self.uploaded_image_base64_1 = base64_str
                    else:
                        self.uploaded_image_base64_2 = base64_str
                    
                    entry.configure(state="normal")
                    entry.delete(0, "end")
                    entry.insert(0, f"[Gambar Lokal Terpotong]: {os.path.basename(filepath)}")
                    entry.configure(state="readonly")
                    messagebox.showinfo("Sukses", f"Gambar {index} lokal berhasil dipotong. Siap disiarkan!", parent=self.app)
                    
                # Buka crop dialog
                AnnounceImageCropDialog(self.app, pil_img, on_crop_done)
            except Exception as e:
                messagebox.showerror("Error", f"Gagal membaca gambar lokal: {e}", parent=self.app)

    def reset_announce_image_upload_1(self):
        self.uploaded_image_base64_1 = ""
        self.entry_announce_image_1.configure(state="normal")
        self.entry_announce_image_1.delete(0, "end")

    def reset_announce_image_upload_2(self):
        self.uploaded_image_base64_2 = ""
        self.entry_announce_image_2.configure(state="normal")
        self.entry_announce_image_2.delete(0, "end")

    def save_announcement(self):
        text_1 = self.txt_announce_1.get("1.0", "end-1c").strip()
        text_2 = self.txt_announce_2.get("1.0", "end-1c").strip()
        
        img_url_1 = ""
        if self.entry_announce_image_1.cget("state") != "readonly":
            img_url_1 = self.entry_announce_image_1.get().strip()
            self.uploaded_image_base64_1 = ""

        img_url_2 = ""
        if self.entry_announce_image_2.cget("state") != "readonly":
            img_url_2 = self.entry_announce_image_2.get().strip()
            self.uploaded_image_base64_2 = ""
            
        payload = {
            "ann1": {
                "text": text_1,
                "image_url": img_url_1,
                "image_base64": self.uploaded_image_base64_1
            },
            "ann2": {
                "text": text_2,
                "image_url": img_url_2,
                "image_base64": self.uploaded_image_base64_2
            },
            "updated_at": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        }

        def _async_save():
            try:
                url = f"{self.app.db_url}/announcements.json"
                res = requests.put(url, json=payload, timeout=10)
                if res.status_code == 200:
                    self._last_data_hash = None
                    self.after(0, lambda: messagebox.showinfo("Sukses", "Pengumuman berhasil disebarkan ke seluruh klien!", parent=self.app))
                    self.after(0, self.refresh_announcement)
                else:
                    self.after(0, lambda: messagebox.showerror("Gagal", f"Gagal mengirim. Status: {res.status_code}", parent=self.app))
            except Exception as e:
                self.after(0, lambda: messagebox.showerror("Error", f"Koneksi gagal: {e}", parent=self.app))

        threading.Thread(target=_async_save, daemon=True).start()
