import customtkinter
from core.firebase_sync import session as requests
import threading
import datetime
import json
import tkinter.messagebox as messagebox

# Patch CustomTkinter CTkOptionMenu destroy bug if imported here
_original_optionmenu_destroy = customtkinter.CTkOptionMenu.destroy
def _safe_optionmenu_destroy(self):
    try:
        if not hasattr(self, "_variable"):
            self._variable = None
        _original_optionmenu_destroy(self)
    except Exception:
        pass
customtkinter.CTkOptionMenu.destroy = _safe_optionmenu_destroy

class AppealsTab(customtkinter.CTkFrame):
    def __init__(self, parent, app, **kwargs):
        super().__init__(parent, fg_color="transparent", **kwargs)
        self.app = app
        self._last_data_hash = None
        
        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(1, weight=1)

        # Header Card
        hdr = customtkinter.CTkFrame(self, fg_color="#FFFFFF", border_width=3, border_color="#000000", corner_radius=0)
        hdr.grid(row=0, column=0, sticky="ew", pady=(0, 15))
        
        lbl = customtkinter.CTkLabel(hdr, text="⚖️ APPEALS MANAGER", font=customtkinter.CTkFont(family="Segoe UI Black", size=24), text_color="#000000")
        lbl.pack(padx=20, pady=15, side="left")
        
        btn_ref = customtkinter.CTkButton(hdr, text="🔄 REFRESH", width=120, height=35, fg_color="#00D084", hover_color="#00B875", text_color="#000000", font=customtkinter.CTkFont(family="Segoe UI Black", size=12), border_width=3, border_color="#000000", corner_radius=0, command=self.refresh_appeals)
        btn_ref.pack(padx=20, pady=15, side="right")

        # Scroll Frame for Appeals List
        self.appeals_scroll = customtkinter.CTkScrollableFrame(self, fg_color="#FFFFFF", border_width=3, border_color="#000000", corner_radius=0)
        self.appeals_scroll.grid(row=1, column=0, sticky="nsew")

    def refresh(self):
        self.refresh_appeals()

    def refresh_appeals(self):
        threading.Thread(target=self._async_load_appeals, daemon=True).start()

    def _async_load_appeals(self):
        try:
            url = f"{self.app.db_url}/appeals.json"
            res = requests.get(url, timeout=10)
            appeals_data = {}
            if res.status_code == 200:
                data = res.json()
                if data:
                    appeals_data = data
            data_hash = hash(json.dumps(appeals_data, sort_keys=True, default=str))
            if data_hash == self._last_data_hash:
                try:
                    from core.skeleton import hide_skeleton
                    self.after(0, lambda: hide_skeleton(self))
                except Exception:
                    pass
                return
            self._last_data_hash = data_hash
            self.after(0, lambda: self._update_appeals_ui(appeals_data))
        except Exception as e:
            pass  # Silent fail on auto-refresh to avoid popup spam

    def _update_appeals_ui(self, appeals_data):
        for widget in self.appeals_scroll.winfo_children():
            widget.destroy()

        if not appeals_data:
            lbl_empty = customtkinter.CTkLabel(self.appeals_scroll, text="Belum ada pengajuan banding.", font=customtkinter.CTkFont(family="Segoe UI", size=13, weight="bold"), text_color="#555555")
            lbl_empty.pack(pady=40)
            try:
                from core.skeleton import hide_skeleton
                hide_skeleton(self)
            except Exception:
                pass
            return

        for user_key, a in sorted(appeals_data.items(), key=lambda x: x[1].get("timestamp", ""), reverse=True):
            dc = a.get("username", "Unknown")
            nick = a.get("nickname", "Anonymous")
            msg = a.get("message", "")
            status = a.get("status", "pending").upper()
            time_str = a.get("timestamp", "")
            response = a.get("admin_response", "")

            # Neo Brutalist Card for appeal
            card = customtkinter.CTkFrame(self.appeals_scroll, fg_color="#FFFFFF", border_width=3, border_color="#000000", corner_radius=0)
            card.pack(fill="x", pady=8, padx=15)

            # Metadata Frame
            meta_frame = customtkinter.CTkFrame(card, fg_color="transparent")
            meta_frame.pack(fill="x", padx=15, pady=(12, 5))
            
            # Badge status color
            badge_color = "#FFD800" if status == "PENDING" else ("#00D084" if status == "APPROVED" else "#FF499E")
            lbl_status = customtkinter.CTkLabel(meta_frame, text=f" {status} ", font=customtkinter.CTkFont(family="Segoe UI Black", size=11), text_color="#000000", fg_color=badge_color, corner_radius=4)
            lbl_status.pack(side="left")
            
            lbl_user = customtkinter.CTkLabel(meta_frame, text=f"  @{dc} ({nick})", font=customtkinter.CTkFont(family="Segoe UI", size=13, weight="bold"), text_color="#000000")
            lbl_user.pack(side="left")
            
            lbl_time = customtkinter.CTkLabel(meta_frame, text=time_str, font=customtkinter.CTkFont(family="Segoe UI", size=11), text_color="#555555")
            lbl_time.pack(side="right")

            # Message content
            lbl_msg = customtkinter.CTkLabel(card, text=f"Pesan Banding:\n\"{msg}\"", font=customtkinter.CTkFont(family="Segoe UI", size=13, weight="bold"), text_color="#000000", justify="left", anchor="w", wraplength=700)
            lbl_msg.pack(fill="x", padx=15, pady=8)

            if response:
                lbl_res = customtkinter.CTkLabel(card, text=f"Respon Admin: \"{response}\"", font=customtkinter.CTkFont(family="Segoe UI", size=12, slant="italic"), text_color="#555555", justify="left", anchor="w", wraplength=700)
                lbl_res.pack(fill="x", padx=15, pady=(0, 8))

            # Actions / Input Frame (Only if status is pending)
            if status == "PENDING":
                input_frame = customtkinter.CTkFrame(card, fg_color="transparent")
                input_frame.pack(fill="x", padx=15, pady=(5, 12))
                
                lbl_input = customtkinter.CTkLabel(input_frame, text="Alasan / Catatan Admin:", font=customtkinter.CTkFont(family="Segoe UI Black", size=11), text_color="#000000")
                lbl_input.pack(side="left", padx=(0, 10))
                
                entry_res = customtkinter.CTkEntry(input_frame, placeholder_text="Tulis alasan penolakan atau catatan pembukaan blokir...", fg_color="#FFFFFF", border_color="#000000", border_width=2, text_color="#000000", font=("Segoe UI", 12), height=30)
                entry_res.pack(side="left", fill="x", expand=True, padx=(0, 10))
                
                # Command bindings
                btn_approve = customtkinter.CTkButton(
                    input_frame, text="TERIMA (UNBLOCK)", width=140, height=30, 
                    fg_color="#00D084", hover_color="#00B875", text_color="#000000", 
                    font=customtkinter.CTkFont(family="Segoe UI Black", size=10), 
                    border_width=3, border_color="#000000", corner_radius=0,
                    command=lambda uk=user_key, ent=entry_res: self.handle_appeal(uk, "approved", ent.get())
                )
                btn_approve.pack(side="right", padx=2)
                
                btn_reject = customtkinter.CTkButton(
                    input_frame, text="TOLAK", width=80, height=30, 
                    fg_color="#FF499E", hover_color="#E03580", text_color="#FFFFFF", 
                    font=customtkinter.CTkFont(family="Segoe UI Black", size=10), 
                    border_width=3, border_color="#000000", corner_radius=0,
                    command=lambda uk=user_key, ent=entry_res: self.handle_appeal(uk, "rejected", ent.get())
                )
                btn_reject.pack(side="right", padx=2)
            else:
                # If approved/rejected, show delete option to clean up
                del_frame = customtkinter.CTkFrame(card, fg_color="transparent")
                del_frame.pack(fill="x", padx=15, pady=(0, 12))
                
                btn_del = customtkinter.CTkButton(
                    del_frame, text="🗑️ HAPUS REKORD BANDING", width=180, height=28, 
                    fg_color="#ef4444", hover_color="#dc2626", text_color="#FFFFFF", 
                    font=customtkinter.CTkFont(family="Segoe UI Black", size=10), 
                    border_width=3, border_color="#000000", corner_radius=0,
                    command=lambda uk=user_key: self.delete_appeal(uk)
                )
                btn_del.pack(side="right")

        try:
            from core.skeleton import hide_skeleton
            hide_skeleton(self)
        except Exception:
            pass

    def handle_appeal(self, user_key, decision, admin_response):
        admin_response = admin_response.strip()
        if not admin_response and decision == "rejected":
            messagebox.showerror("Error", "Anda wajib menulis alasan penolakan!", parent=self.app)
            return

        msg_confirm = "Apakah Anda yakin ingin menyetujui banding ini dan membuka blokir user?" if decision == "approved" else "Apakah Anda yakin ingin menolak banding ini?"
        if not messagebox.askyesno("Konfirmasi", msg_confirm, parent=self.app):
            return

        def worker():
            try:
                # 1. Update appeal status
                url_app = f"{self.app.db_url}/appeals/{user_key}.json"
                payload = {
                    "status": decision,
                    "admin_response": admin_response if admin_response else ("Blokir dibuka oleh Admin." if decision == "approved" else "Ditolak.")
                }
                res1 = requests.patch(url_app, json=payload, timeout=10)
                
                # 2. Update user role to basic if approved
                res2_ok = True
                if decision == "approved":
                    url_usr = f"{self.app.db_url}/users/{user_key}.json"
                    res2 = requests.patch(url_usr, json={"role": "basic"}, timeout=10)
                    res2_ok = (res2.status_code == 200)

                if res1.status_code == 200 and res2_ok:
                    self._last_data_hash = None
                    self.after(0, lambda: messagebox.showinfo("Sukses", "Banding berhasil ditangani!", parent=self.app))
                    self.after(0, self.refresh_appeals)
                else:
                    self.after(0, lambda: messagebox.showerror("Gagal", "Gagal memperbarui status banding di database.", parent=self.app))
            except Exception as e:
                self.after(0, lambda: messagebox.showerror("Error Error", f"Error: {e}", parent=self.app))
        threading.Thread(target=worker, daemon=True).start()

    def delete_appeal(self, user_key):
        if not messagebox.askyesno("Konfirmasi", "Apakah Anda yakin ingin menghapus record banding ini?", parent=self.app):
            return
        def worker():
            try:
                url = f"{self.app.db_url}/appeals/{user_key}.json"
                res = requests.delete(url, timeout=10)
                if res.status_code == 200:
                    self._last_data_hash = None
                    self.after(0, lambda: messagebox.showinfo("Sukses", "Record banding berhasil dihapus!", parent=self.app))
                    self.after(0, self.refresh_appeals)
                else:
                    self.after(0, lambda: messagebox.showerror("Gagal", "Gagal menghapus record banding.", parent=self.app))
            except Exception as e:
                self.after(0, lambda: messagebox.showerror("Error Error", f"Error: {e}", parent=self.app))
        threading.Thread(target=worker, daemon=True).start()
