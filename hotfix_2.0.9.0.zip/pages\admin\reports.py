import customtkinter
import requests
import threading
import json
import tkinter.messagebox as messagebox
from core.firebase_sync import (
    fetch_bug_reports, 
    delete_bug_report
)

class ReportsTab(customtkinter.CTkFrame):
    def __init__(self, parent, app, **kwargs):
        super().__init__(parent, fg_color="transparent", **kwargs)
        self.app = app
        self._last_reports_hash = None
        
        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(0, weight=0) # Header
        self.grid_rowconfigure(1, weight=1) # Content

        # Global Header
        hdr = customtkinter.CTkFrame(self, fg_color="#FFFFFF", border_width=3, border_color="#000000", corner_radius=0)
        hdr.grid(row=0, column=0, sticky="ew", pady=(0, 15))
        
        lbl_title = customtkinter.CTkLabel(hdr, text="📥 REPORTS MODERATION", font=customtkinter.CTkFont(family="Segoe UI Black", size=22), text_color="#000000")
        lbl_title.pack(padx=20, pady=15, side="left")
        
        btn_refresh_all = customtkinter.CTkButton(hdr, text="🔄 REFRESH ALL", width=140, height=35, fg_color="#00D084", hover_color="#00B875", text_color="#000000", font=customtkinter.CTkFont(family="Segoe UI Black", size=12), border_width=3, border_color="#000000", corner_radius=0, command=self.refresh_reports_tab_data)
        btn_refresh_all.pack(padx=20, pady=15, side="right")

        # PANEL: Bug Reports
        panel_left = customtkinter.CTkFrame(self, fg_color="#FFFFFF", border_width=3, border_color="#000000", corner_radius=0)
        panel_left.grid(row=1, column=0, sticky="nsew")
        panel_left.grid_columnconfigure(0, weight=1)
        panel_left.grid_rowconfigure(1, weight=1)

        hdr_left = customtkinter.CTkFrame(panel_left, fg_color="#FFD800", border_width=0, corner_radius=0, height=45)
        hdr_left.grid(row=0, column=0, sticky="ew")
        hdr_left.grid_propagate(False)
        customtkinter.CTkLabel(hdr_left, text="🐛 DAFTAR LAPORAN BUG", font=customtkinter.CTkFont(family="Segoe UI Black", size=14), text_color="#000000").pack(padx=15, pady=10, side="left")

        self.reports_scroll = customtkinter.CTkScrollableFrame(panel_left, fg_color="#FFFFFF", border_width=0, corner_radius=0)
        self.reports_scroll.grid(row=1, column=0, sticky="nsew", padx=5, pady=5)

    def refresh(self):
        self.refresh_reports_tab_data()

    def refresh_reports_tab_data(self):
        self.refresh_admin_reports()

    def refresh_admin_reports(self):
        threading.Thread(target=self._async_load_admin_reports, daemon=True).start()

    def _async_load_admin_reports(self):
        try:
            data = fetch_bug_reports()
            data_hash = hash(json.dumps(data, sort_keys=True, default=str))
            if data_hash == self._last_reports_hash:
                try:
                    from core.skeleton import hide_skeleton
                    self.after(0, lambda: hide_skeleton(self))
                except Exception:
                    pass
                return
            self._last_reports_hash = data_hash
            self.after(0, lambda: self._update_admin_reports_ui(data))
        except Exception:
            try:
                from core.skeleton import hide_skeleton
                self.after(0, lambda: hide_skeleton(self))
            except Exception:
                pass

    def _update_admin_reports_ui(self, data):
        for widget in self.reports_scroll.winfo_children():
            widget.destroy()

        if not data:
            lbl_empty = customtkinter.CTkLabel(self.reports_scroll, text="Belum ada laporan bug dari user.", font=customtkinter.CTkFont(family="Segoe UI", size=13, weight="bold"), text_color="#555555")
            lbl_empty.pack(pady=40)
            try:
                from core.skeleton import hide_skeleton
                hide_skeleton(self)
            except Exception:
                pass
            return

        sorted_reps = []
        for rep_id, rep in data.items():
            rep["id"] = rep_id
            sorted_reps.append(rep)
        
        try:
            sorted_reps.sort(key=lambda x: x.get("timestamp", ""), reverse=True)
        except Exception:
            pass

        for rep in sorted_reps:
            rep_id = rep["id"]
            username = rep.get("username", "Unknown")
            message_text = rep.get("message", "")
            timestamp = rep.get("timestamp", "")

            # Card
            card = customtkinter.CTkFrame(self.reports_scroll, fg_color="#FFFFFF", border_width=3, border_color="#000000", corner_radius=0)
            card.pack(fill="x", pady=6, padx=5)

            # Top info
            hdr_frame = customtkinter.CTkFrame(card, fg_color="transparent")
            hdr_frame.pack(fill="x", padx=15, pady=(10, 5))
            
            lbl_user = customtkinter.CTkLabel(hdr_frame, text=f"👤 @{username}", font=customtkinter.CTkFont(family="Segoe UI", size=12, weight="bold"), text_color="#000000")
            lbl_user.pack(side="left")
            
            lbl_date = customtkinter.CTkLabel(hdr_frame, text=timestamp, font=customtkinter.CTkFont(family="Segoe UI", size=11), text_color="#666666")
            lbl_date.pack(side="right")

            # Bug Message Details
            lbl_msg = customtkinter.CTkLabel(card, text=message_text, font=customtkinter.CTkFont(family="Segoe UI", size=13, weight="bold"), text_color="#ef4444", anchor="w", justify="left", wraplength=800)
            lbl_msg.pack(fill="x", padx=15, pady=(5, 10))

            # Footer
            footer_frame = customtkinter.CTkFrame(card, fg_color="transparent")
            footer_frame.pack(fill="x", padx=15, pady=(0, 10))

            actions_frame = customtkinter.CTkFrame(footer_frame, fg_color="transparent")
            actions_frame.pack(side="right")

            btn_done = customtkinter.CTkButton(actions_frame, text="Tandai Selesai / Hapus", width=150, height=26, fg_color="#00D084", hover_color="#00B875", text_color="#000000", font=customtkinter.CTkFont(family="Segoe UI Black", size=11), border_width=3, border_color="#000000", corner_radius=0, command=lambda r=rep_id: self.handle_delete_report(r))
            btn_done.pack(side="left", padx=2)

        try:
            from core.skeleton import hide_skeleton
            hide_skeleton(self)
        except Exception:
            pass

    def handle_delete_report(self, rep_id):
        if not messagebox.askyesno("Konfirmasi", "Apakah Anda yakin ingin menghapus laporan bug ini?", parent=self.app):
            return
        def _async():
            try:
                if delete_bug_report(rep_id):
                    self.after(0, lambda: messagebox.showinfo("Sukses", "Laporan bug berhasil dihapus!", parent=self.app))
                    self.after(0, self.refresh_admin_reports)
                else:
                    self.after(0, lambda: messagebox.showerror("Gagal", "Gagal menghapus laporan bug.", parent=self.app))
            except Exception as e:
                self.after(0, lambda: messagebox.showerror("Error", f"Koneksi gagal: {e}", parent=self.app))
        threading.Thread(target=_async, daemon=True).start()
