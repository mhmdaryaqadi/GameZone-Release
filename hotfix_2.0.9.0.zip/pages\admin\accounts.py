import customtkinter
from core.firebase_sync import session as requests
import threading
import re
import json
import tkinter.messagebox as messagebox

class AccountsTab(customtkinter.CTkFrame):
    def __init__(self, parent, app, **kwargs):
        super().__init__(parent, fg_color="transparent", **kwargs)
        self.app = app
        self._last_data_hash = None
        
        self.grid_columnconfigure(0, weight=6) # List area
        self.grid_columnconfigure(1, weight=4) # Form area
        self.grid_rowconfigure(0, weight=1)

        # Left area: Account list
        self.left_area = customtkinter.CTkFrame(self, fg_color="transparent")
        self.left_area.grid(row=0, column=0, sticky="nsew", padx=(0, 10))
        self.left_area.grid_columnconfigure(0, weight=1)
        self.left_area.grid_rowconfigure(1, weight=1)

        hdr = customtkinter.CTkFrame(self.left_area, fg_color="#FFFFFF", border_width=3, border_color="#000000", corner_radius=0)
        hdr.grid(row=0, column=0, sticky="ew", pady=(0, 15))
        customtkinter.CTkLabel(hdr, text="🔑 ACCOUNTS LIST", font=customtkinter.CTkFont(family="Segoe UI Black", size=20), text_color="#000000").pack(padx=20, pady=15, side="left")

        self.accounts_scroll = customtkinter.CTkScrollableFrame(self.left_area, fg_color="#FFFFFF", border_width=3, border_color="#000000", corner_radius=0)
        self.accounts_scroll.grid(row=1, column=0, sticky="nsew")

        # Right area: CRUD Form
        self.right_area = customtkinter.CTkFrame(self, fg_color="#FFFFFF", border_width=3, border_color="#000000", corner_radius=0)
        self.right_area.grid(row=0, column=1, sticky="nsew", padx=(10, 0))
        
        lbl_form = customtkinter.CTkLabel(self.right_area, text="FORM MANAJEMEN", font=customtkinter.CTkFont(family="Segoe UI Black", size=18), text_color="#000000")
        lbl_form.pack(pady=(20, 15))

        self.edit_key_var = customtkinter.StringVar(value="") # Empty if creating new

        lbl_platform = customtkinter.CTkLabel(self.right_area, text="Nama Platform:", font=customtkinter.CTkFont(family="Segoe UI Black", size=12), text_color="#000000", anchor="w")
        lbl_platform.pack(padx=20, fill="x", pady=(10, 2))
        self.entry_platform = customtkinter.CTkEntry(self.right_area, placeholder_text="Misal: Online-Fix, SteamShare...", fg_color="#FFFFFF", text_color="#000000", border_width=2, border_color="#000000", corner_radius=0, height=35)
        self.entry_platform.pack(padx=20, fill="x", pady=(0, 10))

        lbl_user = customtkinter.CTkLabel(self.right_area, text="Username Akun:", font=customtkinter.CTkFont(family="Segoe UI Black", size=12), text_color="#000000", anchor="w")
        lbl_user.pack(padx=20, fill="x", pady=(5, 2))
        self.entry_user = customtkinter.CTkEntry(self.right_area, placeholder_text="Username...", fg_color="#FFFFFF", text_color="#000000", border_width=2, border_color="#000000", corner_radius=0, height=35)
        self.entry_user.pack(padx=20, fill="x", pady=(0, 10))

        lbl_pass = customtkinter.CTkLabel(self.right_area, text="Password Akun:", font=customtkinter.CTkFont(family="Segoe UI Black", size=12), text_color="#000000", anchor="w")
        lbl_pass.pack(padx=20, fill="x", pady=(5, 2))
        self.entry_pass = customtkinter.CTkEntry(self.right_area, placeholder_text="Password...", fg_color="#FFFFFF", text_color="#000000", border_width=2, border_color="#000000", corner_radius=0, height=35)
        self.entry_pass.pack(padx=20, fill="x", pady=(0, 20))

        btn_save = customtkinter.CTkButton(self.right_area, text="💾 SIMPAN AKUN", fg_color="#FFD800", hover_color="#E6C300", text_color="#000000", font=customtkinter.CTkFont(family="Segoe UI Black", size=13), border_width=3, border_color="#000000", corner_radius=0, height=40, command=self.save_account)
        btn_save.pack(padx=20, fill="x", pady=5)

        btn_clear = customtkinter.CTkButton(self.right_area, text="🧹 CLEAR FORM", fg_color="#E0E0E0", hover_color="#D0D0D0", text_color="#000000", font=customtkinter.CTkFont(family="Segoe UI Black", size=13), border_width=3, border_color="#000000", corner_radius=0, height=40, command=self.clear_account_form)
        btn_clear.pack(padx=20, fill="x", pady=5)

    def refresh(self):
        self.refresh_accounts()

    def clear_account_form(self):
        self.edit_key_var.set("")
        self.entry_platform.configure(state="normal")
        self.entry_platform.delete(0, "end")
        self.entry_user.delete(0, "end")
        self.entry_pass.delete(0, "end")

    def refresh_accounts(self):
        threading.Thread(target=self._async_load_accounts, daemon=True).start()

    def _async_load_accounts(self):
        try:
            url = f"{self.app.db_url}/accounts.json"
            res = requests.get(url, timeout=10)
            data = {}
            if res.status_code == 200:
                res_data = res.json()
                if res_data:
                    data = res_data
            data_hash = hash(json.dumps(data, sort_keys=True, default=str))
            if data_hash == self._last_data_hash:
                try:
                    from core.skeleton import hide_skeleton
                    self.after(0, lambda: hide_skeleton(self))
                except Exception:
                    pass
                return
            self._last_data_hash = data_hash
            self.after(0, lambda: self._update_accounts_ui(data))
        except Exception as e:
            pass  # Silent fail on auto-refresh to avoid popup spam

    def _update_accounts_ui(self, accounts_data):
        for widget in self.accounts_scroll.winfo_children():
            widget.destroy()

        if not accounts_data:
            lbl_empty = customtkinter.CTkLabel(self.accounts_scroll, text="Belum ada akun sharing terdaftar.", font=("Segoe UI", 13, "bold"), text_color="#555555")
            lbl_empty.pack(pady=40)
            try:
                from core.skeleton import hide_skeleton
                hide_skeleton(self)
            except Exception:
                pass
            return

        for acc_key, acc in accounts_data.items():
            card = customtkinter.CTkFrame(self.accounts_scroll, fg_color="#F4EFEB", border_width=2, border_color="#000000", corner_radius=0)
            card.pack(fill="x", pady=5, padx=5)

            lbl_title = customtkinter.CTkLabel(card, text=acc_key.upper(), font=customtkinter.CTkFont(family="Segoe UI Black", size=15), text_color="#000000")
            lbl_title.pack(anchor="w", padx=15, pady=(8, 2))

            lbl_user = customtkinter.CTkLabel(card, text=f"User: {acc.get('username', '')}", font=customtkinter.CTkFont(family="Segoe UI", size=13, weight="bold"), text_color="#333333")
            lbl_user.pack(anchor="w", padx=15)

            lbl_pass = customtkinter.CTkLabel(card, text=f"Pass: {acc.get('password', '')}", font=customtkinter.CTkFont(family="Segoe UI", size=13, weight="bold"), text_color="#333333")
            lbl_pass.pack(anchor="w", padx=15, pady=(0, 8))

            btn_frame = customtkinter.CTkFrame(card, fg_color="transparent")
            btn_frame.pack(anchor="e", padx=10, pady=(0, 8))

            btn_edit = customtkinter.CTkButton(btn_frame, text="✏️ EDIT", width=70, height=26, fg_color="#FFD800", hover_color="#E6C300", text_color="#000000", font=customtkinter.CTkFont(family="Segoe UI Black", size=11), border_width=2, border_color="#000000", corner_radius=0, command=lambda k=acc_key, a=acc: self.load_account_to_form(k, a))
            btn_edit.pack(side="left", padx=2)

            btn_del = customtkinter.CTkButton(btn_frame, text="🗑️ HAPUS", width=70, height=26, fg_color="#ef4444", hover_color="#dc2626", text_color="#FFFFFF", font=customtkinter.CTkFont(family="Segoe UI Black", size=11), border_width=2, border_color="#000000", corner_radius=0, command=lambda k=acc_key: self.delete_account(k))
            btn_del.pack(side="left", padx=2)

        try:
            from core.skeleton import hide_skeleton
            hide_skeleton(self)
        except Exception:
            pass

    def load_account_to_form(self, key, acc):
        self.edit_key_var.set(key)
        self.entry_platform.configure(state="normal")
        self.entry_platform.delete(0, "end")
        self.entry_platform.insert(0, key)
        self.entry_platform.configure(state="readonly") # Cannot change platform key while editing
        self.entry_user.delete(0, "end")
        self.entry_user.insert(0, acc.get("username", ""))
        self.entry_pass.delete(0, "end")
        self.entry_pass.insert(0, acc.get("password", ""))

    def save_account(self):
        platform = self.entry_platform.get().strip().lower()
        username = self.entry_user.get().strip()
        password = self.entry_pass.get().strip()

        if not platform or not username or not password:
            messagebox.showerror("Error", "Semua kolom input wajib diisi!", parent=self.app)
            return

        # Restrict platform key to alphanumeric and underscore only for Firebase safety
        if not re.match(r'^[a-zA-Z0-9_-]+$', platform):
            messagebox.showerror("Error", "Nama platform hanya boleh huruf, angka, strip (-), atau underscore (_).", parent=self.app)
            return

        def _async_save():
            try:
                url = f"{self.app.db_url}/accounts/{platform}.json"
                payload = {
                    "username": username,
                    "password": password
                }
                res = requests.put(url, json=payload, timeout=10)
                if res.status_code == 200:
                    self._last_data_hash = None
                    self.after(0, lambda: messagebox.showinfo("Sukses", "Akun berhasil disimpan!", parent=self.app))
                    self.after(0, self.clear_account_form)
                    self.after(0, self.refresh_accounts)
                else:
                    self.after(0, lambda: messagebox.showerror("Gagal", f"Gagal menyimpan ke Firebase. Status: {res.status_code}", parent=self.app))
            except Exception as e:
                self.after(0, lambda: messagebox.showerror("Error", f"Koneksi gagal: {e}", parent=self.app))

        threading.Thread(target=_async_save, daemon=True).start()

    def delete_account(self, key):
        ans = messagebox.askyesno("Konfirmasi", f"Apakah Anda yakin ingin menghapus akun platform '{key}'?", parent=self.app)
        if not ans:
            return

        def _async_del():
            try:
                url = f"{self.app.db_url}/accounts/{key}.json"
                res = requests.delete(url, timeout=10)
                if res.status_code == 200:
                    self._last_data_hash = None
                    self.after(0, lambda: messagebox.showinfo("Sukses", f"Akun '{key}' berhasil dihapus!", parent=self.app))
                    self.after(0, self.clear_account_form)
                    self.after(0, self.refresh_accounts)
                else:
                    self.after(0, lambda: messagebox.showerror("Gagal", f"Gagal menghapus. Status: {res.status_code}", parent=self.app))
            except Exception as e:
                self.after(0, lambda: messagebox.showerror("Error", f"Koneksi gagal: {e}", parent=self.app))

        threading.Thread(target=_async_del, daemon=True).start()
