import customtkinter
import tkinter.messagebox as messagebox
import tkinter.filedialog as filedialog
import os
import threading
import requests
import json
import shutil
import time

from services.save_sync_service import get_save_config, save_config, backup_game_saves, restore_game_saves, list_saved_backups
from services.cleanup_service import scan_orphan_files, clean_selected_files
from services.steam_pinning_service import is_manifest_pinned, pin_manifest, unpin_manifest, scan_all_pinned_manifests
from core.database import get_injected_games

class CloudSavePage(customtkinter.CTkFrame):
    def __init__(self, parent, db_manager):
        super().__init__(parent, fg_color="transparent")
        self.db_manager = db_manager
        
        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(0, weight=0)
        self.grid_rowconfigure(1, weight=1)
        
        # Search state - Card 1 (Save Backup)
        self.save_selected_appid = None
        self.save_selected_game_name = None
        self._save_search_timer = None
        self.save_search_cache = {}
        self.save_search_buttons = []
        
        # Search state - Card 2 (Manifest Lock)
        self.pin_selected_appid = None
        self.pin_selected_game_name = None
        self._pin_search_timer = None
        self.pin_search_cache = {}
        self.pin_search_buttons = []
        
        # Load local applist cache if available
        self.applist_data = []
        self._load_applist_async()
        
        # Header Container
        header_container = customtkinter.CTkFrame(self, fg_color="transparent")
        header_container.grid(row=0, column=0, sticky="w", padx=25, pady=(15, 0))
        
        lbl_page_title = customtkinter.CTkLabel(header_container, text="Save Cloud & Utility", font=customtkinter.CTkFont(family="Segoe UI Black", size=28), text_color="#000000")
        lbl_page_title.pack(side="left")
        
        customtkinter.CTkLabel(header_container, text="✦", font=("Segoe UI Black", 24), text_color="#5D5FEF", fg_color="#FFFFFF").pack(side="left", padx=(15, 0))
        customtkinter.CTkLabel(header_container, text="☁️", font=("Segoe UI Emoji", 26), fg_color="#FFFFFF").pack(side="left", padx=(5, 0))
        
        # Scrollable Main Content Frame
        main_scroll = customtkinter.CTkScrollableFrame(self, fg_color="transparent")
        main_scroll.grid(row=1, column=0, sticky="nsew", padx=25, pady=(15, 25))
        main_scroll.grid_columnconfigure(0, weight=1)
        
        # =========================================================================
        # CARD 1: BACKUP & RESTORE SAVE GAME
        # =========================================================================
        save_card = customtkinter.CTkFrame(main_scroll, fg_color="#FFFFFF", border_width=3, border_color="#000000", corner_radius=0)
        save_card.pack(fill="x", pady=(0, 20))
        save_card.grid_columnconfigure(0, weight=1)
        
        lbl_card1_title = customtkinter.CTkLabel(save_card, text="💾 PENCADANGAN SAVE GAME (LOCAL & CLOUD REDIRECT)", font=customtkinter.CTkFont(family="Segoe UI Black", size=18), text_color="#000000")
        lbl_card1_title.pack(anchor="w", padx=20, pady=(20, 5))
        
        lbl_card1_desc = customtkinter.CTkLabel(save_card, text="Cadangkan file save game ke folder cloud/lokal agar progres game injected tetap aman.", font=customtkinter.CTkFont(family="Segoe UI", size=12, weight="bold"), text_color="#555555", justify="left")
        lbl_card1_desc.pack(anchor="w", padx=20, pady=(0, 15))
        
        # Backup Folder Configuration Row
        folder_frame = customtkinter.CTkFrame(save_card, fg_color="#F8F9FA", border_width=2, border_color="#000000", corner_radius=0)
        folder_frame.pack(fill="x", padx=20, pady=(0, 15))
        folder_frame.grid_columnconfigure(1, weight=1)
        
        customtkinter.CTkLabel(folder_frame, text="Folder Backup:", font=customtkinter.CTkFont(family="Segoe UI Black", size=12), text_color="#000000").grid(row=0, column=0, padx=15, pady=12, sticky="w")
        
        cfg = get_save_config()
        self.entry_backup_dir = customtkinter.CTkEntry(folder_frame, font=customtkinter.CTkFont(family="Segoe UI", size=12, weight="bold"), fg_color="#FFFFFF", text_color="#000000", border_width=2, border_color="#000000", corner_radius=0)
        self.entry_backup_dir.grid(row=0, column=1, padx=(0, 10), pady=12, sticky="ew")
        self.entry_backup_dir.insert(0, cfg.get("backup_dir", ""))
        
        btn_browse = customtkinter.CTkButton(folder_frame, text="📁 PILIH FOLDER", font=customtkinter.CTkFont(family="Segoe UI Black", size=11), text_color="#000000", fg_color="#FFD800", hover_color="#E6C300", border_width=2, border_color="#000000", corner_radius=0, command=self.browse_backup_dir)
        btn_browse.grid(row=0, column=2, padx=(0, 15), pady=12)
        
        # Save Game Selection Row
        save_game_frame = customtkinter.CTkFrame(save_card, fg_color="transparent")
        save_game_frame.pack(fill="x", padx=20, pady=(0, 15))
        
        customtkinter.CTkLabel(save_game_frame, text="AppID / Nama Game:", font=customtkinter.CTkFont(family="Segoe UI Black", size=12), text_color="#000000").pack(side="left", padx=(0, 10))
        
        self.save_entry_frame = customtkinter.CTkFrame(save_game_frame, fg_color="transparent")
        self.save_entry_frame.pack(side="left", padx=(0, 15))
        
        self.entry_save_appid = customtkinter.CTkEntry(self.save_entry_frame, placeholder_text="Ketik nama game untuk backup...", width=320, height=38, font=customtkinter.CTkFont(family="Segoe UI", size=12, weight="bold"), fg_color="#FFFFFF", text_color="#000000", border_width=2, border_color="#000000", corner_radius=0)
        self.entry_save_appid.pack(side="left")
        self.entry_save_appid.bind("<KeyRelease>", self.on_save_search_type)
        self.entry_save_appid.bind("<FocusIn>", self.on_save_search_focus)
        
        btn_backup = customtkinter.CTkButton(save_game_frame, text="💾 BACKUP SAVE", font=customtkinter.CTkFont(family="Segoe UI Black", size=12), text_color="#FFFFFF", fg_color="#10B981", hover_color="#059669", border_width=2, border_color="#000000", corner_radius=0, height=38, command=self.action_backup)
        btn_backup.pack(side="left", padx=(0, 10))
        
        btn_restore = customtkinter.CTkButton(save_game_frame, text="🔄 RESTORE SAVE", font=customtkinter.CTkFont(family="Segoe UI Black", size=12), text_color="#FFFFFF", fg_color="#5D5FEF", hover_color="#4B4DDB", border_width=2, border_color="#000000", corner_radius=0, height=38, command=self.action_restore)
        btn_restore.pack(side="left")
        
        # List Container: Daftar Game yang Sudah Dibarckup
        save_hist_hdr = customtkinter.CTkLabel(save_card, text="📜 DAFTAR SAVE GAME YANG TERCADANGKAN:", font=customtkinter.CTkFont(family="Segoe UI Black", size=13), text_color="#000000")
        save_hist_hdr.pack(anchor="w", padx=20, pady=(10, 5))
        
        self.save_history_scroll = customtkinter.CTkScrollableFrame(save_card, fg_color="#F8F9FA", border_width=2, border_color="#000000", corner_radius=0, height=140)
        self.save_history_scroll.pack(fill="x", padx=20, pady=(0, 20))
        self.save_history_scroll.grid_columnconfigure(0, weight=1)
        
        # Save Search Dropdown Overlay Frame (Created AFTER history scroll so it stays on top)
        self.save_search_results_frame = customtkinter.CTkScrollableFrame(save_card, fg_color="#FFFFFF", border_width=3, border_color="#000000", corner_radius=0, height=150, width=320)
        
        # =========================================================================
        # CARD 2: MANIFEST LOCK & ANTI AUTO-UPDATE (DEDICATED SEARCH & LIST)
        # =========================================================================
        pin_card = customtkinter.CTkFrame(main_scroll, fg_color="#FFFFFF", border_width=3, border_color="#000000", corner_radius=0)
        pin_card.pack(fill="x", pady=(0, 20))
        pin_card.grid_columnconfigure(0, weight=1)
        
        lbl_card2_title = customtkinter.CTkLabel(pin_card, text="📌 MANIFEST LOCK & ANTI AUTO-UPDATE (STEAM PINNING)", font=customtkinter.CTkFont(family="Segoe UI Black", size=18), text_color="#000000")
        lbl_card2_title.pack(anchor="w", padx=20, pady=(20, 5))
        
        lbl_card2_desc = customtkinter.CTkLabel(pin_card, text="Kunci file manifest depot agar Steam tidak memaksa auto-update yang merusak lisensi game injected.", font=customtkinter.CTkFont(family="Segoe UI", size=12, weight="bold"), text_color="#555555", justify="left")
        lbl_card2_desc.pack(anchor="w", padx=20, pady=(0, 15))
        
        pin_game_frame = customtkinter.CTkFrame(pin_card, fg_color="transparent")
        pin_game_frame.pack(fill="x", padx=20, pady=(0, 15))
        
        customtkinter.CTkLabel(pin_game_frame, text="Pilih Game / AppID:", font=customtkinter.CTkFont(family="Segoe UI Black", size=12), text_color="#000000").pack(side="left", padx=(0, 10))
        
        self.pin_entry_frame = customtkinter.CTkFrame(pin_game_frame, fg_color="transparent")
        self.pin_entry_frame.pack(side="left", padx=(0, 15))
        
        self.entry_pin_appid = customtkinter.CTkEntry(self.pin_entry_frame, placeholder_text="Ketik nama game yang ingin dikunci...", width=320, height=38, font=customtkinter.CTkFont(family="Segoe UI", size=12, weight="bold"), fg_color="#FFFFFF", text_color="#000000", border_width=2, border_color="#000000", corner_radius=0)
        self.entry_pin_appid.pack(side="left")
        self.entry_pin_appid.bind("<KeyRelease>", self.on_pin_search_type)
        self.entry_pin_appid.bind("<FocusIn>", self.on_pin_search_focus)
        
        self.btn_pin_toggle = customtkinter.CTkButton(pin_game_frame, text="🔒 KUNCI MANIFEST (PIN)", font=customtkinter.CTkFont(family="Segoe UI Black", size=12), text_color="#FFFFFF", fg_color="#5D5FEF", hover_color="#4B4DDB", border_width=2, border_color="#000000", corner_radius=0, height=38, command=self.toggle_manifest_pin)
        self.btn_pin_toggle.pack(side="left")

        # Status Label Row for Manifest Lock
        self.lbl_pin_status = customtkinter.CTkLabel(pin_card, text="Status: Ketik & pilih game dari pencarian di atas terlebih dahulu", font=customtkinter.CTkFont(family="Segoe UI", size=12, weight="bold"), text_color="#666666")
        self.lbl_pin_status.pack(anchor="w", padx=20, pady=(0, 15))

        # List Container: Daftar Game yang Sedang Terkunci (Pinned Manifests)
        pin_hist_hdr = customtkinter.CTkLabel(pin_card, text="🔒 DAFTAR MANIFEST GAME YANG TERKUNCI (PINNED):", font=customtkinter.CTkFont(family="Segoe UI Black", size=13), text_color="#000000")
        pin_hist_hdr.pack(anchor="w", padx=20, pady=(5, 5))

        self.pin_history_scroll = customtkinter.CTkScrollableFrame(pin_card, fg_color="#F8F9FA", border_width=2, border_color="#000000", corner_radius=0, height=140)
        self.pin_history_scroll.pack(fill="x", padx=20, pady=(0, 20))
        self.pin_history_scroll.grid_columnconfigure(0, weight=1)

        # Pin Search Dropdown Overlay Frame (Created AFTER history scroll so it stays on top)
        self.pin_search_results_frame = customtkinter.CTkScrollableFrame(pin_card, fg_color="#FFFFFF", border_width=3, border_color="#000000", corner_radius=0, height=150, width=320)

        # Bind global click to close dropdown when clicking outside
        self.winfo_toplevel().bind("<Button-1>", self.on_window_click, add="+")

        # =========================================================================
        # CARD 3: CLEANUP SAMPAH STEAM
        # =========================================================================
        clean_card = customtkinter.CTkFrame(main_scroll, fg_color="#FFFFFF", border_width=3, border_color="#000000", corner_radius=0)
        clean_card.pack(fill="x", pady=(0, 20))
        clean_card.grid_columnconfigure(0, weight=1)
        
        lbl_card3_title = customtkinter.CTkLabel(clean_card, text="🧹 CLEANUP SAMPAH STEAM (ORPHAN FILES)", font=customtkinter.CTkFont(family="Segoe UI Black", size=18), text_color="#000000")
        lbl_card3_title.pack(anchor="w", padx=20, pady=(20, 5))
        
        lbl_card3_desc = customtkinter.CTkLabel(clean_card, text="Deteksi & bersihkan berkas .lua atau .manifest yatim bekas game yang sudah di-uninstall.", font=customtkinter.CTkFont(family="Segoe UI", size=12, weight="bold"), text_color="#555555", justify="left")
        lbl_card3_desc.pack(anchor="w", padx=20, pady=(0, 15))
        
        clean_btn_frame = customtkinter.CTkFrame(clean_card, fg_color="transparent")
        clean_btn_frame.pack(anchor="w", padx=20, pady=(0, 15))
        
        btn_scan = customtkinter.CTkButton(clean_btn_frame, text="🔍 SCAN FILE SAMPAH", font=customtkinter.CTkFont(family="Segoe UI Black", size=12), text_color="#000000", fg_color="#FF499E", hover_color="#E63F8A", border_width=2, border_color="#000000", corner_radius=0, height=35, command=self.action_scan_cleanup)
        btn_scan.pack(side="left", padx=(0, 10))
        
        btn_clean = customtkinter.CTkButton(clean_btn_frame, text="🗑️ BERSIHKAN FILE TERPILIH", font=customtkinter.CTkFont(family="Segoe UI Black", size=12), text_color="#FFFFFF", fg_color="#EF4444", hover_color="#DC2626", border_width=2, border_color="#000000", corner_radius=0, height=35, command=self.action_clean_selected)
        btn_clean.pack(side="left")
        
        self.cleanup_results_frame = customtkinter.CTkScrollableFrame(clean_card, fg_color="#F8F9FA", border_width=2, border_color="#000000", corner_radius=0, height=180)
        self.cleanup_results_frame.pack(fill="x", padx=20, pady=(0, 20))
        
        self.lbl_scan_status = customtkinter.CTkLabel(self.cleanup_results_frame, text="Klik 'SCAN FILE SAMPAH' untuk memulai pemindaian...", font=customtkinter.CTkFont(family="Segoe UI", size=12, weight="bold"), text_color="#666666")
        self.lbl_scan_status.pack(padx=15, pady=15)
        
        self.checkboxes_clean = []

        # Refresh lists on load
        self.load_saved_backups_list()
        self.load_pinned_manifests_list()

    def _load_applist_async(self):
        def loader():
            try:
                list_path = os.path.join(os.getcwd(), "cache", "applist.json")
                if os.path.exists(list_path):
                    with open(list_path, 'r', encoding='utf-8') as f:
                        data = json.load(f)
                        self.applist_data = data.get('applist', {}).get('apps', [])
            except Exception:
                pass
        threading.Thread(target=loader, daemon=True).start()

    def on_window_click(self, event):
        try:
            x, y = self.winfo_toplevel().winfo_pointerxy()
            widget = self.winfo_toplevel().winfo_containing(x, y)
            is_inside_save = False
            is_inside_pin = False
            w = widget
            while w is not None:
                if w == self.save_search_results_frame or w == self.entry_save_appid:
                    is_inside_save = True
                if w == self.pin_search_results_frame or w == self.entry_pin_appid:
                    is_inside_pin = True
                w = getattr(w, 'master', None)
            if not is_inside_save:
                self.hide_save_search_results()
            if not is_inside_pin:
                self.hide_pin_search_results()
        except Exception:
            pass

    # =========================================================================
    # LIST LOADER - CARD 1 (SAVED BACKUPS LIST) & CARD 2 (PINNED MANIFESTS LIST)
    # =========================================================================
    def load_saved_backups_list(self):
        for w in self.save_history_scroll.winfo_children():
            try: w.destroy()
            except Exception: pass
            
        backups = list_saved_backups()
        if not backups:
            lbl = customtkinter.CTkLabel(self.save_history_scroll, text="Belum ada save data game yang dicadangkan.", font=customtkinter.CTkFont(family="Segoe UI", size=12, weight="bold"), text_color="#888888")
            lbl.pack(padx=10, pady=15)
            return

        for item in backups:
            row = customtkinter.CTkFrame(self.save_history_scroll, fg_color="#FFFFFF", border_width=2, border_color="#000000", corner_radius=0)
            row.pack(fill="x", padx=5, pady=3)
            row.grid_columnconfigure(0, weight=1)
            
            txt = f"🎮 {item['game_name']} (AppID: {item['appid']})  —  {item['size_mb']} MB"
            lbl = customtkinter.CTkLabel(row, text=txt, font=customtkinter.CTkFont(family="Segoe UI Black", size=12), text_color="#000000")
            lbl.pack(side="left", padx=12, pady=8)
            
            btn_r = customtkinter.CTkButton(row, text="🔄 RESTORE", width=85, height=28, fg_color="#5D5FEF", hover_color="#4B4DDB", text_color="#FFFFFF", font=customtkinter.CTkFont(family="Segoe UI Black", size=11), border_width=2, border_color="#000000", corner_radius=0, command=lambda a=item['appid'], n=item['game_name']: self._quick_restore(a, n))
            btn_r.pack(side="right", padx=(5, 10), pady=6)
            
            btn_d = customtkinter.CTkButton(row, text="🗑️ HAPUS", width=75, height=28, fg_color="#EF4444", hover_color="#DC2626", text_color="#FFFFFF", font=customtkinter.CTkFont(family="Segoe UI Black", size=11), border_width=2, border_color="#000000", corner_radius=0, command=lambda p=item['folder_path'], n=item['game_name']: self._delete_backup_folder(p, n))
            btn_d.pack(side="right", padx=(0, 5), pady=6)

    def _quick_restore(self, appid, game_name):
        ok, msg = restore_game_saves(int(appid), game_name)
        if ok:
            messagebox.showinfo("Sukses", msg, parent=self.winfo_toplevel())
        else:
            messagebox.showerror("Gagal", msg, parent=self.winfo_toplevel())

    def _delete_backup_folder(self, folder_path, game_name):
        if messagebox.askyesno("Konfirmasi", f"Apakah Anda yakin ingin menghapus backup save data {game_name}?", parent=self.winfo_toplevel()):
            try:
                shutil.rmtree(folder_path)
                messagebox.showinfo("Sukses", f"Backup save data {game_name} berhasil dihapus.", parent=self.winfo_toplevel())
                self.load_saved_backups_list()
            except Exception as e:
                messagebox.showerror("Gagal", f"Gagal menghapus folder: {e}", parent=self.winfo_toplevel())

    def load_pinned_manifests_list(self):
        for w in self.pin_history_scroll.winfo_children():
            try: w.destroy()
            except Exception: pass
            
        pinned_map = scan_all_pinned_manifests()
        pinned_appids = [aid for aid, is_pinned in pinned_map.items() if is_pinned]
        
        if not pinned_appids:
            lbl = customtkinter.CTkLabel(self.pin_history_scroll, text="Belum ada manifest game yang dikunci (Pinned).", font=customtkinter.CTkFont(family="Segoe UI", size=12, weight="bold"), text_color="#888888")
            lbl.pack(padx=10, pady=15)
            return

        # Resolve titles from injected games database if available
        title_map = {}
        try:
            db_games = get_injected_games()
            for appid, title, _ in db_games:
                title_map[str(appid)] = title
        except Exception: pass

        for appid in pinned_appids:
            row = customtkinter.CTkFrame(self.pin_history_scroll, fg_color="#FFFFFF", border_width=2, border_color="#000000", corner_radius=0)
            row.pack(fill="x", padx=5, pady=3)
            row.grid_columnconfigure(0, weight=1)
            
            gname = title_map.get(str(appid), f"AppID {appid}")
            txt = f"🔒 {gname} (AppID: {appid})  —  [TERKUNCI / PINNED]"
            lbl = customtkinter.CTkLabel(row, text=txt, font=customtkinter.CTkFont(family="Segoe UI Black", size=12), text_color="#10B981")
            lbl.pack(side="left", padx=12, pady=8)
            
            btn_unpin = customtkinter.CTkButton(row, text="🔓 BUKA KUNCI", width=110, height=28, fg_color="#EF4444", hover_color="#DC2626", text_color="#FFFFFF", font=customtkinter.CTkFont(family="Segoe UI Black", size=11), border_width=2, border_color="#000000", corner_radius=0, command=lambda a=appid: self._quick_unpin(a))
            btn_unpin.pack(side="right", padx=10, pady=6)

    def _quick_unpin(self, appid):
        ok, msg = unpin_manifest(appid)
        if ok:
            messagebox.showinfo("Sukses", msg, parent=self.winfo_toplevel())
            self.load_pinned_manifests_list()
            self.update_pin_status_ui()
        else:
            messagebox.showerror("Gagal", msg, parent=self.winfo_toplevel())

    # =========================================================================
    # SEARCH ENGINE LOGIC WITH DYNAMIC .place() & .lift() - CARD 1 (SAVE BACKUP)
    # =========================================================================
    def show_save_search_skeleton(self):
        for btn in self.save_search_buttons:
            try: btn.destroy()
            except Exception: pass
        self.save_search_buttons = []
        
        for _ in range(4):
            sk_frame = customtkinter.CTkFrame(self.save_search_results_frame, height=32, fg_color="#FFFFFF", corner_radius=0)
            sk_frame.pack(fill="x", padx=5, pady=2)
            bar = customtkinter.CTkFrame(sk_frame, width=180, height=14, fg_color="#E0E0E0", corner_radius=4)
            bar.pack(side="left", padx=10, pady=9)
            self.save_search_buttons.append(sk_frame)
        self.show_save_search_results()

    def on_save_search_focus(self, event):
        query = self.entry_save_appid.get().strip()
        if len(query) >= 1:
            self.perform_save_search_async(query)

    def on_save_search_type(self, event):
        if event.keysym not in ("Return", "Up", "Down", "Escape"):
            self.save_selected_appid = None
            self.save_selected_game_name = None
            
        query = self.entry_save_appid.get().strip()
        if not query:
            self.hide_save_search_results()
            return
            
        if self._save_search_timer is not None:
            self.after_cancel(self._save_search_timer)
            self._save_search_timer = None
            
        self._save_search_timer = self.after(250, lambda: self.perform_save_search_async(query))

    def perform_save_search_async(self, query):
        query_lower = query.lower()
        if query_lower in self.save_search_cache:
            self.update_save_search_results(self.save_search_cache[query_lower])
            return
            
        self.show_save_search_skeleton()
        threading.Thread(target=self._async_fetch_save_search, args=(query,), daemon=True).start()

    def _async_fetch_save_search(self, query):
        query_lower = query.lower()
        items = self._search_game_items(query_lower)
        self.save_search_cache[query_lower] = items
        self.after(0, lambda: self.update_save_search_results(items))

    def update_save_search_results(self, items):
        for btn in self.save_search_buttons:
            try: btn.destroy()
            except Exception: pass
        self.save_search_buttons = []
        
        if not items:
            self.hide_save_search_results()
            return
            
        for item in items[:7]:
            appid = str(item.get("id", ""))
            name = item.get("name", "Unknown Game").replace("⚡ [Injected] ", "")
            
            btn = customtkinter.CTkButton(
                self.save_search_results_frame,
                text=name,
                anchor="w", fg_color="transparent", hover_color="#E0E0E0", text_color="#000000",
                font=customtkinter.CTkFont(family="Segoe UI", size=13, weight="bold"),
                command=lambda a=appid, n=name: self.select_save_search_result(a, n)
            )
            btn.pack(fill="x", padx=5, pady=2)
            self.save_search_buttons.append(btn)
            
        self.show_save_search_results()

    def select_save_search_result(self, appid, name):
        self.save_selected_appid = str(appid)
        self.save_selected_game_name = name
        self.entry_save_appid.delete(0, "end")
        self.entry_save_appid.insert(0, name)
        self.hide_save_search_results()

    def show_save_search_results(self):
        if not hasattr(self, "save_search_buttons") or not self.save_search_buttons:
            return
        if not self.save_search_results_frame.winfo_ismapped():
            self.entry_save_appid.update_idletasks()
            x = self.entry_save_appid.winfo_x()
            y = self.entry_save_appid.winfo_y() + self.entry_save_appid.winfo_height()
            w = self.entry_save_appid.winfo_width()
            self.save_search_results_frame.configure(width=max(w, 320))
            self.save_search_results_frame.place(in_=self.save_entry_frame, x=x, y=y)
            self.save_search_results_frame.lift()

    def hide_save_search_results(self):
        if self.save_search_results_frame.winfo_ismapped():
            self.save_search_results_frame.place_forget()

    # =========================================================================
    # SEARCH ENGINE LOGIC WITH DYNAMIC .place() & .lift() - CARD 2 (MANIFEST LOCK / PINNING)
    # =========================================================================
    def show_pin_search_skeleton(self):
        for btn in self.pin_search_buttons:
            try: btn.destroy()
            except Exception: pass
        self.pin_search_buttons = []
        
        for _ in range(4):
            sk_frame = customtkinter.CTkFrame(self.pin_search_results_frame, height=32, fg_color="#FFFFFF", corner_radius=0)
            sk_frame.pack(fill="x", padx=5, pady=2)
            bar = customtkinter.CTkFrame(sk_frame, width=180, height=14, fg_color="#E0E0E0", corner_radius=4)
            bar.pack(side="left", padx=10, pady=9)
            self.pin_search_buttons.append(sk_frame)
        self.show_pin_search_results()

    def on_pin_search_focus(self, event):
        query = self.entry_pin_appid.get().strip()
        if len(query) >= 1:
            self.perform_pin_search_async(query)

    def on_pin_search_type(self, event):
        if event.keysym not in ("Return", "Up", "Down", "Escape"):
            self.pin_selected_appid = None
            self.pin_selected_game_name = None
            self.update_pin_status_ui()
            
        query = self.entry_pin_appid.get().strip()
        if not query:
            self.hide_pin_search_results()
            return
            
        if self._pin_search_timer is not None:
            self.after_cancel(self._pin_search_timer)
            self._pin_search_timer = None
            
        self._pin_search_timer = self.after(250, lambda: self.perform_pin_search_async(query))

    def perform_pin_search_async(self, query):
        query_lower = query.lower()
        if query_lower in self.pin_search_cache:
            self.update_pin_search_results(self.pin_search_cache[query_lower])
            return
            
        self.show_pin_search_skeleton()
        threading.Thread(target=self._async_fetch_pin_search, args=(query,), daemon=True).start()

    def _async_fetch_pin_search(self, query):
        query_lower = query.lower()
        items = self._search_game_items(query_lower)
        self.pin_search_cache[query_lower] = items
        self.after(0, lambda: self.update_pin_search_results(items))

    def update_pin_search_results(self, items):
        for btn in self.pin_search_buttons:
            try: btn.destroy()
            except Exception: pass
        self.pin_search_buttons = []
        
        if not items:
            self.hide_pin_search_results()
            return
            
        for item in items[:7]:
            appid = str(item.get("id", ""))
            name = item.get("name", "Unknown Game").replace("⚡ [Injected] ", "")
            
            btn = customtkinter.CTkButton(
                self.pin_search_results_frame,
                text=name,
                anchor="w", fg_color="transparent", hover_color="#E0E0E0", text_color="#000000",
                font=customtkinter.CTkFont(family="Segoe UI", size=13, weight="bold"),
                command=lambda a=appid, n=name: self.select_pin_search_result(a, n)
            )
            btn.pack(fill="x", padx=5, pady=2)
            self.pin_search_buttons.append(btn)
            
        self.show_pin_search_results()

    def select_pin_search_result(self, appid, name):
        self.pin_selected_appid = str(appid)
        self.pin_selected_game_name = name
        self.entry_pin_appid.delete(0, "end")
        self.entry_pin_appid.insert(0, name)
        self.hide_pin_search_results()
        self.update_pin_status_ui()

    def show_pin_search_results(self):
        if not hasattr(self, "pin_search_buttons") or not self.pin_search_buttons:
            return
        if not self.pin_search_results_frame.winfo_ismapped():
            self.entry_pin_appid.update_idletasks()
            x = self.entry_pin_appid.winfo_x()
            y = self.entry_pin_appid.winfo_y() + self.entry_pin_appid.winfo_height()
            w = self.entry_pin_appid.winfo_width()
            self.pin_search_results_frame.configure(width=max(w, 320))
            self.pin_search_results_frame.place(in_=self.pin_entry_frame, x=x, y=y)
            self.pin_search_results_frame.lift()

    def hide_pin_search_results(self):
        if self.pin_search_results_frame.winfo_ismapped():
            self.pin_search_results_frame.place_forget()

    # Shared helper function to fetch matching games
    def _search_game_items(self, query_lower):
        items = []
        try:
            db_games = get_injected_games()
            for appid, title, _ in db_games:
                if query_lower in str(appid) or query_lower in title.lower():
                    items.append({"id": str(appid), "name": f"⚡ [Injected] {title}"})
        except Exception: pass
        
        if self.applist_data:
            for app in self.applist_data:
                app_name = app.get("name", "")
                if query_lower in app_name.lower():
                    items.append({"id": str(app["appid"]), "name": app_name})
                    if len(items) >= 8: break
                    
        if not items:
            try:
                url = f"https://store.steampowered.com/api/storesearch/?term={query_lower}&l=english&cc=US"
                headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) GameZoneClient/1.0"}
                res = requests.get(url, headers=headers, timeout=4)
                if res.status_code == 200:
                    data = res.json()
                    for item in data.get("items", []):
                        items.append({"id": str(item.get("id")), "name": item.get("name")})
            except Exception: pass
        return items

    # =========================================================================
    # ACTIONS & HANDLERS
    # =========================================================================
    def update_pin_status_ui(self):
        appid, _ = self._resolve_pin_appid_and_name()
        if not appid:
            self.lbl_pin_status.configure(text="Status: Ketik & pilih game dari pencarian di atas terlebih dahulu", text_color="#666666")
            self.btn_pin_toggle.configure(text="🔒 KUNCI MANIFEST (PIN)", fg_color="#5D5FEF", hover_color="#4B4DDB")
            return
            
        pinned = is_manifest_pinned(int(appid))
        if pinned:
            self.lbl_pin_status.configure(text=f"Status (AppID {appid}): 🔒 TERKUNCI (Terlindungi dari Auto-Update)", text_color="#10B981")
            self.btn_pin_toggle.configure(text="🔓 BUKA KUNCI MANIFEST", fg_color="#EF4444", hover_color="#DC2626")
        else:
            self.lbl_pin_status.configure(text=f"Status (AppID {appid}): 🔓 TERBUKA (Bisa Auto-Update)", text_color="#333333")
            self.btn_pin_toggle.configure(text="🔒 KUNCI MANIFEST (PIN)", fg_color="#5D5FEF", hover_color="#4B4DDB")

    def toggle_manifest_pin(self):
        appid, _ = self._resolve_pin_appid_and_name()
        if not appid or not appid.isdigit():
            messagebox.showwarning("Peringatan", "Silakan ketik & pilih game dari pencarian Manifest Lock terlebih dahulu!", parent=self.winfo_toplevel())
            return
            
        int_appid = int(appid)
        currently_pinned = is_manifest_pinned(int_appid)
        if currently_pinned:
            ok, msg = unpin_manifest(int_appid)
        else:
            ok, msg = pin_manifest(int_appid)
            
        if ok:
            messagebox.showinfo("Sukses", msg, parent=self.winfo_toplevel())
            self.update_pin_status_ui()
            self.load_pinned_manifests_list()
        else:
            messagebox.showerror("Gagal", msg, parent=self.winfo_toplevel())

    def browse_backup_dir(self):
        folder = filedialog.askdirectory(parent=self.winfo_toplevel(), title="Pilih Folder Backup Save Data")
        if folder:
            self.entry_backup_dir.delete(0, "end")
            self.entry_backup_dir.insert(0, folder)
            cfg = get_save_config()
            cfg["backup_dir"] = folder
            save_config(cfg)
            self.load_saved_backups_list()

    def _resolve_save_appid_and_name(self):
        if self.save_selected_appid:
            return self.save_selected_appid, self.save_selected_game_name or "Game"
        text = self.entry_save_appid.get().strip()
        if not text: return None, None
        if text.isdigit(): return text, "Game"
        return None, None

    def _resolve_pin_appid_and_name(self):
        if self.pin_selected_appid:
            return self.pin_selected_appid, self.pin_selected_game_name or "Game"
        text = self.entry_pin_appid.get().strip()
        if not text: return None, None
        if text.isdigit(): return text, "Game"
        return None, None

    def action_backup(self):
        appid, game_name = self._resolve_save_appid_and_name()
        if not appid or not appid.isdigit():
            messagebox.showwarning("Peringatan", "Pilihlah game dari daftar pencarian Save Game atau masukkan AppID berformat angka!", parent=self.winfo_toplevel())
            return
        
        b_dir = self.entry_backup_dir.get().strip()
        if b_dir:
            cfg = get_save_config()
            cfg["backup_dir"] = b_dir
            save_config(cfg)
            
        ok, msg = backup_game_saves(int(appid), game_name)
        if ok:
            messagebox.showinfo("Sukses", msg, parent=self.winfo_toplevel())
            self.load_saved_backups_list()
        else:
            messagebox.showerror("Gagal", msg, parent=self.winfo_toplevel())

    def action_restore(self):
        appid, game_name = self._resolve_save_appid_and_name()
        if not appid or not appid.isdigit():
            messagebox.showwarning("Peringatan", "Pilihlah game dari daftar pencarian Save Game atau masukkan AppID berformat angka!", parent=self.winfo_toplevel())
            return
        
        ok, msg = restore_game_saves(int(appid), game_name)
        if ok:
            messagebox.showinfo("Sukses", msg, parent=self.winfo_toplevel())
        else:
            messagebox.showerror("Gagal", msg, parent=self.winfo_toplevel())

    def action_scan_cleanup(self):
        for widget in self.cleanup_results_frame.winfo_children():
            widget.destroy()
            
        lbl_loading = customtkinter.CTkLabel(self.cleanup_results_frame, text="Memindai sisa berkas yatim di folder Steam...", font=customtkinter.CTkFont(family="Segoe UI", size=12, weight="bold"), text_color="#5D5FEF")
        lbl_loading.pack(padx=15, pady=15)
        
        def run_scan():
            data = scan_orphan_files()
            self.after(0, lambda: self.render_cleanup_results(data))
            
        threading.Thread(target=run_scan, daemon=True).start()

    def render_cleanup_results(self, data):
        for widget in self.cleanup_results_frame.winfo_children():
            widget.destroy()
            
        self.checkboxes_clean = []
        stplug_lua = data.get("stplug_lua", [])
        manifests = data.get("depot_manifests", [])
        
        orphans = [item for item in stplug_lua if item.get("is_orphan")]
        
        if not orphans and not manifests:
            lbl_empty = customtkinter.CTkLabel(self.cleanup_results_frame, text="✨ Berkas Steam bersih! Tidak ditemukan file .lua atau .manifest sampah/yatim.", font=customtkinter.CTkFont(family="Segoe UI", size=12, weight="bold"), text_color="#10B981")
            lbl_empty.pack(padx=15, pady=15)
            return
            
        if orphans:
            lbl_hdr = customtkinter.CTkLabel(self.cleanup_results_frame, text="[BERKAS .LUA YATIM (GAME SUDAH DIUNINSTALL)]", font=customtkinter.CTkFont(family="Segoe UI Black", size=12), text_color="#EF4444")
            lbl_hdr.pack(anchor="w", padx=10, pady=(5, 5))
            for item in orphans:
                var = customtkinter.StringVar(value="")
                sz_kb = round(item["size"] / 1024, 1)
                chk = customtkinter.CTkCheckBox(self.cleanup_results_frame, text=f"{item['name']} ({sz_kb} KB)", variable=var, onvalue=item["path"], offvalue="", font=customtkinter.CTkFont(family="Segoe UI", size=11, weight="bold"), text_color="#000000", border_color="#000000", border_width=2, fg_color="#EF4444")
                chk.pack(anchor="w", padx=15, pady=3)
                self.checkboxes_clean.append(var)

    def action_clean_selected(self):
        selected_paths = [var.get() for var in self.checkboxes_clean if var.get() != ""]
        if not selected_paths:
            messagebox.showwarning("Peringatan", "Silakan centang berkas sampah yang ingin dihapus!", parent=self.winfo_toplevel())
            return
            
        cnt, freed, errs = clean_selected_files(selected_paths)
        freed_mb = round(freed / (1024 * 1024), 2)
        
        msg = f"Berhasil menghapus {cnt} berkas sampah!\nRuang penyimpanan dibebaskan: {freed_mb} MB."
        if errs:
            msg += "\n\nCatatan:\n" + "\n".join(errs)
            
        messagebox.showinfo("Pembersihan Selesai", msg, parent=self.winfo_toplevel())
        self.action_scan_cleanup()
