import customtkinter
from core.firebase_sync import session as requests
import threading
import datetime
import json
import tkinter.messagebox as messagebox

# Patch CustomTkinter CTkOptionMenu destroy bug
_original_optionmenu_destroy = customtkinter.CTkOptionMenu.destroy
def _safe_optionmenu_destroy(self):
    try:
        if not hasattr(self, "_variable"):
            self._variable = None
        _original_optionmenu_destroy(self)
    except Exception:
        pass
customtkinter.CTkOptionMenu.destroy = _safe_optionmenu_destroy


class UserMonitorTab(customtkinter.CTkFrame):
    def __init__(self, parent, app, **kwargs):
        super().__init__(parent, fg_color="transparent", **kwargs)
        self.app = app
        self._last_data_hash = None
        
        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(1, weight=1)

        # Header Card
        hdr = customtkinter.CTkFrame(self, fg_color="#FFFFFF", border_width=3, border_color="#000000", corner_radius=0)
        hdr.grid(row=0, column=0, sticky="ew", pady=(0, 15))
        lbl = customtkinter.CTkLabel(hdr, text="👤 USER PRESENCE MONITOR", font=customtkinter.CTkFont(family="Segoe UI Black", size=24), text_color="#000000")
        lbl.pack(padx=20, pady=15, side="left")
        
        btn_ref = customtkinter.CTkButton(hdr, text="🔄 REFRESH", width=120, height=35, fg_color="#00D084", hover_color="#00B875", text_color="#000000", font=customtkinter.CTkFont(family="Segoe UI Black", size=12), border_width=3, border_color="#000000", corner_radius=0, command=self.refresh_users)
        btn_ref.pack(padx=20, pady=15, side="right")

        # Scroll Frame for User List
        self.users_scroll = customtkinter.CTkScrollableFrame(self, fg_color="#FFFFFF", border_width=3, border_color="#000000", corner_radius=0)
        self.users_scroll.grid(row=1, column=0, sticky="nsew")
        self.users_scroll.grid_columnconfigure((0, 1, 2, 3), weight=1)

    def refresh(self):
        """Called by the auto-refresh loop when this tab is active."""
        self.refresh_users()

    def refresh_users(self):
        threading.Thread(target=self._async_load_users, daemon=True).start()

    def _async_load_users(self):
        try:
            url = f"{self.app.db_url}/users.json"
            res = requests.get(url, timeout=10)
            users_data = {}
            if res.status_code == 200:
                data = res.json()
                if data:
                    users_data = data
            # Only rebuild UI if data actually changed
            data_hash = hash(json.dumps(users_data, sort_keys=True, default=str))
            if data_hash == self._last_data_hash:
                try:
                    from core.skeleton import hide_skeleton
                    self.after(0, lambda: hide_skeleton(self))
                except Exception:
                    pass
                return  # Skip rebuild — no changes
            self._last_data_hash = data_hash
            self.after(0, lambda: self._update_users_ui(users_data))
        except Exception as e:
            pass  # Silent fail on auto-refresh to avoid popup spam

    def _update_users_ui(self, users_data):
        for widget in self.users_scroll.winfo_children():
            widget.destroy()

        # Header Frame so header columns match data row columns 1:1!
        hdr_frame = customtkinter.CTkFrame(self.users_scroll, fg_color="#F0F0F0", border_width=2, border_color="#000000", corner_radius=0)
        hdr_frame.grid(row=0, column=0, columnspan=5, sticky="ew", pady=(0, 5))
        hdr_frame.grid_columnconfigure(0, weight=3) # DISCORD USERNAME
        hdr_frame.grid_columnconfigure(1, weight=2) # NICKNAME
        hdr_frame.grid_columnconfigure(2, weight=3) # LAST ACTIVE
        hdr_frame.grid_columnconfigure(3, weight=2) # ROLE
        hdr_frame.grid_columnconfigure(4, weight=2) # AKSI

        hdr_font = customtkinter.CTkFont(family="Segoe UI Black", size=12)
        h_dc = customtkinter.CTkLabel(hdr_frame, text="DISCORD USERNAME", font=hdr_font, text_color="#000000", anchor="w")
        h_dc.grid(row=0, column=0, padx=15, pady=8, sticky="ew")
        
        h_nick = customtkinter.CTkLabel(hdr_frame, text="LOCAL NICKNAME", font=hdr_font, text_color="#000000", anchor="w")
        h_nick.grid(row=0, column=1, padx=15, pady=8, sticky="ew")
        
        h_time = customtkinter.CTkLabel(hdr_frame, text="LAST ACTIVE (HEARTBEAT)", font=hdr_font, text_color="#000000", anchor="w")
        h_time.grid(row=0, column=2, padx=15, pady=8, sticky="ew")
        
        h_role = customtkinter.CTkLabel(hdr_frame, text="ROLE / ACCESS", font=hdr_font, text_color="#000000", anchor="w")
        h_role.grid(row=0, column=3, padx=15, pady=8, sticky="ew")

        h_act = customtkinter.CTkLabel(hdr_frame, text="AKSI", font=hdr_font, text_color="#000000", anchor="w")
        h_act.grid(row=0, column=4, padx=15, pady=8, sticky="ew")

        if not users_data:
            lbl_empty = customtkinter.CTkLabel(self.users_scroll, text="Belum ada user yang terdeteksi aktif.", font=("Segoe UI", 13, "bold"), text_color="#555555")
            lbl_empty.grid(row=1, column=0, columnspan=5, pady=40)
            try:
                from core.skeleton import hide_skeleton
                hide_skeleton(self)
            except Exception:
                pass
            return

        row_idx = 1
        for user_key, u in sorted(users_data.items(), key=lambda x: x[1].get("last_active", ""), reverse=True):
            dc = u.get("discord_username", "Unknown")
            nick = u.get("nickname", "Anonymous")
            last_act = u.get("last_active", "N/A")
            role = u.get("role", "basic")

            # Check if active within 3 minutes for green circle status
            is_active = False
            try:
                dt = datetime.datetime.strptime(last_act, "%Y-%m-%d %H:%M:%S")
                diff = (datetime.datetime.now() - dt).total_seconds()
                if diff < 180: # 3 minutes
                    is_active = True
            except:
                pass
            
            circle = "🟢" if is_active else "⚫"

            item_bg = "#FFFFFF" if row_idx % 2 == 0 else "#F9F6F0"
            r_frame = customtkinter.CTkFrame(self.users_scroll, fg_color=item_bg, border_width=1, border_color="#E0E0E0", corner_radius=0)
            r_frame.grid(row=row_idx, column=0, columnspan=5, sticky="ew", pady=2)
            r_frame.grid_columnconfigure(0, weight=3)
            r_frame.grid_columnconfigure(1, weight=2)
            r_frame.grid_columnconfigure(2, weight=3)
            r_frame.grid_columnconfigure(3, weight=2)
            r_frame.grid_columnconfigure(4, weight=2)

            lbl_dc = customtkinter.CTkLabel(r_frame, text=f"{circle}  {dc}", font=customtkinter.CTkFont(family="Segoe UI", size=13, weight="bold"), text_color="#000000", anchor="w")
            lbl_dc.grid(row=0, column=0, padx=15, pady=8, sticky="ew")

            lbl_nick = customtkinter.CTkLabel(r_frame, text=nick, font=customtkinter.CTkFont(family="Segoe UI", size=13), text_color="#000000", anchor="w")
            lbl_nick.grid(row=0, column=1, padx=15, pady=8, sticky="ew")

            lbl_time = customtkinter.CTkLabel(r_frame, text=last_act, font=customtkinter.CTkFont(family="Segoe UI", size=13), text_color="#555555", anchor="w")
            lbl_time.grid(row=0, column=2, padx=15, pady=8, sticky="ew")

            role_var = customtkinter.StringVar(value=role)
            opt_role = customtkinter.CTkOptionMenu(
                r_frame, 
                values=["basic", "premium", "block"], 
                variable=role_var,
                width=100,
                height=28,
                fg_color="#FFFFFF",
                text_color="#000000",
                button_color="#FFD800",
                button_hover_color="#E6C300",
                dropdown_fg_color="#FFFFFF",
                dropdown_text_color="#000000",
                corner_radius=0,
                font=customtkinter.CTkFont(family="Segoe UI", size=12, weight="bold"),
                dropdown_font=customtkinter.CTkFont(family="Segoe UI", size=12, weight="bold"),
                command=lambda new_val, uk=user_key: self.update_user_role(uk, new_val)
            )
            opt_role.grid(row=0, column=3, padx=15, pady=8, sticky="w")

            btn_del = customtkinter.CTkButton(
                r_frame,
                text="🗑️ HAPUS",
                width=80,
                height=28,
                fg_color="#FF4D4D",
                hover_color="#CC0000",
                text_color="#FFFFFF",
                border_width=2,
                border_color="#000000",
                corner_radius=0,
                font=customtkinter.CTkFont(family="Segoe UI", size=11, weight="bold"),
                command=lambda uk=user_key, dname=dc: self.delete_user(uk, dname)
            )
            btn_del.grid(row=0, column=4, padx=15, pady=8, sticky="w")

            row_idx += 1

        try:
            from core.skeleton import hide_skeleton
            hide_skeleton(self)
        except Exception:
            pass

    def update_user_role(self, user_key, new_role):
        def worker():
            try:
                url = f"{self.app.db_url}/users/{user_key}.json"
                res = requests.patch(url, json={"role": new_role}, timeout=10)
                if res.status_code == 200:
                    pass
                else:
                    self.after(0, lambda: messagebox.showerror("Error", "Gagal memperbarui role user.", parent=self.app))
            except Exception as e:
                self.after(0, lambda: messagebox.showerror("Connection Error", f"Error: {e}", parent=self.app))
        threading.Thread(target=worker, daemon=True).start()

    def delete_user(self, user_key, dc_name):
        if messagebox.askyesno("Konfirmasi Hapus", f"Apakah Anda yakin ingin menghapus user '{dc_name}'?", parent=self.app):
            def worker():
                try:
                    url = f"{self.app.db_url}/users/{user_key}.json"
                    res = requests.delete(url, timeout=10)
                    if res.status_code == 200:
                        self.after(0, self.refresh_users)
                    else:
                        self.after(0, lambda: messagebox.showerror("Error", "Gagal menghapus user.", parent=self.app))
                except Exception as e:
                    self.after(0, lambda: messagebox.showerror("Connection Error", f"Error: {e}", parent=self.app))
            threading.Thread(target=worker, daemon=True).start()
