import requests
import json
import os
import sys
import tkinter.messagebox as messagebox

session = requests.Session()

def check_for_update_async(app_instance, current_version, update_url, manual=False):
    """
    Check for application updates asynchronously.
    Fetches the version information from Firebase Realtime Database or fallback GitHub mirrors.
    If a newer version is available, triggers the update dialog.
    """
    try:
        headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/120.0.0.0 Safari/537.36"}
        
        update_urls = [
            "https://raw.githubusercontent.com/mhmdaryaqadi/GameZone-Release/main/version.json",
            "https://cdn.jsdelivr.net/gh/mhmdaryaqadi/GameZone-Release@main/version.json",
            "https://raw.gitmirror.com/mhmdaryaqadi/GameZone-Release/main/version.json"
        ]
        
        data = None
        firebase_success = False
        
        # 1. Try fetching from Firebase Realtime Database first (Live Update)
        try:
            from core.firebase_sync import get_db_url
            db_base = get_db_url()
            res = session.get(f"{db_base}/version.json", timeout=5)
            if res.status_code == 200:
                data = res.json()
                if data and "version" in data:
                    firebase_success = True
        except Exception as e:
            print(f"Firebase update check failed, trying GitHub fallback: {e}")

        # 2. Try fetching from GitHub mirrors if Firebase failed
        if not firebase_success:
            if not update_url.startswith("http"):
                # Developer / local mode path
                try:
                    with open(update_url, "r", encoding="utf-8") as f:
                        data = json.load(f)
                except Exception:
                    pass
            else:
                for url in update_urls:
                    try:
                        res = session.get(url, headers=headers, timeout=5)
                        if res.status_code == 200:
                            data = res.json()
                            break
                    except Exception:
                        pass
                    
        if data is None:
            if manual:
                app_instance.after(0, lambda: messagebox.showerror("Error", "Gagal menghubungi server pembaruan.", parent=app_instance.winfo_toplevel()))
            return

        latest_version = data.get("version", "0.0.0")
        current_tuple = tuple(map(int, current_version.split(".")))
        latest_tuple = tuple(map(int, latest_version.split(".")))
        
        if latest_tuple > current_tuple:
            download_url = data.get("download_url", "")
            if not download_url: 
                return
            
            # Show mandatory update dialog on the main thread
            # To avoid circular imports, import dialogs here
            from components.dialogs import MandatoryUpdateDialog
            app_instance.after(0, lambda: MandatoryUpdateDialog(app_instance, latest_version, data.get("changelog", ""), download_url))
        else:
            if manual:
                app_instance.after(0, lambda: messagebox.showinfo("Informasi", "Aplikasi Anda sudah berada di versi terbaru!", parent=app_instance.winfo_toplevel()))
    except Exception as e:
        if manual:
            app_instance.after(0, lambda: messagebox.showerror("Error", f"Gagal mengecek pembaruan: {e}", parent=app_instance.winfo_toplevel()))
