import customtkinter
import threading
import webbrowser
from PIL import Image
import io
import requests
from services.deals_service import fetch_live_deals_and_events

class DealsPage(customtkinter.CTkFrame):
    def __init__(self, parent, main_app):
        super().__init__(parent, fg_color="#FFFFFF")
        self.parent = parent
        self.main_app = main_app
        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(1, weight=1)
        
        self.image_cache = {}

        # Header Frame
        header = customtkinter.CTkFrame(self, fg_color="#FFFFFF", border_width=3, border_color="#000000", corner_radius=0)
        header.grid(row=0, column=0, sticky="ew", pady=(0, 8))

        title_container = customtkinter.CTkFrame(header, fg_color="transparent")
        title_container.pack(pady=(8, 2))

        customtkinter.CTkLabel(title_container, text="🔥", font=("Segoe UI Emoji", 20), fg_color="#FFFFFF").pack(side="left", padx=(0, 10))
        lbl_title = customtkinter.CTkLabel(title_container, text="Deals, Freebies & Steam Events", font=customtkinter.CTkFont(family="Segoe UI Black", size=18), text_color="#000000")
        lbl_title.pack(side="left")
        customtkinter.CTkLabel(title_container, text="✦", font=("Segoe UI Black", 16), text_color="#FF499E", fg_color="#FFFFFF").pack(side="left", padx=(10, 0))

        lbl_subtitle = customtkinter.CTkLabel(header, text="Diskon game PC terbesar, game gratis 100%, dan event resmi Steam (Otomatis 24/7).", font=customtkinter.CTkFont(family="Segoe UI Black", size=12), text_color="#333333")
        lbl_subtitle.pack(pady=(0, 8))

        # Main Scrollable Panel
        self.main_panel = customtkinter.CTkScrollableFrame(self, fg_color="transparent")
        self.main_panel.grid(row=1, column=0, sticky="nsew")
        self.main_panel.grid_columnconfigure(0, weight=1)

        # Category Buttons Frame
        self.cat_frame = customtkinter.CTkFrame(self.main_panel, fg_color="transparent")
        self.cat_frame.pack(fill="x", pady=(0, 10))

        self.btn_free = customtkinter.CTkButton(self.cat_frame, text="🎁 Game Gratis (Freebies)", font=customtkinter.CTkFont(family="Segoe UI Black", size=13), fg_color="#FFD800", text_color="#000000", hover_color="#E6C300", border_width=3, border_color="#000000", corner_radius=0, height=36, command=lambda: self.switch_category("freebies"))
        self.btn_free.pack(side="left", padx=(0, 8))

        self.btn_deals = customtkinter.CTkButton(self.cat_frame, text="🔥 Diskon Besar (Up to 90% OFF)", font=customtkinter.CTkFont(family="Segoe UI Black", size=13), fg_color="#FFFFFF", text_color="#000000", hover_color="#E0E0E0", border_width=3, border_color="#000000", corner_radius=0, height=36, command=lambda: self.switch_category("discounts"))
        self.btn_deals.pack(side="left", padx=(0, 8))

        self.btn_events = customtkinter.CTkButton(self.cat_frame, text="🎪 Steam Events & Sales", font=customtkinter.CTkFont(family="Segoe UI Black", size=13), fg_color="#FFFFFF", text_color="#000000", hover_color="#E0E0E0", border_width=3, border_color="#000000", corner_radius=0, height=36, command=lambda: self.switch_category("events"))
        self.btn_events.pack(side="left")

        # Container for Cards
        self.cards_container = customtkinter.CTkFrame(self.main_panel, fg_color="transparent")
        self.cards_container.pack(fill="both", expand=True)

        self.current_cat = "freebies"
        self.deals_data = {}

        # Initial Loading State
        self.lbl_loading = customtkinter.CTkLabel(self.cards_container, text="⚡ Memuat data promo & game gratisan terbaru...", font=customtkinter.CTkFont(family="Segoe UI Black", size=14), text_color="#555555")
        self.lbl_loading.pack(pady=40)

        # Load Async
        threading.Thread(target=self._async_load_data, daemon=True).start()

    def _async_load_data(self):
        try:
            self.deals_data = fetch_live_deals_and_events()
        except Exception:
            self.deals_data = {"freebies": [], "discounts": [], "events": []}
        self.after(0, lambda: self.render_cards(self.current_cat))

    def switch_category(self, cat_key):
        self.current_cat = cat_key
        # Update button highlights
        self.btn_free.configure(fg_color="#FFD800" if cat_key == "freebies" else "#FFFFFF")
        self.btn_deals.configure(fg_color="#FFD800" if cat_key == "discounts" else "#FFFFFF")
        self.btn_events.configure(fg_color="#FFD800" if cat_key == "events" else "#FFFFFF")
        self.render_cards(cat_key)

    def render_cards(self, cat_key):
        for widget in self.cards_container.winfo_children():
            widget.destroy()

        items = self.deals_data.get(cat_key, [])
        if not items:
            lbl_empty = customtkinter.CTkLabel(self.cards_container, text="Belum ada data promo untuk kategori ini.", font=customtkinter.CTkFont(family="Segoe UI Black", size=14), text_color="#777777")
            lbl_empty.pack(pady=30)
            return

        # Render Cards in 2 columns
        grid_frame = customtkinter.CTkFrame(self.cards_container, fg_color="transparent")
        grid_frame.pack(fill="both", expand=True)
        grid_frame.grid_columnconfigure(0, weight=1)
        grid_frame.grid_columnconfigure(1, weight=1)

        for idx, item in enumerate(items):
            row = idx // 2
            col = idx % 2

            card = customtkinter.CTkFrame(grid_frame, fg_color="#FFFFFF", border_width=3, border_color="#000000", corner_radius=0)
            card.grid(row=row, column=col, padx=8, pady=8, sticky="nsew")

            # Title & Badge
            top_box = customtkinter.CTkFrame(card, fg_color="transparent")
            top_box.pack(fill="x", padx=12, pady=(10, 5))

            badge_text = item.get("savings_pct") or item.get("discount_pct") or "PROMO"
            badge_bg = "#FF499E" if "GRATIS" in item.get("sale_price", "") or badge_text == "100%" else "#10b981"
            
            lbl_badge = customtkinter.CTkLabel(top_box, text=f" {badge_text} ", font=customtkinter.CTkFont(family="Segoe UI Black", size=11), fg_color=badge_bg, text_color="#FFFFFF", corner_radius=0)
            lbl_badge.pack(side="right")

            lbl_name = customtkinter.CTkLabel(top_box, text=item.get("title", ""), font=customtkinter.CTkFont(family="Segoe UI Black", size=13), text_color="#000000", anchor="w")
            lbl_name.pack(side="left", fill="x", expand=True)

            # Price info
            price_box = customtkinter.CTkFrame(card, fg_color="transparent")
            price_box.pack(fill="x", padx=12, pady=(0, 10))

            sale_p = item.get("sale_price") or item.get("final_price") or "GRATIS"
            norm_p = item.get("normal_price") or ""

            lbl_price = customtkinter.CTkLabel(price_box, text=f"Harga: {sale_p}  ", font=customtkinter.CTkFont(family="Segoe UI Black", size=13), text_color="#000000")
            lbl_price.pack(side="left")

            if norm_p and norm_p != sale_p:
                lbl_norm = customtkinter.CTkLabel(price_box, text=norm_p, font=customtkinter.CTkFont(family="Segoe UI", size=11, overstrike=True), text_color="#888888")
                lbl_norm.pack(side="left")

            # Action Button
            target_url = item.get("store_url", "https://store.steampowered.com/")
            store_label = get_store_button_label(target_url, item.get("store_name", ""))
            btn_open = customtkinter.CTkButton(card, text=store_label, font=customtkinter.CTkFont(family="Segoe UI Black", size=12), fg_color="#5D5FEF", hover_color="#4B4DDC", text_color="#FFFFFF", border_width=2, border_color="#000000", corner_radius=0, height=32, command=lambda url=target_url: webbrowser.open(url))
            btn_open.pack(fill="x", padx=12, pady=(0, 12))


def get_store_button_label(url, store_name=""):
    url_lower = (url or "").lower()
    store_lower = (store_name or "").lower()

    if "epicgames" in url_lower or "epic games" in store_lower:
        return "🛒 Klaim di Epic Games"
    elif "ubisoft" in url_lower or "uplay" in url_lower or "ubisoft" in store_lower:
        return "🛒 Klaim di Ubisoft Store"
    elif "gog" in url_lower or "gog.com" in store_lower:
        return "🛒 Klaim di GOG"
    elif "steam" in url_lower or "steampowered" in url_lower:
        return "🛒 Buka di Steam"
    elif "humble" in url_lower:
        return "🛒 Buka di Humble Store"
    else:
        return "🛒 Buka Promo di Web"

