import customtkinter
import tkinter.messagebox as messagebox
from PIL import Image
import os
import sys

from core import discord_auth
from core import profile_manager
from core import database
def resource_path(relative_path):
    if getattr(sys, 'frozen', False):
        base_path = sys._MEIPASS
    else:
        base_path = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
    return os.path.join(base_path, relative_path)

class ProfilePage(customtkinter.CTkFrame):
    def __init__(self, parent, main_app, **kwargs):
        super().__init__(parent, fg_color="#FFFFFF", **kwargs)
        self.parent = main_app
        
        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(1, weight=1)
        
        # Load Data
        self.discord_username = discord_auth.get_cached_username()
        self.prof_data = profile_manager.load_profile()
        self.selected_avatar = self.prof_data.get("avatar", "avatar1.png")
        
        # =========================================================================
        # TOP BAR
        # =========================================================================
        top_bar = customtkinter.CTkFrame(self, fg_color="transparent")
        top_bar.grid(row=0, column=0, columnspan=2, pady=(0, 4), sticky="ew")
        
        # Grid title and star side-by-side to prevent overlaps on fullscreen/resizing
        title = customtkinter.CTkLabel(top_bar, text="👤 MY PROFILE", font=customtkinter.CTkFont(family="Segoe UI Black", size=18), text_color="#000000")
        title.grid(row=0, column=0, sticky="w")
        
        customtkinter.CTkLabel(top_bar, text="✦", font=("Segoe UI Black", 16), text_color="#FF499E", fg_color="#FFFFFF").grid(row=0, column=1, padx=(10, 0), sticky="w")
        
        # =========================================================================
        # LEFT PANEL (Identity Settings)
        # =========================================================================
        self.left_panel = customtkinter.CTkFrame(self, fg_color="#FFFFFF", corner_radius=0, border_width=3, border_color="#000000")
        self.left_panel.grid(row=1, column=0, sticky="ns", pady=(10, 20))
        
        lbl_id = customtkinter.CTkLabel(self.left_panel, text="IDENTITY", font=customtkinter.CTkFont(family="Segoe UI Black", size=18), text_color="#000000")
        lbl_id.pack(pady=(10, 5))
        
        # Avatars
        self.avatar_frame = customtkinter.CTkFrame(self.left_panel, fg_color="transparent")
        self.avatar_frame.pack(pady=10)
        
        self.avatar_buttons = []
        avatars = ["avatar1.png", "avatar2.png", "avatar3.png", "avatar4.png"]
        
        for i, av_file in enumerate(avatars):
            av_path = resource_path(os.path.join("assets", "avatars", av_file))
            if os.path.exists(av_path):
                img = customtkinter.CTkImage(Image.open(av_path), size=(60, 60))
            else:
                img = None
                
            border_col = "#FFD800" if av_file == self.selected_avatar else "#000000"
            btn = customtkinter.CTkButton(
                self.avatar_frame, image=img, text="", width=64, height=64, 
                fg_color="#F4EFEB", hover_color="#E0E0E0", corner_radius=0, 
                border_width=3, border_color=border_col,
                command=lambda f=av_file: self.select_avatar(f)
            )
            btn.grid(row=0, column=i, padx=5)
            self.avatar_buttons.append({"file": av_file, "btn": btn})
            
        # Form
        form_frame = customtkinter.CTkFrame(self.left_panel, fg_color="transparent")
        form_frame.pack(fill="x", padx=20, pady=20)
        
        # Discord Username (Locked)
        lbl_dc = customtkinter.CTkLabel(form_frame, text="Discord Username (Locked)", font=customtkinter.CTkFont(family="Segoe UI Black", size=12), text_color="#555555")
        lbl_dc.pack(anchor="w")
        self.entry_dc = customtkinter.CTkEntry(form_frame, width=300, height=35, fg_color="#E0E0E0", border_color="#000000", border_width=2, text_color="#555555", font=customtkinter.CTkFont(family="Segoe UI", size=14, weight="bold"), corner_radius=0)
        self.entry_dc.pack(anchor="w", pady=(0, 15))
        self.entry_dc.insert(0, self.discord_username)
        self.entry_dc.configure(state="readonly")
        
        # Role (Locked)
        lbl_role = customtkinter.CTkLabel(form_frame, text="Server Role (Locked)", font=customtkinter.CTkFont(family="Segoe UI Black", size=12), text_color="#555555")
        lbl_role.pack(anchor="w")
        self.entry_role = customtkinter.CTkEntry(form_frame, width=300, height=35, fg_color="#E0E0E0", border_color="#000000", border_width=2, text_color="#555555", font=customtkinter.CTkFont(family="Segoe UI", size=14, weight="bold"), corner_radius=0)
        self.entry_role.pack(anchor="w", pady=(0, 15))
        role = getattr(self.parent, "CURRENT_ROLE", "basic").upper()
        self.entry_role.insert(0, role)
        self.entry_role.configure(state="readonly")
        
        # Local Nickname (Editable)
        lbl_nick = customtkinter.CTkLabel(form_frame, text="Local Nickname", font=customtkinter.CTkFont(family="Segoe UI Black", size=12), text_color="#000000")
        lbl_nick.pack(anchor="w")
        self.entry_nick = customtkinter.CTkEntry(form_frame, width=300, height=36, fg_color="#FFFFFF", border_color="#000000", border_width=3, text_color="#000000", font=customtkinter.CTkFont(family="Segoe UI", size=14, weight="bold"), corner_radius=0)
        self.entry_nick.pack(anchor="w", pady=(0, 15))
        self.entry_nick.insert(0, self.prof_data.get("nickname", "Anonymous"))
        
        # Save Button
        self.btn_save = customtkinter.CTkButton(self.left_panel, text="SIMPAN PROFIL", width=250, height=36, fg_color="#00D084", hover_color="#00B875", text_color="#000000", font=customtkinter.CTkFont(family="Segoe UI Black", size=13), corner_radius=0, border_width=3, border_color="#000000", command=self.save_profile)
        self.btn_save.pack(pady=8)
 
        # No right panel history needed here (removed as per user request)
        self.load_history()
        
    def load_history(self):
        # Dummy method to prevent crashes when main.py calls this during switch
        try:
            from core.skeleton import hide_skeleton
            hide_skeleton(self)
        except Exception:
            pass

    def select_avatar(self, filename):
        self.selected_avatar = filename
        for item in self.avatar_buttons:
            if item["file"] == filename:
                item["btn"].configure(border_color="#FFD800")
            else:
                item["btn"].configure(border_color="#000000")
                
    def save_profile(self):
        nick = self.entry_nick.get().strip()
        if not nick:
            messagebox.showerror("Error", "Nickname tidak boleh kosong!", parent=self.winfo_toplevel())
            return
            
        profile_manager.save_profile(nick, self.selected_avatar)
        messagebox.showinfo("Sukses", "Profil berhasil disimpan!", parent=self.winfo_toplevel())
        
        # Trigger update main sidebar user info
        if hasattr(self.parent, 'update_sidebar_profile'):
            self.parent.update_sidebar_profile()

    def update_role_display(self):
        role = getattr(self.parent, "CURRENT_ROLE", "basic").upper()
        self.entry_role.configure(state="normal")
        self.entry_role.delete(0, "end")
        self.entry_role.insert(0, role)
        self.entry_role.configure(state="readonly")
