import os
import sys
import customtkinter
from PIL import Image

class AnnounceImageCropDialog(customtkinter.CTkToplevel):
    def __init__(self, parent, pil_image, callback):
        super().__init__(parent)
        self.title("Sesuaikan Potongan Gambar (Crop)")
        self.transient(parent)
        self.grab_set()
        
        self.pil_image = pil_image.convert("RGB")
        self.callback = callback
        
        # Dimensions
        w = 500
        h = 500
        screen_w = self.winfo_screenwidth()
        screen_h = self.winfo_screenheight()
        pos_x = (screen_w // 2) - (w // 2)
        pos_y = (screen_h // 2) - (h // 2)
        self.geometry(f"{w}x{h}+{pos_x}+{pos_y}")
        self.resizable(False, False)
        self.configure(fg_color="#F4EFEB")
        
        # Neo Brutalist header
        hdr = customtkinter.CTkFrame(self, fg_color="#FFFFFF", border_width=3, border_color="#000000", corner_radius=0, height=50)
        hdr.pack(fill="x", padx=15, pady=(15, 10))
        lbl_title = customtkinter.CTkLabel(hdr, text="✂️ SESUAIKAN CROP BANNER", font=customtkinter.CTkFont(family="Segoe UI Black", size=16), text_color="#000000")
        lbl_title.pack(pady=10)
        
        # Preview Frame
        self.preview_frame = customtkinter.CTkFrame(self, fg_color="#FFFFFF", border_width=3, border_color="#000000", corner_radius=0, width=310, height=174)
        self.preview_frame.pack(padx=20, pady=10)
        self.preview_frame.pack_propagate(False)
        
        self.lbl_preview = customtkinter.CTkLabel(self.preview_frame, text="")
        self.lbl_preview.pack(fill="both", expand=True)
        
        # Target aspect ratio: 16:9
        self.target_w = 640
        self.target_h = 360
        self.aspect_ratio = self.target_w / self.target_h
        
        img_w, img_h = self.pil_image.size
        img_aspect = img_w / img_h
        
        if img_aspect > self.aspect_ratio:
            self.mode = "horizontal"
            self.scaled_h = self.target_h
            self.scaled_w = int(self.target_h * img_aspect)
            try: resampling = Image.Resampling.LANCZOS
            except AttributeError: resampling = Image.ANTIALIAS
            self.scaled_img = self.pil_image.resize((self.scaled_w, self.scaled_h), resampling)
            
            self.max_offset = self.scaled_w - self.target_w
            self.lbl_slider_desc = customtkinter.CTkLabel(self, text="Geser Horizontal untuk Menentukan Fokus Gambar:", font=customtkinter.CTkFont(family="Segoe UI", size=12, weight="bold"), text_color="#000000")
            self.lbl_slider_desc.pack(pady=(10, 2))
            
            self.slider = customtkinter.CTkSlider(self, from_=0, to=self.max_offset, number_of_steps=100, command=self.update_crop_preview, progress_color="#FFD800", button_color="#00D084", button_hover_color="#00B875")
            self.slider.pack(fill="x", padx=40, pady=5)
            self.slider.set(self.max_offset // 2)
        else:
            self.mode = "vertical"
            self.scaled_w = self.target_w
            self.scaled_h = int(self.target_w / img_aspect)
            try: resampling = Image.Resampling.LANCZOS
            except AttributeError: resampling = Image.ANTIALIAS
            self.scaled_img = self.pil_image.resize((self.scaled_w, self.scaled_h), resampling)
            
            self.max_offset = self.scaled_h - self.target_h
            self.lbl_slider_desc = customtkinter.CTkLabel(self, text="Geser Vertikal untuk Menentukan Fokus Gambar:", font=customtkinter.CTkFont(family="Segoe UI", size=12, weight="bold"), text_color="#000000")
            self.lbl_slider_desc.pack(pady=(10, 2))
            
            self.slider = customtkinter.CTkSlider(self, from_=0, to=self.max_offset, number_of_steps=100, command=self.update_crop_preview, progress_color="#FFD800", button_color="#00D084", button_hover_color="#00B875")
            self.slider.pack(fill="x", padx=40, pady=5)
            self.slider.set(self.max_offset // 2)

        self.update_crop_preview()
        
        btn_apply = customtkinter.CTkButton(self, text="💾 TERAPKAN POTONGAN (CROP)", font=customtkinter.CTkFont(family="Segoe UI Black", size=14), text_color="#000000", fg_color="#00D084", hover_color="#00B875", border_width=3, border_color="#000000", corner_radius=0, height=45, command=self.apply_crop)
        btn_apply.pack(pady=(25, 10), fill="x", padx=40)

    def update_crop_preview(self, *args):
        offset = int(self.slider.get())
        from PIL import Image
        if self.mode == "horizontal":
            box = (offset, 0, offset + self.target_w, self.target_h)
        else:
            box = (0, offset, self.target_w, offset + self.target_h)
            
        self.cropped_temp = self.scaled_img.crop(box)
        
        try: resampling = Image.Resampling.LANCZOS
        except AttributeError: resampling = Image.ANTIALIAS
        preview_img = self.cropped_temp.resize((310, 174), resampling)
        
        ctk_img = customtkinter.CTkImage(light_image=preview_img, dark_image=preview_img, size=(310, 174))
        self.lbl_preview.configure(image=ctk_img)
        self.lbl_preview.image = ctk_img

    def apply_crop(self):
        self.callback(self.cropped_temp)
        self.destroy()
