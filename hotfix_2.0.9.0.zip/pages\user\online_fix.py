import customtkinter
import webbrowser
import threading
from components.dialogs import InfoDialog
class OnlineFixPage(customtkinter.CTkFrame):
    def __init__(self, parent, main_app, **kwargs):
        super().__init__(parent, fg_color="#FFFFFF", **kwargs)
        self.parent = main_app
        
        top_bar = customtkinter.CTkFrame(self, fg_color="transparent")
        top_bar.pack(fill="x", pady=(0, 4))
        
        title = customtkinter.CTkLabel(top_bar, text="🌐 Online Fix", font=customtkinter.CTkFont(family="Segoe UI Black", size=18), text_color="#000000")
        title.pack(side="left")
        
        # Pack stars side-by-side to prevent overlaps on fullscreen/resizing
        customtkinter.CTkLabel(top_bar, text="✨", font=("Segoe UI Emoji", 18), fg_color="#FFFFFF").pack(side="left", padx=(10, 0))
        customtkinter.CTkLabel(top_bar, text="✦", font=("Segoe UI Black", 16), text_color="#5D5FEF", fg_color="#FFFFFF").pack(side="left", padx=(4, 0))
        
        self.content_frame = customtkinter.CTkFrame(self, fg_color="#FFFFFF", border_width=3, border_color="#000000", corner_radius=0)
        self.content_frame.pack(fill="both", expand=True, padx=10, pady=10)
        
        self.content_frame.grid_columnconfigure(0, weight=5) # Left side (info)
        self.content_frame.grid_columnconfigure(1, weight=5) # Right side (shared accounts)
        self.content_frame.grid_rowconfigure(0, weight=1)

        # =========================================================================
        # LEFT PANEL (Info & Guides)
        # =========================================================================
        left_panel = customtkinter.CTkFrame(self.content_frame, fg_color="transparent")
        left_panel.grid(row=0, column=0, sticky="nsew", padx=10, pady=10)
        left_panel.grid_columnconfigure(0, weight=1)
        left_panel.grid_rowconfigure((0, 1, 2, 3), weight=1)

        lbl_desc = customtkinter.CTkLabel(left_panel, text="Ubah game menjadi Multiplayer Online!", font=customtkinter.CTkFont(family="Segoe UI Black", size=18), text_color="#000000", wraplength=350)
        lbl_desc.grid(row=0, column=0, pady=(10, 5), sticky="ew")
        
        lbl_sub = customtkinter.CTkLabel(left_panel, text="Unduh file perbaikan (Fix Repair) dan mainkan secara resmi bersama teman Anda.", font=customtkinter.CTkFont(family="Segoe UI Black", size=11), text_color="#555555", wraplength=350)
        lbl_sub.grid(row=1, column=0, pady=(0, 10), sticky="ew")
        
        btn_open = customtkinter.CTkButton(left_panel, text="Buka Online-Fix.me", font=customtkinter.CTkFont(family="Segoe UI Black", size=12), text_color="#000000", fg_color="#5D5FEF", hover_color="#4B4CD9", border_width=3, border_color="#000000", corner_radius=0, height=36, width=240, command=lambda: webbrowser.open("https://online-fix.me/"))
        btn_open.grid(row=2, column=0, pady=5)

        btn_guide = customtkinter.CTkButton(left_panel, text="📖 Baca Panduan", font=customtkinter.CTkFont(family="Segoe UI Black", size=11), text_color="#000000", fg_color="#FFD800", hover_color="#E6C300", border_width=3, border_color="#000000", corner_radius=0, height=36, width=240, command=self.open_onlinefix_guide)
        btn_guide.grid(row=3, column=0, pady=5)

        # =========================================================================
        # RIGHT PANEL (Shared Accounts List)
        # =========================================================================
        right_panel = customtkinter.CTkFrame(self.content_frame, fg_color="transparent")
        right_panel.grid(row=0, column=1, sticky="nsew", padx=10, pady=10)
        right_panel.grid_columnconfigure(0, weight=1)
        right_panel.grid_rowconfigure(1, weight=1)

        # Title block
        title_container = customtkinter.CTkFrame(right_panel, fg_color="transparent")
        title_container.grid(row=0, column=0, sticky="ew", pady=(0, 6))
        title_container.grid_columnconfigure(0, weight=1)

        lbl_sharing = customtkinter.CTkLabel(title_container, text="🔑 ACCOUNTHUB", font=customtkinter.CTkFont(family="Segoe UI Black", size=18), text_color="#000000")
        lbl_sharing.grid(row=0, column=0, sticky="w")

        btn_refresh = customtkinter.CTkButton(
            title_container, text="🔄", width=42, height=32, 
            font=customtkinter.CTkFont(family="Segoe UI Black", size=14), 
            text_color="#000000", fg_color="#00D084", hover_color="#00B875", 
            border_width=3, border_color="#000000", corner_radius=0, 
            command=self.load_shared_accounts
        )
        btn_refresh.grid(row=0, column=1, sticky="e")

        self.accounts_scroll = customtkinter.CTkScrollableFrame(right_panel, fg_color="#F4EFEB", border_width=3, border_color="#000000", corner_radius=0)
        self.accounts_scroll.grid(row=1, column=0, sticky="nsew")

        self.loading_active = False

    def load_shared_accounts(self):
        if self.loading_active:
            return
        self.loading_active = True
        
        # Hanya bersihkan widget dan tampilkan loading di pemuatan pertama
        if not getattr(self, "_first_load_done", False):
            for widget in self.accounts_scroll.winfo_children():
                widget.destroy()
            lbl_load = customtkinter.CTkLabel(self.accounts_scroll, text="Menghubungkan ke Firebase...", font=customtkinter.CTkFont(family="Segoe UI", size=13, weight="bold"), text_color="#333333")
            lbl_load.pack(pady=40)
        
        threading.Thread(target=self._async_load_accounts, daemon=True).start()

    def filter_content(self, query):
        self.search_query = query
        if hasattr(self, "_last_accounts_data") and self._last_accounts_data:
            self._render_accounts(self._last_accounts_data)

    def _async_load_accounts(self):
        import json
        try:
            from core.firebase_sync import fetch_shared_accounts
            accounts_data = fetch_shared_accounts()
            if accounts_data is None:
                accounts_data = {}
        except Exception:
            accounts_data = {}
            
        self._last_accounts_data = accounts_data
        data_hash = hash(json.dumps(accounts_data, sort_keys=True, default=str))
        if getattr(self, "_last_accounts_hash", None) == data_hash:
            self.loading_active = False
            try:
                from core.skeleton import hide_skeleton
                self.after(0, lambda: hide_skeleton(self))
            except Exception:
                pass
            return
            
        self._last_accounts_hash = data_hash
        
        def update_ui():
            self.loading_active = False
            self._first_load_done = True
            self._render_accounts(self._last_accounts_data)
            
        self.after(0, update_ui)

    def _render_accounts(self, accounts_data):
        for widget in self.accounts_scroll.winfo_children():
            widget.destroy()
            
        query = getattr(self, "search_query", "").strip().lower()
        filtered_accounts = {}
        if query:
            for key, acc in accounts_data.items():
                username = acc.get('username', '').lower()
                password = acc.get('password', '').lower()
                if query in key.lower() or query in username or query in password:
                    filtered_accounts[key] = acc
        else:
            filtered_accounts = accounts_data

        if not filtered_accounts:
            lbl_empty = customtkinter.CTkLabel(self.accounts_scroll, text="Tidak ada akun sharing terdaftar.", font=customtkinter.CTkFont(family="Segoe UI", size=13, weight="bold"), text_color="#555555")
            lbl_empty.pack(pady=40)
            try:
                from core.skeleton import hide_skeleton
                hide_skeleton(self)
            except Exception:
                pass
            return

        for key, acc in filtered_accounts.items():
            card = customtkinter.CTkFrame(self.accounts_scroll, fg_color="#FFFFFF", border_width=2, border_color="#000000", corner_radius=0)
            card.pack(fill="x", padx=5, pady=5)
            
            # Platform Tag (Header)
            platform_lbl = customtkinter.CTkLabel(card, text=key.upper(), font=customtkinter.CTkFont(family="Segoe UI Black", size=13), text_color="#000000")
            platform_lbl.pack(anchor="w", padx=10, pady=(5, 5))
            
            # Username Row
            user_frame = customtkinter.CTkFrame(card, fg_color="transparent")
            user_frame.pack(fill="x", padx=10, pady=2)
            
            user_lbl = customtkinter.CTkLabel(user_frame, text=f"User: {acc.get('username', '')}", font=customtkinter.CTkFont(family="Segoe UI", size=12, weight="bold"), text_color="#333333", anchor="w")
            user_lbl.pack(side="left", fill="x", expand=True)
            
            btn_copy_user = customtkinter.CTkButton(user_frame, text="Copy", font=customtkinter.CTkFont(family="Segoe UI Black", size=10), text_color="#000000", fg_color="#FFD800", hover_color="#E6C300", border_width=2, border_color="#000000", corner_radius=0, width=50, height=22)
            btn_copy_user.pack(side="right")
            btn_copy_user.configure(command=lambda u=acc.get('username', ''), b=btn_copy_user: self.copy_to_clipboard(u, b))

            # Password Row
            pass_frame = customtkinter.CTkFrame(card, fg_color="transparent")
            pass_frame.pack(fill="x", padx=10, pady=(2, 8))
            
            pass_lbl = customtkinter.CTkLabel(pass_frame, text=f"Pass: {acc.get('password', '')}", font=customtkinter.CTkFont(family="Segoe UI", size=12, weight="bold"), text_color="#333333", anchor="w")
            pass_lbl.pack(side="left", fill="x", expand=True)
            
            btn_copy_pass = customtkinter.CTkButton(pass_frame, text="Copy", font=customtkinter.CTkFont(family="Segoe UI Black", size=10), text_color="#000000", fg_color="#FFD800", hover_color="#E6C300", border_width=2, border_color="#000000", corner_radius=0, width=50, height=22)
            btn_copy_pass.pack(side="right")
            btn_copy_pass.configure(command=lambda p=acc.get('password', ''), b=btn_copy_pass: self.copy_to_clipboard(p, b))

        try:
            from core.skeleton import hide_skeleton
            hide_skeleton(self)
        except Exception:
            pass

    def copy_to_clipboard(self, text, button):
        self.clipboard_clear()
        self.clipboard_append(text)
        
        # Visual feedback animation
        original_text = button.cget("text")
        button.configure(text="Copied!", fg_color="#00D084")
        
        def restore():
            if button.winfo_exists():
                button.configure(text=original_text, fg_color="#FFD800")
                
        self.after(1000, restore)

    def open_onlinefix_guide(self):
        msg = (
            "📖 PANDUAN MULTIPLAYER (ONLINE-FIX):\n\n"
            "Ikuti langkah-langkah berikut untuk meng-online-kan game Anda:\n\n"
            "1. Klik tombol 'BUKA ONLINE-FIX.ME' di halaman sebelumnya.\n"
            "2. Wajib Login menggunakan akun sharing yang tertera di panel ACCOUNTHUB sebelah kanan.\n"
            "3. Cari game yang ingin dimainkan online di kolom Search web tersebut.\n"
            "4. Scroll ke bawah pada halaman game, temukan 4 tombol download berwarna biru. Pilih tombol ke-3.\n"
            "5. Klik opsi tulisan 'Fix Repair'.\n"
            "6. Akan muncul file .rar untuk diunduh (misal: forzahorizon5_fix_repair.rar). Klik dan download!\n"
            "7. Ekstrak file .rar tersebut (Password ekstrak: online-fix.me).\n"
            "8. Salin (Copy) semua isi folder hasil ekstrak tadi, lalu Timpa (Paste / Replace) ke dalam folder direktori instalasi game Anda.\n\n"
            "Selesai! Jalankan game lewat Steam atau file .exe gamenya, dan nikmati fitur Multiplayer Online bersama teman Anda!"
        )
        self.info_dialog = InfoDialog(self.parent, "Panduan Online Fix", msg)
