import customtkinter
import webbrowser
import sys
import os
import subprocess

def set_dialog_icon(dialog):
    try:
        if getattr(sys, 'frozen', False):
            base_path = sys._MEIPASS
        else:
            base_path = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
        icon_path = os.path.join(base_path, 'assets', 'app_icon_real.ico')
        dialog.iconbitmap(icon_path)
    except Exception:
        pass

class LoadingDialog(customtkinter.CTkToplevel):
    def __init__(self, parent, mode="inject"):
        super().__init__(parent)
        if mode == "inject": win_title = "Proses Injeksi"
        elif mode == "netfix": win_title = "Perbaikan Koneksi"
        else: win_title = "Pembaruan Aplikasi"
        self.title(win_title)
        set_dialog_icon(self)
        
        w, h = 500, 420
        self.resizable(False, False)
        self.transient(parent)
        self.grab_set()

        self.update_idletasks()
        try:
            x = parent.winfo_rootx() + (parent.winfo_width() // 2) - (w // 2)
            y = parent.winfo_rooty() + (parent.winfo_height() // 2) - (h // 2)
        except Exception:
            x = self.winfo_screenwidth() // 2 - w // 2
            y = self.winfo_screenheight() // 2 - h // 2
        self.geometry(f"{w}x{h}+{x}+{y}")
        self.configure(fg_color="#F4EFEB")

        if mode == "inject": title_text = "Inject Berlangsung"
        elif mode == "netfix": title_text = "Memperbaiki Koneksi"
        else: title_text = "Mengunduh Pembaruan"

        lbl_title = customtkinter.CTkLabel(self, text=title_text, font=customtkinter.CTkFont(family="Segoe UI Black", size=24), text_color="#000000")
        lbl_title.pack(pady=(20, 15))
        
        # Decorations
        customtkinter.CTkLabel(self, text="✨", font=("Segoe UI Emoji", 24), fg_color="#F4EFEB").place(x=30, y=20)
        customtkinter.CTkLabel(self, text="✦", font=("Segoe UI Black", 20), text_color="#FF499E", fg_color="#F4EFEB").place(x=430, y=10)
        customtkinter.CTkLabel(self, text="*", font=("Segoe UI Black", 40), text_color="#5D5FEF", fg_color="#F4EFEB").place(x=40, y=340)
        customtkinter.CTkLabel(self, text="✔", font=("Segoe UI Emoji", 28), text_color="#00D084", fg_color="#F4EFEB").place(x=430, y=340)
        
        if mode == "inject":
            self.servers = {
                "Lightning Repo": {"label": "Lightning Repo", "var": customtkinter.StringVar(value="Menunggu...")},
                "SkyApi": {"label": "SkyApi Cloud", "var": customtkinter.StringVar(value="Menunggu...")},
                "Sushi Repo": {"label": "Sushi Repo", "var": customtkinter.StringVar(value="Menunggu...")}
            }
        elif mode == "netfix":
            self.servers = {
                "GitHub": {"label": "GitHub Mirror", "var": customtkinter.StringVar(value="Menunggu...")},
                "ManifestHub": {"label": "ManifestHub API", "var": customtkinter.StringVar(value="Menunggu...")}
            }
        else:
            self.servers = {}

        self.server_frames = {}
        for key, data in self.servers.items():
            f = customtkinter.CTkFrame(self, fg_color="#FFFFFF", border_width=3, border_color="#000000", corner_radius=0)
            f.pack(fill="x", padx=30, pady=5)
            customtkinter.CTkLabel(f, text=data["label"], font=customtkinter.CTkFont(family="Segoe UI Black", size=14), text_color="#000000").pack(side="left", padx=15, pady=10)
            status_lbl = customtkinter.CTkLabel(f, textvariable=data["var"], font=customtkinter.CTkFont(family="Segoe UI Black", size=13), text_color="#555555")
            status_lbl.pack(side="right", padx=15, pady=10)
            self.server_frames[key] = {"frame": f, "status_lbl": status_lbl}
            
        self.lbl_progress = customtkinter.CTkLabel(self, text="☁ Memulai...", font=customtkinter.CTkFont(family="Segoe UI Black", size=14), text_color="#000000")
        self.lbl_progress.pack(pady=(15, 5))
        
        self.progressbar = customtkinter.CTkProgressBar(self, mode="indeterminate", fg_color="#FFFFFF", progress_color="#5D5FEF", border_color="#000000", border_width=3, corner_radius=0, height=12)
        self.progressbar.pack(fill="x", padx=30, pady=5)
        self.progressbar.start()
        
        self.lbl_mb = customtkinter.CTkLabel(self, text="", font=customtkinter.CTkFont(family="Segoe UI", size=12, weight="bold"), text_color="#333333", wraplength=440, justify="center")
        self.lbl_mb.pack(anchor="center", padx=30, pady=(5, 0))
        
        self.btn_ok = customtkinter.CTkButton(self, text="Sembunyikan", command=self.destroy, width=150, height=35, fg_color="#FF499E", hover_color="#E63F8A", border_color="#000000", border_width=3, text_color="#000000", font=customtkinter.CTkFont(family="Segoe UI Black", size=12), corner_radius=0)
        self.btn_ok.pack(pady=(5, 20))

    def update_status(self, text):
        if isinstance(text, dict):
            if text.get("type") == "progress":
                dl = text.get("downloaded", 0)
                tot = text.get("total", 0)
                if tot > 0:
                    self.progressbar.configure(mode="determinate")
                    self.progressbar.set(dl / tot)
                    self.lbl_mb.configure(text=f"Mendownload: {dl/1024/1024:.2f} MB / {tot/1024/1024:.2f} MB")
                else:
                    self.progressbar.configure(mode="indeterminate")
                    if not self.progressbar._is_started: self.progressbar.start()
                    self.lbl_mb.configure(text=f"Mendownload: {dl/1024/1024:.2f} MB")
                return
            else:
                text = text.get("msg", "")

        self.lbl_progress.configure(text=f"☁️ {text}")
        
        if "Menghubungkan ke" in text:
            for s in self.servers.keys():
                if self.servers[s]["var"].get() == "Mencari..." or self.servers[s]["var"].get() == "Mencari...":
                    self.servers[s]["var"].set("Dilewati ➖")
                    self.server_frames[s]["status_lbl"].configure(text_color="#ef4444")
            for s in self.servers.keys():
                if s in text:
                    self.servers[s]["var"].set("Mencari...")
                    self.server_frames[s]["status_lbl"].configure(text_color="#F59E0B")
        elif "Mengunduh" in text:
            for s in self.servers.keys():
                if s in text:
                    self.servers[s]["var"].set("Ditemukan ✔️")
                    self.server_frames[s]["status_lbl"].configure(text_color="#10B981")

    def set_done(self, success, message):
        self.progressbar.stop()
        self.progressbar.configure(mode="determinate")
        self.progressbar.set(1.0 if success else 0.0)
        
        if success:
            self.lbl_progress.configure(text="☁️ BERHASIL!", text_color="#10b981")
            self.lbl_mb.configure(text=message, text_color="#10b981")
        else:
            self.lbl_progress.configure(text="⚠️ GAGAL!", text_color="#ef4444")
            self.lbl_mb.configure(text=message, text_color="#ef4444")
            
        self.btn_ok.configure(text="Tutup")

class InfoDialog(customtkinter.CTkToplevel):
    def __init__(self, parent, title, message):
        super().__init__(parent)
        self.title(title)
        set_dialog_icon(self)
        
        w = 600
        h = 450
        x = self.winfo_screenwidth() // 2 - w // 2
        y = self.winfo_screenheight() // 2 - h // 2
        
        if parent:
            x = parent.winfo_rootx() + (parent.winfo_width() // 2) - (w // 2)
            y = parent.winfo_rooty() + (parent.winfo_height() // 2) - (h // 2)

        self.geometry(f"{w}x{h}+{x}+{y}")
        self.configure(fg_color="#F4EFEB")
        self.attributes("-topmost", True)
        self.grab_set()
        
        lbl_title = customtkinter.CTkLabel(self, text=title, font=customtkinter.CTkFont(family="Segoe UI Black", size=24), text_color="#000000")
        lbl_title.pack(pady=(20, 10))
        
        # Decorations
        customtkinter.CTkLabel(self, text="✦", font=("Segoe UI Black", 20), text_color="#FF499E", fg_color="#F4EFEB").place(x=20, y=10)
        customtkinter.CTkLabel(self, text="🙂", font=("Segoe UI Emoji", 24), fg_color="#F4EFEB").place(x=540, y=15)
        
        frame = customtkinter.CTkFrame(self, fg_color="#FFFFFF", border_width=3, border_color="#000000", corner_radius=0)
        frame.pack(fill="both", expand=True, padx=20, pady=(0, 20))
        
        textbox = customtkinter.CTkTextbox(frame, font=customtkinter.CTkFont(family="Segoe UI", size=13, weight="bold"), text_color="#000000", fg_color="transparent", wrap="word")
        textbox.pack(fill="both", expand=True, padx=10, pady=10)
        textbox.insert("0.0", message)
        textbox.configure(state="disabled")

        def _fade_in(step=0):
            if step <= 10:
                self.attributes("-alpha", step/10.0)
                self.after(16, lambda: _fade_in(step+1))
                
        self.attributes("-alpha", 0.0)
        _fade_in()

class WarningDialog(customtkinter.CTkToplevel):
    def __init__(self, parent, title, message):
        super().__init__(parent)
        self.title(title)
        set_dialog_icon(self)
        
        w = 400
        h = 250
        self.update_idletasks()
        try:
            x = parent.winfo_rootx() + (parent.winfo_width() // 2) - (w // 2)
            y = parent.winfo_rooty() + (parent.winfo_height() // 2) - (h // 2)
        except Exception:
            x = self.winfo_screenwidth() // 2 - w // 2
            y = self.winfo_screenheight() // 2 - h // 2

        self.geometry(f"{w}x{h}+{x}+{y}")
        self.configure(fg_color="#F4EFEB")
        self.attributes("-topmost", True)
        self.grab_set()
        
        lbl_title = customtkinter.CTkLabel(self, text=title, font=customtkinter.CTkFont(family="Segoe UI Black", size=24), text_color="#000000")
        lbl_title.pack(pady=(15, 5))
        
        frame = customtkinter.CTkFrame(self, fg_color="#FFFFFF", border_width=3, border_color="#000000", corner_radius=0)
        frame.pack(fill="both", expand=True, padx=20, pady=(0, 15))
        
        textbox = customtkinter.CTkTextbox(frame, font=customtkinter.CTkFont(family="Segoe UI", size=13, weight="bold"), text_color="#000000", fg_color="transparent", wrap="word")
        textbox.pack(fill="both", expand=True, padx=5, pady=5)
        textbox.insert("0.0", message)
        textbox.configure(state="disabled")
        
        btn_ok = customtkinter.CTkButton(self, text="Mengerti", font=customtkinter.CTkFont(family="Segoe UI Black", size=12), text_color="#000000", fg_color="#FF499E", hover_color="#E63F8A", corner_radius=0, border_width=3, border_color="#000000", command=self.destroy)
        btn_ok.pack(pady=(0, 15))

class ReadyToUpdateDialog(customtkinter.CTkToplevel):
    def __init__(self, parent, new_version, changelog, installer_path):
        super().__init__(parent)
        self.title("Pembaruan Tersedia")
        set_dialog_icon(self)
        
        w = 500
        h = 450
        self.update_idletasks()
        try:
            x = parent.winfo_rootx() + (parent.winfo_width() // 2) - (w // 2)
            y = parent.winfo_rooty() + (parent.winfo_height() // 2) - (h // 2)
        except Exception:
            x = self.winfo_screenwidth() // 2 - w // 2
            y = self.winfo_screenheight() // 2 - h // 2
        self.geometry(f"{w}x{h}+{x}+{y}")
        self.configure(fg_color="#F4EFEB")
        self.attributes("-topmost", True)
        self.grab_set()

        lbl_title = customtkinter.CTkLabel(self, text="Pembaruan Siap Dipasang!", font=customtkinter.CTkFont(family="Segoe UI Black", size=28), text_color="#000000")
        lbl_title.pack(pady=(20, 5))
        
        # Decorations
        customtkinter.CTkLabel(self, text="✨", font=("Segoe UI Emoji", 24), fg_color="#F4EFEB").place(x=20, y=10)
        customtkinter.CTkLabel(self, text="✦", font=("Segoe UI Black", 20), text_color="#5D5FEF", fg_color="#F4EFEB").place(x=450, y=10)
        customtkinter.CTkLabel(self, text="*", font=("Segoe UI Black", 40), text_color="#FF499E", fg_color="#F4EFEB").place(x=30, y=380)
        customtkinter.CTkLabel(self, text="✔", font=("Segoe UI Emoji", 28), text_color="#00D084", fg_color="#F4EFEB").place(x=430, y=390)
        
        lbl_version = customtkinter.CTkLabel(self, text=f"Versi Baru Ditemukan: v{new_version}", font=customtkinter.CTkFont(family="Segoe UI Black", size=14), text_color="#333333")
        lbl_version.pack(pady=(0, 15))

        frame = customtkinter.CTkFrame(self, fg_color="#FFFFFF", border_width=3, border_color="#000000", corner_radius=0)
        frame.pack(fill="both", expand=True, padx=25, pady=(0, 15))
        
        textbox = customtkinter.CTkTextbox(frame, font=customtkinter.CTkFont(family="Segoe UI", size=13, weight="bold"), text_color="#000000", fg_color="transparent", wrap="word")
        textbox.pack(fill="both", expand=True, padx=10, pady=10)
        textbox.insert("0.0", changelog)
        textbox.configure(state="disabled")

        def run_update():
            try:
                import ctypes
                ctypes.windll.shell32.ShellExecuteW(None, "runas", installer_path, "/SILENT", None, 1)
                sys.exit(0)
            except Exception as e:
                pass

        btn_install = customtkinter.CTkButton(self, text="Restart & Perbarui Sekarang", font=customtkinter.CTkFont(family="Segoe UI Black", size=16), text_color="#000000", fg_color="#00D084", hover_color="#00B875", border_width=3, border_color="#000000", corner_radius=0, height=45, command=run_update)
        btn_install.pack(fill="x", padx=25, pady=(0, 10))

        btn_close = customtkinter.CTkButton(self, text="Nanti Saja", font=customtkinter.CTkFont(family="Segoe UI Black", size=14), text_color="#000000", fg_color="#FFFFFF", hover_color="#E0E0E0", corner_radius=0, border_width=3, border_color="#000000", height=35, command=self.destroy)
        btn_close.pack(pady=(0, 20))

class MandatoryUpdateDialog(customtkinter.CTkToplevel):
    def __init__(self, parent, new_version, changelog, download_url):
        super().__init__(parent)
        self.parent = parent
        self.download_url = download_url
        self.title("Pembaruan Wajib Tersedia")
        set_dialog_icon(self)
        
        # Nonaktifkan tombol close (X)
        self.protocol("WM_DELETE_WINDOW", lambda: None)
        
        w = 500
        h = 450
        self.update_idletasks()
        try:
            x = parent.winfo_rootx() + (parent.winfo_width() // 2) - (w // 2)
            y = parent.winfo_rooty() + (parent.winfo_height() // 2) - (h // 2)
        except Exception:
            x = self.winfo_screenwidth() // 2 - w // 2
            y = self.winfo_screenheight() // 2 - h // 2
        self.geometry(f"{w}x{h}+{x}+{y}")
        self.configure(fg_color="#F4EFEB")
        self.attributes("-topmost", True)
        self.grab_set()

        lbl_title = customtkinter.CTkLabel(self, text="Pembaruan Wajib!", font=customtkinter.CTkFont(family="Segoe UI Black", size=28), text_color="#000000")
        lbl_title.pack(pady=(20, 5))
        
        lbl_version = customtkinter.CTkLabel(self, text=f"Versi Baru: v{new_version}", font=customtkinter.CTkFont(family="Segoe UI Black", size=14), text_color="#333333")
        lbl_version.pack(pady=(0, 15))

        frame = customtkinter.CTkFrame(self, fg_color="#FFFFFF", border_width=3, border_color="#000000", corner_radius=0)
        frame.pack(fill="both", expand=True, padx=25, pady=(0, 15))
        
        textbox = customtkinter.CTkTextbox(frame, font=customtkinter.CTkFont(family="Segoe UI", size=13, weight="bold"), text_color="#000000", fg_color="transparent", wrap="word")
        textbox.pack(fill="both", expand=True, padx=10, pady=10)
        textbox.insert("0.0", changelog)
        textbox.configure(state="disabled")

        def start_download_and_update():
            # Hancurkan dialog ini, lalu munculkan dialog loading
            self.destroy()
            loading = LoadingDialog(self.parent, mode="update")
            loading.update_status("Mengunduh Pembaruan...\nMohon jangan tutup aplikasi.")
            
            def download_worker():
                import os, requests, sys, ctypes
                appdata = os.getenv('LOCALAPPDATA', '')
                temp_dir = os.path.join(appdata, 'GameZone', 'temp')
                if not os.path.exists(temp_dir):
                    try: os.makedirs(temp_dir)
                    except: pass
                    
                installer_path = os.path.join(temp_dir, "GameZone_Update_Installer.exe")
                headers = {
                    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36",
                    "Accept": "*/*",
                    "Connection": "keep-alive"
                }
                
                urls_to_try = [self.download_url]
                # If GitHub release URL, fallback to raw CDN URL if connection gets reset
                if "github.com" in self.download_url and "releases/download" in self.download_url:
                    filename = self.download_url.split("/")[-1]
                    urls_to_try.append(f"https://raw.githubusercontent.com/mhmdaryaqadi/GameZone-Release/main/{filename}")

                success = False
                last_error = ""
                for target_url in urls_to_try:
                    try:
                        dl_res = requests.get(target_url, headers=headers, stream=True, timeout=30, allow_redirects=True)
                        if dl_res.status_code == 200:
                            with open(installer_path, 'wb') as f:
                                for chunk in dl_res.iter_content(chunk_size=16384):
                                    if chunk:
                                        f.write(chunk)
                            success = True
                            break
                        else:
                            last_error = f"Server mengembalikan status {dl_res.status_code}"
                    except Exception as err:
                        last_error = str(err)
                        continue

                if success:
                    loading.update_status("Pemasangan otomatis dimulai...")
                    ctypes.windll.shell32.ShellExecuteW(None, "runas", installer_path, "/SILENT", None, 1)
                    os._exit(0)
                else:
                    loading.set_done(False, f"Terjadi kesalahan saat mengunduh: {last_error}")

            import threading
            threading.Thread(target=download_worker, daemon=True).start()

        btn_install = customtkinter.CTkButton(self, text="OK (Perbarui Sekarang)", font=customtkinter.CTkFont(family="Segoe UI Black", size=16), text_color="#000000", fg_color="#00D084", hover_color="#00B875", border_width=3, border_color="#000000", corner_radius=0, height=45, command=start_download_and_update)
        btn_install.pack(fill="x", padx=25, pady=(0, 20))


class DiagnosticDialog(customtkinter.CTkToplevel):
    def __init__(self, parent):
        super().__init__(parent)
        self.parent = parent
        self.title("Diagnostik Kesehatan Game")
        set_dialog_icon(self)

        w, h = 600, 520
        self.resizable(False, False)
        self.transient(parent)
        self.grab_set()

        self.update_idletasks()
        try:
            x = parent.winfo_rootx() + (parent.winfo_width() // 2) - (w // 2)
            y = parent.winfo_rooty() + (parent.winfo_height() // 2) - (h // 2)
        except Exception:
            x = self.winfo_screenwidth() // 2 - w // 2
            y = self.winfo_screenheight() // 2 - h // 2
        self.geometry(f"{w}x{h}+{x}+{y}")
        self.configure(fg_color="#F4EFEB")

        lbl_title = customtkinter.CTkLabel(self, text="🔍 Diagnostik & Health Check", font=customtkinter.CTkFont(family="Segoe UI Black", size=22), text_color="#000000")
        lbl_title.pack(pady=(15, 5))

        self.lbl_subtitle = customtkinter.CTkLabel(self, text="⚡ Memindai seluruh library Steam lokal...", font=customtkinter.CTkFont(family="Segoe UI Black", size=13), text_color="#555555")
        self.lbl_subtitle.pack(pady=(0, 10))

        self.list_frame = customtkinter.CTkScrollableFrame(self, fg_color="#FFFFFF", border_width=3, border_color="#000000", corner_radius=0)
        self.list_frame.pack(fill="both", expand=True, padx=20, pady=(0, 15))

        self.btn_repair = customtkinter.CTkButton(self, text="⚡ PERBAIKI SEMUA SEKARANG (1-KLIK)", font=customtkinter.CTkFont(family="Segoe UI Black", size=15), fg_color="#FFD800", hover_color="#E6C300", text_color="#000000", border_width=3, border_color="#000000", corner_radius=0, height=42, command=self._start_repair)
        self.btn_repair.pack(fill="x", padx=20, pady=(0, 15))

        self.reports_data = []
        import threading
        threading.Thread(target=self._async_scan, daemon=True).start()

    def _async_scan(self):
        try:
            from services.diagnostic_service import scan_all_games_health
            result = scan_all_games_health()
            self.reports_data = result.get("reports", [])
            healthy = result.get("healthy_count", 0)
            issues = result.get("issues_count", 0)

            def _update_ui():
                if not self.winfo_exists(): return
                if issues == 0:
                    self.lbl_subtitle.configure(text=f"🟢 Semua Game Sehat! ({healthy} Game Terpindai Normal)", text_color="#10b981")
                else:
                    self.lbl_subtitle.configure(text=f"⚠️ Ditemukan {issues} Game Bermasalah! (Dari {healthy + issues} Game)", text_color="#ef4444")
                self._render_list()

            self.after(0, _update_ui)
        except Exception as e:
            def _err():
                if not self.winfo_exists(): return
                self.lbl_subtitle.configure(text=f"Error saat memindai: {e}", text_color="#ef4444")
            self.after(0, _err)

    def _render_list(self):
        for w in self.list_frame.winfo_children():
            w.destroy()

        if not self.reports_data:
            customtkinter.CTkLabel(self.list_frame, text="Tidak ada game Steam terdeteksi.", font=customtkinter.CTkFont(family="Segoe UI Black", size=13), text_color="#777777").pack(pady=30)
            return

        for item in self.reports_data:
            box = customtkinter.CTkFrame(self.list_frame, fg_color="#F9F9F9", border_width=2, border_color="#000000", corner_radius=0)
            box.pack(fill="x", padx=5, pady=4)

            name = item.get("name", "Unknown Game")
            status = item.get("status")
            issues = item.get("issues", [])

            badge_txt = "🟢 Sehat" if status == "healthy" else "🟡 Butuh Perbaikan"
            badge_bg = "#10b981" if status == "healthy" else "#f59e0b"

            top_row = customtkinter.CTkFrame(box, fg_color="transparent")
            top_row.pack(fill="x", padx=10, pady=5)

            customtkinter.CTkLabel(top_row, text=name, font=customtkinter.CTkFont(family="Segoe UI Black", size=13), text_color="#000000").pack(side="left")
            customtkinter.CTkLabel(top_row, text=f" {badge_txt} ", font=customtkinter.CTkFont(family="Segoe UI Black", size=11), fg_color=badge_bg, text_color="#FFFFFF").pack(side="right")

            if issues:
                for iss in issues:
                    customtkinter.CTkLabel(box, text=f"• {iss}", font=customtkinter.CTkFont(family="Segoe UI", size=11, weight="bold"), text_color="#ef4444", anchor="w").pack(fill="x", padx=15, pady=(0, 2))

    def _start_repair(self):
        self.btn_repair.configure(state="disabled", text="⏳ Sedang Memperbaiki Semua Game...")
        def _worker():
            try:
                from services.diagnostic_service import repair_all_diagnosed_issues
                ok, cnt, msg = repair_all_diagnosed_issues(self.reports_data)
                def _done():
                    if not self.winfo_exists(): return
                    self.btn_repair.configure(state="normal", text="⚡ PERBAIKI SEMUA SEKARANG (1-KLIK)")
                    import tkinter.messagebox as messagebox
                    messagebox.showinfo("Berhasil", f"{msg}\n\nSilakan restart Steam sekarang.", parent=self)
                    self._async_scan()
                self.after(0, _done)
            except Exception as e:
                def _err():
                    if not self.winfo_exists(): return
                    self.btn_repair.configure(state="normal", text="⚡ PERBAIKI SEMUA SEKARANG (1-KLIK)")
                    import tkinter.messagebox as messagebox
                    messagebox.showerror("Gagal", str(e), parent=self.winfo_toplevel())
                self.after(0, _err)
        import threading
        threading.Thread(target=_worker, daemon=True).start()

