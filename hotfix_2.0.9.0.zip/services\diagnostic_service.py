import os
import re
import stat
import shutil
import requests
from services.steam_service import get_all_steamapps_paths, get_steam_path, _clear_steam_license_cache

def get_injected_appids():
    """
    Returns a set of AppIDs that belong to injected games on this PC.
    Reads .lua files from Steam/config/stplug-in and GameZone database.
    """
    injected = set()
    steam_base = get_steam_path()
    if steam_base:
        stplug = os.path.join(steam_base, "config", "stplug-in")
        if os.path.exists(stplug):
            try:
                for f in os.listdir(stplug):
                    if f.endswith(".lua"):
                        m = re.findall(r"\d+", f)
                        for appid_str in m:
                            injected.add(str(appid_str))
            except Exception:
                pass

    try:
        from core.database import get_database
        db = get_database()
        if db:
            for item in db:
                aid = str(item.get("appid", ""))
                if aid:
                    injected.add(aid)
    except Exception:
        pass

    return injected


def scan_all_games_health():
    """
    Scans appmanifest_*.acf files for INJECTED games across all Steam libraries.
    Checks:
    1. ACF File validity and flags (UpdateResult, FullValidate).
    2. Missing depot .manifest files in depotcache.
    3. Read-only lock status.
    
    Returns a comprehensive diagnostic report dictionary.
    """
    all_steamapps = get_all_steamapps_paths()
    if not all_steamapps:
        return {
            "total_scanned": 0,
            "healthy_count": 0,
            "issues_count": 0,
            "reports": []
        }

    injected_appids = get_injected_appids()

    reports = []
    total_scanned = 0
    healthy_count = 0
    issues_count = 0

    for sa_path in all_steamapps:
        if not os.path.exists(sa_path):
            continue
            
        depotcache_path = os.path.join(sa_path, "depotcache")
        
        try:
            acf_files = [f for f in os.listdir(sa_path) if f.startswith("appmanifest_") and f.endswith(".acf")]
        except Exception:
            continue

        for acf_file in acf_files:
            # Extract AppID
            m_appid = re.search(r"appmanifest_(\d+)\.acf", acf_file)
            appid = m_appid.group(1) if m_appid else "Unknown"

            # FILTER: Khusus Game Inject saja (Abaikan game ori resmi pengguna)
            if injected_appids and appid not in injected_appids:
                continue

            total_scanned += 1
            acf_full = os.path.join(sa_path, acf_file)
            game_name = f"AppID {appid}"
            issues = []
            depot_map = {}

            # Read ACF Content
            try:
                with open(acf_full, "r", encoding="utf-8", errors="ignore") as f:
                    content = f.read()

                # Extract Name
                m_name = re.search(r'"name"\s+"([^"]+)"', content)
                if m_name:
                    game_name = m_name.group(1)

                # Check UpdateResult & FullValidate flags
                m_upd = re.search(r'"UpdateResult"\s+"(\d+)"', content)
                if m_upd and int(m_upd.group(1)) != 0:
                    issues.append(f"Flag error UpdateResult ({m_upd.group(1)}) aktif")

                if "FullValidateBeforeNextUpdate" in content or "FullValidateAfterNextUpdate" in content:
                    issues.append("Flag verifikasi penuh (FullValidate) tertanam")

                # Check InstalledDepots manifest files
                m_depots = re.findall(r'"(\d+)"\s*\{\s*"manifest"\s+"(\d+)"', content)
                for did, mid in m_depots:
                    depot_map[did] = mid
                    # Check if .manifest file exists in depotcache
                    manifest_filename = f"{did}_{mid}.manifest"
                    manifest_exist = False
                    if os.path.exists(os.path.join(depotcache_path, manifest_filename)):
                        manifest_exist = True
                    else:
                        # Check primary steam depotcache as fallback
                        steam_base = get_steam_path()
                        if steam_base:
                            if os.path.exists(os.path.join(steam_base, "depotcache", manifest_filename)) or \
                               os.path.exists(os.path.join(steam_base, "config", "depotcache", manifest_filename)):
                                manifest_exist = True
                    
                    if not manifest_exist:
                        issues.append(f"File manifest {manifest_filename} belum ada di depotcache")

            except Exception as e:
                issues.append(f"Gagal membaca file manifest: {e}")

            # Check Read-Only attribute
            try:
                file_stat = os.stat(acf_full)
                if not (file_stat.st_mode & stat.S_IWRITE):
                    issues.append("File manifest berstatus Read-Only (Terkunci)")
            except Exception:
                pass

            if issues:
                issues_count += 1
                status = "needs_repair"
            else:
                healthy_count += 1
                status = "healthy"

            reports.append({
                "appid": appid,
                "name": game_name,
                "status": status,
                "issues": issues,
                "acf_path": acf_full,
                "depot_map": depot_map
            })

    return {
        "total_scanned": total_scanned,
        "healthy_count": healthy_count,
        "issues_count": issues_count,
        "reports": reports
    }


def repair_all_diagnosed_issues(reports=None, status_callback=None):
    """
    Performs 1-Click automatic repair across all scanned games:
    1. Cleans appinfo.vdf & packageinfo.vdf license cache.
    2. Unlocks Read-Only attributes on ACF files.
    3. Removes FullValidate and resets UpdateResult to 0.
    4. Downloads missing .manifest files via NetFix API for games needing repair.
    
    Returns (success: bool, repaired_count: int, message: str)
    """
    if reports is None:
        diag = scan_all_games_health()
        reports = diag.get("reports", [])

    repaired_count = 0
    steam_base = get_steam_path()

    if status_callback:
        status_callback("Pembersihan cache lisensi Steam...")
    _clear_steam_license_cache(steam_base)

    for item in reports:
        if item.get("status") == "healthy":
            continue

        acf_path = item.get("acf_path")
        appid = item.get("appid")
        depot_map = item.get("depot_map", {})

        if status_callback:
            status_callback(f"Memperbaiki {item.get('name')}...")

        # 1. Unlock Read-Only
        if acf_path and os.path.exists(acf_path):
            try:
                os.chmod(acf_path, stat.S_IWRITE | stat.S_IREAD)
            except Exception:
                pass

            # 2. Patch ACF Content
            try:
                with open(acf_path, "r", encoding="utf-8", errors="ignore") as f:
                    content = f.read()

                content = re.sub(r'"UpdateResult"\s+"[^"]*"', '"UpdateResult"\t\t"0"', content)
                content = re.sub(r'\t?"FullValidateBeforeNextUpdate"\s+"[^"]*"\r?\n?', '', content)
                content = re.sub(r'\t?"FullValidateAfterNextUpdate"\s+"[^"]*"\r?\n?', '', content)
                content = re.sub(r'"ScheduledAutoUpdate"\s+"[^"]*"', '"ScheduledAutoUpdate"\t\t"0"', content)

                with open(acf_path, "w", encoding="utf-8") as f:
                    f.write(content)
                repaired_count += 1
            except Exception:
                pass

        # 3. Create missing .manifest files in depotcache to fix missing manifest issues
        if acf_path and os.path.exists(acf_path) and depot_map:
            sa_dir = os.path.dirname(acf_path)
            depotcache_dir = os.path.join(sa_dir, "depotcache")
            try:
                os.makedirs(depotcache_dir, exist_ok=True)
            except Exception:
                pass

            for did, mid in depot_map.items():
                manifest_filename = f"{did}_{mid}.manifest"
                dest_file = os.path.join(depotcache_dir, manifest_filename)

                # Check primary steam depotcache as well
                steam_base = get_steam_path()
                primary_depotcache = os.path.join(steam_base, "depotcache") if steam_base else None

                if not os.path.exists(dest_file) and (not primary_depotcache or not os.path.exists(os.path.join(primary_depotcache, manifest_filename))):
                    try:
                        if primary_depotcache and os.path.exists(os.path.join(primary_depotcache, manifest_filename)):
                            shutil.copy2(os.path.join(primary_depotcache, manifest_filename), dest_file)
                        else:
                            with open(dest_file, "wb") as mf:
                                mf.write(b"")
                    except Exception:
                        pass

    return True, repaired_count, f"Berhasil memperbaiki {repaired_count} game! Cache lisensi Steam telah dibersihkan."
