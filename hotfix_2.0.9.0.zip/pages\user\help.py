import customtkinter
import threading
import datetime
import tkinter.messagebox as messagebox
from core.firebase_sync import submit_bug_report

class BugReportDialog(customtkinter.CTkToplevel):
    def __init__(self, parent, username, **kwargs):
        super().__init__(parent, **kwargs)
        self.parent = parent
        self.username = username
        
        self.title("Laporan Masalah (Bug Report)")
        self.transient(parent)
        self.grab_set()
        
        # Dimensions
        w = 480
        h = 360
        screen_w = self.winfo_screenwidth()
        screen_h = self.winfo_screenheight()
        pos_x = (screen_w // 2) - (w // 2)
        pos_y = (screen_h // 2) - (h // 2)
        self.geometry(f"{w}x{h}+{pos_x}+{pos_y}")
        self.resizable(False, False)
        self.configure(fg_color="#F4EFEB")
        
        # Header Neo Brutalist
        hdr = customtkinter.CTkFrame(self, fg_color="#FFFFFF", border_width=3, border_color="#000000", corner_radius=0, height=50)
        hdr.pack(fill="x", padx=15, pady=(15, 10))
        lbl_title = customtkinter.CTkLabel(hdr, text=f"⚠️ {'Laporan Masalah (Bug Report)'.upper()}", font=customtkinter.CTkFont(family="Segoe UI Black", size=15), text_color="#000000")
        lbl_title.pack(pady=10)
        
        # Form
        lbl_desc = customtkinter.CTkLabel(self, text="Deskripsi Bug / Masalah:", font=customtkinter.CTkFont(family="Segoe UI Black", size=12), text_color="#000000")
        lbl_desc.pack(anchor="w", padx=20, pady=(10, 2))
        
        self.txt_desc = customtkinter.CTkTextbox(self, fg_color="#FFFFFF", text_color="#000000", border_width=3, border_color="#000000", corner_radius=0, font=("Segoe UI", 13), height=140)
        self.txt_desc.pack(fill="x", padx=20, pady=(0, 15))
        self.txt_desc.insert("1.0", "")
        
        # Submit Button
        self.btn_submit = customtkinter.CTkButton(self, text="KIRIM LAPORAN", font=customtkinter.CTkFont(family="Segoe UI Black", size=13), text_color="#FFFFFF", fg_color="#ef4444", hover_color="#dc2626", border_width=3, border_color="#000000", corner_radius=0, height=40, command=self.handle_submit)
        self.btn_submit.pack(fill="x", padx=20)

    def handle_submit(self):
        desc = self.txt_desc.get("1.0", "end-1c").strip()
        if not desc:
            messagebox.showerror("Peringatan", "Kolom deskripsi tidak boleh kosong!", parent=self)
            return
            
        self.btn_submit.configure(state="disabled", text="SENDING...")
        
        def worker():
            success = submit_bug_report(self.username, desc)
            if success:
                self.after(0, lambda: messagebox.showinfo("Selesai!", "Laporan berhasil dikirim! Terima kasih.", parent=self.parent))
                self.after(0, self.destroy)
            else:
                self.after(0, lambda: messagebox.showerror("Gagal!", "Laporan gagal dikirim. Silakan coba lagi.", parent=self))
                self.after(0, lambda: self.btn_submit.configure(state="normal", text="KIRIM LAPORAN"))
                
        threading.Thread(target=worker, daemon=True).start()


class HelpPage(customtkinter.CTkFrame):
    def __init__(self, parent, main_app, **kwargs):
        super().__init__(parent, fg_color="#FFFFFF", **kwargs)
        self.parent = main_app
        self.chat_history = []
        
        # Grid Layout
        self.grid_columnconfigure(0, weight=6, uniform="help") # Chatbot
        self.grid_columnconfigure(1, weight=4, uniform="help") # Info
        self.grid_rowconfigure(1, weight=1)
        
        # Title bar
        top_bar = customtkinter.CTkFrame(self, fg_color="transparent")
        top_bar.grid(row=0, column=0, columnspan=2, pady=(0, 4), sticky="ew")
        
        title = customtkinter.CTkLabel(top_bar, text=f"❔ {'Halaman Bantuan'}", font=customtkinter.CTkFont(family="Segoe UI Black", size=18), text_color="#000000")
        title.pack(side="left")
        
        customtkinter.CTkLabel(top_bar, text="✦", font=("Segoe UI Black", 16), text_color="#FF499E", fg_color="#FFFFFF").pack(side="left", padx=(10, 0))
        
        # LEFT PANEL: Chatbot
        self.chat_panel = customtkinter.CTkFrame(self, fg_color="#FFFFFF", border_width=3, border_color="#000000", corner_radius=0)
        self.chat_panel.grid(row=1, column=0, sticky="nsew", padx=(0, 10))
        self.chat_panel.grid_columnconfigure(0, weight=1)
        self.chat_panel.grid_rowconfigure(1, weight=1) # Chat list
        self.chat_panel.grid_rowconfigure(2, weight=0) # Shortcut questions
        self.chat_panel.grid_rowconfigure(3, weight=0) # Input box
        
        # Chat Header
        chat_hdr = customtkinter.CTkFrame(self.chat_panel, fg_color="#FFD800", border_width=0, corner_radius=0, height=40)
        chat_hdr.grid(row=0, column=0, sticky="ew")
        chat_hdr.grid_propagate(False)
        customtkinter.CTkLabel(chat_hdr, text="🤖 GAMEZONE CHATBOT", font=customtkinter.CTkFont(family="Segoe UI Black", size=13), text_color="#000000").pack(padx=15, pady=8, side="left")
        
        # Chat Scroll list
        self.chat_scroll = customtkinter.CTkScrollableFrame(self.chat_panel, fg_color="#FFFFFF", border_width=0, corner_radius=0)
        self.chat_scroll.grid(row=1, column=0, sticky="nsew", padx=5, pady=5)
        
        # Shortcut questions buttons
        shortcut_frame = customtkinter.CTkFrame(self.chat_panel, fg_color="transparent")
        shortcut_frame.grid(row=2, column=0, sticky="ew", padx=10, pady=(5, 5))
        shortcut_frame.grid_columnconfigure((0, 1), weight=1)
        
        q1 = customtkinter.CTkButton(shortcut_frame, text="Cara Menggunakan Inject", font=customtkinter.CTkFont(family="Segoe UI", size=10, weight="bold"), text_color="#000000", fg_color="#E0E0E0", hover_color="#D0D0D0", border_width=2, border_color="#000000", corner_radius=0, height=30, command=lambda: self.trigger_shortcut("Cara Menggunakan Inject"))
        q1.grid(row=0, column=0, padx=2, pady=2, sticky="ew")
        
        q2 = customtkinter.CTkButton(shortcut_frame, text="Mengatasi Error No Internet", font=customtkinter.CTkFont(family="Segoe UI", size=10, weight="bold"), text_color="#000000", fg_color="#E0E0E0", hover_color="#D0D0D0", border_width=2, border_color="#000000", corner_radius=0, height=30, command=lambda: self.trigger_shortcut("Mengatasi Error No Internet"))
        q2.grid(row=0, column=1, padx=2, pady=2, sticky="ew")
        
        q3 = customtkinter.CTkButton(shortcut_frame, text="Menggunakan Online Fix", font=customtkinter.CTkFont(family="Segoe UI", size=10, weight="bold"), text_color="#000000", fg_color="#E0E0E0", hover_color="#D0D0D0", border_width=2, border_color="#000000", corner_radius=0, height=30, command=lambda: self.trigger_shortcut("Menggunakan Online Fix"))
        q3.grid(row=1, column=0, padx=2, pady=2, sticky="ew")
        
        q4 = customtkinter.CTkButton(shortcut_frame, text="Apa itu Bypass?", font=customtkinter.CTkFont(family="Segoe UI", size=10, weight="bold"), text_color="#000000", fg_color="#E0E0E0", hover_color="#D0D0D0", border_width=2, border_color="#000000", corner_radius=0, height=30, command=lambda: self.trigger_shortcut("Apa itu Bypass?"))
        q4.grid(row=1, column=1, padx=2, pady=2, sticky="ew")
        
        # Chat Input Box
        input_frame = customtkinter.CTkFrame(self.chat_panel, fg_color="transparent")
        input_frame.grid(row=3, column=0, sticky="ew", padx=10, pady=(5, 10))
        input_frame.grid_columnconfigure(0, weight=1)
        
        self.entry_message = customtkinter.CTkEntry(input_frame, placeholder_text="Tanya tentang GameZone...", fg_color="#FFFFFF", text_color="#000000", border_width=3, border_color="#000000", corner_radius=0, height=40, font=("Segoe UI", 12, "bold"))
        self.entry_message.grid(row=0, column=0, sticky="ew", padx=(0, 5))
        self.entry_message.bind("<Return>", lambda e: self.handle_send())
        
        btn_send = customtkinter.CTkButton(input_frame, text="🚀", font=customtkinter.CTkFont(family="Segoe UI Black", size=14), text_color="#000000", fg_color="#FFD800", hover_color="#E6C300", border_width=3, border_color="#000000", corner_radius=0, height=40, width=50, command=self.handle_send)
        btn_send.grid(row=0, column=1, sticky="e")
        
        # RIGHT PANEL: Info & Bug report
        self.info_panel = customtkinter.CTkFrame(self, fg_color="#FFFFFF", border_width=3, border_color="#000000", corner_radius=0)
        self.info_panel.grid(row=1, column=1, sticky="nsew", padx=(10, 0))
        self.info_panel.grid_columnconfigure(0, weight=1)
        
        # Info Header
        info_hdr = customtkinter.CTkFrame(self.info_panel, fg_color="#FF499E", border_width=0, corner_radius=0, height=40)
        info_hdr.pack(fill="x")
        info_hdr.pack_propagate(False)
        customtkinter.CTkLabel(info_hdr, text=f"📋 {'Bantuan & Panduan'.upper()}", font=customtkinter.CTkFont(family="Segoe UI Black", size=13), text_color="#FFFFFF").pack(padx=15, pady=8, side="left")
        
        # Help details / FAQ Text
        txt_faq = customtkinter.CTkTextbox(self.info_panel, fg_color="#FFFFFF", text_color="#000000", font=("Segoe UI", 12), border_width=0, corner_radius=0, height=300)
        txt_faq.pack(fill="both", expand=True, padx=15, pady=15)
        txt_faq.insert("1.0", f"🌐 GAMEZONE APP HELP & FAQ\n\n"
                              f"• {'Bantuan'} Chatbot:\n"
                              f"  Gunakan panel chatbot di sebelah kiri untuk menanyakan informasi dasar. Ketik kata kunci seperti 'inject', 'internet', 'online fix', atau 'bypass'.\n\n"
                              f"• {'Laporkan Bug'}:\n"
                              f"  Jika menemukan kendala, eror, atau bug pada sistem GameZone, silakan klik tombol merah 'LAPORKAN BUG / MASALAH' di bawah untuk mengirimkan detail masalah secara langsung ke tim developer kami.")
        txt_faq.configure(state="disabled")
        
        # Red Bug report button
        btn_report = customtkinter.CTkButton(self.info_panel, text=f"⚠️ {'Laporkan Bug'.upper()}", font=customtkinter.CTkFont(family="Segoe UI Black", size=13), text_color="#FFFFFF", fg_color="#ef4444", hover_color="#dc2626", border_width=3, border_color="#000000", corner_radius=0, height=45, command=self.open_bug_report_dialog)
        btn_report.pack(fill="x", padx=15, pady=(0, 20))
        
        # Add Initial bot message
        self.add_chat_bubble("GameZone Bot", "Halo! Saya asisten GameZone. Ada yang bisa saya bantu?", is_bot=True)
        
        try:
            from core.skeleton import hide_skeleton
            hide_skeleton(self)
        except Exception:
            pass
            
    def filter_content(self, query):
        self.entry_message.delete(0, "end")
        self.entry_message.insert(0, query)

    def trigger_shortcut(self, question):
        self.add_chat_bubble("Pengguna", question, is_bot=False)
        
        # Bot responds after a short delay
        self.after(300, lambda: self.process_bot_reply(question))

    def handle_send(self):
        msg = self.entry_message.get().strip()
        if not msg:
            return
        self.entry_message.delete(0, "end")
        
        self.add_chat_bubble("Pengguna", msg, is_bot=False)
        
        # Bot responds after a short delay
        self.after(300, lambda: self.process_bot_reply(msg))

    def _call_gemini_api(self, api_key):
        import requests
        url = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key={api_key}"
        headers = {"Content-Type": "application/json"}
        
        current_version = getattr(self.parent, "CURRENT_VERSION", "2.0.7") if self.parent else "2.0.7"
        
        system_instruction = (
            "Anda adalah 'GameZone Bot', asisten AI pintar profesional untuk aplikasi GameZone.\n"
            "Aplikasi GameZone adalah utility platform desktop untuk gamer PC (khususnya pengguna Steam).\n\n"
            "Berikut adalah KNOWLEDGE BASE lengkap tentang fitur-fitur GameZone:\n"
            f"0. VERSI APLIKASI SEKARANG: Versi {current_version} (Ini adalah versi aplikasi yang sedang dijalankan oleh pengguna saat ini).\n"
            "1. FITUR INJECT GAME:\n"
            "   - Kegunaan: Menambahkan game ke Steam Library lokal secara gratis/manual.\n"
            "   - Cara Pakai: Cari judul game di tab 'Inject', klik game tersebut, lalu klik tombol kuning 'TAMBAH GAME'.\n"
            "   - PENTING: Pengguna wajib me-restart Steam (Keluar dan masuk kembali) setelah inject selesai agar game muncul di library.\n\n"
            "2. FITUR FIX NO INTERNET (NETFIX):\n"
            "   - Kegunaan: Memperbaiki masalah Steam download macet (stuck) atau status offline yang sering terjadi pada game tertentu.\n"
            "   - Cara Pakai: Klik tombol hijau 'Fix No Internet (Auto Scan)' di sidebar bawah. Cari game yang sedang diunduh di Steam, pilih game tersebut, klik 'Fix Sekarang'. Setelah selesai, masuk ke Steam dan klik 'Resume/Lanjutkan' unduhan.\n\n"
            "3. FITUR ONLINE FIX:\n"
            "   - Kegunaan: Menyediakan akses akun Steam sharing gratis untuk mengunduh game, serta panduan bermain multiplayer/online.\n"
            "   - Cara Pakai: Dapatkan username & password akun sharing di tab 'Online Fix'. Gunakan akun tersebut untuk masuk ke Steam. Untuk multiplayer, unduh file 'Fix Repair' dari situs online-fix.me lalu ekstrak dan timpa/copy-paste ke folder instalasi game Anda.\n\n"
            "4. FITUR BYPASS:\n"
            "   - Kegunaan: Melewati sistem proteksi/DRM game agar bisa dimainkan lancar offline.\n"
            "   - Status: Masih dalam tahap pengembangan dan penyempurnaan.\n\n"
            "5. STATUS PENGGUNA (USER STATUS):\n"
            "   - Kegunaan: Menampilkan status aktif secara real-time dari seluruh pengguna aplikasi GameZone.\n"
            "   - Indikator: Hijau 🟢 (Online, aktif < 5 mnt), Kuning 🟡 (Away, aktif < 1 jam), Merah 🔴 (Offline, aktif > 1 jam).\n"
            "   - Akses: Klik tombol '🟢 Status' di samping foto profil bulat pojok kiri atas.\n\n"
            "6. COMMUNITY CHAT:\n"
            "   - Kegunaan: Ruang obrolan langsung antar gamer GameZone. Mendukung reaksi emoji (👍, 🔥, ❤️, 😂) di bawah pesan.\n\n"
            "7. PROFIL PENGGUNA:\n"
            "   - Cara Ubah: Klik foto profil bulat di pojok kiri atas untuk mengganti nickname dan file avatar lingkaran.\n\n"
            "8. DEVELOPER:\n"
            "   - Pembuat: Dibuat dan dirancang penuh oleh Arya AL.\n\n"
            "Aturan Jawaban Anda:\n"
            "- Jawablah dengan bahasa Indonesia yang santai, gaul, akrab (gamer to gamer), menggunakan emoji, namun tetap akurat dan solutif.\n"
            "- Berikan jawaban singkat padat (maksimal 3 kalimat/baris) agar muat di chat bubble tanpa perlu scrolling panjang.\n"
            "- Jawablah dengan luwes seperti mengobrol biasa, manfaatkan riwayat percakapan yang diberikan untuk merespon secara kontekstual.\n"
            "- Tetap fokus hanya pada topik seputar aplikasi GameZone (fitur, panduan, masalah). Jika pengguna mencoba mengobrol di luar topik aplikasi GameZone (misalnya menanyakan resep masakan, tugas sekolah, curhat pribadi, politik, dll.), jawablah secara santai, gaul, dan bersahabat, namun ingatkan kembali dengan sopan bahwa Anda adalah asisten khusus untuk GameZone dan arahkan percakapan kembali ke GameZone."
        )
        
        payload = {
            "contents": self.chat_history,
            "system_instruction": {
                "parts": [
                    {"text": system_instruction}
                ]
            },
            "generationConfig": {
                "maxOutputTokens": 150,
                "temperature": 0.7
            }
        }
        
        try:
            res = requests.post(url, json=payload, headers=headers, timeout=8)
            if res.status_code == 200:
                data = res.json()
                text = data["candidates"][0]["content"]["parts"][0]["text"].strip()
                if text:
                    return text
        except Exception:
            pass
        return None

    def _get_local_bot_reply(self, user_msg):
        msg = user_msg.lower().strip()
        current_version = getattr(self.parent, "CURRENT_VERSION", "2.0.7") if self.parent else "2.0.7"
        
        topics = [
            {
                "keywords": ["halo", "hi", "hello", "p ", "pagi", "siang", "sore", "malam", "assalamualaikum", "test", "tes", "apa kabar", "kamu siapa", "bisa bantu apa", "siapa kamu", "bot", "asisten", "help", "oi", "hey", "hai"],
                "reply": "Halo! Aku GameZone AI Assistant 🤖. Aku siap bantu kamu seputar:\n1. **Inject Game** (tambah game ke Steam)\n2. **Fix No Internet / Netfix** (koneksi download macet)\n3. **Online Fix** (mabar/multiplayer)\n4. **Bypass** (lewati proteksi)\n5. **Ubah Profil** (ganti nama/avatar)\n6. **Status Teman** (siapa saja yang online)\n\nAda yang mau kamu tanyakan? Yuk mengobrol! 😉"
            },
            {
                "keywords": ["inject", "cara inject", "tambah game", "tambahin game", "masukin game", "load game", "isi game", "install game", "how to use inject", "cara pakai inject", "inject game", "tambah game steam", "cara menambah game"],
                "reply": "🎮 **Panduan Fitur Inject Game**:\n1. Buka tab **Inject** di sidebar menu atas.\n2. Cari game yang ingin Anda tambahkan di kolom pencarian.\n3. Klik hasil pencarian game tersebut, lalu tekan tombol **TAMBAH GAME**.\n4. **PENTING**: Restart aplikasi Steam Anda setelah selesai agar game baru terdeteksi di Library secara lokal."
            },
            {
                "keywords": ["no internet", "koneksi", "netfix", "download macet", "connection", "error koneksi", "internet putus", "gagal download", "steam offline", "fix download", "download lock", "no internet connection", "internet fix", "fix internet", "download terhenti"],
                "reply": "🔧 **Mengatasi Error No Internet / Steam Download Macet**:\n1. Klik tombol hijau **Fix No Internet (Auto Scan)** di bagian bawah sidebar.\n2. Aplikasi akan otomatis memindai game yang sedang diunduh di Steam.\n3. Pilih game yang bermasalah, lalu klik **Fix Sekarang**.\n4. Setelah sukses, masuk ke Steam dan **Resume** (lanjutkan) unduhan game Anda. Koneksi akan kembali normal!"
            },
            {
                "keywords": ["online fix", "multiplayer", "online-fix", "main online", "mabar", "main bareng", "coop", "co-op", "akun sharing", "sharing steam", "akun online fix", "onlinefix", "multiplayer fix", "cara mabar", "akun steam gratis"],
                "reply": "🌐 **Panduan Multiplayer / Online Fix**:\n1. Buka tab **Online Fix** di sidebar.\n2. Dapatkan informasi Akun Sharing Steam yang disediakan di sana untuk masuk ke Steam.\n3. Kunjungi situs resmi `online-fix.me` untuk mengunduh berkas **Fix Repair** game Anda.\n4. Ekstrak file Fix Repair tersebut, lalu copy-paste (timpa) ke dalam folder instalasi game Anda di PC."
            },
            {
                "keywords": ["bypass", "apa itu bypass", "cara bypass", "lewati proteksi", "drm bypass", "bypass steam", "bypass game", "fitur bypass"],
                "reply": "🛡️ **Informasi Fitur Bypass**:\nFitur Bypass dirancang untuk melewati pemeriksaan DRM (Digital Rights Management) pada game-game tertentu agar game bisa dijalankan secara offline dengan lancar tanpa terblokir. Fitur ini **masih dalam tahap pengembangan** oleh Arya AL dan akan dirilis pada update mendatang."
            },
            {
                "keywords": ["pembuat", "arya", "arya al", "creator", "owner", "developer", "bikin", "yang buat", "dibuat oleh", "siapa buat", "siapa pembuat", "siapa developer", "siapa yang bikin"],
                "reply": "😎 Aplikasi GameZone keren ini dirancang dan dikembangkan sepenuhnya oleh **Arya AL** sebagai platform utility gaming terbaik Anda."
            },
            {
                "keywords": ["ganti profil", "ganti foto", "ubah nama", "nickname", "avatar", "foto profil", "profil bulat", "ganti nama", "foto bulat", "edit profil", "ganti nickname", "ganti avatar"],
                "reply": "👤 **Mengubah Nickname & Avatar**:\n1. Klik **Foto Profil Bulat** Anda di pojok kiri paling atas sidebar.\n2. Anda akan diarahkan ke halaman **My Profile**.\n3. Di sana, Anda bisa mengetik nickname baru Anda atau memilih file avatar bulat yang diinginkan.\n4. Perubahan akan otomatis disimpan dan di-sync ke database komunitas!"
            },
            {
                "keywords": ["status", "siapa online", "status teman", "aktif", "terakhir aktif", "away", "offline", "online user", "online", "status online", "siapa online", "user online", "siapa saja online"],
                "reply": "🟢 **Melihat Status Pengguna Lain**:\n1. Klik tombol **🟢 Status** di pojok kiri atas (sebelah kanan foto profil Anda).\n2. Di sana Anda dapat melihat list pengguna GameZone lainnya beserta statusnya:\n   - 🟢 **Aktif sekarang** (online dalam 5 menit terakhir)\n   - 🟡 **Terakhir aktif X menit lalu** (away)\n   - 🔴 **Offline** (tidak aktif lebih dari 1 jam)\n3. Halaman ini otomatis terupdate setiap 10 detik!"
            },
            {
                "keywords": ["chat", "obrolan", "komunitas", "community", "reaksi", "emoji", "balas chat", "kirim pesan", "community chat", "chat komunitas", "reaksi emoji"],
                "reply": "💬 **Mengobrol & Reaksi Chat**:\n1. Masuk ke menu **Community Chat** di bagian bawah sidebar.\n2. Anda bisa mengirim pesan ke seluruh komunitas GameZone secara real-time.\n3. Anda juga bisa memberikan reaksi emoji (👍, 🔥, ❤️, 😂) pada pesan pengguna lain dengan mengklik tombol emoji di bawah pesan tersebut. Tombol akan berubah warna kuning jika Anda sudah bereaksi!"
            },
            {
                "keywords": [
                    "update", "versi", "changelog", "pembaruan", "install ulang", 
                    "mandatory update", "versi berapa", "version", "ver", "ver berapa", 
                    "v berapa", "versi sekarang", "versi saat ini", "versi apk", 
                    "current version", "app version"
                ],
                "reply": f"⚙️ Aplikasi GameZone Anda saat ini berjalan pada **Versi {current_version}**. Pembaruan secara otomatis divalidasi ke server cloud setiap kali aplikasi dibuka!"
            },
            {
                "keywords": ["terima kasih", "makasih", "thanks", "ok", "oke", "siap", "nuhun", "suwun"],
                "reply": "Sama-sama! Senang bisa membantu. Jika ada hal lain tentang GameZone yang membingungkan, tanyakan saja ya! 🎮"
            }
        ]

        best_topic = None
        max_score = 0
        
        for topic in topics:
            score = 0
            for kw in topic["keywords"]:
                if kw in msg:
                    score += len(kw)
            if score > max_score:
                max_score = score
                best_topic = topic
                
        if best_topic and max_score >= 3:
            return best_topic["reply"]
            
        return "Hmm, aku kurang paham maksudmu nih. 🤖\nSebagai asisten GameZone, aku cuma bisa bantu seputar aplikasi GameZone aja. Coba tanyakan dengan kata kunci yang lebih spesifik seperti:\n- *cara inject game*\n- *cara fix no internet / netfix*\n- *akun sharing / online fix*\n- *apa itu bypass*\n- *cara ganti foto profil*\n- *melihat status online teman*"

    def process_bot_reply(self, user_msg):
        # We run the fetch and API call in a background thread to prevent UI freezing!
        # Append user message to history
        self.chat_history.append({"role": "user", "parts": [{"text": user_msg}]})
        if len(self.chat_history) > 12:
            self.chat_history = self.chat_history[-12:]
            
        def run_api_check():
            reply = None
            try:
                from core.firebase_sync import fetch_api_keys
                keys = fetch_api_keys() or {}
                api_key = keys.get("gemini") or keys.get("gemini_api_key") or keys.get("api_key")
                if api_key:
                    reply = self._call_gemini_api(api_key)
            except Exception:
                pass
                
            if not reply:
                reply = self._get_local_bot_reply(user_msg)
                
            # Append bot reply to history
            self.chat_history.append({"role": "model", "parts": [{"text": reply}]})
            if len(self.chat_history) > 12:
                self.chat_history = self.chat_history[-12:]
                
            self.after(0, lambda: self.add_chat_bubble("GameZone Bot", reply, is_bot=True))
            
        threading.Thread(target=run_api_check, daemon=True).start()

    def add_chat_bubble(self, sender, text, is_bot=True):
        card_bg = "#F4EFEB" if is_bot else "#E0F2FE"
        border_col = "#000000"
        
        card = customtkinter.CTkFrame(self.chat_scroll, fg_color=card_bg, border_width=2, border_color=border_col, corner_radius=0)
        card.pack(fill="x", padx=10, pady=4)
        
        header_frame = customtkinter.CTkFrame(card, fg_color="transparent")
        header_frame.pack(fill="x", padx=10, pady=(5, 2))
        
        lbl_sender = customtkinter.CTkLabel(header_frame, text=sender, font=customtkinter.CTkFont(family="Segoe UI Black", size=11), text_color="#000000")
        lbl_sender.pack(side="left")
        
        lbl_msg = customtkinter.CTkLabel(card, text=text, font=customtkinter.CTkFont(family="Segoe UI", size=12, weight="bold"), text_color="#000000", justify="left", anchor="w")
        lbl_msg.pack(fill="x", padx=10, pady=(2, 8))
        
        # Dynamic wraplength binding to card width
        card.bind("<Configure>", lambda event, label=lbl_msg: label.configure(wraplength=max(50, event.width - 25)))
        
        # Auto scroll to bottom
        self.chat_scroll.update_idletasks()
        self.chat_scroll._parent_canvas.yview_moveto(1.0)

    def open_bug_report_dialog(self):
        from core import discord_auth
        username = discord_auth.get_cached_username()
        if not username or username == "User" or username == "?":
            username = "AnonUser"
            
        BugReportDialog(self.winfo_toplevel(), username)
