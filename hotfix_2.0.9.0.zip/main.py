import os
import sys

# Ensure project root directory is in sys.path before chdir
project_dir = os.path.dirname(os.path.abspath(__file__))
if project_dir not in sys.path:
    sys.path.insert(0, project_dir)

# Apply OTA Hotfix path override at highest priority in sys.path
try:
    from services.hotfix_service import apply_hotfix_path
    apply_hotfix_path("2.0.8")
except Exception as e:
    pass

# Ensure Application Data Directory Exists and Set as Working Directory
appdata_dir = os.path.join(os.getenv('LOCALAPPDATA', os.path.expanduser('~')), 'GameZone')
if not os.path.exists(appdata_dir):
    try:
        os.makedirs(appdata_dir)
    except Exception:
        pass
try:
    os.chdir(appdata_dir)
except Exception:
    pass

# Ensure certificates are found in PyInstaller bundle
if getattr(sys, 'frozen', False):
    import certifi
    os.environ['REQUESTS_CA_BUNDLE'] = certifi.where()
    os.environ['SSL_CERT_FILE'] = certifi.where()

import ctypes
try:
    ctypes.windll.shcore.SetProcessDpiAwareness(2) # Fix DPI scaling in PyInstaller
except Exception:
    pass

import customtkinter
customtkinter.set_window_scaling(1.0)
customtkinter.set_widget_scaling(1.0)

import tkinter.messagebox as messagebox
import threading
import json

class LazySession:
    def __getattr__(self, name):
        global db_session
        import requests
        db_session = requests.Session()
        return getattr(db_session, name)

db_session = LazySession()
from core.database import init_db

import sys
import os

def resource_path(relative_path):
    """ Get absolute path to resource, works for dev and for PyInstaller """
    try:
        # PyInstaller creates a temp folder and stores path in _MEIPASS
        base_path = sys._MEIPASS
    except Exception:
        base_path = os.path.dirname(__file__)
    return os.path.join(base_path, relative_path)

import re

def get_steam_username():
    from services.steam_service import get_steam_path
    steam_base = get_steam_path()
    vdf_path = os.path.join(steam_base, "config", "loginusers.vdf")
    if not os.path.exists(vdf_path):
        return "User"
    try:
        with open(vdf_path, "r", encoding="utf-8") as f:
            content = f.read()
        blocks = re.findall(r'(\"[0-9]+\"\s*\{[^}]+\})', content)
        for block in blocks:
            if re.search(r'"MostRecent"\s+"1"', block):
                match = re.search(r'"PersonaName"\s+"([^"]+)"', block)
                if match:
                    return match.group(1)
        return "User"
    except:
        return "User"

# --- KONFIGURASI VERSI ---
CURRENT_VERSION = "2.0.9"
# URL resmi untuk versi live
UPDATE_URL = "https://raw.githubusercontent.com/mhmdaryaqadi/GameZone-Release/main/version.json"

# --- SMOOTH SCROLLING PATCH ---
_original_wheel = customtkinter.CTkScrollableFrame._mouse_wheel_all

def _smooth_mouse_wheel(self, event):
    is_valid = False
    if hasattr(self, "_check_if_valid_scroll"):
        is_valid = self._check_if_valid_scroll(event.widget)
    elif hasattr(self, "check_if_master_is_canvas"):
        is_valid = self.check_if_master_is_canvas(event.widget)
    elif hasattr(self, "_check_if_master_is_canvas"):
        is_valid = self._check_if_master_is_canvas(event.widget)
    else:
        is_valid = True

    if is_valid:
        if sys.platform.startswith("win"):
            if not hasattr(self, "_scroll_target"):
                self._scroll_target = 0.0
                self._scroll_frac = 0.0
                self._is_scrolling = False
            
            # 1 notch (120) = 80 pixels.
            self._scroll_target -= (event.delta * 0.6)
            
            if not self._is_scrolling:
                self._is_scrolling = True
                self._smooth_scroll_loop()
        else:
            _original_wheel(self, event)

def _smooth_scroll_loop(self):
    if abs(self._scroll_target) < 0.1:
        self._scroll_target = 0.0
        self._scroll_frac = 0.0
        self._is_scrolling = False
        return
        
    # Easing sangat halus (12% per frame)
    step = self._scroll_target * 0.12
    
    # Akumulasi pecahan pixel supaya tidak patah-patah
    self._scroll_frac += step
    step_int = int(self._scroll_frac)
    self._scroll_frac -= step_int
    
    self._scroll_target -= step
    
    if step_int != 0:
        if getattr(self, "_shift_pressed", False):
            if self._parent_canvas.xview() != (0.0, 1.0):
                self._parent_canvas.xview("scroll", step_int, "units")
        else:
            if self._parent_canvas.yview() != (0.0, 1.0):
                self._parent_canvas.yview("scroll", step_int, "units")
            
    self.after(10, self._smooth_scroll_loop)

customtkinter.CTkScrollableFrame._mouse_wheel_all = _smooth_mouse_wheel
customtkinter.CTkScrollableFrame._smooth_scroll_loop = _smooth_scroll_loop
# -----------------------------

class GameZoneApp(customtkinter.CTk):
    def report_callback_exception(self, exc, val, tb):
        import _tkinter
        if issubclass(exc, _tkinter.TclError) and "invalid command name" in str(val):
            return
        sys.__excepthook__(exc, val, tb)

    def check_focus(self, event):
        if "entry" not in str(event.widget).lower() and "entry" not in str(type(event.widget)).lower():
            self.focus_set()

    def __init__(self):
        super().__init__()
        self.withdraw() # Hide window during initialization
        self.CURRENT_VERSION = CURRENT_VERSION
        self.CURRENT_ROLE = "basic"
        self._last_ann_timestamp = None
        init_db()

        customtkinter.set_appearance_mode("dark")
        self.title("GameZone")
        
        from core import discord_auth
        import os
        self._has_local_session = os.path.exists(discord_auth.get_session_file())
        
        self.update_idletasks()
        screen_w = self.winfo_screenwidth()
        screen_h = self.winfo_screenheight()
        
        pos_x = (screen_w // 2) - (650 // 2)
        pos_y = (screen_h // 2) - (450 // 2)
        self.geometry(f"650x450+{pos_x}+{pos_y}")
        self.minsize(650, 450)
        self.resizable(True, True)
        
        # Neo Brutalism background (Solid Cream)
        self.configure(fg_color="#F4EFEB")
        
        # Standard OS Titlebar is REQUIRED on this machine to prevent invisibility and blinking
        
        # Background Canvas for Floating Shapes
        self.bg_canvas = customtkinter.CTkCanvas(self, bg="#F4EFEB", highlightthickness=0)
        self.bg_canvas.place(x=0, y=0, relwidth=1, relheight=1)
        self.bind("<Configure>", self._on_resize_draw)
        self._last_w = 0
        self._last_h = 0
        
        # Solid Black Shadow Frame
        self.shadow_frame = customtkinter.CTkFrame(self, fg_color="#000000", bg_color="#F4EFEB", corner_radius=20)
        self.shadow_frame.place(relx=0.03, rely=0.03, relwidth=0.94, relheight=0.94, x=15, y=15)
        
        # Border Frame (Black)
        self.border_frame = customtkinter.CTkFrame(self, fg_color="#000000", bg_color="#F4EFEB", corner_radius=20)
        self.border_frame.place(relx=0.03, rely=0.03, relwidth=0.94, relheight=0.94)
        
        # Main White App Container (Inside Border Frame to fix border bleeding)
        self.app_frame = customtkinter.CTkFrame(self.border_frame, fg_color="#FFFFFF", bg_color="#000000", corner_radius=16)
        # self.app_frame.pack(fill="both", expand=True, padx=4, pady=4) # Packed later in _finish_login_success
        
        self.app_frame.grid_columnconfigure(0, weight=0)
        self.app_frame.grid_columnconfigure(1, weight=0) # Separator
        self.app_frame.grid_columnconfigure(2, weight=1)
        self.app_frame.grid_rowconfigure(0, weight=0)    # Top Bar row
        self.app_frame.grid_rowconfigure(1, weight=0)    # Horizontal Separator row
        self.app_frame.grid_rowconfigure(2, weight=1)    # Sidebar / Content row
        
        import os
        import ctypes
        try:
            myappid = 'gamezone.client.1.0'
            ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(myappid)
        except Exception:
            pass
            
        icon_path = None
        try:
            icon_path = resource_path(os.path.join('assets', 'app_icon_real.ico'))
            self.iconbitmap(icon_path)
        except Exception:
            pass

        # System Tray & Close Behavior Setup
        self.protocol("WM_DELETE_WINDOW", self.hide_to_tray)
        from core.tray_manager import TrayManager
        self.tray_manager = TrayManager(
            app=self,
            icon_path=icon_path,
            on_restore=self.restore_from_tray,
            on_exit=self.quit_app_completely
        )
        self.tray_manager.start()
        
        self.configure(fg_color="#F4EFEB")
        self.bind("<Button-1>", self.check_focus, add="+")


        # =========================================================================
        # BILAH ATAS (TOP BAR)
        # =========================================================================
        # Kiri Atas: Logo & Nama
        self.top_bar_left = customtkinter.CTkFrame(self.app_frame, width=180, height=34, fg_color="#FFFFFF")
        self.top_bar_left.grid(row=0, column=0, sticky="nsew", padx=8, pady=(2, 2))
        self.top_bar_left.pack_propagate(False)
        
        self.logo_label = customtkinter.CTkLabel(self.top_bar_left, text="GAMEZONE", font=customtkinter.CTkFont(family="Segoe UI Black", size=18), text_color="#000000", cursor="hand2")
        self.logo_label.pack(side="left", padx=(10, 4), pady=3)
        self.logo_label.bind("<Button-1>", lambda e: self.show_home_page())
        
        self.logo_stick = customtkinter.CTkLabel(self.top_bar_left, text="🎮", font=customtkinter.CTkFont(family="Segoe UI Emoji", size=16), text_color="#000000")
        self.logo_stick.pack(side="left", pady=3)

        # Atas Tengah: Garis vertikal yang simetris dengan garis bawah
        self.top_vertical_separator = customtkinter.CTkFrame(self.app_frame, width=4, height=34, fg_color="#000000", corner_radius=0)
        self.top_vertical_separator.grid(row=0, column=1, sticky="ns", pady=0)

        # Kanan Atas: Frame penampung profil
        self.top_bar_right = customtkinter.CTkFrame(self.app_frame, height=34, fg_color="#FFFFFF")
        self.top_bar_right.grid(row=0, column=2, sticky="nsew", padx=15, pady=(2, 2))
        self.top_bar_right.pack_propagate(False)

        # Kanan Atas - Bagian Profil & Status
        self.top_right_container = customtkinter.CTkFrame(self.top_bar_right, fg_color="#FFFFFF")
        self.top_right_container.pack(side="right", padx=10, pady=3)
        
        self.btn_profile = customtkinter.CTkButton(
            self.top_right_container, text="", width=28, height=28,
            fg_color="transparent", hover_color="#E0E0E0",
            corner_radius=14, border_width=2, border_color="#000000",
            command=self.show_profile_page
        )
        self.btn_profile.pack(side="right")
        
        self.user_details_frame = customtkinter.CTkFrame(self.top_right_container, fg_color="#FFFFFF")
        self.user_details_frame.pack(side="right", padx=(0, 10))
        
        self.lbl_top_nick = customtkinter.CTkLabel(self.user_details_frame, text="Username", font=customtkinter.CTkFont(family="Segoe UI Black", size=11), text_color="#000000", anchor="e")
        self.lbl_top_nick.pack(anchor="ne")
        
        self.lbl_top_role = customtkinter.CTkLabel(self.user_details_frame, text="Role: Basic", font=customtkinter.CTkFont(family="Segoe UI", size=9, weight="bold"), text_color="#FF499E", anchor="e")
        self.lbl_top_role.pack(anchor="se")

        self.btn_status = customtkinter.CTkButton(
            self.top_right_container, text="🟢 Status", width=75, height=28,
            fg_color="transparent", hover_color="#E0E0E0", text_color="#000000",
            font=customtkinter.CTkFont(family="Segoe UI Black", size=11),
            corner_radius=0, border_width=2, border_color="#000000",
            command=self.show_status_page
        )
        self.btn_status.pack(side="right", padx=(0, 10))

        # Horizontal Separator
        self.top_separator = customtkinter.CTkFrame(self.app_frame, height=4, fg_color="#000000", corner_radius=0)
        self.top_separator.grid(row=1, column=0, columnspan=3, sticky="ew", pady=0)

        # =========================================================================
        # BILAH KIRI (LEFT SIDEBAR)
        # =========================================================================
        self.sidebar_frame = customtkinter.CTkFrame(self.app_frame, width=180, corner_radius=0, fg_color="#FFFFFF")
        self.sidebar_frame.pack_propagate(False)
        self.sidebar_frame.grid(row=2, column=0, sticky="nsew", padx=8, pady=(6, 6))
        
        font_btn = customtkinter.CTkFont(family="Segoe UI Black", size=14)
        
        # Utilities & bottom buttons (Packed first with side="bottom" to guarantee visibility)
        bottom_buttons_frame = customtkinter.CTkFrame(self.sidebar_frame, fg_color="#FFFFFF")
        bottom_buttons_frame.pack(side="bottom", fill="x", padx=10, pady=(2, 6))
        bottom_buttons_frame.grid_columnconfigure(0, weight=1)
        bottom_buttons_frame.grid_columnconfigure(1, weight=1)

        self.btn_discord_sidebar = customtkinter.CTkButton(
            bottom_buttons_frame, 
            text="💬 Discord", 
            height=24, 
            width=60,
            fg_color="#5D5FEF", 
            hover_color="#4B4CD9", 
            text_color="#FFFFFF", 
            font=customtkinter.CTkFont(family="Segoe UI Black", size=10), 
            corner_radius=0, 
            border_width=2, 
            border_color="#000000",
            command=lambda: __import__('webbrowser').open("https://discord.gg/psVN4DDGA")
        )
        self.btn_discord_sidebar.grid(row=0, column=0, padx=(0, 2), sticky="ew")

        self.btn_help_sidebar = customtkinter.CTkButton(
            bottom_buttons_frame, 
            text=f"❓ {'Bantuan'}", 
            height=24, 
            width=60,
            fg_color="#FF499E", 
            hover_color="#FF3385", 
            text_color="#FFFFFF", 
            font=customtkinter.CTkFont(family="Segoe UI Black", size=10), 
            corner_radius=0, 
            border_width=2, 
            border_color="#000000",
            command=self.show_help_page
        )
        self.btn_help_sidebar.grid(row=0, column=1, padx=(2, 0), sticky="ew")

        # Label Author & Versi di bawah tombol
        self.lbl_author_sidebar = customtkinter.CTkLabel(
            bottom_buttons_frame, 
            text="By Arya AL", 
            font=customtkinter.CTkFont(family="Segoe UI", size=9, weight="bold"), 
            text_color="#555555"
        )
        self.lbl_author_sidebar.grid(row=1, column=0, sticky="w", pady=(2, 0))

        self.lbl_version_sidebar = customtkinter.CTkLabel(
            bottom_buttons_frame, 
            text=f"v{CURRENT_VERSION}", 
            font=customtkinter.CTkFont(family="Segoe UI", size=9, weight="bold"), 
            text_color="#555555"
        )
        self.lbl_version_sidebar.grid(row=1, column=1, sticky="e", pady=(2, 0))

        from pages.user.netfix import auto_scan_and_fix
        self.btn_netfix_action = customtkinter.CTkButton(
            self.sidebar_frame, 
            text="Fix No Internet\n(Auto Scan)", 
            fg_color="#00D084", 
            hover_color="#00B875", 
            text_color="#000000", 
            font=customtkinter.CTkFont(family="Segoe UI Black", size=12), 
            corner_radius=0, 
            border_width=3, 
            border_color="#000000",
            command=lambda: auto_scan_and_fix(self),
            height=38
        )
        self.btn_netfix_action.pack(side="bottom", fill="x", padx=10, pady=4)

        self.btn_fix_purchase = customtkinter.CTkButton(
            self.sidebar_frame,
            text="🛒 Fix Purchase",
            fg_color="#FFD800",
            hover_color="#E6C300",
            text_color="#000000",
            font=customtkinter.CTkFont(family="Segoe UI Black", size=12),
            corner_radius=0,
            border_width=3,
            border_color="#000000",
            command=self._run_fix_purchase_loop,
            height=38
        )
        self.btn_fix_purchase.pack(side="bottom", fill="x", padx=10, pady=(0, 0))

        # Navigation buttons (Packed from the top)
        self.btn_home = customtkinter.CTkButton(self.sidebar_frame, text="Home", anchor="center", fg_color="#FFFFFF", hover_color="#E0E0E0", text_color="#000000", font=font_btn, corner_radius=0, border_width=3, border_color="#F4EFEB", command=self.show_home_page, height=36)
        self.btn_home.pack(side="top", fill="x", padx=10, pady=3)

        self.btn_hub = customtkinter.CTkButton(self.sidebar_frame, text="Inject", anchor="center", fg_color="#FFD800", hover_color="#E6C300", text_color="#000000", font=font_btn, corner_radius=0, border_width=3, border_color="#000000", command=self.show_injection_hub, height=36)
        self.btn_hub.pack(side="top", fill="x", padx=10, pady=3)

        self.btn_library = customtkinter.CTkButton(self.sidebar_frame, text="My Library", anchor="center", fg_color="#FFFFFF", hover_color="#E0E0E0", text_color="#000000", font=font_btn, corner_radius=0, border_width=3, border_color="#F4EFEB", command=self.show_library, height=36)
        self.btn_library.pack(side="top", fill="x", padx=10, pady=3)

        self.btn_onlinefix = customtkinter.CTkButton(self.sidebar_frame, text="Online Fix", anchor="center", fg_color="#FFFFFF", hover_color="#E0E0E0", text_color="#000000", font=font_btn, corner_radius=0, border_width=3, border_color="#F4EFEB", command=self.show_onlinefix_page, height=36)
        self.btn_onlinefix.pack(side="top", fill="x", padx=10, pady=3)

        self.btn_cloud_save = customtkinter.CTkButton(self.sidebar_frame, text="Cloud Save", anchor="center", fg_color="#FFFFFF", hover_color="#E0E0E0", text_color="#000000", font=font_btn, corner_radius=0, border_width=3, border_color="#F4EFEB", command=self.show_cloud_save_page, height=36)
        self.btn_cloud_save.pack(side="top", fill="x", padx=10, pady=3)

        self.btn_settings = customtkinter.CTkButton(self.sidebar_frame, text="Settings", anchor="center", fg_color="#FFFFFF", hover_color="#E0E0E0", text_color="#000000", font=font_btn, corner_radius=0, border_width=3, border_color="#F4EFEB", command=self.show_settings_page, height=36)
        self.btn_settings.pack(side="top", fill="x", padx=10, pady=3)

        self.btn_diagnostic = customtkinter.CTkButton(
            self.sidebar_frame,
            text="🔍 Diagnostik (1-Klik)",
            anchor="center",
            fg_color="#10b981",
            hover_color="#059669",
            text_color="#FFFFFF",
            font=customtkinter.CTkFont(family="Segoe UI Black", size=12),
            corner_radius=0,
            border_width=3,
            border_color="#000000",
            command=self.show_diagnostic_dialog,
            height=36
        )
        self.btn_diagnostic.pack(side="bottom", fill="x", padx=10, pady=(0, 4))

        # Spacer expander in the middle
        self.sidebar_spacer = customtkinter.CTkFrame(self.sidebar_frame, fg_color="#FFFFFF")
        self.sidebar_spacer.pack(side="top", fill="both", expand=True)
        
        self.update_sidebar_profile()

        # Separator Line
        self.separator = customtkinter.CTkFrame(self.app_frame, width=4, fg_color="#000000", corner_radius=0)
        self.separator.grid(row=2, column=1, sticky="ns", pady=0)

        # =========================================================================
        # MAIN CONTENT FRAME
        # =========================================================================
        self.content_frame = customtkinter.CTkFrame(self.app_frame, fg_color="#FFFFFF", corner_radius=0)
        self.content_frame.grid(row=2, column=2, sticky="nsew", padx=20, pady=(15, 20))
        self.content_frame.grid_columnconfigure(0, weight=1)
        self.content_frame.grid_rowconfigure(0, weight=1)

        # No search dropdown needed
        self.top_search_dropdown = None

        # Inisialisasi Halaman (Secara Lazy / On-Demand)
        self.home_page = None
        self.library_page = None
        self.hub_page = None
        self.onlinefix_page = None
        self.cloud_save_page = None
        self.deals_page = None
        self.help_page = None
        self.settings_page = None
        self.profile_page = None
        self.status_page = None
        
        self.current_page = None
        self.show_home_page()
        
        threading.Thread(target=self._async_check_update, args=(False,), daemon=True).start()
        
        self.after(50, self._animate_canvas)
        
        if self._has_local_session:
            self._finish_login_success()
        else:
            self._show_login_ui()
        
    def _show_login_ui(self):
        # Resize to small window for login
        self.update_idletasks()
        screen_w = self.winfo_screenwidth()
        screen_h = self.winfo_screenheight()
        pos_x = (screen_w // 2) - (650 // 2)
        pos_y = (screen_h // 2) - (450 // 2)
        self.minsize(650, 450)
        self.geometry(f"650x450+{pos_x}+{pos_y}")
        
        # Hide main app until login succeeds
        self.app_frame.pack_forget()
        
        self.login_frame = customtkinter.CTkFrame(self, fg_color="#F4EFEB")
        self.login_frame.place(relx=0, rely=0, relwidth=1, relheight=1)
        
        # Login Decorative Elements
        self.bg_canvas_login = customtkinter.CTkCanvas(self.login_frame, bg="#F4EFEB", highlightthickness=0)
        self.bg_canvas_login.place(x=0, y=0, relwidth=1, relheight=1)
        self.bg_canvas_login.create_text(50, 50, text="*", font=("Segoe UI Black", 80), fill="#FFD800")
        self.bg_canvas_login.create_text(550, 350, text="+", font=("Segoe UI Black", 70), fill="#00D084")
        self.bg_canvas_login.create_oval(600, 50, 650, 100, fill="#FF499E", outline="#000000", width=4)
        
        self.login_box = customtkinter.CTkFrame(self.login_frame, fg_color="#FFFFFF", corner_radius=20, border_width=4, border_color="#000000", width=500, height=300)
        self.login_box.place(relx=0.5, rely=0.5, anchor="center")
        self.login_box.grid_propagate(False)
        
        lbl_block = customtkinter.CTkLabel(self.login_box, text="🔒 LOGIN REQUIRED", font=("Segoe UI Black", 30), text_color="#000000")
        lbl_block.place(relx=0.5, rely=0.3, anchor="center")
        
        desc = customtkinter.CTkLabel(self.login_box, text="Anda diwajibkan tergabung di\nserver Discord GAME ZONE.", font=("Segoe UI", 14, "bold"), text_color="#333333")
        desc.place(relx=0.5, rely=0.5, anchor="center")
        
        self.btn_login = customtkinter.CTkButton(self.login_box, text="LOGIN WITH DISCORD", width=250, height=50, fg_color="#5D5FEF", hover_color="#4B4CD9", text_color="#FFFFFF", font=("Segoe UI Black", 16), corner_radius=0, border_width=4, border_color="#000000", command=self._handle_discord_login)
        self.btn_login.place(relx=0.5, rely=0.75, anchor="center")
        
        # Check session automatically
        self.after(500, self._auto_check_login)
        
        # Show fully rendered login window
        self.update()
        import time
        time.sleep(0.05)
        self.update()
        self.deiconify()
        
    def _auto_check_login(self):
        self.btn_login.configure(state="disabled", text="VERIFYING SESSION...")
        def _check():
            from core import discord_auth
            if discord_auth.check_saved_session():
                self.after(0, self._login_success)
            else:
                self.after(0, lambda: self.btn_login.configure(state="normal", text="LOGIN WITH DISCORD"))
        threading.Thread(target=_check, daemon=True).start()

    def _handle_discord_login(self):
        self.btn_login.configure(state="disabled", text="MENUNGGU BROWSER...")
        def _run_login():
            from core import discord_auth
            import tkinter.messagebox as messagebox
            success, msg = discord_auth.authenticate_and_verify()
            if success:
                self.after(0, lambda: messagebox.showinfo("Login Berhasil", msg))
                self.after(0, self._login_success)
            else:
                self.after(0, lambda: messagebox.showerror("Login Gagal", msg))
                self.after(0, lambda: self.btn_login.configure(state="normal", text="LOGIN WITH DISCORD"))
        threading.Thread(target=_run_login, daemon=True).start()
        
    def _login_success(self):
        self.btn_login.configure(state="disabled", text="VERIFYING ROLE...")
        
        def _check_role():
            from core import discord_auth, firebase_sync
            db_base = firebase_sync.get_db_url()
            dc = discord_auth.get_cached_username()
            clean_user = firebase_sync.sanitize_key(dc)
            
            role = "basic"
            try:
                url = f"{db_base}/users/{clean_user}/role.json"
                res = db_session.get(url, timeout=10)
                if res.status_code == 200:
                    val = res.json()
                    if val in ["basic", "premium", "block"]:
                        role = val
            except Exception as e:
                print(f"Error checking user role: {e}")
                
            self.CURRENT_ROLE = role
            
            if role == "block":
                self.after(0, self._show_blocked_ui)
            else:
                self.after(0, self._finish_login_success)
                
        threading.Thread(target=_check_role, daemon=True).start()

    def _finish_login_success(self):
        self.withdraw() # Hide window immediately so the resize and initial layout rendering are invisible
        
        screen_w = self.winfo_screenwidth()
        screen_h = self.winfo_screenheight()
        pos_x = (screen_w // 2) - (1250 // 2)
        pos_y = (screen_h // 2) - (700 // 2)
        self.geometry(f"1250x700+{pos_x}+{pos_y}")
        self.minsize(1250, 700)
        
        if hasattr(self, 'login_frame') and self.login_frame:
            try:
                self.login_frame.destroy()
            except Exception:
                pass
        
        self.app_frame.pack(fill="both", expand=True, padx=4, pady=4)
        
        # Report user presence to Firebase database in a separate thread
        def _report():
            from core import firebase_sync, discord_auth, profile_manager
            dc = discord_auth.get_cached_username()
            prof = profile_manager.load_profile()
            nick = prof.get("nickname", "Anonymous")
            av_url = discord_auth.get_cached_avatar_url()
            firebase_sync.report_user_presence(dc, nick, av_url)
        threading.Thread(target=_report, daemon=True).start()
        
        if not getattr(self, '_watchdog_running', False):
            self._watchdog_running = True
            threading.Thread(target=self._background_watchdog, daemon=True).start()
        self.update_sidebar_profile()
        if hasattr(self, 'profile_page') and self.profile_page:
            self.profile_page.update_role_display()
            
        self.show_home_page()
        
        self.update()
        import time
        time.sleep(0.05)
        self.update()
        self.deiconify() # Bring the window back!

    def _show_blocked_ui(self):
        if hasattr(self, 'blocked_frame') and self.blocked_frame.winfo_exists():
            return
            
        self.withdraw() # Hide window during transition
        
        screen_w = self.winfo_screenwidth()
        screen_h = self.winfo_screenheight()
        pos_x = (screen_w // 2) - (650 // 2)
        pos_y = (screen_h // 2) - (450 // 2)
        self.minsize(650, 450)
        self.geometry(f"650x450+{pos_x}+{pos_y}")
        
        if hasattr(self, 'login_frame') and self.login_frame:
            try:
                self.login_frame.destroy()
            except Exception:
                pass
            
        self.app_frame.pack_forget()
        
        # Stop normal watchdog if active
        self._watchdog_running = False
        
        # Blocked Frame
        self.blocked_frame = customtkinter.CTkFrame(self, fg_color="#F4EFEB")
        self.blocked_frame.place(relx=0, rely=0, relwidth=1, relheight=1)
        
        # Blocked Canvas for shapes
        self.bg_canvas_blocked = customtkinter.CTkCanvas(self.blocked_frame, bg="#F4EFEB", highlightthickness=0)
        self.bg_canvas_blocked.place(x=0, y=0, relwidth=1, relheight=1)
        self.bg_canvas_blocked.create_text(50, 50, text="*", font=("Segoe UI Black", 80), fill="#FF499E")
        self.bg_canvas_blocked.create_text(550, 350, text="+", font=("Segoe UI Black", 70), fill="#FFD800")
        
        self.blocked_box = customtkinter.CTkFrame(self.blocked_frame, fg_color="#FFFFFF", corner_radius=20, border_width=4, border_color="#000000", width=550, height=360)
        self.blocked_box.place(relx=0.5, rely=0.5, anchor="center")
        self.blocked_box.grid_propagate(False)
        
        self.lbl_blocked_loading = customtkinter.CTkLabel(self.blocked_box, text="Memeriksa status akun...", font=("Segoe UI", 14, "bold"), text_color="#000000")
        self.lbl_blocked_loading.place(relx=0.5, rely=0.5, anchor="center")
        
        self.protocol("WM_DELETE_WINDOW", lambda: os._exit(0))
        
        self._blocked_polling_active = True
        threading.Thread(target=self._blocked_polling_loop, daemon=True).start()
        
        self.update()
        import time
        time.sleep(0.05)
        self.update()
        self.deiconify()

    def _blocked_polling_loop(self):
        import time
        from core import discord_auth, firebase_sync
        
        dc = discord_auth.get_cached_username()
        clean_user = firebase_sync.sanitize_key(dc)
        db_base = firebase_sync.get_db_url()
        
        last_appeal_status = None
        last_appeal_msg = None
        last_admin_res = None
        first_run = True
        
        while getattr(self, "_blocked_polling_active", False):
            try:
                # 1. Fetch user role
                url_role = f"{db_base}/users/{clean_user}/role.json"
                res_role = db_session.get(url_role, timeout=5)
                role = "basic"
                if res_role.status_code == 200:
                    val = res_role.json()
                    role = val if val in ["basic", "premium", "block"] else "basic"
                
                # If unblocked, restore application UI
                if role != "block":
                    self.CURRENT_ROLE = role
                    self._blocked_polling_active = False
                    self.after(0, self._restore_app_from_blocked)
                    break
                
                # 2. Fetch appeal status
                url_app = f"{db_base}/appeals/{clean_user}.json"
                res_app = db_session.get(url_app, timeout=5)
                appeal_data = None
                if res_app.status_code == 200:
                    appeal_data = res_app.json()
                
                status = appeal_data.get("status") if appeal_data else None
                msg = appeal_data.get("message") if appeal_data else None
                admin_res = appeal_data.get("admin_response") if appeal_data else None
                
                # Update UI only if data actually changed to prevent cursor resetting/flickering
                if (first_run or 
                     status != last_appeal_status or 
                     msg != last_appeal_msg or 
                     admin_res != last_admin_res):
                    
                    last_appeal_status = status
                    last_appeal_msg = msg
                    last_admin_res = admin_res
                    first_run = False
                    
                    self.after(0, lambda data=appeal_data: self._update_blocked_ui_content(data))
            except Exception as e:
                pass
                
            time.sleep(1.5)

    def _restore_app_from_blocked(self):
        self._blocked_polling_active = False
        if hasattr(self, 'blocked_frame') and self.blocked_frame:
            try:
                self.blocked_frame.destroy()
            except:
                pass
        self._finish_login_success()

    def _update_blocked_ui_content(self, appeal_data):
        if hasattr(self, 'lbl_blocked_loading') and self.lbl_blocked_loading:
            try:
                self.lbl_blocked_loading.destroy()
            except:
                pass
                
        for widget in self.blocked_box.winfo_children():
            try:
                widget.destroy()
            except:
                pass
            
        lbl_title = customtkinter.CTkLabel(self.blocked_box, text="🛑 AKSES DIBLOKIR", font=("Segoe UI Black", 24), text_color="#FF499E")
        lbl_title.pack(pady=(15, 10))
        
        from core import discord_auth, firebase_sync, profile_manager
        dc = discord_auth.get_cached_username()
        prof = profile_manager.load_profile()
        nick = prof.get("nickname", "Anonymous")
        
        if not appeal_data:
            lbl_desc = customtkinter.CTkLabel(self.blocked_box, text="Kamu telah diblokir dari GameZone.\nSilakan hubungi administrator atau ajukan banding di bawah.", font=("Segoe UI", 12, "bold"), text_color="#333333", justify="center")
            lbl_desc.pack(pady=5)
            
            self.appeal_entry = customtkinter.CTkEntry(self.blocked_box, placeholder_text="Tulis alasan banding Anda di sini...", width=450, height=35, fg_color="#FFFFFF", border_color="#000000", border_width=2, text_color="#000000", font=("Segoe UI", 12))
            self.appeal_entry.pack(pady=10)
            
            btn_frame = customtkinter.CTkFrame(self.blocked_box, fg_color="transparent")
            btn_frame.pack(pady=10)
            
            btn_appeal = customtkinter.CTkButton(btn_frame, text="KIRIM BANDING", width=180, height=40, fg_color="#00D084", hover_color="#00B875", text_color="#000000", font=("Segoe UI Black", 12), corner_radius=0, border_width=3, border_color="#000000", command=lambda: self._submit_appeal(dc, nick, self.appeal_entry.get()))
            btn_appeal.pack(side="left", padx=10)
            
            btn_close = customtkinter.CTkButton(btn_frame, text="CLOSE APK", width=180, height=40, fg_color="#FF499E", hover_color="#E03580", text_color="#FFFFFF", font=("Segoe UI Black", 12), corner_radius=0, border_width=3, border_color="#000000", command=lambda: os._exit(0))
            btn_close.pack(side="left", padx=10)
            
        elif appeal_data.get("status") == "pending":
            orig_msg = appeal_data.get("message", "")
            lbl_desc = customtkinter.CTkLabel(self.blocked_box, text=f"Banding Anda sedang ditinjau oleh Admin.\n\nPesan Anda:\n\"{orig_msg}\"\n\nHarap tunggu respon dari administrator.", font=("Segoe UI", 12, "bold"), text_color="#000000", justify="center", wraplength=480)
            lbl_desc.pack(pady=20)
            
            btn_close = customtkinter.CTkButton(self.blocked_box, text="CLOSE APK", width=200, height=45, fg_color="#FF499E", hover_color="#E03580", text_color="#FFFFFF", font=("Segoe UI Black", 14), corner_radius=0, border_width=3, border_color="#000000", command=lambda: os._exit(0))
            btn_close.pack(pady=10)
            
        elif appeal_data.get("status") == "rejected":
            reason = appeal_data.get("admin_response", "Tidak ada alasan spesifik.")
            lbl_desc = customtkinter.CTkLabel(self.blocked_box, text=f"Banding Anda DITOLAK!\n\nAlasan Admin:\n\"{reason}\"\n\nAkun Anda tetap diblokir.", font=("Segoe UI", 12, "bold"), text_color="#FF499E", justify="center", wraplength=480)
            lbl_desc.pack(pady=10)
            
            self.appeal_entry = customtkinter.CTkEntry(self.blocked_box, placeholder_text="Tulis banding baru jika ingin mencoba lagi...", width=450, height=35, fg_color="#FFFFFF", border_color="#000000", border_width=2, text_color="#000000", font=("Segoe UI", 12))
            self.appeal_entry.pack(pady=10)
            
            btn_frame = customtkinter.CTkFrame(self.blocked_box, fg_color="transparent")
            btn_frame.pack(pady=10)
            
            btn_appeal = customtkinter.CTkButton(btn_frame, text="KIRIM BANDING BARU", width=180, height=40, fg_color="#00D084", hover_color="#00B875", text_color="#000000", font=("Segoe UI Black", 11), corner_radius=0, border_width=3, border_color="#000000", command=lambda: self._submit_appeal(dc, nick, self.appeal_entry.get()))
            btn_appeal.pack(side="left", padx=10)
            
            btn_close = customtkinter.CTkButton(btn_frame, text="CLOSE APK", width=180, height=40, fg_color="#FF499E", hover_color="#E03580", text_color="#FFFFFF", font=("Segoe UI Black", 12), corner_radius=0, border_width=3, border_color="#000000", command=lambda: os._exit(0))
            btn_close.pack(side="left", padx=10)

    def _submit_appeal(self, username, nickname, message_text):
        message_text = message_text.strip()
        if not message_text:
            messagebox.showerror("Error", "Pesan banding tidak boleh kosong!", parent=self.winfo_toplevel())
            return
            
        def _async():
            try:
                from core import firebase_sync
                db_base = firebase_sync.get_db_url()
                clean_user = firebase_sync.sanitize_key(username)
                url = f"{db_base}/appeals/{clean_user}.json"
                
                import datetime
                payload = {
                    "username": username,
                    "nickname": nickname,
                    "message": message_text,
                    "status": "pending",
                    "admin_response": "",
                    "timestamp": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                }
                res = db_session.put(url, json=payload, timeout=10)
                if res.status_code == 200:
                    self.after(0, lambda: messagebox.showinfo("Banding Dikirim", "Banding Anda akan ditangani dan segera direspon.", parent=self.winfo_toplevel()))
                else:
                    self.after(0, lambda: messagebox.showerror("Gagal", "Gagal mengirim banding. Coba lagi.", parent=self.winfo_toplevel()))
            except Exception as e:
                self.after(0, lambda: messagebox.showerror("Error", f"Terjadi kesalahan koneksi: {e}", parent=self.winfo_toplevel()))
                
        threading.Thread(target=_async, daemon=True).start()

    def _background_watchdog(self):
        import time
        from core import discord_auth, firebase_sync, profile_manager
        heartbeat_counter = 0
        chat_check_counter = 0
        ann_check_counter = 5 # Check immediately on first loop
        role_check_counter = 5 # Check immediately on first loop
        dc_check_counter = 150 # Check immediately on first loop
        while getattr(self, '_watchdog_running', False):
            if dc_check_counter >= 150:
                dc_check_counter = 0
                if not discord_auth.check_saved_session():
                    self.after(0, self._force_logout)
                    break
            else:
                dc_check_counter += 1
                
            dc = discord_auth.get_cached_username()
            clean_user = firebase_sync.sanitize_key(dc)
            db_base = firebase_sync.get_db_url()
            
            # Fetch user role (every 10 seconds: 2s * 5 = 10s)
            if role_check_counter >= 5:
                role_check_counter = 0
                try:
                    url = f"{db_base}/users/{clean_user}/role.json"
                    res = db_session.get(url, timeout=5)
                    if res.status_code == 200:
                        val = res.json()
                        role = val if val in ["basic", "premium", "block"] else "basic"
                        self.CURRENT_ROLE = role
                        
                        if role == "block":
                            self.after(0, self._show_blocked_ui)
                            break
                        elif role == "basic":
                            if self.current_page == self.onlinefix_page:
                                self.after(0, self._kick_to_hub)
                except Exception:
                    pass
            else:
                role_check_counter += 1
                
            # Check for announcement updates while on Injection Hub page (every 10 seconds: 2s * 5 = 10s)
            if ann_check_counter >= 5:
                ann_check_counter = 0
                if self.current_page == self.hub_page:
                    try:
                        url_ts = f"{db_base}/announcements/updated_at.json"
                        res_ts = db_session.get(url_ts, timeout=3)
                        if res_ts.status_code == 200:
                            current_ts = res_ts.json()
                            if current_ts != self._last_ann_timestamp:
                                self._last_ann_timestamp = current_ts
                                self.after(0, self.hub_page.load_announcement)
                    except Exception:
                        pass
            else:
                ann_check_counter += 1
                
            # Heartbeat every 120 seconds (2s * 60 = 120s)
            if heartbeat_counter >= 60:
                heartbeat_counter = 0
                try:
                    prof = profile_manager.load_profile()
                    nick = prof.get("nickname", "Anonymous")
                    av_url = discord_auth.get_cached_avatar_url()
                    firebase_sync.report_user_presence(dc, nick, av_url)
                except:
                    pass
            else:
                heartbeat_counter += 1
                
            # Background Auto-Clean Steam License Cache:
            # Whenever Steam is NOT running, keep appinfo.vdf purged so manual opens are ALWAYS clean!
            try:
                from services.steam_service import is_steam_running, _clear_steam_license_cache
                if not is_steam_running():
                    _clear_steam_license_cache()
            except Exception:
                pass

            time.sleep(2)


    def _kick_to_hub(self):
        messagebox.showwarning("Akses Dibatasi", "Role Anda telah diubah menjadi Basic. Halaman ini hanya untuk Premium!", parent=self.winfo_toplevel())
        self.show_injection_hub()

    def _force_logout(self):
        import tkinter.messagebox as messagebox
        messagebox.showwarning("Akses Dicabut", "Anda terdeteksi keluar dari server Discord GAME ZONE!\nAplikasi dikunci.")
        self._watchdog_running = False
        self._show_login_ui()

    def _on_resize_draw(self, event):
        if event.widget == self:
            w, h = event.width, event.height
            if abs(w - self._last_w) > 50 or abs(h - self._last_h) > 50:
                self._last_w, self._last_h = w, h
                self.after(50, self._draw_canvas_decorations)

    def _animate_canvas(self):
        if not hasattr(self, '_anim_angle'):
            self._anim_angle = 0.0
            
        import math
        self._anim_angle += 0.02 # lebih pelan dari sebelumnya (0.05)
        
        try:
            for i in range(12):
                # dy dihitung dengan sinus agar bergerak naik-turun halus (floating)
                dy = math.sin(self._anim_angle + (i * 0.6)) * 0.5 # amplitudo dikecilkan (1.5 -> 0.5) agar lebih smooth
                self.bg_canvas.move(f"floater_{i}", 0, dy)
        except Exception:
            pass
            
        self.after(60, self._animate_canvas) # 60ms = ~16fps untuk performa enteng


    def _draw_canvas_decorations(self):
        c = self.bg_canvas
        c.delete("all")
        
        w = self.winfo_width()
        h = self.winfo_height()
        if w < 100: w = 1250
        if h < 100: h = 700
        
        # Color Blending to achieve transparency on a solid background
        def blend_color(hex_src, alpha=0.35, hex_bg="#F4EFEB"):
            try:
                r_s = int(hex_src[1:3], 16)
                g_s = int(hex_src[3:5], 16)
                b_s = int(hex_src[5:7], 16)
                r_b = int(hex_bg[1:3], 16)
                g_b = int(hex_bg[3:5], 16)
                b_b = int(hex_bg[5:7], 16)
                r = int(alpha * r_s + (1 - alpha) * r_b)
                g = int(alpha * g_s + (1 - alpha) * g_b)
                b = int(alpha * b_s + (1 - alpha) * b_b)
                return f"#{r:02x}{g:02x}{b:02x}"
            except Exception:
                return hex_src

        shadow_col = blend_color("#000000", 0.12)
        border_col = blend_color("#000000", 0.35)
        
        def shadow_oval(x, y, sz, fill_col, grp):
            c.create_oval(x+8, y+8, x+sz+8, y+sz+8, fill=shadow_col, outline="", tags=f"floater_{grp}")
            c.create_oval(x, y, x+sz, y+sz, fill=blend_color(fill_col, 0.35), outline=border_col, width=4, tags=f"floater_{grp}")
            
        def shadow_rect(x, y, rw, rh, fill_col, grp):
            c.create_rectangle(x+8, y+8, x+rw+8, y+rh+8, fill=shadow_col, outline="", tags=f"floater_{grp}")
            c.create_rectangle(x, y, x+rw, y+rh, fill=blend_color(fill_col, 0.35), outline=border_col, width=4, tags=f"floater_{grp}")
            
        # Left Pink half-circle
        c.create_arc(-40, 200, 60, 300, start=270, extent=180, fill=blend_color("#FF499E", 0.35), outline=border_col, width=4, tags="floater_0")
        # Bottom Right Yellow quarter-circle
        c.create_arc(w-100, h-100, w+100, h+100, start=90, extent=90, fill=blend_color("#FFD800", 0.35), outline=border_col, width=4, tags="floater_1")
        
        # Top right Blue pill with text
        shadow_rect(w-250, 20, 120, 50, "#5D5FEF", 2)
        c.create_text(w-190, 45, text="GameZone", font=("Segoe UI Black", 14), fill=border_col, tags="floater_2")
        
        # Top left Green box
        shadow_rect(80, 40, 60, 60, "#00D084", 3)
        c.create_text(110, 70, text="📊", font=("Segoe UI Emoji", 24), tags="floater_3")
        
        # Bottom left Yellow Circle
        shadow_oval(50, h-150, 70, "#FFD800", 4)
        c.create_text(85, h-115, text="👁️", font=("Segoe UI Emoji", 26), tags="floater_4")
        
        # Right Pink Circle
        shadow_oval(w-150, 300, 80, "#FF499E", 5)
        c.create_text(w-110, 340, text="🏀", font=("Segoe UI Emoji", 30), tags="floater_5")
        
        # Top-Left elements (Pojok Kiri Atas)
        c.create_text(25, 25, text="+", font=("Segoe UI Black", 80), fill=blend_color("#5D5FEF", 0.35), tags="floater_6")
        c.create_oval(80, 20, 110, 50, fill=blend_color("#FF499E", 0.35), outline=border_col, width=3, tags="floater_6")
        
        # Bottom-Left elements (Pojok Kiri Bawah)
        c.create_text(30, h-30, text="*", font=("Segoe UI Black", 100), fill=blend_color("#00D084", 0.35), tags="floater_7")
        c.create_line(60, h-100, 90, h-70, 120, h-120, fill=border_col, width=5, smooth=True, tags="floater_7")
        c.create_text(110, h-50, text="😎", font=("Segoe UI Emoji", 40), tags="floater_7")
        
        # Top-Right elements (Pojok Kanan Atas)
        c.create_text(w-30, 40, text="*", font=("Segoe UI Black", 90), fill=blend_color("#FFD800", 0.35), tags="floater_8")
        c.create_polygon(w-120, 20, w-90, 10, w-70, 40, fill=blend_color("#5D5FEF", 0.35), outline=border_col, width=4, tags="floater_8")
        c.create_text(w-80, 90, text="🔥", font=("Segoe UI Emoji", 35), tags="floater_8")
        
        # Bottom-Right elements (Pojok Kanan Bawah)
        c.create_text(w-40, h-40, text="+", font=("Segoe UI Black", 110), fill=blend_color("#FF499E", 0.35), tags="floater_9")
        c.create_rectangle(w-130, h-70, w-90, h-30, fill=blend_color("#00D084", 0.35), outline=border_col, width=4, tags="floater_9")
        
        # Center Top / Bottom edges
        c.create_text(w/2 - 100, 20, text="~~~~~~~~", font=("Segoe UI Black", 30), fill=border_col, tags="floater_10")
        c.create_text(w/2 + 200, h-20, text="■ ■ ■ ■", font=("Segoe UI Black", 20), fill=blend_color("#FF499E", 0.35), tags="floater_11")
        
    def _async_check_update(self, manual=False):
        from services.update_service import check_for_update_async
        check_for_update_async(self, CURRENT_VERSION, UPDATE_URL, manual=manual)
        
        # Check for OTA Hotfix patches (minor background updates without downloading EXE)
        try:
            from services.hotfix_service import check_and_apply_hotfix_async
            check_and_apply_hotfix_async(self)
        except Exception:
            pass

    def _presence_heartbeat(self):
        """Heartbeat setiap 2 menit untuk menjaga status online tetap akurat"""
        import time
        while True:
            try:
                from core import profile_manager, discord_auth, firebase_sync
                prof = profile_manager.load_profile()
                nick = prof.get("nickname", "Anonymous")
                dc = discord_auth.get_cached_username()
                avatar_url = discord_auth.get_cached_avatar_url()
                firebase_sync.report_user_presence(dc, nick, avatar_url)
            except Exception:
                pass
            time.sleep(120)  # 2 menit

    def update_sidebar_profile(self):
        from core import profile_manager, discord_auth
        import os
        from PIL import Image, ImageDraw
        
        prof = profile_manager.load_profile()
        nick = prof.get("nickname", "Anonymous")
        dc = discord_auth.get_cached_username()
        
        # Configure top bar profile text
        if hasattr(self, 'lbl_top_nick'):
            self.lbl_top_nick.configure(text=nick)
        if hasattr(self, 'lbl_top_role'):
            role_text = f"Role: {self.CURRENT_ROLE.upper()}"
            role_color = "#00D084" if self.CURRENT_ROLE == "premium" else "#FF499E"
            self.lbl_top_role.configure(text=role_text, text_color=role_color)
        
        # Report updated profile to Firebase in background
        def _report():
            from core import firebase_sync, discord_auth
            avatar_url = discord_auth.get_cached_avatar_url()
            firebase_sync.report_user_presence(dc, nick, avatar_url)
        threading.Thread(target=_report, daemon=True).start()
        
        if getattr(self, 'hub_page', None) is not None:
            self.hub_page.update_username(nick)
        
        av_file = prof.get("avatar", "avatar1.png")
        av_path = resource_path(os.path.join("assets", "avatars", av_file))
        
        if os.path.exists(av_path):
            try:
                img = Image.open(av_path).resize((22, 22)).convert("RGBA")
                mask = Image.new('L', (22, 22), 0)
                draw = ImageDraw.Draw(mask)
                draw.ellipse((0, 0, 22, 22), fill=255)
                
                result = Image.new('RGBA', (22, 22), (0,0,0,0))
                result.paste(img, (0,0), mask=mask)
                
                ctk_img = customtkinter.CTkImage(result, size=(22, 22))
                self.btn_profile.configure(image=ctk_img, text="")
            except Exception:
                pass

    def _reset_buttons(self):
        if hasattr(self, 'btn_home'):
            self.btn_home.configure(fg_color="#FFFFFF", hover_color="#E0E0E0", text_color="#000000", border_width=3, border_color="#F4EFEB")
        if hasattr(self, 'btn_hub'):
            self.btn_hub.configure(fg_color="#FFFFFF", hover_color="#E0E0E0", text_color="#000000", border_width=3, border_color="#F4EFEB")
        if hasattr(self, 'btn_library'):
            self.btn_library.configure(fg_color="#FFFFFF", hover_color="#E0E0E0", text_color="#000000", border_width=3, border_color="#F4EFEB")
        if hasattr(self, 'btn_onlinefix'):
            self.btn_onlinefix.configure(fg_color="#FFFFFF", hover_color="#E0E0E0", text_color="#000000", border_width=3, border_color="#F4EFEB")
        if hasattr(self, 'btn_cloud_save'):
            self.btn_cloud_save.configure(fg_color="#FFFFFF", hover_color="#E0E0E0", text_color="#000000", border_width=3, border_color="#F4EFEB")
        if hasattr(self, 'btn_deals'):
            self.btn_deals.configure(fg_color="#FFFFFF", hover_color="#E0E0E0", text_color="#000000", border_width=3, border_color="#F4EFEB")
        if hasattr(self, 'btn_help_sidebar'):
            self.btn_help_sidebar.configure(fg_color="#FF499E", hover_color="#FF3385", text_color="#FFFFFF", border_width=2, border_color="#000000")
        if hasattr(self, 'btn_settings'):
            self.btn_settings.configure(fg_color="#FFFFFF", hover_color="#E0E0E0", text_color="#000000", border_width=3, border_color="#F4EFEB")
        if hasattr(self, 'btn_profile'):
            self.btn_profile.configure(fg_color="#FFFFFF", hover_color="#E0E0E0", border_width=2, border_color="#000000")
        if hasattr(self, 'btn_status'):
            self.btn_status.configure(fg_color="#FFFFFF", hover_color="#E0E0E0", text_color="#000000", border_width=2, border_color="#000000")

    def _switch_page(self, new_page):
        if self.current_page == new_page: return
        
        # Sembunyikan semua halaman secara eksplisit untuk mencegah penumpukan/tabrakan UI
        pages_to_hide = [
            getattr(self, 'home_page', None),
            getattr(self, 'hub_page', None),
            getattr(self, 'library_page', None),
            getattr(self, 'onlinefix_page', None),
            getattr(self, 'cloud_save_page', None),
            getattr(self, 'deals_page', None),
            getattr(self, 'help_page', None),
            getattr(self, 'settings_page', None),
            getattr(self, 'profile_page', None),
            getattr(self, 'status_page', None),
        ]
        for p in pages_to_hide:
            if p and p != new_page:
                try:
                    p.place_forget()
                except Exception:
                    pass
                    
        self.current_page = new_page
        new_page.place(relx=0, rely=0, relwidth=1, relheight=1)
        new_page.lift() # Naikkan ke atas tumpukan agar tidak tertutup halaman lama
        
        # Tampilkan animasi skeleton HANYA untuk halaman My Library
        if new_page == getattr(self, 'library_page', None):
            try:
                from core.skeleton import show_skeleton
                show_skeleton(new_page)
            except Exception:
                pass
            
        self.update_idletasks()

        # Reclaim unused RAM memory asynchronously on page switch
        def _gc():
            import gc
            gc.collect()
        threading.Thread(target=_gc, daemon=True).start()

    def show_home_page(self):
        if not getattr(self, 'home_page', None):
            from pages.user.home import HomePage
            self.home_page = HomePage(self.content_frame, self)
        if self.current_page == self.home_page: return
        self._reset_buttons()
        self.btn_home.configure(fg_color="#FFD800", hover_color="#E6C300", text_color="#000000", border_width=3, border_color="#000000")
        self._switch_page(self.home_page)

    def show_injection_hub(self):
        if not getattr(self, 'hub_page', None):
            from pages.user.hub import InjectionHubPage
            self.hub_page = InjectionHubPage(self.content_frame, self)
        if self.current_page == self.hub_page: return
        self._reset_buttons()
        self.btn_hub.configure(fg_color="#FFD800", hover_color="#E6C300", text_color="#000000", border_width=3, border_color="#000000")
        self._switch_page(self.hub_page)

    def show_library(self):
        if not getattr(self, 'library_page', None):
            from pages.user.library import LibraryPage
            self.library_page = LibraryPage(self.content_frame, self)
            self.library_page.force_reload_library()
        if self.current_page == self.library_page: return
        self._reset_buttons()
        self.btn_library.configure(fg_color="#FFD800", hover_color="#E6C300", text_color="#000000", border_width=3, border_color="#000000")
        self._switch_page(self.library_page)
        
    def show_onlinefix_page(self):
        if getattr(self, "CURRENT_ROLE", "basic") != "premium":
            messagebox.showwarning("Akses Dibatasi", "Fitur Online Fix hanya tersedia untuk pengguna Premium!", parent=self.winfo_toplevel())
            return
        if not getattr(self, 'onlinefix_page', None):
            from pages.user.online_fix import OnlineFixPage
            self.onlinefix_page = OnlineFixPage(self.content_frame, self)
            self.onlinefix_page.load_shared_accounts()
        if self.current_page == self.onlinefix_page: return
        self._reset_buttons()
        self.btn_onlinefix.configure(fg_color="#FFD800", hover_color="#E6C300", text_color="#000000", border_width=3, border_color="#000000")
        self._switch_page(self.onlinefix_page)

    def show_cloud_save_page(self):
        if not getattr(self, 'cloud_save_page', None):
            from pages.user.cloud_save import CloudSavePage
            self.cloud_save_page = CloudSavePage(self.content_frame, self)
        if self.current_page == self.cloud_save_page: return
        self._reset_buttons()
        if hasattr(self, 'btn_cloud_save'):
            self.btn_cloud_save.configure(fg_color="#FFD800", hover_color="#E6C300", text_color="#000000", border_width=3, border_color="#000000")
        self._switch_page(self.cloud_save_page)

    def show_deals_page(self):
        if not getattr(self, 'deals_page', None):
            from pages.user.deals import DealsPage
            self.deals_page = DealsPage(self.content_frame, self)
        if self.current_page == self.deals_page: return
        self._reset_buttons()
        if hasattr(self, 'btn_deals'):
            self.btn_deals.configure(fg_color="#FFD800", hover_color="#E6C300", text_color="#000000", border_width=3, border_color="#000000")
        self._switch_page(self.deals_page)

    def show_diagnostic_dialog(self):
        try:
            from components.dialogs import DiagnosticDialog
            DiagnosticDialog(self)
        except Exception as e:
            messagebox.showerror("Error", str(e), parent=self.winfo_toplevel())

    def show_help_page(self):
        if not getattr(self, 'help_page', None):
            from pages.user.help import HelpPage
            self.help_page = HelpPage(self.content_frame, self)
        if self.current_page == self.help_page: return
        self._reset_buttons()
        self.btn_help_sidebar.configure(fg_color="#FFD800", hover_color="#E6C300", text_color="#000000", border_width=2, border_color="#000000")
        self._switch_page(self.help_page)
        
    def show_settings_page(self):
        if not getattr(self, 'settings_page', None):
            from pages.user.settings import SettingsPage
            self.settings_page = SettingsPage(self.content_frame, self)
        if self.current_page == self.settings_page: return
        self._reset_buttons()
        self.btn_settings.configure(fg_color="#FFD800", hover_color="#E6C300", text_color="#000000", border_width=3, border_color="#000000")
        self._switch_page(self.settings_page)

    def show_profile_page(self):
        if not getattr(self, 'profile_page', None):
            from pages.user.profile import ProfilePage
            self.profile_page = ProfilePage(self.content_frame, self)
            self.profile_page.load_history()
        if self.current_page == self.profile_page: return
        self._reset_buttons()
        self.btn_profile.configure(fg_color="#FFD800", hover_color="#E6C300", border_width=2, border_color="#000000")
        if hasattr(self.profile_page, 'update_role_display'):
            self.profile_page.update_role_display()
        self._switch_page(self.profile_page)

    def show_status_page(self):
        if not getattr(self, 'status_page', None):
            from pages.user.status import StatusPage
            self.status_page = StatusPage(self.content_frame, self)
            self.status_page.manual_refresh()
        if self.current_page == self.status_page: return
        self._reset_buttons()
        self.btn_status.configure(fg_color="#FFD800", hover_color="#E6C300", text_color="#000000", border_width=2, border_color="#000000")
        self._switch_page(self.status_page)

    def _run_fix_purchase_loop(self):
        """Fix tombol Purchase ↔ Play selang-seling di game inject."""
        import tkinter.messagebox as messagebox
        import threading
        self.btn_fix_purchase.configure(state="disabled", text="⏳ Memperbaiki...")

        def _worker():
            try:
                from services.steam_service import fix_purchase_loop
                ok, msg = fix_purchase_loop()
                def _done():
                    self.btn_fix_purchase.configure(state="normal", text="🛒 Fix Purchase")
                    if ok:
                        messagebox.showinfo("Fix Purchase Selesai", f"{msg}\n\nRestart Steam agar perubahan berlaku.", parent=self)
                    else:
                        messagebox.showerror("Gagal", msg, parent=self)
                self.after(0, _done)
            except Exception as e:
                self.after(0, lambda: (
                    self.btn_fix_purchase.configure(state="normal", text="🛒 Fix Purchase"),
                    messagebox.showerror("Error", str(e), parent=self)
                ))
        threading.Thread(target=_worker, daemon=True).start()

    def hide_to_tray(self):
        """Sembunyikan jendela ke System Tray tanpa mematikan aplikasi jika tray tersedia."""
        try:
            if hasattr(self, 'tray_manager') and self.tray_manager and getattr(self.tray_manager, 'available', False):
                self.withdraw()
            else:
                self.quit_app_completely()
        except Exception:
            self.quit_app_completely()

    def restore_from_tray(self):
        """Tampilkan kembali jendela dari System Tray dan fokus ke depan."""
        def _do_restore():
            try:
                self.deiconify()
                self.state('normal')
                self.attributes('-topmost', True)
                self.update_idletasks()
                self.after(50, lambda: self.attributes('-topmost', False))
                self.focus_force()
            except Exception:
                pass
        self.after(0, _do_restore)

    def quit_app_completely(self):
        """Keluar sepenuhnya dari aplikasi via menu System Tray."""
        try:
            self.withdraw()
        except Exception:
            pass
        try:
            if hasattr(self, 'single_instance_lock') and self.single_instance_lock:
                self.single_instance_lock.close()
        except Exception:
            pass
        try:
            if hasattr(self, 'tray_manager') and self.tray_manager:
                self.tray_manager.stop()
        except Exception:
            pass
        os._exit(0)

if __name__ == "__main__":
    import sys
    from core.single_instance import SingleInstanceLock

    lock = SingleInstanceLock()
    _app_instance = [None]

    def _on_restore_signal():
        if _app_instance[0]:
            _app_instance[0].restore_from_tray()

    if not lock.check_and_lock(_on_restore_signal):
        # Sudah ada GameZone yang berjalan -> Instance kedua keluar setelah memanggil restore instance pertama
        sys.exit(0)

    app = GameZoneApp()
    app.single_instance_lock = lock
    _app_instance[0] = app
    app.mainloop()