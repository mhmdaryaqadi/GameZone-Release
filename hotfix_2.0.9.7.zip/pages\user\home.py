import customtkinter
import os
import threading
import json
import webbrowser
from PIL import Image, ImageOps
from io import BytesIO
import requests

def wrap_text(text, width=15):
    import textwrap
    lines = textwrap.wrap(text, width=width)
    return "\n".join(lines)

class HomePage(customtkinter.CTkFrame):
    def __init__(self, parent, main_app):
        super().__init__(parent, fg_color="#FFFFFF")
        self.parent = parent
        self.main_app = main_app
        self.is_destroyed = False
        self.home_deals_data = {}
        self.home_deals_cat = "freebies"
        self._last_ann_hash = None
        self.deal_img_cache = {}
        
        self.button_data = {
            "panduan": """📌 [PANDUAN PENGGUNAAN GAMEZONE]

1. Cara Injeksi Game:
- Buka tab 'Inject' di menu samping.
- Pilih game yang ingin diinjeksi dan klik tombol 'INJECT GAME'.
- Tunggu hingga proses verifikasi lisensi dan pembuatan file manifest selesai.
- Buka Steam, game akan muncul di library dan siap untuk dimainkan!

2. Cara Menggunakan Fix Purchase:
- Jika tombol di Steam berubah menjadi 'Purchase', klik tombol 'Fix Purchase' di sidebar.
- GameZone akan mereset cache lisensi Steam dan memperbaiki file manifest secara otomatis.

3. Cara Memperbaiki Koneksi (NetFix):
- Jika game butuh pembaruan / unduhan, jalankan fitur 'Fix No Internet' untuk mengunduh file manifest depot terbaru.""",
            "pembaruan": """✨ [v2.0.7]:
- 🔥 Integrasi Radar Deals & Freebies: Info otomatis 24/7 game PC gratis (Epic/Steam/GOG), diskon besar & Steam Events.
- 🔍 Diagnostik & Perbaiki 1-Klik: Pemeriksa kesehatan khusus game inject.
- 🧹 Auto Steam License Cleaner Toggle Switch di Settings.
- 🛒 Sidebar Fix Purchase Loop button.""",
            "donasi": "https://saweria.co/"
        }
        
        # Grid layout: Column 0 (Left 42%), Column 1 (Right 58%)
        self.grid_columnconfigure(0, weight=42)
        self.grid_columnconfigure(1, weight=58)
        self.grid_rowconfigure(1, weight=1)

        # Theme Colors - Neo-Brutalism
        self.CARD_BG = "#FFFFFF"
        self.ACCENT_YELLOW = "#FFD800"
        self.ACCENT_PINK = "#FF499E"
        self.ACCENT_GREEN = "#00D084"
        self.ACCENT_BLUE = "#5D5FEF"
        self.BORDER_COLOR = "#000000"
        self.TEXT_BLACK = "#000000"
        self.TEXT_MUTED = "#555555"
        
        # Top Bar Title
        top_bar = customtkinter.CTkFrame(self, fg_color="transparent")
        top_bar.grid(row=0, column=0, columnspan=2, pady=(0, 6), sticky="ew")
        
        title = customtkinter.CTkLabel(
            top_bar, text="Home Dashboard", 
            font=customtkinter.CTkFont(family="Segoe UI Black", size=18), 
            text_color=self.TEXT_BLACK
        )
        title.grid(row=0, column=0, sticky="w")

        # =========================================================================
        # LEFT COLUMN (Welcome Card + Pengumuman Card)
        # =========================================================================
        left_column = customtkinter.CTkFrame(self, fg_color="transparent")
        left_column.grid(row=1, column=0, padx=(0, 8), sticky="nsew")
        left_column.grid_columnconfigure(0, weight=1)
        left_column.grid_rowconfigure(1, weight=1)

        # 1. Hero Welcome Card (Top Left)
        self.hero_card = customtkinter.CTkFrame(
            left_column, fg_color=self.CARD_BG, 
            border_width=3, border_color=self.BORDER_COLOR, corner_radius=0
        )
        self.hero_card.grid(row=0, column=0, sticky="ew", pady=(0, 10))
        
        self.lbl_welcome = customtkinter.CTkLabel(
            self.hero_card, text="WELCOME BACK!", 
            font=customtkinter.CTkFont(family="Segoe UI Black", size=18), 
            text_color=self.TEXT_BLACK, anchor="w", justify="left"
        )
        self.lbl_welcome.pack(fill="x", padx=15, pady=(12, 2))
        
        self.lbl_level = customtkinter.CTkLabel(
            self.hero_card, text="✨ Status: Premium Member", 
            font=customtkinter.CTkFont(family="Segoe UI Black", size=11), 
            text_color=self.ACCENT_GREEN, anchor="w", justify="left"
        )
        self.lbl_level.pack(fill="x", padx=15, pady=(0, 12))

        # 2. Pengumuman Card (Bottom Left)
        self.ann_card = customtkinter.CTkFrame(
            left_column, fg_color=self.CARD_BG, 
            border_width=3, border_color=self.BORDER_COLOR, corner_radius=0
        )
        self.ann_card.grid(row=1, column=0, sticky="nsew")

        lbl_ann_title = customtkinter.CTkLabel(
            self.ann_card, text="📢 PENGUMUMAN", 
            font=customtkinter.CTkFont(family="Segoe UI Black", size=15), 
            text_color=self.TEXT_BLACK, anchor="w"
        )
        lbl_ann_title.pack(fill="x", padx=15, pady=(12, 5))
        
        self.announce_scroll = customtkinter.CTkScrollableFrame(
            self.ann_card, fg_color="#FFFFFF", border_width=2, 
            border_color=self.BORDER_COLOR, corner_radius=0
        )
        self.announce_scroll.pack(fill="both", expand=True, padx=12, pady=(0, 12))

        # =========================================================================
        # RIGHT COLUMN (Deals, Freebies & Events Widget + Utility Buttons)
        # =========================================================================
        right_column = customtkinter.CTkFrame(self, fg_color="transparent")
        right_column.grid(row=1, column=1, padx=(8, 0), sticky="nsew")
        right_column.grid_columnconfigure(0, weight=1)
        right_column.grid_rowconfigure(0, weight=1)

        # 1. Deals & Promo Widget Card (Right Full Height)
        self.deals_card = customtkinter.CTkFrame(
            right_column, fg_color=self.CARD_BG, 
            border_width=3, border_color=self.BORDER_COLOR, corner_radius=0
        )
        self.deals_card.grid(row=0, column=0, sticky="nsew", pady=(0, 10))
        self.deals_card.grid_columnconfigure(0, weight=1)
        # CRITICAL FIX: grid_rowconfigure(3, weight=1) so the scrollable frame expands, NOT the header/tabs!
        self.deals_card.grid_rowconfigure(3, weight=1)

        # Header Deals
        lbl_deals_title = customtkinter.CTkLabel(
            self.deals_card, text="🔥 DEALS, FREEBIES & STEAM EVENTS", 
            font=customtkinter.CTkFont(family="Segoe UI Black", size=15), 
            text_color=self.TEXT_BLACK, anchor="w"
        )
        lbl_deals_title.grid(row=0, column=0, sticky="w", padx=15, pady=(12, 2))

        lbl_deals_sub = customtkinter.CTkLabel(
            self.deals_card, text="Info promo game PC 100% gratis, diskon & event resmi (Otomatis 24/7).", 
            font=customtkinter.CTkFont(family="Segoe UI Black", size=11), 
            text_color=self.TEXT_MUTED, anchor="w"
        )
        lbl_deals_sub.grid(row=1, column=0, sticky="w", padx=15, pady=(0, 8))

        # Filter Tabs inside Deals Card
        deals_tab_frame = customtkinter.CTkFrame(self.deals_card, fg_color="transparent")
        deals_tab_frame.grid(row=2, column=0, sticky="ew", padx=12, pady=(0, 8))

        self.btn_h_free = customtkinter.CTkButton(
            deals_tab_frame, text="🎁 Game Gratis", font=customtkinter.CTkFont(family="Segoe UI Black", size=11),
            fg_color="#FFD800", text_color="#000000", hover_color="#E6C300", border_width=2, border_color="#000000", corner_radius=0, height=30,
            command=lambda: self.switch_home_deals_cat("freebies")
        )
        self.btn_h_free.pack(side="left", padx=(0, 4))

        self.btn_h_deals = customtkinter.CTkButton(
            deals_tab_frame, text="🔥 Diskon Besar", font=customtkinter.CTkFont(family="Segoe UI Black", size=11),
            fg_color="#FFFFFF", text_color="#000000", hover_color="#E0E0E0", border_width=2, border_color="#000000", corner_radius=0, height=30,
            command=lambda: self.switch_home_deals_cat("discounts")
        )
        self.btn_h_deals.pack(side="left", padx=4)

        self.btn_h_events = customtkinter.CTkButton(
            deals_tab_frame, text="🎪 Steam Events", font=customtkinter.CTkFont(family="Segoe UI Black", size=11),
            fg_color="#FFFFFF", text_color="#000000", hover_color="#E0E0E0", border_width=2, border_color="#000000", corner_radius=0, height=30,
            command=lambda: self.switch_home_deals_cat("events")
        )
        self.btn_h_events.pack(side="left", padx=(4, 0))

        # Scrollable Frame for Deals Items
        self.deals_cards_scroll = customtkinter.CTkScrollableFrame(
            self.deals_card, fg_color="#FFFFFF", border_width=2, 
            border_color=self.BORDER_COLOR, corner_radius=0
        )
        self.deals_cards_scroll.grid(row=3, column=0, sticky="nsew", padx=12, pady=(0, 12))
        self.deals_cards_scroll.grid_columnconfigure(0, weight=1)
        self.deals_cards_scroll.grid_columnconfigure(1, weight=1)

        # 2. Bottom Utility Buttons (Panduan, Pembaruan, Donasi)
        bot_btns = customtkinter.CTkFrame(right_column, fg_color="transparent")
        bot_btns.grid(row=1, column=0, sticky="ew")
        bot_btns.grid_columnconfigure(0, weight=1)
        bot_btns.grid_columnconfigure(1, weight=1)
        bot_btns.grid_columnconfigure(2, weight=1)

        btn_panduan = customtkinter.CTkButton(
            bot_btns, text="PANDUAN", fg_color="#5D5FEF", hover_color="#4B4CD9", 
            text_color="#FFFFFF", font=customtkinter.CTkFont(family="Segoe UI Black", size=11), 
            corner_radius=0, border_width=3, border_color="#000000", command=self.open_guide, height=36
        )
        btn_panduan.grid(row=0, column=0, padx=(0, 4), sticky="ew")

        btn_pembaruan = customtkinter.CTkButton(
            bot_btns, text="PEMBARUAN", fg_color="#00D084", hover_color="#00B875", 
            text_color="#000000", font=customtkinter.CTkFont(family="Segoe UI Black", size=11), 
            corner_radius=0, border_width=3, border_color="#000000", command=self.open_changelog, height=36
        )
        btn_pembaruan.grid(row=0, column=1, padx=4, sticky="ew")

        btn_donasi = customtkinter.CTkButton(
            bot_btns, text="DONASI", fg_color="#FF499E", hover_color="#E63F8A", 
            text_color="#000000", font=customtkinter.CTkFont(family="Segoe UI Black", size=11), 
            corner_radius=0, border_width=3, border_color="#000000", command=self.open_donasi, height=36
        )
        btn_donasi.grid(row=0, column=2, padx=(4, 0), sticky="ew")

        # Start Realtime Background Sync Loop for Announcements and Deals
        self.start_realtime_announcements()
        self.load_live_deals()

    # =========================================================================
    # DEALS RENDERING LOGIC
    # =========================================================================
    def render_deals_skeleton(self):
        if not hasattr(self, "deals_cards_scroll") or not self.deals_cards_scroll.winfo_exists():
            return
            
        for w in self.deals_cards_scroll.winfo_children():
            w.destroy()

        for i in range(4):
            row = i // 2
            col = i % 2

            card = customtkinter.CTkFrame(
                self.deals_cards_scroll, fg_color="#FFFFFF", 
                border_width=2, border_color="#000000", corner_radius=0
            )
            card.grid(row=row, column=col, padx=4, pady=5, sticky="nsew")
            card.grid_columnconfigure(0, weight=1)

            # Skeleton Cover Box
            img_box = customtkinter.CTkFrame(card, fg_color="#E5E7EB", height=85, corner_radius=0, border_width=0)
            img_box.pack(fill="x", padx=6, pady=(6, 4))

            # Skeleton Title Line
            txt_box = customtkinter.CTkFrame(card, fg_color="#E5E7EB", height=14, width=120, corner_radius=0, border_width=0)
            txt_box.pack(anchor="center", pady=(4, 6))

            # Skeleton Price Line
            prc_box = customtkinter.CTkFrame(card, fg_color="#E5E7EB", height=12, width=80, corner_radius=0, border_width=0)
            prc_box.pack(anchor="center", pady=(0, 6))

            # Skeleton Button Box
            btn_box = customtkinter.CTkFrame(card, fg_color="#D1D5DB", height=28, corner_radius=0, border_width=2, border_color="#000000")
            btn_box.pack(fill="x", padx=6, pady=(0, 6))

    def load_live_deals(self, force_refresh=False):
        if not force_refresh and self.home_deals_data.get("freebies"):
            self.render_home_deals(getattr(self, "home_deals_cat", "freebies"))
            return
        self.render_deals_skeleton()
        threading.Thread(target=self._async_load_deals, daemon=True).start()

    def _async_load_deals(self):
        try:
            from services.deals_service import fetch_live_deals_and_events
            self.home_deals_data = fetch_live_deals_and_events()
        except Exception:
            self.home_deals_data = {"freebies": [], "discounts": [], "events": []}
        if not getattr(self, "is_destroyed", False):
            try:
                self.after(0, lambda: self.render_home_deals(getattr(self, "home_deals_cat", "freebies")))
            except Exception:
                pass

    def _reset_deals_scroll_top(self):
        if hasattr(self, "deals_cards_scroll") and self.deals_cards_scroll.winfo_exists():
            try:
                self.deals_cards_scroll._parent_canvas.yview_moveto(0.0)
            except Exception:
                try:
                    self.deals_cards_scroll.yview_moveto(0.0)
                except Exception:
                    pass

    def switch_home_deals_cat(self, cat_key):
        self.home_deals_cat = cat_key
        self.btn_h_free.configure(fg_color="#FFD800" if cat_key == "freebies" else "#FFFFFF")
        self.btn_h_deals.configure(fg_color="#FFD800" if cat_key == "discounts" else "#FFFFFF")
        self.btn_h_events.configure(fg_color="#FFD800" if cat_key == "events" else "#FFFFFF")
        self.render_home_deals(cat_key)

    def render_home_deals(self, cat_key):
        if not hasattr(self, "deals_cards_scroll") or not self.deals_cards_scroll.winfo_exists():
            return

        self._reset_deals_scroll_top()

        for w in self.deals_cards_scroll.winfo_children():
            try:
                w.grid_forget()
                w.pack_forget()
                w.destroy()
            except Exception:
                pass

        items = self.home_deals_data.get(cat_key, [])
        if not items:
            customtkinter.CTkLabel(
                self.deals_cards_scroll, text="Belum ada data promo untuk kategori ini.", 
                font=customtkinter.CTkFont(family="Segoe UI Black", size=13), text_color="#777777"
            ).pack(pady=30)
            return

        from pages.user.deals import get_store_button_label

        for idx, item in enumerate(items):
            row = idx // 2
            col = idx % 2

            # Card Container - Thick Black Border like My Library!
            card = customtkinter.CTkFrame(
                self.deals_cards_scroll, fg_color="#FFFFFF", 
                border_width=2, border_color="#000000", corner_radius=0
            )
            card.grid(row=row, column=col, padx=4, pady=5, sticky="nsew")
            card.grid_columnconfigure(0, weight=1)

            # Image Container Frame
            img_frame = customtkinter.CTkFrame(card, fg_color="#EAEAEA", height=85, corner_radius=0, border_width=0)
            img_frame.pack(fill="x", padx=6, pady=(6, 4))
            img_frame.pack_propagate(False)

            # Image Label (Placeholder text while downloading asynchronously)
            img_lbl = customtkinter.CTkLabel(
                img_frame, text="🎮 Loading...", 
                font=customtkinter.CTkFont(family="Segoe UI Black", size=10),
                text_color="#888888", fg_color="transparent"
            )
            img_lbl.pack(expand=True, fill="both")

            # Load Cover Image Asynchronously!
            thumb_url = item.get("thumb", "")
            if thumb_url:
                self._async_load_deal_image(thumb_url, img_lbl, size=(190, 85))

            # Overlay Badge Pill Tag on top-right inside Card
            badge_text = item.get("savings_pct") or item.get("discount_pct") or "PROMO"
            badge_bg = "#FF499E" if "GRATIS" in item.get("sale_price", "") or badge_text == "100%" or badge_text == "-100%" else "#10b981"
            
            lbl_badge = customtkinter.CTkLabel(
                img_frame, text=f" {badge_text} ", 
                font=customtkinter.CTkFont(family="Segoe UI Black", size=10), 
                fg_color=badge_bg, text_color="#FFFFFF", corner_radius=0
            )
            lbl_badge.place(relx=1.0, rely=0.0, anchor="ne", x=-3, y=3)

            # Game Title below cover image
            raw_title = item.get("title", "")
            clean_title = raw_title[:24] + "..." if len(raw_title) > 26 else raw_title

            lbl_name = customtkinter.CTkLabel(
                card, text=clean_title, 
                font=customtkinter.CTkFont(family="Segoe UI Black", size=11), 
                text_color="#000000", justify="center", anchor="center"
            )
            lbl_name.pack(fill="x", padx=6, pady=(4, 2))

            # Price Row
            price_box = customtkinter.CTkFrame(card, fg_color="transparent")
            price_box.pack(anchor="center", pady=(0, 4))

            sale_p = item.get("sale_price") or item.get("final_price") or "GRATIS"
            norm_p = item.get("normal_price") or ""

            lbl_price = customtkinter.CTkLabel(
                price_box, text=f"{sale_p} ", 
                font=customtkinter.CTkFont(family="Segoe UI Black", size=11), text_color="#000000"
            )
            lbl_price.pack(side="left")

            if norm_p and norm_p != sale_p:
                lbl_norm = customtkinter.CTkLabel(
                    price_box, text=norm_p, 
                    font=customtkinter.CTkFont(family="Segoe UI", size=9, overstrike=True), text_color="#888888"
                )
                lbl_norm.pack(side="left")

            # Store Button
            target_url = item.get("store_url", "https://store.steampowered.com/")
            store_label = get_store_button_label(target_url, item.get("store_name", ""))

            btn_open = customtkinter.CTkButton(
                card, text=store_label, 
                font=customtkinter.CTkFont(family="Segoe UI Black", size=10), 
                fg_color="#5D5FEF", hover_color="#4B4DDC", text_color="#FFFFFF", 
                border_width=2, border_color="#000000", corner_radius=0, height=28, 
                command=lambda url=target_url: webbrowser.open(url)
            )
            btn_open.pack(fill="x", padx=6, pady=(0, 6))

    def _async_load_deal_image(self, url, img_label, size=(190, 85)):
        if not url: return
        if url in self.deal_img_cache:
            try:
                img_label.configure(image=self.deal_img_cache[url], text="")
            except Exception:
                pass
            return

        def _worker():
            try:
                headers = {"User-Agent": "Mozilla/5.0"}
                res = requests.get(url, headers=headers, timeout=5)
                if res.status_code == 200:
                    pil_img = Image.open(BytesIO(res.content))
                    pil_img = ImageOps.fit(pil_img, size, Image.Resampling.LANCZOS)
                    ctk_img = customtkinter.CTkImage(light_image=pil_img, dark_image=pil_img, size=size)
                    self.deal_img_cache[url] = ctk_img
                    if not self.is_destroyed:
                        self.after(0, lambda: self._safe_set_img(img_label, ctk_img))
            except Exception:
                pass

        threading.Thread(target=_worker, daemon=True).start()

    def _safe_set_img(self, img_label, ctk_img):
        try:
            if img_label.winfo_exists():
                img_label.configure(image=ctk_img, text="")
        except Exception:
            pass


    # =========================================================================
    # UTILITY HANDLERS & ANNOUNCEMENT LOGIC
    # =========================================================================
    def open_guide(self):
        from components.dialogs import InfoDialog
        text = self.button_data.get("panduan", "")
        InfoDialog(self.winfo_toplevel(), "Panduan Penggunaan", text)

    def open_changelog(self):
        from components.dialogs import InfoDialog
        text = self.button_data.get("pembaruan", "")
        InfoDialog(self.winfo_toplevel(), "Update Terbaru", text)

    def open_donasi(self):
        url = self.button_data.get("donasi", "https://saweria.co/")
        webbrowser.open(url)

    def destroy(self):
        self.is_destroyed = True
        super().destroy()

    def refresh_page(self):
        self._last_ann_hash = None
        self.load_announcement()

    def load_announcement(self):
        threading.Thread(target=self._async_load_announcement, daemon=True).start()

    def start_realtime_announcements(self):
        threading.Thread(target=self._realtime_loop, daemon=True).start()

    def _realtime_loop(self):
        import time
        while not self.is_destroyed:
            try:
                from core.firebase_sync import fetch_announcements
                ann_data = fetch_announcements()
                
                cur_hash = hash(json.dumps(ann_data, sort_keys=True)) if ann_data else 0
                if cur_hash != self._last_ann_hash:
                    self._last_ann_hash = cur_hash
                    self.after(0, lambda data=ann_data: self._render_announcement_items(data))
            except Exception:
                pass
            time.sleep(3)

    def _async_load_announcement(self):
        try:
            from core.firebase_sync import fetch_announcements
            ann_data = fetch_announcements()
            self.after(0, lambda: self._render_announcement_items(ann_data))
        except Exception:
            pass

    def _render_announcement_items(self, ann_data):
        if not hasattr(self, 'announce_scroll') or not self.announce_scroll.winfo_exists():
            return
            
        for child in self.announce_scroll.winfo_children():
            child.destroy()
            
        if not ann_data or not isinstance(ann_data, (dict, list)):
            empty_lbl = customtkinter.CTkLabel(
                self.announce_scroll, text="Belum ada pengumuman.", 
                font=customtkinter.CTkFont(family="Segoe UI Black", size=13), text_color=self.TEXT_MUTED
            )
            empty_lbl.pack(pady=20)
            return

        from core import discord_auth
        current_dc = discord_auth.get_cached_username()

        items_list = []
        if isinstance(ann_data, dict):
            for k, v in ann_data.items():
                if isinstance(v, dict):
                    v['_id'] = k
                    items_list.append(v)
        elif isinstance(ann_data, list):
            for idx, v in enumerate(ann_data):
                if isinstance(v, dict):
                    v['_id'] = str(idx)
                    items_list.append(v)

        if not items_list:
            empty_lbl = customtkinter.CTkLabel(
                self.announce_scroll, text="Belum ada pengumuman.", 
                font=customtkinter.CTkFont(family="Segoe UI Black", size=13), text_color=self.TEXT_MUTED
            )
            empty_lbl.pack(pady=20)
            return

        for item in items_list:
            ann_id = item.get('_id', 'ann')
            text_content = item.get('text') or item.get('content') or ''
            image_url = item.get('image_url', '')
            image_b64 = item.get('image_base64', '')
            reactions = item.get('reactions', {})
            if not isinstance(reactions, dict): reactions = {}

            if not text_content and not image_url and not image_b64:
                continue
            
            box = customtkinter.CTkFrame(
                self.announce_scroll, fg_color="#FFFFFF", 
                border_width=2, border_color=self.BORDER_COLOR, corner_radius=0
            )
            box.pack(fill="x", pady=5, padx=2)
            
            if text_content:
                txt_lbl = customtkinter.CTkLabel(
                    box, text=text_content, 
                    font=customtkinter.CTkFont(family="Segoe UI", size=12, weight="bold"), 
                    text_color=self.TEXT_BLACK, wraplength=250, justify="center", anchor="center"
                )
                txt_lbl.pack(fill="x", padx=10, pady=(12, 6))
            
            react_bar = customtkinter.CTkFrame(box, fg_color="transparent")
            react_bar.pack(fill="x", padx=10, pady=(4, 8))
            
            react_inner = customtkinter.CTkFrame(react_bar, fg_color="transparent")
            react_inner.pack(anchor="center")

            emojis = [("fire", "🔥"), ("like", "👍"), ("rocket", "🚀")]
            for e_key, e_symbol in emojis:
                users_list = reactions.get(e_key, [])
                if not isinstance(users_list, list): users_list = []
                count = len(users_list)
                has_reacted = current_dc in users_list
                
                btn_bg = self.ACCENT_YELLOW if has_reacted else "#FFFFFF"
                
                btn = customtkinter.CTkButton(
                    react_inner, text=f"{e_symbol} {count}", 
                    font=customtkinter.CTkFont(family="Segoe UI Black", size=11),
                    fg_color=btn_bg, hover_color="#E6C300" if has_reacted else "#F0F0F0",
                    text_color="#000000", border_width=2, border_color="#000000",
                    corner_radius=0, width=46, height=24,
                    command=lambda aid=ann_id, ek=e_key: self._toggle_reaction(aid, ek)
                )
                btn.pack(side="left", padx=3)

    def _toggle_reaction(self, ann_id, emoji_key):
        from core import discord_auth, firebase_sync
        current_dc = discord_auth.get_cached_username()
        if not current_dc: return
        
        threading.Thread(
            target=lambda: firebase_sync.toggle_announcement_reaction(ann_id, emoji_key, current_dc), 
            daemon=True
        ).start()
