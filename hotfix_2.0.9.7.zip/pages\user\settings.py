import customtkinter
import threading
import sys
import os
import subprocess
import tkinter.messagebox as messagebox
from core.config import load_config, save_config

class SettingsPage(customtkinter.CTkFrame):
    def __init__(self, parent, main_app):
        super().__init__(parent, fg_color="#FFFFFF")
        self.parent = parent
        self.main_app = main_app
        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(1, weight=1)
        
        self.config = load_config()
        
        # Header
        header = customtkinter.CTkFrame(self, fg_color="#FFFFFF", border_width=3, border_color="#000000", corner_radius=0)
        header.grid(row=0, column=0, sticky="ew", pady=(0, 8))
        
        # Title Container to keep title and ornaments perfectly aligned and consistent on resize
        title_container = customtkinter.CTkFrame(header, fg_color="transparent")
        title_container.pack(pady=(8, 2))
        
        customtkinter.CTkLabel(title_container, text="🙂", font=("Segoe UI Emoji", 18), fg_color="#FFFFFF").pack(side="left", padx=(0, 10))
        
        lbl_title = customtkinter.CTkLabel(title_container, text="Pengaturan Aplikasi", font=customtkinter.CTkFont(family="Segoe UI Black", size=18), text_color="#000000")
        lbl_title.pack(side="left")
        
        customtkinter.CTkLabel(title_container, text="✦", font=("Segoe UI Black", 16), text_color="#5D5FEF", fg_color="#FFFFFF").pack(side="left", padx=(10, 0))
        
        lbl_subtitle = customtkinter.CTkLabel(header, text="Kustomisasi pengalaman pengguna.", font=customtkinter.CTkFont(family="Segoe UI Black", size=12), text_color="#333333")
        lbl_subtitle.pack(pady=(0, 8))

        # Main Panel (Scrollable to prevent overflow)
        self.main_panel = customtkinter.CTkScrollableFrame(self, fg_color="transparent")
        self.main_panel.grid(row=1, column=0, sticky="nsew")
        self.main_panel.grid_columnconfigure(0, weight=1)
        
        # 1. Update Card
        update_card = customtkinter.CTkFrame(self.main_panel, fg_color="#FFFFFF", corner_radius=0, border_width=3, border_color="#000000")
        update_card.grid(row=0, column=0, pady=(0, 10), sticky="ew")
        
        lbl_update = customtkinter.CTkLabel(update_card, text="Pembaruan Aplikasi", font=customtkinter.CTkFont(family="Segoe UI Black", size=16), text_color="#000000")
        lbl_update.pack(pady=(15, 5))
        
        lbl_update_desc = customtkinter.CTkLabel(update_card, text="Pastikan GameZone Anda selalu menggunakan versi terbaru.", font=customtkinter.CTkFont(family="Segoe UI", size=12, weight="bold"), text_color="#555555")
        lbl_update_desc.pack(pady=(0, 15))
        
        btn_update = customtkinter.CTkButton(update_card, text="Periksa Pembaruan", width=320, height=38, fg_color="#00D084", hover_color="#00B875", text_color="#000000", font=customtkinter.CTkFont(family="Segoe UI Black", size=13), corner_radius=0, border_width=3, border_color="#000000", command=self.check_for_update)
        btn_update.pack(pady=(0, 20))

        # 2. Cache & Storage Card
        cache_card = customtkinter.CTkFrame(self.main_panel, fg_color="#FFFFFF", corner_radius=0, border_width=3, border_color="#000000")
        cache_card.grid(row=1, column=0, pady=(0, 10), sticky="ew")
        
        lbl_cache = customtkinter.CTkLabel(cache_card, text="Pembersihan Cache", font=customtkinter.CTkFont(family="Segoe UI Black", size=16), text_color="#000000")
        lbl_cache.pack(pady=(15, 5))
        
        lbl_cache_desc = customtkinter.CTkLabel(cache_card, text="Membersihkan cache gambar, daftar game, dan data sementara untuk menyegarkan aplikasi.", font=customtkinter.CTkFont(family="Segoe UI", size=12, weight="bold"), text_color="#555555")
        lbl_cache_desc.pack(pady=(0, 15))
        
        btn_clear_cache = customtkinter.CTkButton(cache_card, text="Bersihkan Semua Cache", width=320, height=38, fg_color="#FF499E", hover_color="#E63F8A", text_color="#000000", font=customtkinter.CTkFont(family="Segoe UI Black", size=13), corner_radius=0, border_width=3, border_color="#000000", command=self.clear_all_cache)
        btn_clear_cache.pack(pady=(0, 20))

        # 3. Auto Steam License Cache Cleaner Toggle Card
        cleaner_card = customtkinter.CTkFrame(self.main_panel, fg_color="#FFFFFF", corner_radius=0, border_width=3, border_color="#000000")
        cleaner_card.grid(row=2, column=0, pady=(0, 10), sticky="ew")

        lbl_cleaner = customtkinter.CTkLabel(cleaner_card, text="🧹 Auto Steam License Cleaner (Windows Logon)", font=customtkinter.CTkFont(family="Segoe UI Black", size=16), text_color="#000000")
        lbl_cleaner.pack(pady=(15, 5))

        lbl_cleaner_desc = customtkinter.CTkLabel(cleaner_card, text="Otomatis membersihkan file cache lisensi Steam (appinfo.vdf) setiap kali PC dinyalakan.\nMencegah tombol game inject berubah menjadi 'Purchase' saat Steam dibuka manual.", font=customtkinter.CTkFont(family="Segoe UI", size=12, weight="bold"), text_color="#555555", justify="center")
        lbl_cleaner_desc.pack(pady=(0, 10))

        try:
            from services.steam_service import is_steam_cleaner_task_installed
            is_active = is_steam_cleaner_task_installed()
        except Exception:
            is_active = False

        self.switch_cleaner = customtkinter.CTkSwitch(
            cleaner_card, 
            text="Pembersih Lisensi Otomatis (Saat PC Booting)",
            font=customtkinter.CTkFont(family="Segoe UI Black", size=13),
            text_color="#000000",
            progress_color="#10b981",
            button_color="#000000",
            button_hover_color="#333333",
            command=self._on_toggle_cleaner
        )
        if is_active:
            self.switch_cleaner.select()
        else:
            self.switch_cleaner.deselect()
        self.switch_cleaner.pack(pady=(0, 20))

    def _on_toggle_cleaner(self):
        val = bool(self.switch_cleaner.get())
        def _worker():
            try:
                from services.steam_service import toggle_steam_cleaner_task
                ok = toggle_steam_cleaner_task(val)
                def _done():
                    if ok:
                        msg = "Pembersih lisensi otomatis SAAT PC BOOTING telah DIAKTIFKAN." if val else "Pembersih lisensi otomatis SAAT PC BOOTING telah DIMATIKAN."
                        messagebox.showinfo("Berhasil", msg, parent=self.winfo_toplevel())
                    else:
                        messagebox.showerror("Gagal", "Gagal memperbarui status autorun Windows.", parent=self.winfo_toplevel())
                self.after(0, _done)
            except Exception as e:
                self.after(0, lambda: messagebox.showerror("Error", str(e), parent=self.winfo_toplevel()))
        threading.Thread(target=_worker, daemon=True).start()


    def check_for_update(self):
        # Memanggil metode async check update dengan argumen 'manual=True' 
        # (kita akan update fungsi _async_check_update di main.py untuk menerima argumen ini)
        threading.Thread(target=self.main_app._async_check_update, args=(True,), daemon=True).start()


    def clear_all_cache(self):
        if messagebox.askyesno("Konfirmasi", "Apakah Anda yakin ingin membersihkan semua cache aplikasi?", parent=self.winfo_toplevel()):
            def _async_clear():
                try:
                    # 1. Clear local cache directory
                    cache_dir = os.path.join(os.getcwd(), "cache")
                    if os.path.exists(cache_dir):
                        for item in os.listdir(cache_dir):
                            if item == "discord_session.json":
                                continue
                            item_path = os.path.join(cache_dir, item)
                            try:
                                if os.path.isfile(item_path):
                                    os.remove(item_path)
                                elif os.path.isdir(item_path):
                                    import shutil
                                    shutil.rmtree(item_path)
                            except Exception:
                                pass

                    # 2. Clear AppData deals cache
                    appdata_deals_cache = os.path.join(os.getenv('LOCALAPPDATA', os.path.expanduser('~')), 'GameZone', 'deals_cache.json')
                    if os.path.exists(appdata_deals_cache):
                        try:
                            os.remove(appdata_deals_cache)
                        except Exception:
                            pass

                    # 3. Clear memory image caches & trigger live refresh
                    if hasattr(self.main_app, "library_page") and self.main_app.library_page:
                        try:
                            self.main_app.library_page.image_cache.clear()
                            self.main_app.library_page.force_reload_library()
                        except Exception:
                            pass

                    if hasattr(self.main_app, "home_page") and self.main_app.home_page:
                        try:
                            self.main_app.home_page.deal_img_cache.clear()
                            self.main_app.home_page.load_live_deals()
                        except Exception:
                            pass

                    # 4. Clear Steam depotcache manifest files (.manifest) across all Steam drives
                    try:
                        from services.steam_service import get_all_steamapps_paths
                        for sa_path in get_all_steamapps_paths():
                            depotcache_path = os.path.join(os.path.dirname(sa_path), "depotcache")
                            if os.path.exists(depotcache_path):
                                for f in os.listdir(depotcache_path):
                                    if f.endswith(".manifest"):
                                        try:
                                            os.remove(os.path.join(depotcache_path, f))
                                        except Exception:
                                            pass
                    except Exception:
                        pass

                    self.after(0, lambda: messagebox.showinfo("Sukses", "Semua cache aplikasi & manifest depotcache Steam berhasil dibersihkan!", parent=self.winfo_toplevel()))
                except Exception as e:
                    self.after(0, lambda: messagebox.showerror("Gagal", f"Gagal membersihkan cache: {e}", parent=self.winfo_toplevel()))

            threading.Thread(target=_async_clear, daemon=True).start()

