try:
    import pystray
    PYSTRAY_AVAILABLE = True
except ImportError:
    pystray = None
    PYSTRAY_AVAILABLE = False

from PIL import Image
import os
import threading

class TrayManager:
    def __init__(self, app, icon_path=None, on_restore=None, on_exit=None):
        self.app = app
        self.icon_path = icon_path
        self.on_restore = on_restore
        self.on_exit = on_exit
        self.icon = None
        self._thread = None
        self.available = PYSTRAY_AVAILABLE

    def _create_default_image(self):
        """Generate a clean 64x64 PIL Image if icon file is missing."""
        img = Image.new('RGBA', (64, 64), color=(0, 0, 0, 0))
        from PIL import ImageDraw
        draw = ImageDraw.Draw(img)
        draw.ellipse([4, 4, 60, 60], fill='#5D5FEF', outline='#000000', width=3)
        draw.text((20, 20), "GZ", fill="#FFFFFF")
        return img

    def _load_icon_image(self):
        if self.icon_path and os.path.exists(self.icon_path):
            try:
                img = Image.open(self.icon_path)
                return img
            except Exception:
                pass
        return self._create_default_image()

    def start(self):
        if not self.available or not pystray:
            return
        image = self._load_icon_image()


        def _on_restore_clicked(icon, item):
            if self.on_restore:
                self.on_restore()

        def _on_exit_clicked(icon, item):
            if self.on_exit:
                self.on_exit()

        menu = pystray.Menu(
            pystray.MenuItem("Tampilkan GameZone", _on_restore_clicked, default=True),
            pystray.MenuItem("Keluar", _on_exit_clicked)
        )

        self.icon = pystray.Icon("GameZone", image, "GameZone", menu=menu)

        def _run_icon():
            try:
                self.icon.run()
            except Exception:
                pass

        self._thread = threading.Thread(target=_run_icon, daemon=True)
        self._thread.start()

    def stop(self):
        if self.icon:
            try:
                self.icon.stop()
            except Exception:
                pass
            self.icon = None
