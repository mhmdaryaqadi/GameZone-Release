import os
import json

def get_profile_file():
    os.makedirs("cache", exist_ok=True)
    return os.path.join("cache", "profile.json")

_cached_profile = None

def load_profile():
    global _cached_profile
    if _cached_profile is not None:
        return _cached_profile
    profile_file = get_profile_file()
    if os.path.exists(profile_file):
        try:
            with open(profile_file, 'r', encoding='utf-8') as f:
                _cached_profile = json.load(f)
                return _cached_profile
        except:
            pass
    return {"nickname": "Anonymous", "avatar": "avatar1.png"}

def save_profile(nickname, avatar):
    global _cached_profile
    _cached_profile = {"nickname": nickname, "avatar": avatar}
    profile_file = get_profile_file()
    with open(profile_file, 'w', encoding='utf-8') as f:
        json.dump(_cached_profile, f)
