import socket
import threading
import sys
import os

SINGLE_INSTANCE_PORT = 49281

class SingleInstanceLock:
    def __init__(self, port=SINGLE_INSTANCE_PORT):
        self.port = port
        self.server_socket = None
        self.is_primary = False
        self._listener_thread = None

    def check_and_lock(self, on_restore_callback):
        """
        Returns True if this is the primary instance.
        Returns False if another instance is already running (and notifies it to restore).
        """
        # Try connecting to an existing instance
        try:
            client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            client.settimeout(0.8)
            client.connect(('127.0.0.1', self.port))
            client.sendall(b"RESTORE_GAMEZONE\n")
            client.close()
            return False  # Existing instance found and notified!
        except (socket.error, ConnectionRefusedError, OSError):
            pass

        # If connection failed, we become the primary instance and start listening
        try:
            self.server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            self.server_socket.bind(('127.0.0.1', self.port))
            self.server_socket.listen(5)
            self.is_primary = True

            def _listen_loop():
                while self.server_socket:
                    try:
                        conn, _ = self.server_socket.accept()
                        data = conn.recv(1024)
                        if b"RESTORE_GAMEZONE" in data:
                            if on_restore_callback:
                                on_restore_callback()
                        conn.close()
                    except Exception:
                        break

            self._listener_thread = threading.Thread(target=_listen_loop, daemon=True)
            self._listener_thread.start()
            return True
        except Exception as e:
            # Fallback: if binding fails for any unexpected reason, proceed as primary
            return True

    def close(self):
        if self.server_socket:
            try:
                self.server_socket.close()
            except Exception:
                pass
            self.server_socket = None
