import threading
import webbrowser
import requests
import urllib.parse
import os
import json
from http.server import HTTPServer, BaseHTTPRequestHandler

CLIENT_ID = "1516735618921529444"
CLIENT_SECRET = "Wnw8DaiGxb0o_oa2odLkRj2znACdPq_F"
REDIRECT_URI = "http://localhost:8080/callback"
GUILD_ID = "1433834824472199168"
INVITE_LINK = "https://discord.gg/psVN4DDGA"

auth_code = None

class OAuthHandler(BaseHTTPRequestHandler):
    def log_message(self, format, *args):
        pass

    def do_GET(self):
        global auth_code
        parsed_path = urllib.parse.urlparse(self.path)
        if parsed_path.path == '/callback':
            query = urllib.parse.parse_qs(parsed_path.query)
            if 'code' in query:
                auth_code = query['code'][0]
                html = """
                <html><head><style>body { background-color: #F4EFEB; font-family: sans-serif; text-align: center; padding-top: 50px; }</style></head>
                <body>
                    <h1 style='color: #00D084;'>Login Discord Berhasil!</h1>
                    <p>Silakan tutup tab ini dan kembali ke aplikasi GameZone.</p>
                    <script>setTimeout(function(){ window.close(); }, 3000);</script>
                </body></html>
                """
                encoded_html = html.encode('utf-8')
                self.send_response(200)
                self.send_header('Content-type', 'text/html; charset=utf-8')
                self.send_header('Content-Length', str(len(encoded_html)))
                self.send_header('Connection', 'close')
                self.end_headers()
                self.wfile.write(encoded_html)
                self.wfile.flush()
            else:
                html = "<html><body><h1>Login Gagal</h1><p>Kode otentikasi tidak ditemukan.</p></body></html>"
                encoded_html = html.encode('utf-8')
                self.send_response(400)
                self.send_header('Content-type', 'text/html; charset=utf-8')
                self.send_header('Content-Length', str(len(encoded_html)))
                self.send_header('Connection', 'close')
                self.end_headers()
                self.wfile.write(encoded_html)
                self.wfile.flush()
            
            # Stop the server after receiving the callback
            def shutdown_server():
                import time
                time.sleep(0.1)
                self.server.shutdown()
            threading.Thread(target=shutdown_server, daemon=True).start()

def get_discord_auth_url():
    return f"https://discord.com/api/oauth2/authorize?client_id={CLIENT_ID}&redirect_uri={urllib.parse.quote(REDIRECT_URI)}&response_type=code&scope=identify%20guilds"

def get_session_file():
    appdata = os.getenv('LOCALAPPDATA', '')
    cache_dir = os.path.join(appdata, 'GameZone', 'cache')
    os.makedirs(cache_dir, exist_ok=True)
    return os.path.join(cache_dir, "discord_session.json")

def verify_access_token(access_token):
    try:
        headers = {
            'Authorization': f"Bearer {access_token}"
        }
        r2 = requests.get("https://discord.com/api/users/@me/guilds", headers=headers, timeout=10)
        if r2.status_code in [401, 403]:
            return False, "Token tidak valid atau kadaluarsa."
        if r2.status_code != 200:
            return True, None
            
        r3 = requests.get("https://discord.com/api/users/@me", headers=headers, timeout=10)
        username = "Unknown"
        avatar_url = ""
        if r3.status_code == 200:
            user_data = r3.json()
            username = user_data.get('username', 'Unknown')
            user_id = user_data.get('id', '')
            avatar_hash = user_data.get('avatar', '')
            if user_id:
                if avatar_hash:
                    avatar_url = f"https://cdn.discordapp.com/avatars/{user_id}/{avatar_hash}.png?size=64"
                else:
                    avatar_url = f"https://cdn.discordapp.com/embed/avatars/{int(user_id) % 5}.png"
            
        guilds = r2.json()
        for g in guilds:
            if str(g.get('id', '')) == GUILD_ID:
                return True, (username, avatar_url)
                
        return False, f"Anda belum bergabung dengan server Discord GAME ZONE!\nSilakan bergabung melalui link:\n{INVITE_LINK}"
    except requests.exceptions.RequestException:
        # Connection error, assume token is still valid (don't kick offline users)
        return True, None
    except Exception as e:
        return False, f"Gagal mengecek server Discord: {e}"

def check_saved_session():
    session_file = get_session_file()
    if os.path.exists(session_file):
        try:
            with open(session_file, 'r', encoding='utf-8') as f:
                data = json.load(f)
                access_token = data.get('access_token')
                if access_token:
                    success, res_data = verify_access_token(access_token)
                    if success:
                        if res_data is not None:
                            save_session(access_token, res_data)
                    return success
        except:
            pass
    return False

_cached_username = None
_cached_avatar_url = None

def get_cached_username():
    global _cached_username
    if _cached_username is not None:
        return _cached_username
    session_file = get_session_file()
    if os.path.exists(session_file):
        try:
            with open(session_file, 'r', encoding='utf-8') as f:
                data = json.load(f)
                _cached_username = data.get('username', 'Unknown')
                return _cached_username
        except:
            pass
    return "Unknown"

def get_cached_avatar_url():
    global _cached_avatar_url
    if _cached_avatar_url is not None:
        return _cached_avatar_url
    session_file = get_session_file()
    if os.path.exists(session_file):
        try:
            with open(session_file, 'r', encoding='utf-8') as f:
                data = json.load(f)
                _cached_avatar_url = data.get('avatar_url', '')
                return _cached_avatar_url
        except:
            pass
    return ""

def save_session(access_token, username_or_tuple):
    global _cached_username, _cached_avatar_url
    session_file = get_session_file()
    if isinstance(username_or_tuple, tuple):
        username = username_or_tuple[0]
        avatar_url = username_or_tuple[1]
    else:
        username = username_or_tuple
        avatar_url = ""
        
    _cached_username = username
    _cached_avatar_url = avatar_url
        
    with open(session_file, 'w', encoding='utf-8') as f:
        json.dump({'access_token': access_token, 'username': username, 'avatar_url': avatar_url}, f)

class ReusableHTTPServer(HTTPServer):
    allow_reuse_address = True

def _free_port_8080():
    try:
        import subprocess
        cmd = 'netstat -ano | findstr :8080'
        out = subprocess.check_output(cmd, shell=True, text=True, errors='ignore')
        for line in out.splitlines():
            if 'LISTENING' in line:
                parts = line.strip().split()
                pid = parts[-1]
                if pid.isdigit() and int(pid) != os.getpid():
                    subprocess.call(f'taskkill /PID {pid} /F', shell=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except Exception:
        pass

def authenticate_and_verify():
    global auth_code
    auth_code = None
    
    # 1. Otomatis bebaskan port 8080 jika ada sisa proses zombie
    _free_port_8080()
    import time
    time.sleep(0.2)
    
    server = None
    try:
        server = ReusableHTTPServer(('localhost', 8080), OAuthHandler)
    except OSError:
        try:
            import socket
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            sock.bind(('localhost', 8080))
            sock.listen(5)
            server = ReusableHTTPServer(('localhost', 8080), OAuthHandler, bind_and_activate=False)
            server.socket = sock
            server.server_address = sock.getsockname()
        except Exception:
            return False, "Port 8080 sedang digunakan oleh aplikasi lain. Harap tutup aplikasi yang menggunakan port tersebut."

    auth_url = get_discord_auth_url()
    webbrowser.open(auth_url)
    
    # Block until server receives callback
    server.serve_forever()
    server.server_close()
    
    if not auth_code:
        return False, "Gagal mendapatkan kode otentikasi dari Discord."
        
    # Exchange code for token
    data = {
        'client_id': CLIENT_ID,
        'client_secret': CLIENT_SECRET,
        'grant_type': 'authorization_code',
        'code': auth_code,
        'redirect_uri': REDIRECT_URI
    }
    headers = {
        'Content-Type': 'application/x-www-form-urlencoded'
    }
    
    try:
        r = requests.post("https://discord.com/api/oauth2/token", data=data, headers=headers, timeout=10)
        if r.status_code != 200:
            return False, f"Gagal menukar token: {r.text}"
            
        token_data = r.json()
        access_token = token_data.get('access_token')
        
        if not access_token:
            return False, "Token akses tidak ditemukan."
            
        success, msg_or_username = verify_access_token(access_token)
        if success:
            save_session(access_token, msg_or_username)
            return True, "Login Berhasil!"
        else:
            # If they failed, open the invite link for them
            webbrowser.open(INVITE_LINK)
            return False, msg_or_username
            
    except Exception as e:
        return False, f"Terjadi kesalahan saat memverifikasi Discord: {e}"
