import customtkinter
import json

class SkeletonOverlay(customtkinter.CTkFrame):
    def __init__(self, master, layout_type="grid", bg_color="#F4EFEB", element_color="#E0E0E0", border_color="#000000", place_overlay=True, **kwargs):
        # Master adalah container spesifik (misal: content_frame, left_panel, main_box)
        super().__init__(master, fg_color=bg_color, corner_radius=0, border_width=0, **kwargs)
        self.layout_type = layout_type
        self.bg_color = bg_color
        self.element_color = element_color
        self.border_color = border_color
        
        if place_overlay:
            # We absolute place it to cover the container
            self.place(relx=0, rely=0, relwidth=1, relheight=1)
            self.lift()
        
        self.fade_widgets = []
        self.containers = []
        
        self.build_layout()

    def register_element(self, widget):
        self.fade_widgets.append(widget)

    def register_container(self, widget):
        self.containers.append(widget)

    def build_layout(self):
        if self.layout_type == "hub_left":
            self.build_hub_left()
        elif self.layout_type == "hub_right":
            self.build_hub_right()
        elif self.layout_type == "online_fix":
            self.build_online_fix()
        elif self.layout_type == "profile":
            self.build_profile()
        elif self.layout_type == "settings":
            self.build_settings()
        elif self.layout_type == "status":
            self.build_status()
        elif self.layout_type == "help":
            self.build_help()
        # Admin Specific layouts (within content container)
        elif self.layout_type == "admin_db_settings":
            self.build_admin_db_settings()
        elif self.layout_type == "admin_announce":
            self.build_admin_announce()
        elif self.layout_type == "admin_accounts_list":
            self.build_admin_accounts_list()
        elif self.layout_type == "admin_accounts_form":
            self.build_admin_accounts_form()
        elif self.layout_type == "admin_generic_split":
            self.build_admin_generic_split()
        elif self.layout_type == "admin_generic_table":
            self.build_admin_generic_table()
        else:
            self.build_generic()

    def build_hub_left(self):
        # Hanya bagian kiri (Form Inject) InjectionHubPage
        t_box = customtkinter.CTkFrame(self, width=180, height=45, fg_color=self.element_color, corner_radius=6)
        t_box.pack(pady=(20, 10))
        self.register_element(t_box)
        
        desc_bar = customtkinter.CTkFrame(self, width=280, height=14, fg_color=self.element_color, corner_radius=4)
        desc_bar.pack(pady=(0, 15))
        self.register_element(desc_bar)
        
        inp_p = customtkinter.CTkFrame(self, height=45, fg_color=self.element_color, corner_radius=0, border_width=3, border_color=self.border_color)
        inp_p.pack(fill="x", padx=20, pady=(0, 20))
        self.register_element(inp_p)
        
        btn_p = customtkinter.CTkFrame(self, width=250, height=50, fg_color=self.element_color, corner_radius=0, border_width=3, border_color=self.border_color)
        btn_p.pack(pady=(0, 20))
        self.register_element(btn_p)
        
        alt_p = customtkinter.CTkFrame(self, width=130, height=80, fg_color=self.element_color, corner_radius=0, border_width=3, border_color=self.border_color)
        alt_p.pack(pady=(0, 20))
        self.register_element(alt_p)

    def build_hub_right(self):
        # Hanya bagian kanan (Scroll list pengumuman)
        r_title = customtkinter.CTkFrame(self, width=160, height=30, fg_color=self.element_color, corner_radius=6)
        r_title.pack(pady=(15, 10))
        self.register_element(r_title)
        
        for _ in range(2):
            card = customtkinter.CTkFrame(self, height=110, fg_color="#F4EFEB", border_width=2, border_color=self.border_color, corner_radius=0)
            card.pack(fill="x", padx=15, pady=8)
            self.register_container(card)
            
            c_header = customtkinter.CTkFrame(card, height=14, fg_color=self.element_color, corner_radius=4)
            c_header.pack(fill="x", padx=15, pady=(15, 8))
            self.register_element(c_header)
            
            c_body1 = customtkinter.CTkFrame(card, height=10, fg_color=self.element_color, corner_radius=4)
            c_body1.pack(fill="x", padx=15, pady=4)
            self.register_element(c_body1)

    def build_online_fix(self):
        # Isi dari content_frame OnlineFixPage
        self.grid_columnconfigure(0, weight=5)
        self.grid_columnconfigure(1, weight=5)
        self.grid_rowconfigure(0, weight=1)
        
        left_area = customtkinter.CTkFrame(self, fg_color="transparent")
        left_area.grid(row=0, column=0, sticky="nsew", padx=20, pady=20)
        
        desc_bar = customtkinter.CTkFrame(left_area, width=280, height=24, fg_color=self.element_color, corner_radius=6)
        desc_bar.pack(pady=(40, 15), fill="x")
        self.register_element(desc_bar)
        
        sub_bar = customtkinter.CTkFrame(left_area, width=280, height=14, fg_color=self.element_color, corner_radius=4)
        sub_bar.pack(pady=(0, 30), fill="x")
        self.register_element(sub_bar)
        
        btn1 = customtkinter.CTkFrame(left_area, width=280, height=50, fg_color=self.element_color, corner_radius=0, border_width=3, border_color=self.border_color)
        btn1.pack(pady=10)
        self.register_element(btn1)
        
        right_area = customtkinter.CTkFrame(self, fg_color="transparent")
        right_area.grid(row=0, column=1, sticky="nsew", padx=20, pady=20)
        right_area.grid_columnconfigure(0, weight=1)
        right_area.grid_rowconfigure(1, weight=1)
        
        lbl_acc = customtkinter.CTkFrame(right_area, width=150, height=22, fg_color=self.element_color, corner_radius=4)
        lbl_acc.grid(row=0, column=0, sticky="w", pady=(0, 10))
        self.register_element(lbl_acc)
        
        acc_scroll = customtkinter.CTkFrame(right_area, fg_color="#F4EFEB", border_width=3, border_color=self.border_color, corner_radius=0)
        acc_scroll.grid(row=1, column=0, sticky="nsew")
        self.register_container(acc_scroll)
        
        for _ in range(3):
            card = customtkinter.CTkFrame(acc_scroll, height=75, fg_color="#FFFFFF", border_width=2, border_color=self.border_color, corner_radius=0)
            card.pack(fill="x", padx=10, pady=6)
            self.register_container(card)
            
            p_bar = customtkinter.CTkFrame(card, width=100, height=14, fg_color=self.element_color, corner_radius=4)
            p_bar.pack(anchor="w", padx=10, pady=(5, 5))
            self.register_element(p_bar)

    def build_profile(self):
        card = customtkinter.CTkFrame(self, fg_color="#F4EFEB", border_width=2, border_color=self.border_color, corner_radius=0)
        card.pack(pady=40, padx=40, fill="both", expand=True)
        self.register_container(card)
        
        avatar = customtkinter.CTkFrame(card, width=90, height=90, fg_color=self.element_color, corner_radius=45)
        avatar.pack(pady=20)
        self.register_element(avatar)
        
        for _ in range(3):
            bar = customtkinter.CTkFrame(card, width=250, height=14, fg_color=self.element_color, corner_radius=4)
            bar.pack(pady=8)
            self.register_element(bar)

    def build_settings(self):
        for _ in range(4):
            row = customtkinter.CTkFrame(self, fg_color="transparent")
            row.pack(fill="x", padx=30, pady=15)
            
            lbl_b = customtkinter.CTkFrame(row, width=140, height=14, fg_color=self.element_color, corner_radius=4)
            lbl_b.pack(side="left")
            self.register_element(lbl_b)
            
            val_b = customtkinter.CTkFrame(row, width=100, height=26, fg_color=self.element_color, corner_radius=4)
            val_b.pack(side="right")
            self.register_element(val_b)

    def build_status(self):
        for r in range(4):
            row = customtkinter.CTkFrame(self, fg_color="#F4EFEB" if r % 2 == 0 else "#FFFFFF", corner_radius=0)
            row.pack(fill="x", padx=15, pady=4)
            row.grid_columnconfigure((0, 1, 2, 3), weight=1)
            self.register_container(row)
            
            for c in range(4):
                bar = customtkinter.CTkFrame(row, height=12, fg_color=self.element_color, corner_radius=4)
                bar.grid(row=0, column=c, padx=15, pady=12, sticky="ew")
                self.register_element(bar)

    def build_help(self):
        for _ in range(3):
            row = customtkinter.CTkFrame(self, fg_color="#F4EFEB", border_width=2, border_color=self.border_color, corner_radius=0)
            row.pack(fill="x", padx=20, pady=10)
            self.register_container(row)
            
            title_line = customtkinter.CTkFrame(row, width=200, height=15, fg_color=self.element_color, corner_radius=4)
            title_line.pack(anchor="w", padx=15, pady=(15, 5))
            self.register_element(title_line)
            
            body_line = customtkinter.CTkFrame(row, width=400, height=10, fg_color=self.element_color, corner_radius=4)
            body_line.pack(anchor="w", padx=15, pady=(5, 15))
            self.register_element(body_line)

    def build_admin_db_settings(self):
        hdr = customtkinter.CTkFrame(self, fg_color="#FFFFFF", border_width=3, border_color=self.border_color, corner_radius=0)
        hdr.pack(fill="x", pady=(0, 15))
        self.register_container(hdr)
        
        title_p = customtkinter.CTkFrame(hdr, width=260, height=30, fg_color=self.element_color, corner_radius=6)
        title_p.pack(padx=20, pady=15, side="left")
        self.register_element(title_p)
        
        box1 = customtkinter.CTkFrame(self, fg_color="#FFFFFF", border_width=3, border_color=self.border_color, corner_radius=0)
        box1.pack(fill="x", pady=(0, 15))
        self.register_container(box1)
        
        bar_sub = customtkinter.CTkFrame(box1, width=150, height=16, fg_color=self.element_color, corner_radius=4)
        bar_sub.pack(padx=30, pady=(20, 10), anchor="w")
        self.register_element(bar_sub)
        
        for _ in range(2):
            inp = customtkinter.CTkFrame(box1, height=38, fg_color=self.element_color, corner_radius=0, border_width=2, border_color=self.border_color)
            inp.pack(padx=30, fill="x", pady=8)
            self.register_element(inp)

    def build_admin_announce(self):
        self.grid_columnconfigure(0, weight=1)
        self.grid_columnconfigure(1, weight=1)
        self.grid_rowconfigure(0, weight=1)
        
        for i in range(2):
            box = customtkinter.CTkFrame(self, fg_color="#FFFFFF", border_width=3, border_color=self.border_color, corner_radius=0)
            box.grid(row=0, column=i, sticky="nsew", padx=(0, 10) if i == 0 else (10, 0))
            self.register_container(box)
            
            sub = customtkinter.CTkFrame(box, width=180, height=16, fg_color=self.element_color, corner_radius=4)
            sub.pack(padx=20, pady=(15, 10), anchor="w")
            self.register_element(sub)
            
            txt_p = customtkinter.CTkFrame(box, fg_color=self.element_color, border_width=2, border_color=self.border_color, corner_radius=0, height=140)
            txt_p.pack(padx=20, fill="both", expand=True, pady=10)
            self.register_element(txt_p)

    def build_admin_accounts_list(self):
        for _ in range(3):
            card = customtkinter.CTkFrame(self, height=75, fg_color="#F4EFEB", border_width=2, border_color=self.border_color, corner_radius=0)
            card.pack(fill="x", pady=5, padx=5)
            self.register_container(card)
            
            p_bar = customtkinter.CTkFrame(card, width=120, height=14, fg_color=self.element_color, corner_radius=4)
            p_bar.pack(anchor="w", padx=15, pady=(8, 2))
            self.register_element(p_bar)

    def build_admin_accounts_form(self):
        title_r = customtkinter.CTkFrame(self, width=150, height=22, fg_color=self.element_color, corner_radius=4)
        title_r.pack(pady=20)
        self.register_element(title_r)
        
        for _ in range(3):
            inp = customtkinter.CTkFrame(self, height=35, fg_color=self.element_color, border_width=2, border_color=self.border_color, corner_radius=0)
            inp.pack(padx=20, fill="x", pady=8)
            self.register_element(inp)

    def build_admin_generic_split(self):
        self.grid_columnconfigure(0, weight=1)
        self.grid_columnconfigure(1, weight=1)
        self.grid_rowconfigure(0, weight=1)
        
        left = customtkinter.CTkFrame(self, fg_color="#FFFFFF", border_width=3, border_color=self.border_color, corner_radius=0)
        left.grid(row=0, column=0, sticky="nsew", padx=(0, 10))
        self.register_container(left)
        
        right = customtkinter.CTkFrame(self, fg_color="#FFFFFF", border_width=3, border_color=self.border_color, corner_radius=0)
        right.grid(row=0, column=1, sticky="nsew", padx=(10, 0))
        self.register_container(right)
        
        for b in [left, right]:
            bar = customtkinter.CTkFrame(b, width=180, height=18, fg_color=self.element_color, corner_radius=4)
            bar.pack(padx=20, pady=20, anchor="w")
            self.register_element(bar)

    def build_admin_generic_table(self):
        for r in range(4):
            row = customtkinter.CTkFrame(self, fg_color="#F4EFEB" if r % 2 == 0 else "#FFFFFF", corner_radius=0)
            row.pack(fill="x", padx=10, pady=4)
            row.grid_columnconfigure((0, 1, 2, 3), weight=1)
            self.register_container(row)
            
            for c in range(4):
                bar = customtkinter.CTkFrame(row, height=12, fg_color=self.element_color, corner_radius=4)
                bar.grid(row=0, column=c, padx=15, pady=12, sticky="ew")
                self.register_element(bar)

    def build_generic(self):
        for _ in range(4):
            bar = customtkinter.CTkFrame(self, width=350, height=16, fg_color=self.element_color, corner_radius=4)
            bar.pack(pady=15, padx=20, fill="x")
            self.register_element(bar)

    def start(self, duration_ms=250):
        self.after(duration_ms, self.destroy)

def show_skeleton(page_widget):
    # Dibuat instan muncul tanpa delay skeleton loader
    if page_widget and hasattr(page_widget, "winfo_exists") and page_widget.winfo_exists():
        class_name = page_widget.__class__.__name__
        if "Library" not in class_name:
            page_widget._first_load_done = True
    return

def hide_skeleton(page_widget):
    if not page_widget or not hasattr(page_widget, "winfo_exists") or not page_widget.winfo_exists():
        return
    page_widget._first_load_done = True
    if hasattr(page_widget, "_skeleton_overlays"):
        for overlay in page_widget._skeleton_overlays:
            try:
                if overlay.winfo_exists():
                    overlay.destroy()
            except Exception:
                pass
        page_widget._skeleton_overlays.clear()
