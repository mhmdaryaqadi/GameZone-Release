import math
import random
import time

def lerp(start, end, t):
    """Linear interpolation between start and end by t (0.0 to 1.0)"""
    return start + (end - start) * t

def ease_out_expo(t):
    return 1 if t == 1 else 1 - math.pow(2, -10 * t)

class ParticleSystem:
    def __init__(self, canvas, width, height, num_particles=50):
        self.canvas = canvas
        self.width = width
        self.height = height
        self.particles = []
        self.running = False
        
        for _ in range(num_particles):
            self._add_particle()

    def _add_particle(self):
        x = random.randint(0, self.width)
        y = random.randint(0, self.height)
        vx = random.uniform(-0.5, 0.5)
        vy = random.uniform(-0.5, 0.5)
        radius = random.uniform(1, 2.5)
        
        # Neon colors (Cyan, Purple, Blue)
        colors = ["#00f3ff", "#bc13fe", "#0900ff", "#ffffff"]
        color = random.choice(colors)
        
        item = self.canvas.create_oval(x-radius, y-radius, x+radius, y+radius, fill=color, outline="", stipple="gray50")
        
        self.particles.append({
            "item": item,
            "x": x, "y": y,
            "vx": vx, "vy": vy,
            "radius": radius
        })

    def start(self):
        self.running = True
        self._animate()

    def stop(self):
        self.running = False

    def resize(self, width, height):
        self.width = width
        self.height = height

    def _animate(self):
        if not self.running:
            return
            
        for p in self.particles:
            p["x"] += p["vx"]
            p["y"] += p["vy"]
            
            # Bounce off walls
            if p["x"] < 0 or p["x"] > self.width:
                p["vx"] *= -1
            if p["y"] < 0 or p["y"] > self.height:
                p["vy"] *= -1
                
            self.canvas.coords(p["item"], p["x"]-p["radius"], p["y"]-p["radius"], p["x"]+p["radius"], p["y"]+p["radius"])
            
        # Draw lines between close particles (Matrix effect)
        self.canvas.delete("connection")
        
        # Very lightweight connection logic (O(n^2) but with small n)
        for i in range(len(self.particles)):
            p1 = self.particles[i]
            for j in range(i+1, len(self.particles)):
                p2 = self.particles[j]
                dx = p1["x"] - p2["x"]
                dy = p1["y"] - p2["y"]
                dist_sq = dx*dx + dy*dy
                if dist_sq < 10000: # 100 pixels
                    opacity = 1.0 - (math.sqrt(dist_sq) / 100.0)
                    # We can't do true alpha in canvas lines easily, so we just use stipple or thin lines
                    # Alternatively, just draw a thin line
                    if opacity > 0.3:
                        self.canvas.create_line(p1["x"], p1["y"], p2["x"], p2["y"], fill="#1e3a8a", tags="connection", width=0.5)
                        
        self.canvas.tag_lower("connection") # Keep lines behind other stuff if any
        
        # 30 FPS is plenty for background and very lightweight
        self.canvas.after(33, self._animate)

class CosmicBackgroundSystem:
    def __init__(self, canvas, width, height, density=30):
        self.canvas = canvas
        self.width = width
        self.height = height
        self.running = False
        self.orbs = []
        self.mouse_x = width / 2
        self.mouse_y = height / 2
        
        # Buat gradient orbs
        for _ in range(density):
            x = random.randint(0, width)
            y = random.randint(0, height)
            radius = random.randint(20, 150)
            colors = ["#3b82f6", "#8b5cf6", "#ec4899", "#06b6d4"]
            color = random.choice(colors)
            item = self.canvas.create_oval(x-radius, y-radius, x+radius, y+radius, fill=color, outline="", stipple="gray25")
            
            self.orbs.append({
                "item": item,
                "x": x, "y": y,
                "base_x": x, "base_y": y,
                "radius": radius,
                "speed_x": random.uniform(-0.2, 0.2),
                "speed_y": random.uniform(-0.2, 0.2),
                "z_depth": random.uniform(0.1, 1.0) # Untuk parallax
            })

    def update_mouse(self, x, y):
        self.mouse_x = x
        self.mouse_y = y

    def start(self):
        self.running = True
        self._animate()

    def stop(self):
        self.running = False

    def resize(self, width, height):
        self.width = width
        self.height = height

    def _animate(self):
        if not self.running:
            return
            
        center_x, center_y = self.width / 2, self.height / 2
        mouse_dx = (self.mouse_x - center_x) * 0.05
        mouse_dy = (self.mouse_y - center_y) * 0.05
            
        for orb in self.orbs:
            orb["base_x"] += orb["speed_x"]
            orb["base_y"] += orb["speed_y"]
            
            if orb["base_x"] < -200: orb["base_x"] = self.width + 200
            if orb["base_x"] > self.width + 200: orb["base_x"] = -200
            if orb["base_y"] < -200: orb["base_y"] = self.height + 200
            if orb["base_y"] > self.height + 200: orb["base_y"] = -200
            
            target_x = orb["base_x"] - (mouse_dx * orb["z_depth"])
            target_y = orb["base_y"] - (mouse_dy * orb["z_depth"])
            
            self.canvas.coords(orb["item"], target_x-orb["radius"], target_y-orb["radius"], target_x+orb["radius"], target_y+orb["radius"])
            
        self.canvas.after(33, self._animate)

class TransitionManager:
    @staticmethod
    def slide_transition(parent, old_frame, new_frame, direction="left", duration_ms=400):
        if not new_frame: return
        
        parent.update_idletasks()
        w = parent.winfo_width()
        h = parent.winfo_height()
        if w <= 1: w = 800
        if h <= 1: h = 600
        
        start_time = time.time()
        
        if direction == "left":
            start_x_new = w
            end_x_old = -w
        elif direction == "right":
            start_x_new = -w
            end_x_old = w
        elif direction == "up":
            start_x_new, start_y_new = 0, h
            end_x_old, end_y_old = 0, -h
        else:
            start_x_new = w
            end_x_old = -w
            
        new_frame.place(x=start_x_new if direction in ["left", "right"] else 0, 
                        y=h if direction == "up" else 0, 
                        relwidth=1, relheight=1)
        new_frame.tkraise()
        
        def step():
            elapsed = (time.time() - start_time) * 1000
            t = min(elapsed / duration_ms, 1.0)
            eased_t = ease_out_expo(t)
            
            if direction in ["left", "right"]:
                curr_x_new = lerp(start_x_new, 0, eased_t)
                new_frame.place(x=curr_x_new, y=0, relwidth=1, relheight=1)
                if old_frame:
                    curr_x_old = lerp(0, end_x_old, eased_t)
                    old_frame.place(x=curr_x_old, y=0, relwidth=1, relheight=1)
            else: # up
                curr_y_new = lerp(h, 0, eased_t)
                new_frame.place(x=0, y=curr_y_new, relwidth=1, relheight=1)
                if old_frame:
                    curr_y_old = lerp(0, -h, eased_t)
                    old_frame.place(x=0, y=curr_y_old, relwidth=1, relheight=1)
            
            if t < 1.0:
                parent.after(16, step)
            else:
                if old_frame:
                    old_frame.place_forget()
        step()

    @staticmethod
    def emerge_transition(parent, old_frame, new_frame, duration_ms=400):
        if not new_frame: return
        parent.update_idletasks()
        
        start_time = time.time()
        start_y = 60
        
        new_frame.place(x=0, y=start_y, relwidth=1, relheight=1)
        new_frame.tkraise()
        
        def step():
            elapsed = (time.time() - start_time) * 1000
            t = min(elapsed / duration_ms, 1.0)
            eased_t = ease_out_expo(t)
            
            curr_y = lerp(start_y, 0, eased_t)
            new_frame.place(x=0, y=curr_y, relwidth=1, relheight=1)
            
            if t < 1.0:
                parent.after(16, step)
            else:
                if old_frame:
                    old_frame.place_forget()
        step()
