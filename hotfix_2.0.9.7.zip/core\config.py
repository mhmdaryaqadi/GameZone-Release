import json
import os

appdata = os.getenv('LOCALAPPDATA', '')
config_dir = os.path.join(appdata, 'GameZone')
if not os.path.exists(config_dir):
    try: os.makedirs(config_dir)
    except: pass

CONFIG_FILE = os.path.join(config_dir, "config.json")

def load_config():
    default_mh = "7a2ba72f93149b69106514a0e9f5eaae916f7697cdb73ec40232f0b886d11ba64799c6d591c3"
    default_morr = "smm_1a84c0ba5aca0ca0f245c2e1df4deab7540ae3e2b9c5d01e931dd9e7c39c7fffa7f7f6735d3baac0a6ff393ab0abfe6d"
    default_fb = "https://gamezone-31073-default-rtdb.asia-southeast1.firebasedatabase.app"
    if not os.path.exists(CONFIG_FILE):
        return {"lang": "id", "manifesthub_key": default_mh, "morrenus_key": default_morr, "firebase_url": default_fb}
    try:
        with open(CONFIG_FILE, "r") as f:
            data = json.load(f)
            if "manifesthub_key" not in data:
                data["manifesthub_key"] = default_mh
            if "morrenus_key" not in data:
                data["morrenus_key"] = default_morr
            if "firebase_url" not in data:
                data["firebase_url"] = default_fb
            return data
    except Exception:
        return {"lang": "id", "manifesthub_key": default_mh, "morrenus_key": default_morr, "firebase_url": default_fb}

def save_config(conf):
    try:
        with open(CONFIG_FILE, "w") as f:
            json.dump(conf, f)
    except Exception:
        pass
