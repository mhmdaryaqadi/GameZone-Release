import requests
import re
import datetime
from core.config import load_config

# Persistent session to reuse TCP/SSL connections for faster and lower-overhead real-time operations
session = requests.Session()

def get_db_url():
    config = load_config()
    url = config.get("firebase_url", "https://gamezone-5d5fef-default-rtdb.firebaseio.com").strip()
    if url.endswith("/"):
        url = url[:-1]
    return url

def sanitize_key(key_str):
    # Firebase keys cannot contain ., $, #, [, ], /, or ASCII control characters
    return re.sub(r'[\.\$#\[\]/]', '_', key_str)

def report_user_presence(dc_username, local_nickname, avatar_url=None):
    if not dc_username:
        return False
    try:
        db_base = get_db_url()
        clean_user = sanitize_key(dc_username)
        url = f"{db_base}/users/{clean_user}.json"
        
        payload = {
            "discord_username": dc_username,
            "nickname": local_nickname,
            "last_active": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "status": "online"
        }
        if avatar_url:
            payload["avatar_url"] = avatar_url
        
        res = session.patch(url, json=payload, timeout=10)
        return res.status_code == 200
    except Exception:
        return False

def fetch_users_status():
    """Ambil data semua user dari /users.json untuk halaman Status"""
    try:
        db_base = get_db_url()
        url = f"{db_base}/users.json"
        res = session.get(url, timeout=10)
        if res.status_code == 200:
            data = res.json()
            if data:
                return data
        return {}
    except Exception:
        return {}

def toggle_chat_reaction(msg_id, emoji, username):
    """Toggle reaksi emoji di pesan chat (add/remove)"""
    if not msg_id or not emoji or not username:
        return None
    try:
        db_base = get_db_url()
        clean_user = sanitize_key(username)
        url = f"{db_base}/chat/{msg_id}/reactions/{emoji}/{clean_user}.json"
        
        # Check if already reacted
        res = session.get(url, timeout=10)
        if res.status_code == 200 and res.text != 'null' and res.json() == True:
            # Remove reaction
            session.delete(url, timeout=10)
            return False  # Removed
        else:
            # Add reaction
            session.put(url, json=True, timeout=10)
            return True  # Added
    except Exception:
        return None

def fetch_shared_accounts():
    try:
        db_base = get_db_url()
        url = f"{db_base}/accounts.json"
        res = session.get(url, timeout=10)
        if res.status_code == 200:
            data = res.json()
            if data:
                return data
        return None
    except Exception:
        return None

def fetch_announcements():
    try:
        db_base = get_db_url()
        url = f"{db_base}/announcements.json"
        res = session.get(url, timeout=10)
        if res.status_code == 200:
            data = res.json()
            if data:
                return data
        return None
    except Exception:
        return None

def fetch_api_keys():
    try:
        db_base = get_db_url()
        url = f"{db_base}/keys.json"
        res = session.get(url, timeout=10)
        if res.status_code == 200:
            data = res.json()
            if data:
                return data
        return {}
    except Exception:
        return {}

def fetch_button_texts():
    try:
        db_base = get_db_url()
        url = f"{db_base}/buttons.json"
        res = session.get(url, timeout=10)
        if res.status_code == 200:
            data = res.json()
            if data:
                return data
        return {}
    except Exception:
        return {}

def fetch_requests():
    try:
        db_base = get_db_url()
        url = f"{db_base}/requests.json"
        res = session.get(url, timeout=10)
        if res.status_code == 200:
            return res.json()
        return None
    except Exception:
        return None

def submit_request(username, nickname, game_name, appid):
    try:
        db_base = get_db_url()
        url = f"{db_base}/requests.json"
        payload = {
            "username": username,
            "nickname": nickname,
            "game_name": game_name,
            "appid": appid,
            "status": "Pending",
            "created_at": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        }
        res = session.post(url, json=payload, timeout=10)
        return res.status_code == 200
    except Exception:
        return False

def update_request_status(req_id, status):
    try:
        db_base = get_db_url()
        url = f"{db_base}/requests/{req_id}.json"
        res = session.patch(url, json={"status": status}, timeout=10)
        return res.status_code == 200
    except Exception:
        return False

def delete_request(req_id):
    try:
        db_base = get_db_url()
        url = f"{db_base}/requests/{req_id}.json"
        res = session.delete(url, timeout=10)
        return res.status_code == 200
    except Exception:
        return False

def fetch_chat_messages():
    try:
        db_base = get_db_url()
        url = f"{db_base}/chat.json"
        res = session.get(url, timeout=10)
        if res.status_code == 200:
            data = res.json()
            if data:
                return data
        return None
    except Exception:
        return None

def send_chat_message(username, nickname, message, avatar_url=None, reply_to=None, reply_to_user=None, reply_to_text=None):
    try:
        db_base = get_db_url()
        url = f"{db_base}/chat.json"
        payload = {
            "username": username,
            "nickname": nickname,
            "message": message,
            "avatar_url": avatar_url,
            "timestamp": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        }
        if reply_to:
            payload["reply_to"] = reply_to
            payload["reply_to_user"] = reply_to_user
            payload["reply_to_text"] = reply_to_text
        res = session.post(url, json=payload, timeout=10)
        return res.status_code == 200
    except Exception:
        return False

def fetch_announcement_comments(ann_id):
    try:
        db_base = get_db_url()
        url = f"{db_base}/announcements/{ann_id}/comments.json"
        res = session.get(url, timeout=10)
        if res.status_code == 200:
            return res.json()
        return None
    except Exception:
        return None

def submit_announcement_comment(ann_id, username, nickname, comment, avatar_url=None):
    try:
        db_base = get_db_url()
        url = f"{db_base}/announcements/{ann_id}/comments.json"
        payload = {
            "username": username,
            "nickname": nickname,
            "comment": comment,
            "avatar_url": avatar_url,
            "timestamp": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        }
        res = session.post(url, json=payload, timeout=10)
        return res.status_code == 200
    except Exception:
        return False

def delete_chat_message(msg_id):
    try:
        db_base = get_db_url()
        url = f"{db_base}/chat/{msg_id}.json"
        res = session.delete(url, timeout=10)
        return res.status_code == 200
    except Exception:
        return False

def add_announcement_reaction(ann_id, emoji):
    try:
        db_base = get_db_url()
        url = f"{db_base}/announcements/{ann_id}/reactions/{emoji}.json"
        res = session.get(url, timeout=10)
        count = 0
        if res.status_code == 200 and res.text != 'null':
            try:
                count = int(res.json())
            except:
                pass
        count += 1
        session.put(url, json=count, timeout=10)
        return count
    except Exception:
        return False

def submit_bug_report(username, message):
    try:
        db_base = get_db_url()
        url = f"{db_base}/reports.json"
        payload = {
            "username": username,
            "message": message,
            "timestamp": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        }
        res = session.post(url, json=payload, timeout=10)
        return res.status_code == 200
    except Exception:
        return False

def fetch_bug_reports():
    try:
        db_base = get_db_url()
        url = f"{db_base}/reports.json"
        res = session.get(url, timeout=10)
        if res.status_code == 200:
            return res.json()
        return None
    except Exception:
        return None

def delete_bug_report(report_id):
    try:
        db_base = get_db_url()
        url = f"{db_base}/reports/{report_id}.json"
        res = session.delete(url, timeout=10)
        return res.status_code == 200
    except Exception:
        return False

def ambil_daftar_server():
    try:
        db_base = get_db_url()
        url = f"{db_base}/inject_servers.json"
        res = session.get(url, timeout=10)
        if res.status_code == 200:
            data = res.json()
            if data:
                # Firebase might return list or dict. Let's make sure it's a list.
                if isinstance(data, list):
                    return [s for s in data if s is not None]
                elif isinstance(data, dict):
                    return list(data.values())
        return []
    except Exception:
        return []

def simpan_daftar_server(list_server):
    try:
        db_base = get_db_url()
        url = f"{db_base}/inject_servers.json"
        res = session.put(url, json=list_server, timeout=10)
        return res.status_code == 200
    except Exception:
        return False

def ambil_daftar_netfix_server():
    try:
        db_base = get_db_url()
        url = f"{db_base}/netfix_servers.json"
        res = session.get(url, timeout=10)
        if res.status_code == 200:
            data = res.json()
            if data:
                if isinstance(data, list):
                    return [s for s in data if s is not None]
                elif isinstance(data, dict):
                    return list(data.values())
        return []
    except Exception:
        return []

def simpan_daftar_netfix_server(list_server):
    try:
        db_base = get_db_url()
        url = f"{db_base}/netfix_servers.json"
        res = session.put(url, json=list_server, timeout=10)
        return res.status_code == 200
    except Exception:
        return False

def toggle_announcement_reaction(ann_id, emoji_key, username):
    """
    Toggles user reaction (fire, like, rocket) for a specific announcement ID in Firebase.
    """
    if not ann_id or not emoji_key or not username:
        return False
    try:
        db_base = get_db_url()
        clean_user = sanitize_key(username)
        url = f"{db_base}/announcements/{ann_id}/reactions/{emoji_key}.json"
        res = session.get(url, timeout=5)
        
        users_list = []
        if res.status_code == 200 and res.json():
            val = res.json()
            if isinstance(val, list):
                users_list = [u for u in val if u]
                
        if clean_user in users_list:
            users_list.remove(clean_user)
        else:
            users_list.append(clean_user)
            
        session.put(url, json=users_list, timeout=5)
        return True
    except Exception:
        return False

